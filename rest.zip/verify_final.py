# -*- coding: utf-8 -*-
"""
🔬 최종 자체 검증 (Final Self Verification)
==========================================
핵심 수정 경로 E2E 시뮬레이션 (키/네트워크 없이도 동작):
  1) 종목별 일봉 저장 (data/stocks/*.db - 백필과 동일 경로)
  2) ★ backfill_coverage → 전 종목 스캔 입력 (빈 목록 버그 재발 방지)
  3) ★ get_latest_backfill_bars → 스캔 후보 최신 봉
  4) get_stock_daily / get_daily_series (차트·전략 공용) / get_latest_price (가격 폴백)
  5) 조건식 등록(명예의 전당) → top_conditions
  6) ★ 전 종목 스캔 _signals_all_conditions (빈 목록이면 여기서 즉시 ❌)
  7) ★ 모의실전 run_paper_once(scan_all) → "[모의실전] 진입" 로그
  8) 모의실전 DB·성과 (paper_positions / paper_summary / 함수형 통계)
  9) AI 매수/매도 판단 (키 없음 → rule 폴백)
 10) 일일 복기 리포트 + 매수타점 차트 (PNG)
 11) 네이버 실제 일봉 수집 1종목
"""
import logging
import os
import random
import shutil
import sys
from datetime import date, timedelta

logging.basicConfig(level=logging.WARNING, format="%(levelname)s:%(name)s: %(message)s")
import db
from config import CFG

db.init_db()   # 자기완결: DB 없어도 테이블부터 생성
# ★ 지수 위험 스위치·국면 점수제는 별도 시나리오로 검증하므로, E2E 진입 경로 검증은 비활성
#   (실시간 지수가 -1% 아래면 warning으로 진입이 정상 중단되는데, 이는 별도 검증 대상)
from config import CFG as _CFG
_CFG.INDEX_ENABLED = False
_CFG.INDEX_COND_ENABLED = False
_CFG.LEADER_ENABLED = False   # ★ 대장주 공략은 실시간 네트워크 필요 - E2E에선 비활성(별도 검증)
# ★ 장외(15:30 이후)에도 진입 경로를 검증하도록, 검증 동안만 실제주문 스위치를 끔
#   (주문 자체는 DRY_RUN=true라 어차피 생략 - 진입/청산 로직 검증이 목적)
import paper_test as _pt
# 원본 REAL_PAPER_ORDER 값 소스에서 읽어 보존 (검증 중에는 잠시 끔)
import re as _re
_ORIG_REAL_PAPER_ORDER = (_re.search(
    r"REAL_PAPER_ORDER\s*=\s*(True|False)",
    open("paper_test.py", encoding="utf-8").read()).group(1) == "True")
_pt.REAL_PAPER_ORDER = False

PASS = 0
FAIL = 0


def check(name, cond, detail=""):
    global PASS, FAIL
    mark = "✅" if cond else "❌"
    print(f"  {mark} {name}" + (f"  ({detail})" if detail else ""))
    if cond:
        PASS += 1
    else:
        FAIL += 1


print("=" * 58)
print("🔬 최종 자체 검증 - 핵심 수정 경로 E2E")
print("=" * 58)

# ── 0) 설정/핵심 속성 (수정 버그 회귀 확인) ──
print("\n[0] 설정/핵심 속성")
check("STOCK_DIR_SAVE=true (종목별 저장)", CFG.STOCK_DIR_SAVE)
check("AI_BUY_CONFIDENCE 존재", hasattr(CFG, "AI_BUY_CONFIDENCE"))
check("AI_BUY_CONFIDENCE_THRESHOLD=70", getattr(CFG, "AI_BUY_CONFIDENCE_THRESHOLD", 0) == 70)
# ★ DRY_RUN은 사용자 설정 반영 (true=안전 기본 / false=실제 모의주문 - 의도된 경우 정상)
if CFG.DRY_RUN:
    check("DRY_RUN=true (안전 기본 - 주문 생략)", True)
else:
    print("  ⚠️ DRY_RUN=false — 실제 모의주문이 나가는 설정입니다 (의도된 경우 정상)")
    check("DRY_RUN=false (사용자 설정 - 실제 모의주문)", True)
import paper_test as _pt
check("REAL_PAPER_ORDER=true (실제 모의주문 경로)", _ORIG_REAL_PAPER_ORDER)

# ── 테스트 데이터 정리 (재실행 안전 - 멱등) ──
sdir = os.path.join(db.DATA_DIR, "stocks")
if os.path.isdir(sdir):
    shutil.rmtree(sdir)
    print("\n[준비] 이전 종목별 테스트 파일 정리 완료")
with db.get_conn() as conn:   # ★ 이전 실행 잔여물 제거 (연속 실행 시 재진입 스킵 방지)
    for _t in ("paper_positions", "hall_of_fame", "validation_results", "screener_results"):
        try:
            conn.execute(f"DELETE FROM {_t}")
        except Exception:
            pass
print("[준비] 이전 모의실전 테스트 데이터 정리 완료")

# ── 1) 종목별 일봉 저장 (백필과 동일 경로) ──
#    4종목 = 강한 상승추세 + 마지막 12일 거래량 급증 (사진 조건식이 발화하도록)
#    4종목 = 횡보 (조건 미충족 확인용)
print("\n[1] 종목별 일봉 저장 (data/stocks/*.db)")
syms = ["005930", "000660", "035420", "042700", "086520", "247540", "010130", "034220"]
trend = {"005930": True, "000660": True, "035420": True, "042700": True,
         "086520": False, "247540": False, "010130": False, "034220": False}
days = []
d = date.today() - timedelta(days=1)
while len(days) < 70:            # ★ 70봉 (50봉 필요 조건식 포함)
    if d.weekday() < 5:
        days.append(d)
    d -= timedelta(days=1)
days.reverse()
random.seed(99)
stored = 0
for sym in syms:
    p = 15000 + random.randint(0, 100) * 100   # ★ 최종 종가 < MOCK_PRICE_MAX(10만) 보장
    for bd in days:
        if trend[sym]:
            p *= 1.012            # 매일 +1.2% 상승 (70봉 후에도 10만 미만)
        else:
            p *= (1 + random.uniform(-0.02, 0.02))
        o, h, l, c = p * 0.997, p * 1.008, p * 0.992, p
        v = 3000000 if (trend[sym] and bd >= days[-12]) else 500000
        if db.record_stock_daily(sym, bd.isoformat(), round(o), round(h), round(l),
                                 round(c), v, round(v * c), source="backfill"):
            stored += 1
check("종목별 일봉 저장 8종목×70봉", stored == 8 * 70, f"{stored}/{8 * 70}")

# ── 2) ★ backfill_coverage (전 종목 스캔 입력 - 빈 목록 버그 재확인) ──
print("\n[2] ★ backfill_coverage (전 종목 스캔 입력)")
cov = db.backfill_coverage(min_days=30)
ready = cov["ready"]
check("30봉 이상 종목 인식", ready >= 8, f"ready={ready} total={cov['total']}")

# ── 3) get_latest_backfill_bars ──
print("\n[3] get_latest_backfill_bars (스캔 후보 최신 봉)")
latest = db.get_latest_backfill_bars()
check("8종목 전부 최신 봉 반환", all(s in latest for s in syms), f"{len(latest)}종목")
if "005930" in latest:
    check("005930 최신 봉 값 정상",
          latest["005930"]["close"] > 0 and latest["005930"]["amount"] > 0,
          f"close={latest['005930']['close']}")

# ── 4) 일봉/가격 조회 (차트·전략·진입 공용) ──
print("\n[4] 일봉·가격 조회")
s = db.get_stock_daily("005930", max_days=80)
check("get_stock_daily 70봉 오래된순", len(s) == 70 and s[0]["date"] < s[-1]["date"], f"{len(s)}봉")
from strategy_auto import get_daily_series
ds = get_daily_series("005930", max_days=80)
check("get_daily_series 종목별 우선", len(ds) >= 30, f"{len(ds)}봉")
pr = db.get_latest_price("005930")
check("get_latest_price 종목별 폴백", bool(pr), f"{pr}")

# ── 5) 조건식 등록 + top_conditions ──
print("\n[5] 조건식 (명예의 전당 → 모의실전 입력)")
import photo_conditions
tpl = photo_conditions.PHOTO_TEMPLATES[0]
slots = photo_conditions.template_slots(tpl)
txt = f"[사진{tpl['photo']}] {tpl['name']}"
db.hof_upsert("TEST-P1", txt, slots, win_rate=65.0, pf=1.5,
              oos_win=60.0, oos_avg=1.0, passed=True)
# ★ 랭킹 진입용 매매 기록 (매도 5건 승률 60% → score>0 → 상위 랭킹 진입)
with db.get_conn() as conn:
    cnt = conn.execute("SELECT COUNT(*) FROM paper_positions WHERE cond_key='TEST-P1'").fetchone()[0]
    if cnt < 5:
        for j in range(5):
            won = j < 3
            conn.execute(
                "INSERT INTO paper_positions (cond_key,cond_txt,symbol,entry_price,entry_time,"
                "qty,status,exit_price,exit_time,ret_pct) VALUES (?,?,?,?,?,?,?,?,?,?)",
                ("TEST-P1", txt, f"T{j:04d}", 30000 + j * 100,
                 "2026-08-01T09:00:00+09:00", 10, "closed",
                 31500 if won else 28500, "2026-08-08T15:00:00+09:00", 5.0 if won else -5.0))
if cnt < 5:
    db.hof_rank(limit=50)   # ★ 커밋(블록 종료) 후 랭킹 반영
from paper_test import top_conditions
conds = top_conditions(n=3)
check("top_conditions 조건식 반환", len(conds) >= 1, f"{len(conds)}개")
if conds:
    print(f"     → {conds[0]['cond_txt'][:60]}")

# ── 6) ★ 전 종목 스캔 (빈 목록 버그의 최종 검증 지점) ──
print("\n[6] ★ 전 종목 스캔 (_signals_all_conditions)")
from paper_test import _signals_all_conditions
sig = _signals_all_conditions(conds)
total_hits = sum(len(v) for v in sig.values())
check("스캔 결과 비어있지 않음", total_hits > 0, f"조건 {len(sig)}개 / 신호 {total_hits}건")
for k, v in list(sig.items())[:3]:
    print(f"     {k}: {v[:5]}")

# ── 7) ★ 모의실전 1사이클 (실제 주문 경로 - DRY_RUN=true라 로그만) ──
print("\n[7] ★ 모의실전 1사이클 (run_paper_once, scan_all)")
# ★ 결정적 가격 주입: 각 종목 최신 종가를 live 스냅샷으로 저장
#   (get_quote_cached가 랜덤 모의가격 대신 이 종가를 쓰도록 - 가격필터 안정화)
for sym in syms:
    pr = db.get_latest_price(sym)
    if pr:
        db.record_snapshot(sym, pr, volume=1000000, source="live")
logs = []
from paper_test import run_paper_once
r = run_paper_once(conditions=conds, max_new=12, log_out=logs.append, scan_all=True)
entered = r.get("entered") or []
check("진입 로그 발생", len(entered) > 0, f"{len(entered)}건")
for e in entered[:5]:
    print(f"     진입 {e['symbol']} {e['qty']}주 @{e['price']:,.0f} | {e['cond'][:40]}")
n_log = len([l for l in logs if "[모의실전] 진입" in l])
check("진입 DB 저장 = 로그 수 일치", len(entered) == n_log, f"DB {len(entered)}건 / 로그 {n_log}건")

# ── 8) 모의실전 DB·성과 ──
print("\n[8] 모의실전 DB·성과")
from paper_test import paper_summary, paper_status
sm = paper_summary()
check("paper_summary 정상", sm["open"] > 0, f"open={sm['open']}")
st = paper_status()
check("paper_status 오픈 포지션 조회", len(st["open"]) > 0, f"{len(st['open'])}개")
with db.get_conn() as conn:
    tabs = {r["name"] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
need_tab = {"conditions", "paper_positions", "hall_of_fame"}
check("핵심 테이블 존재", need_tab <= tabs, f"{len(need_tab & tabs)}/{len(need_tab)}")
try:
    dcs = db.data_collection_stats()
    check("data_collection_stats() 동작", dcs.get("stock_files", 0) >= 8,
          f"stock_files={dcs.get('stock_files')} daily_bars={dcs.get('daily_bars')}")
except Exception as e:
    check("data_collection_stats() 동작", False, str(e)[:60])
try:
    psc = db.paper_stats_per_condition()
    check("paper_stats_per_condition() 동작", isinstance(psc, dict))
except Exception as e:
    check("paper_stats_per_condition() 동작", False, str(e)[:60])

# ── 9) AI 판단 (키 없음 → rule 폴백) ──
print("\n[9] AI 매수/매도 판단 (rule 폴백)")
from ai_judge import (evaluate_buy_rule_based, evaluate_sell_rule_based, enrich_market_data)
md = {"price": 50000, "전일고가": 49000, "전일저가": 48000, "전일종가": 49500,
      "체결강도": 150, "최근1분거래대금": 1_000_000_000, "최근3분거래대금": 2_000_000_000,
      "저가": 49500, "고점갱신": True, "거래대금동시증가": True, "중심선아래약세": False}
enr = enrich_market_data(md)
is_buy, reason, score = evaluate_buy_rule_based(enr)
check("매수 판단 정상", isinstance(is_buy, bool), f"score={score}")
dec, r2 = evaluate_sell_rule_based(enr, {"entry_price": 49000, "highest_return": 3.0})
check("매도 판단 정상", dec in ("보유", "수익청산", "손절"), f"{dec}")

# ── 10) 일일 복기 리포트 + 차트 ──
print("\n[10] 일일 복기 리포트 + 매수타점 차트")
import daily_report
rep = daily_report.generate_daily_report()
if rep:
    check("리포트 생성", os.path.exists(rep["path"]), rep["path"])
    charts = rep.get("charts") or []
    check("타점 차트 PNG 생성", len(charts) > 0, f"{len(charts)}장")
    for c in charts[:3]:
        print(f"     {c}")
else:
    check("리포트 생성", False, "데이터 없음")

# ── 11) 네이버 실제 일봉 수집 1종목 (네트워크 있는 샌드박스에서) ──
print("\n[11] 네이버 실제 일봉 수집 (005930)")
try:
    from backfill_history import fetch_daily
    bars = fetch_daily("005930", days=30)
    check("네이버 일봉 fetch", len(bars) >= 20, f"{len(bars)}봉")
except Exception as e:
    check("네이버 일봉 fetch", False, str(e)[:80])

print("\n" + "=" * 58)
if FAIL == 0:
    print(f"🎉 최종 자체 검증 통과 - {PASS}개 항목 전부 정상")
else:
    print(f"⚠️ 검증 실패 {FAIL}개 / 통과 {PASS}개")
print("=" * 58)
sys.exit(1 if FAIL else 0)
