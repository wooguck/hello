# -*- coding: utf-8 -*-
"""
🔬 강건성 검사 (robust_check.py) - Walk-Forward + Monte Carlo
==============================================================
외부 퀀트 플랫폼 기준 감사에서 빠져있던 2개 핵심 검증을 구현.

[1] Walk-Forward Analysis (롤링 시간 분리)
    기존 param_optimizer는 70/30 1회 분리 → 이것은 창을 밀며 반복:
      학습 구간1 → 검증 구간2 / 학습 구간2 → 검증 구간3 / ...
    모든 검증 구간에서 플러스여야 "시기 무관 전략"으로 인정.

[2] Monte Carlo (거래 순서 재배열)
    백테스트 거래들의 순서를 1,000회 무작위 재배열 →
    MDD 분포 / 5% 최악 시나리오 / 파산(자본 -X%) 확률 추정.
    "운 좋은 순서" 덕에 MDD가 작아 보였는지 확인.

실행:
  python robust_check.py --cond 2            # 조건식 2번 (param_optimizer와 같은 번호)
  python robust_check.py --cond 2 --windows 4
결과: 콘솔 + strategy/robust_{cond}.json (재현성 메타데이터 포함)
"""
import argparse
import json
import os
import random
import sys
import time

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db
import validation as V

ENGINE_VERSION = "robust-1.0"


def list_conds():
    from param_optimizer import list_conds as _lc
    return _lc()


def walk_forward(slots, windows=4, max_symbols=300, tp=None, sl=None, trail=None, hold=None):
    """롤링 학습/검증. 반환: 구간별 결과 + 통과 여부"""
    tp = tp if tp is not None else V.TP_PCT
    sl = sl if sl is not None else V.SL_PCT
    trail = trail if trail is not None else V.TRAIL_PCT
    hold = hold if hold is not None else V.MAX_HOLD
    try:
        cov = db.backfill_coverage(min_days=120)
        symbols = sorted(s for s, n in cov["symbols"].items() if n >= 120)[:max_symbols]
    except Exception:
        symbols = []
    if not symbols:
        return {"error": "데이터 부족"}
    # 전체 날짜 범위 → windows+1 등분 → (i 학습, i+1 검증) 롤링
    b0 = V._load_bars(symbols[0], max_days=1000)
    all_dates = sorted({b["date"] for s in symbols[:30] for b in V._load_bars(s, max_days=1000)})
    if len(all_dates) < 120:
        return {"error": "날짜 범위 부족"}
    seg = len(all_dates) // (windows + 1)
    results = []
    for w in range(windows):
        tr_s, tr_e = all_dates[w * seg], all_dates[(w + 1) * seg - 1]
        te_s = all_dates[(w + 1) * seg]
        te_e = all_dates[min((w + 2) * seg - 1, len(all_dates) - 1)]
        r_tr = V.run_backtest_detail(symbols, slots, start=tr_s, end=tr_e,
                                     tp=tp, sl=sl, trail=trail, max_hold=hold,
                                     max_symbols=max_symbols)
        r_te = V.run_backtest_detail(symbols, slots, start=te_s, end=te_e,
                                     tp=tp, sl=sl, trail=trail, max_hold=hold,
                                     max_symbols=max_symbols)
        def _st(res):
            t = res["trades"]
            if not t:
                return {"n": 0, "avg": 0, "win": 0}
            w_ = [x for x in t if x["ret_pct"] > 0]
            return {"n": len(t), "avg": round(sum(x["ret_pct"] for x in t) / len(t), 2),
                    "win": round(len(w_) / len(t) * 100, 1)}
        results.append({"window": w + 1,
                        "train": {"range": f"{tr_s}~{tr_e}", **_st(r_tr)},
                        "test": {"range": f"{te_s}~{te_e}", **_st(r_te)}})
    tests = [r["test"] for r in results if r["test"]["n"] >= 5]
    pos = sum(1 for t in tests if t["avg"] > 0)
    verdict = ("✅ 통과" if tests and pos == len(tests) else
               "🟡 부분" if tests and pos >= len(tests) * 0.6 else
               "🔴 실패" if tests else "표본부족")
    return {"windows": results, "test_positive": f"{pos}/{len(tests)}", "verdict": verdict}


def monte_carlo(trades, runs=1000, capital=10_000_000, position_frac=0.2, seed=42):
    """거래 순서 재배열 → MDD 분포 / 최악 시나리오
    position_frac: 거래당 자본 비중 (기본 20% - 5슬롯 가정)
    """
    rets = [t["ret_pct"] / 100 for t in trades]
    if len(rets) < 20:
        return {"error": f"거래 {len(rets)}건 - 20건 미만은 무의미"}
    rng = random.Random(seed)
    mdds, finals = [], []
    ruin = 0
    for _ in range(runs):
        seq = rets[:]
        rng.shuffle(seq)
        eq = 1.0
        peak = 1.0
        mdd = 0.0
        for r in seq:
            eq *= (1 + r * position_frac)
            peak = max(peak, eq)
            mdd = max(mdd, (peak - eq) / peak)
        mdds.append(mdd * 100)
        finals.append((eq - 1) * 100)
        if eq < 0.7:            # 자본 -30% = 사실상 파산 기준
            ruin += 1
    mdds.sort()
    finals.sort()
    def pct(arr, p):
        return round(arr[min(len(arr) - 1, int(len(arr) * p))], 1)
    return {"runs": runs, "trades": len(rets),
            "mdd_median": pct(mdds, 0.5), "mdd_p95": pct(mdds, 0.95),
            "final_median": pct(finals, 0.5), "final_p5_worst": pct(finals, 0.05),
            "ruin_pct": round(ruin / runs * 100, 1),
            "note": "MDD_p95 = 100번 중 95번은 이 낙폭 이내 · ruin = 자본-30% 확률"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cond", type=int, default=0)
    ap.add_argument("--windows", type=int, default=4)
    ap.add_argument("--runs", type=int, default=1000)
    ap.add_argument("--max-symbols", type=int, default=300)
    args = ap.parse_args()
    conds = list_conds()
    if not args.cond:
        print("조건식: (--cond 번호)")
        for i, c in enumerate(conds):
            print(f"  {i+1}. [{c['id']}] {c['txt'][:60]}")
        return
    c = conds[min(args.cond - 1, len(conds) - 1)]
    slots = [tuple(s) for s in c["slots"]]

    print("=" * 70)
    print(f"🔬 강건성 검사 | {c['txt'][:60]}")
    print("=" * 70)

    print(f"\n[1] Walk-Forward ({args.windows}구간 롤링)...")
    wf = walk_forward(slots, windows=args.windows, max_symbols=args.max_symbols)
    if wf.get("error"):
        print("   ⛔", wf["error"])
    else:
        for w in wf["windows"]:
            tr, te = w["train"], w["test"]
            mark = "✅" if te["avg"] > 0 else ("🔴" if te["n"] >= 5 else "⚪")
            print(f"   구간{w['window']}: 학습 {tr['range']} ({tr['n']}건 {tr['avg']:+}%) → "
                  f"검증 {te['range']} ({te['n']}건 {te['avg']:+}% 승률{te['win']}%) {mark}")
        print(f"   → 검증구간 플러스 {wf['test_positive']} · 판정: {wf['verdict']}")

    print(f"\n[2] Monte Carlo ({args.runs}회 순서 재배열)...")
    full = V.run_backtest_detail(
        sorted(s for s, n in db.backfill_coverage(min_days=120)["symbols"].items() if n >= 120)[:args.max_symbols],
        slots, max_symbols=args.max_symbols)
    mc = monte_carlo(full["trades"], runs=args.runs)
    if mc.get("error"):
        print("   ⛔", mc["error"])
    else:
        print(f"   거래 {mc['trades']}건 기준:")
        print(f"   MDD 중앙값 {mc['mdd_median']}% · 95퍼센타일(불운) {mc['mdd_p95']}%")
        print(f"   최종수익 중앙값 {mc['final_median']}% · 최악5% {mc['final_p5_worst']}%")
        print(f"   파산(자본-30%) 확률: {mc['ruin_pct']}%")
        print(f"   ({mc['note']})")

    # 재현성 메타데이터와 함께 저장 (감사 지적사항 반영)
    os.makedirs("strategy", exist_ok=True)
    meta = {"cond_id": c["id"], "cond_txt": c["txt"], "slots": c["slots"],
            "engine_version": ENGINE_VERSION, "random_seed": 42,
            "tp": V.TP_PCT, "sl": V.SL_PCT, "trail": V.TRAIL_PCT, "hold": V.MAX_HOLD,
            "fee": V.FEE_PCT, "max_symbols": args.max_symbols,
            "checked_at": db.now_kst_iso(),
            "walk_forward": wf, "monte_carlo": mc}
    path = os.path.join("strategy", f"robust_{args.cond}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=1)
    print(f"\n📄 저장: {path} (재현 파라미터 포함 - 같은 조건이면 같은 결과)")


if __name__ == "__main__":
    main()
