# -*- coding: utf-8 -*-
"""
📡 개장 전 급등 레이더 (preopen_radar.py)
===========================================
사용자: "장초/장중에 급등 '예정'인 종목을 위한 것이 필요함"

정직한 전제: 미래 급등을 확실히 아는 방법은 없음. 하지만 급등 '직전'에
자주 나타나는 상태는 통계적으로 잡을 수 있음 (surge_mining의 T-1 철학).

3개 시점에서 자동 실행:
  [08:40 개장 전] 어제까지의 데이터로 '오늘 급등 후보' 랭킹
    · 세력 매집 (기관+외인 5일 순매수) + 아직 안 오름
    · 거래량 바닥 후 첫 증가 (조용→깨어남)
    · 20일 레인지 상단 근접 (돌파 대기)
    · 급등유전자 조건 충족 (surge_mining 발굴 조건)
  [09:02 장초] 시초 갭+3% 이상 & 거래대금 상위 → 스캘핑 후보에 주입
  [장중 3분마다] 거래대금 급증 감지 (직전 20분 대비 3배+) → 로그 알림

결과: strategy/preopen_radar.json + 현황판 표시 + 스캘핑/모멘텀 채널이 참조

실행: python preopen_radar.py        # 수동 1회 (개장 전 랭킹)
자동: channels_auto가 08:40+/09:02+에 호출
"""
import json
import os
import sys
import time

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

OUT = os.path.join("strategy", "preopen_radar.json")


def _log(m):
    print(m, flush=True)


def preopen_rank(top=20, max_scan=250):
    """개장 전: 어제까지 데이터로 오늘 급등 후보 랭킹"""
    from validation import _load_bars
    import sqlite3
    sd = os.path.join(db.DATA_DIR, "stocks")
    names = {}
    try:
        for u in db.get_universe():
            names[u.get("symbol")] = u.get("name") or ""
    except Exception:
        pass
    # 유동성 상위만 스캔
    pool = []
    for f in os.listdir(sd) if os.path.isdir(sd) else []:
        if not f.endswith(".db"):
            continue
        try:
            c = sqlite3.connect(os.path.join(sd, f))
            r = c.execute("SELECT AVG(amount) FROM (SELECT amount FROM daily_bars "
                          "ORDER BY bar_date DESC LIMIT 5)").fetchone()
            c.close()
            if r and r[0] and r[0] >= 500_000_000:
                pool.append((f[:-3], r[0]))
        except Exception:
            continue
    pool.sort(key=lambda x: -x[1])
    pool = [s for s, _ in pool[:max_scan]]

    cands = []
    for sym in pool:
        bars = _load_bars(sym, max_days=40)
        if len(bars) < 25:
            continue
        c = [b["close"] for b in bars]
        h = [b["high"] for b in bars]
        v = [b["volume"] for b in bars]
        px = c[-1]
        chg5 = (c[-1] / c[-6] - 1) * 100 if c[-6] else 0
        chg1 = (c[-1] / c[-2] - 1) * 100 if c[-2] else 0
        hi20 = max(h[-20:])
        range_pos = px / hi20 if hi20 else 0
        # 거래량: 바닥(10일 최저 근처) 후 첫 증가
        v_min10 = min(v[-11:-1]) if len(v) > 11 else 0
        vol_wake = v[-1] > (sum(v[-21:-1]) / 20) * 1.3 and v[-2] <= v_min10 * 2
        score = 0.0
        notes = []
        if 0.93 <= range_pos < 1.0:
            score += 30
            notes.append("돌파대기(20일고점 -7%내)")
        if vol_wake:
            score += 25
            notes.append("거래량 깨어남")
        if -2 <= chg5 <= 4 and chg1 < 5:
            score += 15
            notes.append("과열아님")
        cands.append({"symbol": sym, "name": names.get(sym, "")[:8], "price": px,
                      "score": score, "notes": notes})
    # 세력 매집 가점 (상위 40개만 API 조회 - 시간 절약)
    cands.sort(key=lambda x: -x["score"])
    try:
        from force_line import fetch_trend
        for cd in cands[:40]:
            rows = fetch_trend(cd["symbol"], days=6)
            if len(rows) >= 5 and sum(r["organ"] + r["frgn"] for r in rows[-5:]) > 0:
                cd["score"] += 20
                cd["notes"].append("세력매집")
            time.sleep(0.3)
    except Exception:
        pass
    # ★ 🇺🇸 미국 섹터 가점 (2026-08-27): 어젯밤 미국서 오른 업종의 한국 관련주 +25
    #   (us_sector.py가 밤 라운드에 저장 - 없으면 가점 0으로 조용히 통과)
    try:
        from us_sector import boost_symbols
        us = boost_symbols()
        for cd in cands:
            u = us.get(cd["symbol"])
            if u:
                cd["score"] += 25
                cd["notes"].append(f"미국{u['sector']}{u['us_chg']:+.1f}%")
    except Exception:
        pass
    cands = [cd for cd in cands if cd["score"] >= 45]
    cands.sort(key=lambda x: -x["score"])
    return cands[:top]


def opening_gap_scan(top=10):
    """09:02: 시초 갭상승 + 거래대금 상위 (네이버 실시간)"""
    import requests
    H = {"User-Agent": "Mozilla/5.0"}
    out = []
    for mk in ("KOSPI", "KOSDAQ"):
        try:
            r = requests.get(f"https://m.stock.naver.com/api/stocks/up/{mk}",
                             params={"page": 1, "pageSize": 30}, headers=H, timeout=10)
            for s in (r.json().get("stocks") or []):
                if s.get("stockEndType") != "stock":
                    continue
                chg = float(str(s.get("fluctuationsRatio", "0")).replace(",", ""))
                amt = float(str(s.get("accumulatedTradingValue", "0")).replace(",", "")) / 100
                if 3 <= chg <= 20 and amt >= 10:   # 개장 2분에 10억+ = 진짜 관심
                    out.append({"symbol": s["itemCode"], "name": s.get("stockName", "")[:8],
                                "chg": chg, "amount_억": round(amt)})
        except Exception:
            continue
    out.sort(key=lambda x: -x["amount_억"])
    return out[:top]


def save(kind, items):
    os.makedirs("strategy", exist_ok=True)
    data = {}
    try:
        data = json.load(open(OUT, encoding="utf-8"))
    except Exception:
        pass
    if data.get("date") != db.now_kst().strftime("%Y-%m-%d"):
        data = {"date": db.now_kst().strftime("%Y-%m-%d")}
    data[kind] = items
    data["updated_at"] = db.now_kst_iso()
    json.dump(data, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)


def main():
    print("📡 개장 전 급등 레이더 (어제까지 데이터 기준)")
    cands = preopen_rank()
    save("preopen", cands)
    if not cands:
        print("  후보 없음 (조건 미충족)")
        return
    print(f"\n{'':2}{'종목':8} {'이름':10} {'점수':>4}  신호")
    for c in cands:
        print(f"  {c['symbol']:8} {c['name']:10} {c['score']:>4.0f}  {' · '.join(c['notes'])}")
    print(f"\n📄 저장: {OUT} (현황판 표시 + 스캘핑/모멘텀 채널이 참조)")
    print("⚠️ '급등 예정'은 확률이지 보장이 아님 - 매수는 채널 필터가 다시 거릅니다")


if __name__ == "__main__":
    main()
