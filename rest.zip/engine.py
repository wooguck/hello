"""일일 실행 엔진 (장중 반복 호출되는 메인 루프)

설계:
- 모든 전략은 virtual_positions(가상 포지션, 실제 시세 기반)로 평가
- SURVIVOR_COUNT(기본 3)만 실제 kiwoom_client로 모의/실전 주문
- AI_JUDGE_ENABLED=true 면 ai_judge.py(매수/매도 프롬프트)가 판단
- CONDITION_SEQ 없으면 샘플 3종목(005930,000660,035420)으로 테스트
"""
import logging
import json
import os
import random
from datetime import datetime, date
from db import now_kst

import db
from config import CFG
from kiwoom_client import client
from strategy import (evaluate_entry, evaluate_exit, compute_fitness, random_params,
                      calc_indicators, fill_default_params)
from genetic import select_survivors, next_generation

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("engine")

# AI 프롬프트 판단 (선택)
try:
    from ai_judge import evaluate_buy as ai_buy, evaluate_sell as ai_sell
    AI_OK = True
except Exception:
    AI_OK = False

ENGINE_MODE = os.getenv("ENGINE_MODE", getattr(CFG, "ENGINE_MODE_DEFAULT", "ai_prompt"))
# auto | params | ai_prompt  (기본 ai_prompt - 프롬프트+AI 중심)


def use_ai() -> bool:
    if ENGINE_MODE == "params":
        return False
    if ENGINE_MODE == "ai_prompt":
        return AI_OK
    # auto: AI 판단 활성화돼 있으면 AI, 아니면 파라미터
    return AI_OK and CFG.AI_JUDGE_ENABLED


def bootstrap_population():
    if db.get_active_strategies():
        log.info("기존 전략이 있어 bootstrap 스킵")
        return
    log.info(f"0세대 population 생성 ({CFG.POPULATION_SIZE}개)")
    for _ in range(CFG.POPULATION_SIZE):
        db.create_strategy(generation=0, params=random_params(), status="candidate")


def latest_fitness(strategy_id: int) -> float:
    return db.latest_fitness(strategy_id)


# 순위 조회 실패 캐시: 모의 서버에서 순위 TR이 안 되면 10분간 재시도 안 함 (전체종목 스캔으로 폴백)
_rank_fail_until = 0.0
_rank_last_mode = ""
# ★ 최근 매수 감시 후보 (점수 포함) - UI '감시 대기 종목' 표시용 (호환용 별칭)
_last_watch_candidates = []


def _apply_price_filter(cands):
    """
    ★ 가격 필터: 800원 ~ MOCK_PRICE_MAX(100,000원) 이하 종목만 남김
    cands: [(score, symbol, name), ...] 점수 내림차순
    반환: [{rank, symbol, name, price, score}, ...] 점수 높은 순 (최대 RANK_CANDIDATE_COUNT개)
    가격은 get_quote_cached(최근 5분 스냅샷 우선)로 조회 - API 재호출 최소화
    """
    out = []
    for score, sym, name in cands:
        q = get_quote_cached(sym, max_age_sec=300)
        price = (q or {}).get("price") or 0
        if price <= 0:
            continue  # 가격 모름 → 제외 (감시 안 함)
        if price < CFG.MOCK_PRICE_MIN or price > CFG.MOCK_PRICE_MAX:
            continue  # ★ 800원 미만 or 10만원 초과 → 제외
        out.append({"rank": len(out) + 1, "symbol": sym, "name": name,
                    "price": price, "score": score})
        if len(out) >= CFG.RANK_CANDIDATE_COUNT:
            break
    return out


# 네이버 순위 캐시 (5분) - 파일 스캔 최적화
_naver_rank_cache = {"t": 0.0, "data": None}
# 네이버 실시간 순위 캐시 (5분) - m.stock.naver.com API
_naver_live_cache = {"t": 0.0, "stocks": None}
# ★ 매수 감시 카테고리별 후보: {카테고리: [cands]} - UI/감시 풀용
_last_watch = {}


def get_naver_live_rank(force=False):
    """
    ★ 네이버 모바일 증권 API로 전 종목 실시간 데이터 수집 (키움 무관, 무료)
    - m.stock.naver.com/api/stocks/marketValue/{KOSPI|KOSDAQ} 페이지네이션 (60개/페이지)
    - 각 종목: 현재가 / 등락률 / 누적거래량 / 누적거래대금 / 시가총액 / 회전율(계산) / 최신 체결시각
    - 장중이면 실시간, 장마감 후에는 최근 종가 기준 (언제든 조회 가능)
    - 5분 캐시 (전체 수집 약 60초)
    반환: [{symbol, name, price, chg_pct, volume, amount, market_value, turnover, traded_at}...]
    """
    import time as _t
    if not force and _naver_live_cache["stocks"] is not None and _t.time() - _naver_live_cache["t"] < 300:
        return _naver_live_cache["stocks"]
    try:
        import requests as _req
        hdrs = {"User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X)"}
        all_stocks = []
        for market in ("KOSPI", "KOSDAQ"):
            page, total = 1, None
            while True:
                url = f"https://m.stock.naver.com/api/stocks/marketValue/{market}?page={page}&pageSize=60"
                try:
                    r = _req.get(url, headers=hdrs, timeout=15)
                    if r.status_code != 200:
                        break
                    data = r.json()
                except Exception:
                    break
                if total is None:
                    total = data.get("totalCount") or 0
                batch = data.get("stocks", [])
                if not batch:
                    break
                all_stocks.extend(batch)
                if len(all_stocks) >= total or len(batch) < 60:
                    break
                page += 1
                _t.sleep(0.06)
        out = []
        for s in all_stocks:
            try:
                code = s.get("itemCode") or ""
                if not code or len(code) != 6:
                    continue
                price = float(str(s.get("closePrice") or 0).replace(",", ""))
                if price <= 0:
                    continue
                chg = float(str(s.get("fluctuationsRatio") or 0).replace(",", ""))
                vol = float(str(s.get("accumulatedTradingVolume") or 0).replace(",", ""))
                amt = float(str(s.get("accumulatedTradingValue") or 0).replace(",", "")) * 1e6  # 백만→원
                mv = float(str(s.get("marketValue") or 0).replace(",", "")) * 1e6
                turnover = 0.0
                if mv > 0:
                    shares = mv / price
                    if shares > 0:
                        turnover = vol / shares * 100  # 회전율(%)
                out.append({
                    "symbol": code, "name": s.get("stockName") or code,
                    "price": price, "chg_pct": chg, "volume": vol, "amount": amt,
                    "market_value": mv, "turnover": turnover,
                    "end_type": s.get("stockEndType") or "stock",
                    "traded_at": s.get("localTradedAt") or "",
                })
            except Exception:
                continue
        _naver_live_cache["t"] = _t.time()
        _naver_live_cache["stocks"] = out
        return out
    except Exception as e:
        log.warning(f"네이버 실시간 순위 수집 실패: {e}")
        return []


def _prefilter_stocks(stocks, chg_min=None, chg_max=None, min_amt=None):
    """
    ★ 1차 조건식 (프리필터 - 하드 필터): 하나라도 걸리면 감시 후보에서 제외
    - 주식만 (ETF/ETN 제외) / 가격 800~100,000원
    - 등락률 범위: 급락(-5%↓)·상한가 추격(+25%↑) 제외
    - 당일 거래대금 최소(3억) 미만 제외 (저유동성) / 거래량 0 제외 (거래정지)
    """
    if chg_min is None:
        chg_min = float(getattr(CFG, "WATCH_CHG_MIN", -5.0))
    if chg_max is None:
        chg_max = float(getattr(CFG, "WATCH_CHG_MAX", 25.0))
    if min_amt is None:
        min_amt = int(getattr(CFG, "WATCH_MIN_AMOUNT", 300_000_000))
    out = []
    for s in stocks:
        if (s.get("end_type") or "stock") != "stock":
            continue
        price = s.get("price") or 0
        if price <= 0 or price < CFG.MOCK_PRICE_MIN or price > CFG.MOCK_PRICE_MAX:
            continue
        chg = s.get("chg_pct") or 0
        if chg < chg_min or chg > chg_max:
            continue
        if (s.get("amount") or 0) < min_amt:
            continue
        if (s.get("volume") or 0) <= 0:
            continue
        out.append(s)
    return out


# 일봉 패턴 캐시: (symbol) → {"t": 시각, "pat": {mom5, ...}} - 백필/실시간 모두 10분 캐시
_pattern_cache = {}


def _daily_pattern(symbol: str, allow_fetch=True):
    """일봉(최대 60봉)으로 패턴 지표 계산 (반등/저평가 판별용)
    - mom5 : 5일 수익률 (주봉 그림: 최근 1주 흐름)
    - mom10: 10일 수익률
    - ret_from_high60: 60일 고가 대비 하락률 (월봉 그림: 3개월 낙폭)
    - vol_ratio: 최근 5일 평균거래량 / 60일 평균거래량 (수급 턴어라운드)
    ★ 백필 데이터가 없어도(첫날부터) 네이버 일봉을 그 자리에서 fetch → 3개 카테고리 동시 동작
    """
    import time as _t
    try:
        # 10분 캐시
        ent = _pattern_cache.get(symbol)
        if ent is not None and _t.time() - ent.get("t", 0) < 600:
            return ent.get("pat")
        from strategy_auto import get_daily_series
        bars = get_daily_series(symbol, max_days=60)
        fetched = False
        # 백필 부족 → 실시간 fetch (네이버 fchart 일봉 90일) - 첫날부터 동작
        if len(bars) < 30 and allow_fetch:
            try:
                from backfill_history import fetch_daily
                fd = fetch_daily(symbol, days=90)
                if len(fd) >= 30:
                    bars = [{"close": b["close"], "high": b["high"], "low": b["low"],
                             "volume": b["volume"]} for b in fd]
                    fetched = True
            except Exception:
                pass
        if len(bars) < 30:
            _pattern_cache[symbol] = {"t": _t.time(), "pat": None}
            return None
        closes = [b["close"] for b in bars]
        vols = [b["volume"] or 0 for b in bars]
        n = len(closes)
        c = closes[-1]
        mom5 = c / closes[-6] - 1 if closes[-6] > 0 else 0
        mom10 = c / closes[-11] - 1 if n >= 11 and closes[-11] > 0 else 0
        high60 = max(closes)
        ret_from_high60 = c / high60 - 1 if high60 > 0 else 0
        vol5 = sum(vols[-5:]) / 5 if n >= 5 else 0
        vol60 = sum(vols[-60:]) / 60 if n >= 60 else (sum(vols) / n if vols else 0)
        vol_ratio = vol5 / vol60 if vol60 > 0 else 1.0
        pat = {"mom5": mom5, "mom10": mom10, "ret_from_high60": ret_from_high60,
               "vol_ratio": vol_ratio, "fetched": fetched}
        _pattern_cache[symbol] = {"t": _t.time(), "pat": pat}
        return pat
    except Exception:
        _pattern_cache[symbol] = None
        return None


def _top_by_score(pre, cat, cat_size=None):
    """공통: pre(실시간 종목 리스트)에서 카테고리별 점수 상위 cat_size개 추출"""
    if cat_size is None:
        cat_size = int(getattr(CFG, "CATEGORY_SIZE", 50))
    if not pre:
        return []
    n = len(pre)
    def _ranked(key):
        return sorted(pre, key=lambda s: -(s.get(key) or 0))
    scores = {}
    def _add(sym, name, pts):
        d = scores.setdefault(sym, {"score": 0, "name": name})
        d["score"] += pts
    if cat == "저평가":
        for i, s in enumerate(_ranked("amount")):
            _add(s["symbol"], s["name"], max(0, n - i) * 2)  # 거래대금 2배
        for i, s in enumerate(_ranked("volume")):
            _add(s["symbol"], s["name"], max(0, n - i) * 1)
        for i, s in enumerate(_ranked("turnover")):
            _add(s["symbol"], s["name"], max(0, n - i) * 1)
    elif cat == "반등":
        for i, s in enumerate(_ranked("chg_pct")):
            _add(s["symbol"], s["name"], max(0, n - i) * 2)  # 반등폭 2배
        for i, s in enumerate(_ranked("amount")):
            _add(s["symbol"], s["name"], max(0, n - i) * 1)
        for i, s in enumerate(_ranked("turnover")):
            _add(s["symbol"], s["name"], max(0, n - i) * 1)
    else:  # 급등 (기본)
        for i, s in enumerate(_ranked("chg_pct")):
            w = 1.0 if (s.get("chg_pct") or 0) > 15.0 else 2.0  # +15% 초과는 추격 위험 감점
            _add(s["symbol"], s["name"], max(0, n - i) * w)
        for i, s in enumerate(_ranked("amount")):
            _add(s["symbol"], s["name"], max(0, n - i) * 1)
        for i, s in enumerate(_ranked("volume")):
            _add(s["symbol"], s["name"], max(0, n - i) * 1)
        for i, s in enumerate(_ranked("turnover")):
            _add(s["symbol"], s["name"], max(0, n - i) * 1)
    ranked = sorted(scores.items(), key=lambda kv: -kv[1]["score"])
    meta = {s["symbol"]: s for s in pre}
    out = []
    for sym, sc in ranked:
        info = meta.get(sym) or {}
        out.append({"rank": len(out) + 1, "symbol": sym, "name": sc["name"],
                    "price": info.get("price") or 0, "score": sc["score"],
                    "chg_pct": info.get("chg_pct") or 0,
                    "turnover": info.get("turnover") or 0})
        if len(out) >= cat_size:
            break
    return out


def _relaxed_stocks(stocks):
    """가격+주식+거래량만 (등락률/거래대금 조건 해제 - 최후 완화)"""
    return [s for s in stocks
            if (s.get("end_type") or "stock") == "stock"
            and CFG.MOCK_PRICE_MIN <= (s.get("price") or 0) <= CFG.MOCK_PRICE_MAX
            and (s.get("volume") or 0) > 0]


def _cat_surge(cat_size=None):
    """★ 급등 카테고리: 당일 등락률/거래대금/거래량/회전율 순위 (실시간만)"""
    if cat_size is None:
        cat_size = int(getattr(CFG, "CATEGORY_SIZE", 50))
    stocks = get_naver_live_rank()
    if len(stocks) < 100:
        return []
    pre = _prefilter_stocks(stocks)
    if len(pre) < cat_size:
        pre = _prefilter_stocks(stocks, chg_min=-8.0, chg_max=30.0, min_amt=100_000_000)
    if len(pre) < cat_size:
        pre = _relaxed_stocks(stocks)
    return _top_by_score(pre, "급등", cat_size)


def _patterns_batch(symbols, max_workers=8):
    """★ 일봉 패턴 병렬 로드 (백필 없으면 실시간 fetch - 8개 동시)
    반환: {symbol: pat|None}
    """
    if not symbols:
        return {}
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        results = list(ex.map(lambda sym: (sym, _daily_pattern(sym, allow_fetch=True)), symbols))
    return {sym: pat for sym, pat in results}


def _cat_rebound(cat_size=None):
    """★ 반등 카테고리: 5일 -3%↓ 하락(주봉 그림) 후 오늘 반등 → 반등폭×2+거래대금+회전율
    백필 없어도 첫날부터 실시간 fetch로 동작 (3개 카테고리 동시)"""
    if cat_size is None:
        cat_size = int(getattr(CFG, "CATEGORY_SIZE", 50))
    stocks = get_naver_live_rank()
    if len(stocks) < 100:
        return []
    pre = _prefilter_stocks(stocks)
    if len(pre) < cat_size:
        pre = _prefilter_stocks(stocks, chg_min=-8.0, chg_max=30.0, min_amt=100_000_000)
    # 오늘 반등(등락률>0) 종목만 패턴 계산 (fetch 수 절반으로)
    pre_up = [s for s in pre if (s.get("chg_pct") or 0) > 0]
    pats = _patterns_batch([s["symbol"] for s in pre_up])
    filtered = [s for s in pre_up
                if pats.get(s["symbol"]) and pats[s["symbol"]]["mom5"] < -0.03]
    if len(filtered) < cat_size:
        pre2 = [s for s in _relaxed_stocks(stocks) if (s.get("chg_pct") or 0) > 0]
        pats2 = _patterns_batch([s["symbol"] for s in pre2])
        for s in pre2:
            if pats2.get(s["symbol"]) and pats2[s["symbol"]]["mom5"] < -0.03:
                filtered.append(s)
    return _top_by_score(filtered, "반등", cat_size)


def _cat_undervalued(cat_size=None):
    """★ 저평가 카테고리: 60일 고가 대비 -30%↓(월봉 그림) + 반등 조짐 + 거래량 턴어라운드
    백필 없어도 첫날부터 실시간 fetch로 동작"""
    if cat_size is None:
        cat_size = int(getattr(CFG, "CATEGORY_SIZE", 50))
    stocks = get_naver_live_rank()
    if len(stocks) < 100:
        return []
    pre = _prefilter_stocks(stocks)
    pre_up = [s for s in pre if (s.get("chg_pct") or 0) > 0]
    pats = _patterns_batch([s["symbol"] for s in pre_up])
    filtered = [s for s in pre_up
                if pats.get(s["symbol"]) and pats[s["symbol"]]["ret_from_high60"] <= -0.30
                and pats[s["symbol"]]["vol_ratio"] >= 1.2]
    if len(filtered) < cat_size:
        pre2 = [s for s in _relaxed_stocks(stocks) if (s.get("chg_pct") or 0) > 0]
        pats2 = _patterns_batch([s["symbol"] for s in pre2])
        for s in pre2:
            if pats2.get(s["symbol"]) and pats2[s["symbol"]]["ret_from_high60"] <= -0.30:
                filtered.append(s)
    return _top_by_score(filtered, "저평가", cat_size)


_CAT_FN = {"급등": _cat_surge, "반등": _cat_rebound, "저평가": _cat_undervalued}


def get_watch_categories():
    """★ 감시 카테고리별 후보 (최근 순위 조회 기준) - UI/감시 풀용
    반환: {카테고리: [{rank, symbol, name, price, score, chg_pct, turnover}, ...]}
    """
    return _last_watch


def get_watch_candidates(category=None, limit=300):
    """★ 감시 대기 종목 전체/카테고리별 리스트 (UI 표시용)
    category=None → 전체 (카테고리 필드 포함), 지정 시 해당 카테고리만
    """
    out = []
    for cat in ("급등", "반등", "저평가"):
        if category and cat != category:
            continue
        for c in _last_watch.get(cat, []):
            out.append({**c, "category": cat})
    return out[:limit]


def get_rank_from_naver(limit=None, use_cache=True):
    """
    ★ 키움 순위 API 실패 시 폴백: 네이버 백필 일봉으로 순위 점수 직접 계산
    - 최신 일봉의 거래대금(종가×거래량) 순위×2 + 거래량 순위×1 합산
    - 가격 필터(800~100,000원) 적용 후 점수 상위 N개 반환
    - 키움 계좌/키 불필요 (네이버 공개 데이터만 사용) → 모의 서버에서도 항상 동작
    반환: [{rank, symbol, name, price, score}, ...] / [] (데이터 부족)
    """
    import time as _t
    if limit is None:
        limit = CFG.RANK_CANDIDATE_COUNT
    if use_cache and _naver_rank_cache["data"] is not None and _t.time() - _naver_rank_cache["t"] < 300:
        return _naver_rank_cache["data"]
    try:
        bars = db.get_latest_backfill_bars()
    except Exception as e:
        log.warning(f"네이버 순위 데이터 로드 실패: {e}")
        return []
    if not bars:
        return []
    amt_ranked = sorted(bars.items(), key=lambda kv: -(kv[1].get("amount") or 0))
    vol_ranked = sorted(bars.items(), key=lambda kv: -(kv[1].get("volume") or 0))
    n = len(amt_ranked)
    scores = {}
    for i, (sym, _b) in enumerate(amt_ranked):
        s = scores.setdefault(sym, {"score": 0, "name": db.get_symbol_name(sym)})
        s["score"] += max(0, (n - i)) * 2  # 거래대금 가중 2배
    for i, (sym, _b) in enumerate(vol_ranked):
        s = scores.setdefault(sym, {"score": 0, "name": db.get_symbol_name(sym)})
        s["score"] += max(0, (n - i)) * 1  # 거래량 1배
    ranked = sorted(scores.items(), key=lambda kv: -kv[1]["score"])
    out = []
    for sym, sc in ranked:
        price = bars[sym].get("close") or 0
        if price <= 0 or price < CFG.MOCK_PRICE_MIN or price > CFG.MOCK_PRICE_MAX:
            continue
        out.append({"rank": len(out) + 1, "symbol": sym, "name": sc["name"],
                    "price": price, "score": sc["score"]})
        if len(out) >= limit:
            break
    _naver_rank_cache["t"] = _t.time()
    _naver_rank_cache["data"] = out
    return out


def _kiwoom_rank_candidates():
    """키움 순위 API(ka10032/10030/10038) 3종 합산 → 가격 필터 후 점수 상위 반환
    실패(모의 미지원 등) 시 [] 반환
    """
    for n in (CFG.RANK_TOP_N, CFG.RANK_TOP_N * 2, CFG.RANK_TOP_N * 3):
        value_rank = client.get_top_trading_value(limit=n, market="000")
        volume_rank = client.get_top_volume(limit=n, market="000")
        turnover_rank = client.get_top_turnover(limit=n, market="000") if CFG.RANK_INCLUDE_TURNOVER else []
        if not value_rank and not volume_rank and not turnover_rank:
            return []
        scores = {}
        def _add(rank, sym, name, score_w):
            s = scores.get(sym, {"score": 0, "name": name})
            s["score"] += score_w
            scores[sym] = s
        for rank, sym, name, _v in value_rank:
            _add(rank, sym, name, (n - rank) * 2)  # 거래대금 가중 2배
        for rank, sym, name, _v in volume_rank:
            _add(rank, sym, name, (n - rank) * 1)
        for rank, sym, name, _v in turnover_rank:
            _add(rank, sym, name, (n - rank) * 1)
        ranked = sorted(scores.items(), key=lambda x: -x[1]["score"])
        cands = [(sc["score"], sym, sc["name"]) for sym, sc in ranked]
        filtered = _apply_price_filter(cands)
        if len(filtered) >= CFG.RANK_CANDIDATE_COUNT or n >= CFG.RANK_TOP_N * 3:
            return filtered
    return []


def get_rank_scored_candidates() -> list:
    """
    ★ 매수 감시 풀 선정: 급등/반등/저평가 카테고리별 후보를 만들고 합집합 반환
    - 각 카테고리 CATEGORY_SIZE(50)개 → 총 최대 150개 풀 (중복 제거)
    - 가격 800~100,000원 · 주식만 · 1차 조건식(등락률/거래대금) 적용
    - 카테고리별 실패(백필 부족 등)는 자동 생략, 하나도 없으면 전체종목 스캔 폴백(10분 후 재시도)
    반환: [symbol, ...] 합집합 (최대 ~150)
    """
    global _rank_fail_until, _rank_last_mode, _last_watch, _last_watch_candidates
    try:
        if not CFG.RANK_SCORING_ENABLED:
            return []
        import time as _t
        if _t.time() < _rank_fail_until:
            return []
        # 1) 키움 순위 API로 50개 이상이면 rank 모드 (기존 우선)
        kw = _kiwoom_rank_candidates()
        if len(kw) >= CFG.RANK_CANDIDATE_COUNT:
            _rank_last_mode = "rank"
            _last_watch = {"급등": kw}
            _last_watch_candidates = kw
            top = [c["symbol"] for c in kw]
            log.info(f"[순위점수:rank] 키움 순위 {len(top)}개 → ★ 매수 감시 후보")
            return top
        # 2) 카테고리별 네이버 실시간 (기본: 급등+반등+저평가)
        cats_raw = (getattr(CFG, "WATCH_CATEGORIES", "급등,반등,저평가") or "급등,반등,저평가")
        cats = [c.strip() for c in cats_raw.split(",") if c.strip() in _CAT_FN]
        if not cats:
            cats = ["급등"]
        results = {}
        for cat in cats:
            try:
                cands = _CAT_FN[cat]()
            except Exception as e:
                log.warning(f"[카테고리:{cat}] 생성 실패: {e}")
                cands = []
            if cands:
                results[cat] = cands
                log.info(f"[감시:{cat}] {len(cands)}개")
            else:
                log.info(f"[감시:{cat}] 후보 0개 - 생략 (백필/데이터 부족)")
        if not results:
            # 전 카테고리 실패 → 10분 후 재시도
            _rank_fail_until = _t.time() + 600
            return []
        _rank_last_mode = "naver_live"
        _last_watch = results
        # 호환용: 전체 합집합 리스트
        flat = []
        for cat in ("급등", "반등", "저평가"):
            for c in results.get(cat, []):
                flat.append(c)
        _last_watch_candidates = flat
        seen = []
        for cat in ("급등", "반등", "저평가"):
            for c in results.get(cat, []):
                if c["symbol"] not in seen:
                    seen.append(c["symbol"])
        log.info(f"[순위점수:naver_live] 카테고리 {list(results.keys())} "
                 f"합집합 {len(seen)}개 → ★ 매수 감시 풀 (1위: {seen[0] if seen else '-'})")
        return seen
    except Exception as e:
        import time as _t
        _rank_fail_until = _t.time() + 600
        log.warning(f"순위 점수화 실패({e}) - 10분 후 재시도, 그동안 전체종목 스캔 사용")
        return []


def watch_mode() -> dict:
    """지금 매수 감시가 어떤 방식으로 돌고 있는지 (UI 표시용)
    - 'rank'       : 키움 순위 점수 상위 N개 집중 감시 (거래대금+거래량+회전율)
    - 'naver_live' : ★ 네이버 실시간 순위 상위 N개 집중 감시 (당일 등락률×2+거래대금+거래량+회전율)
    - 'naver'      : 네이버 백필 일봉 순위 (전일 데이터 - 실시간 실패 시 폴백)
    - 'scan'       : 전체 종목 배치 순환 감시 (순위 데이터 부족 시 폴백)
    """
    import time as _t
    if CFG.RANK_SCORING_ENABLED and _rank_last_mode in ("rank", "naver_live", "naver"):
        mode = _rank_last_mode
    elif CFG.RANK_SCORING_ENABLED and _t.time() >= _rank_fail_until:
        mode = "rank"  # 시도 대기 상태 (다음 사이클에서 갱신)
    else:
        mode = "scan"
    return {
        "mode": mode,
        "top_n": CFG.RANK_CANDIDATE_COUNT,
        "batch": CFG.SCAN_BATCH_SIZE,
        "rank_enabled": CFG.RANK_SCORING_ENABLED,
        "categories": getattr(CFG, "WATCH_CATEGORIES", "급등,반등,저평가"),
        "cat_counts": {k: len(v) for k, v in _last_watch.items()},
    }


def next_watch_time(now=None, period=None):
    """
    ★ 다음 매수 감시 시각 (정각 정렬 - 켠 시점 기준 아님)
    - 장중(09:00~15:30 거래일): 09:00 정각부터 period분 간격으로 정렬
      예) period=3 → 09:00, 09:03, 09:06, ... 15:30 (모두 :00초)
    - 장 시작 전(09:00 이전) / 장 마감 후 / 주말·공휴일:
      다음 거래일 09:00:00 정각
    반환: KST datetime (다음 실행 시각)
    """
    from db import is_trading_day
    from db import KST_TZ
    from datetime import datetime as _dt, timedelta as _td
    if now is None:
        now = now_kst()
    if period is None:
        period = max(1, int(getattr(CFG, "WATCH_PERIOD_MINUTES", 3)))

    today_9 = now.replace(hour=9, minute=0, second=0, microsecond=0)
    today_1530 = now.replace(hour=15, minute=30, second=0, microsecond=0)

    # 장 시작 전 (오늘 거래일이면 오늘 09:00, 아니면 다음 거래일 09:00)
    if now < today_9:
        if is_trading_day(now.date()):
            return today_9
        d = now.date()
        while True:
            d = d + _td(days=1)
            if is_trading_day(d):
                return _dt(d.year, d.month, d.day, 9, 0, tzinfo=KST_TZ)

    # 장 마감 후 (15:30 이후) → 다음 거래일 09:00
    if now > today_1530:
        d = now.date()
        while True:
            d = d + _td(days=1)
            if is_trading_day(d):
                return _dt(d.year, d.month, d.day, 9, 0, tzinfo=KST_TZ)

    # 주말/공휴일 (9~15:30 사이에 있지만 거래일 아님) → 다음 거래일 09:00
    if not is_trading_day(now.date()):
        d = now.date()
        while True:
            d = d + _td(days=1)
            if is_trading_day(d):
                return _dt(d.year, d.month, d.day, 9, 0, tzinfo=KST_TZ)

    # 장중: 09:00 정각 기준 period분 간격의 다음 슬롯 (정각 :00초)
    elapsed_min = (now - today_9).total_seconds() / 60.0
    slot = int(elapsed_min // period) + 1
    nxt = today_9 + _td(minutes=slot * period)
    # 15:30을 넘지 않게 (넘으면 다음 거래일)
    if nxt > today_1530:
        d = now.date()
        while True:
            d = d + _td(days=1)
            if is_trading_day(d):
                return _dt(d.year, d.month, d.day, 9, 0, tzinfo=KST_TZ)
    return nxt


def get_candidate_symbols() -> list:
    seq = CFG.CONDITION_SEQ
    # 0) ★ 키움 검색식(조건검색) 최우선: 영웅문에서 저장한 검색식 SEQ가 있으면
    #    그 검색식이 뽑은 종목들만 매수 감시 (사용자 요청 - 검색식 위주)
    #    ※ 모의 서버에서 조건검색이 500 오류면(검증됨) 아래 카테고리 풀로 자동 대체
    if seq:
        try:
            r = client.get_condition_search_results(condition_seq=seq)
            if r:
                log.info(f"[검색식] 조건검색 SEQ {seq} → {len(r)}개 매수 감시 (사용자 검색식 위주)")
                return r
            log.warning(f"[검색식] SEQ {seq} 결과 0개 - 카테고리 풀로 대체")
        except Exception as e:
            log.warning(f"[검색식] 조건검색 실패({e}) - 카테고리 풀로 대체")
    # 1) ★ 매수 감시 카테고리 풀: 급등/반등/저평가 각 50개 (검색식 없을 때 기본)
    #    - 전 종목(코스피+코스닥)에서 카테고리별 후보를 만들고 합집합 안에서만 매수 감시
    #    - 순위 조회가 불가능한 환경이면 10분 후 재시도, 그동안 전체종목 스캔 배치로 폴백
    if CFG.RANK_SCORING_ENABLED:
        try:
            rank_cands = get_rank_scored_candidates()
            if rank_cands:
                return rank_cands
        except Exception:
            pass
    # 2) 전체 종목 스캔 모드 (기본): 전 종목을 배치로 순환 (카테고리 풀 실패 시 폴백)
    if CFG.SCAN_ALL_MODE:
        try:
            import universe as _uni
            batch, ptr, total = _uni.get_scan_batch()
            if batch:
                done = min(total, (ptr + len(batch)))
                log.info(f"[전체종목 스캔] {ptr + 1}~{done} / {total}개 "
                         f"(진행률 {min(100, done / total * 100):.1f}%)")
                return batch
        except Exception as e:
            log.warning(f"전체종목 배치 조회 실패({e}) - 기본 유니버스 사용")
    # 3) fallback: 기본 유니버스 (중소형주)
    if CFG.USE_MOCK or CFG.DRY_RUN or CFG.AI_JUDGE_ENABLED or CFG.TEST_FORCE_MOCK_INDICATORS:
        log.info(f"기본 검사 종목 {len(CFG.UNIVERSE)}개 사용")
        return CFG.UNIVERSE
    log.warning("스캔 대상 없음 - 전체종목 목록이 비어있음 (⚙️ 설정에서 '전체종목 갱신' 실행)")
    return []


def _naver_daily_indicators(symbol: str, price: float) -> dict:
    """★ 네이버 일봉(백필 데이터)으로 지표 계산 - mock/키 없는 환경에서도 실데이터 사용
    (랜덤 지표 금지 - 거짓 신호 방지)
    """
    try:
        from strategy_auto import get_daily_series
        bars = get_daily_series(symbol, max_days=60)
        if len(bars) >= 20:
            closes = [b["close"] for b in bars]
            vols = [b["volume"] or 0 for b in bars]
            ind = calc_indicators([{"close": c, "volume": v} for c, v in zip(closes, vols)])
            ind["price"] = price
            return ind
    except Exception:
        pass
    return {"price": price, "rsi_14": 50, "volume": 0, "volume_avg_20": 0,
            "ema_12": price * 1.01, "ema_26": price * 0.99}


def _naver_flow(symbol: str, price: float):
    """★ 네이버 분봉으로 체결강도 추정/거래대금 계산 (mock 환경 실데이터 폴백)
    반환: (chegyul, cheg_trend, amount_1m, amount_3m, amount_avg_3m)
    """
    try:
        bars = db.get_minute_bars(symbol, days=1)
        if len(bars) < 5:
            return 100.0, [100.0, 100.0, 100.0], 0, 0, 0
        last3 = bars[-3:]
        p0, p1 = last3[0]["price"], last3[-1]["price"]
        vols3 = [b.get("volume") or 0 for b in last3]
        vol_up = all(vols3[i] <= vols3[i + 1] for i in range(len(vols3) - 1))
        if p1 > p0 and vol_up:
            v = 135.0
        elif p1 < p0 and vol_up:
            v = 75.0
        elif p1 > p0:
            v = 115.0
        elif p1 < p0:
            v = 90.0
        else:
            v = 100.0
        trend = [v - 8, v - 3, v]
        v1 = vols3[-1]
        v3 = sum(vols3)
        amount_1m = v1 * price
        amount_3m = v3 * price
        return v, trend, amount_1m, amount_3m, amount_3m / 3
    except Exception:
        return 100.0, [100.0, 100.0, 100.0], 0, 0, 0


def fetch_market_data_once(symbol: str) -> dict:
    """종목당 1회만 API 호출해서 공통 market_data 생성
    ★ 랜덤 지표 금지: API 실패/mock이면 네이버 일봉·분봉(백필 데이터)으로 실측 계산
    ★ 150개 감시 풀 성능: 최근 5분 이내 스냅샷이 있으면 API 재호출 없이 가격 재사용
    """
    try:
        # 5분 시세 캐시 (스냅샷 DB 재사용) - 첫 사이클만 API, 이후 스냅샷
        q = get_quote_cached(symbol, max_age_sec=300)
        if q and q.get("price"):
            raw_price = {"price": q["price"], "name": q.get("symbol", symbol),
                         "source": q.get("source", "snapshot")}
        else:
            raw_price = client.get_current_price(symbol)
    except Exception as e:
        log.warning(f"시세조회 실패({symbol}): {e}")
        return {}

    # 종목명 DB 저장 (코드 → 이름 표시용)
    try:
        nm = raw_price.get("name") or symbol
        if nm and nm != symbol:
            db.save_symbol_name(symbol, nm)
    except Exception:
        pass

    price = raw_price.get("price", 0)
    # ★ TEST_FORCE_MOCK_INDICATORS=true 일 때만 랜덤 유지 (명시적 매수 테스트용)
    #   그 외(mock 서버 포함)에는 네이버 일봉/분봉 실데이터로 계산 - 랜덤 금지
    force_mock = CFG.TEST_FORCE_MOCK_INDICATORS

    indicators, extra = {}, {}
    if force_mock:
        indicators = {
            "price": price,
            "rsi_14": random.uniform(15, 32),
            "rsi": random.uniform(15, 32),
            "volume": random.randint(100000, 1000000),
            "volume_avg_20": random.randint(50000, 300000),
            "ema_12": price * 1.03,
            "ema_26": price * 0.97,
            "sma_5": price,
            "sma_20": price * 0.98,
        }
        extra = {
            "체결강도": random.uniform(150, 250),
            "chegyul": random.uniform(150, 250),
            "volume_ratio": random.uniform(2.5, 4.0),
            "mock": True,
        }
    else:
        chart_ok = False
        try:
            chart_raw = client.get_chart_daily(symbol)
            candles = []
            if isinstance(chart_raw, dict):
                for key in ["stk_dt_pole_chart_qry", "chart", "data", "output", "items"]:
                    if key in chart_raw and isinstance(chart_raw[key], list):
                        candles = chart_raw[key]
                        break
            if candles:
                normalized = [{"close": (c.get("stk_clpr") or c.get("cur_prc")
                                         or c.get("close_prc") or c.get("close", 0)),
                               "volume": (c.get("cntg_vol") or c.get("trde_qty")
                                          or c.get("volume", 0))} for c in candles[:60]]
                normalized.reverse()
                indicators = calc_indicators(normalized)
                chart_ok = bool(indicators.get("rsi_14") is not None)
            else:
                indicators = {"price": price, "rsi_14": 50, "volume": 0, "volume_avg_20": 0}
        except Exception as e:
            log.debug(f"차트 지표 계산 실패 {symbol}: {e}")
            indicators = {"rsi_14": 50}
        # ★ API 차트 실패/mock → 네이버 일봉(백필)으로 지표 실측 (랜덤 금지)
        if not chart_ok or not indicators.get("rsi_14") or indicators.get("rsi_14") in (50, None) and not indicators.get("ema_12"):
            naver_ind = _naver_daily_indicators(symbol, price)
            if naver_ind.get("ema_12") or naver_ind.get("rsi_14") not in (None, 50):
                indicators = naver_ind
                indicators.setdefault("source_daily", "naver_backfill")

        # ── 실제 수급 데이터: 체결강도 + 1분/3분 거래대금 (프롬프트 판단용) ──
        try:
            cheg = client.get_chegyul_data(symbol)
            chegyul_val = cheg.get("chegyul", 100.0)
            cheg_trend = cheg.get("trend", []) or []
            cheg_source = cheg.get("source", "error")
            # ★ mock/실패 → 네이버 분봉 기반 실측 (랜덤 금지)
            if cheg_source == "mock" or not cheg_trend:
                _f = _naver_flow(symbol, price)
                chegyul_val, cheg_trend = _f[0], _f[1]
                cheg_source = "naver_minute"
        except Exception as e:
            _f = _naver_flow(symbol, price)
            chegyul_val, cheg_trend = _f[0], _f[1]
            cheg_source = "naver_minute"
            log.debug(f"체결강도 가져오기 실패 {symbol}: {e}")

        try:
            amt = client.get_trading_amount_1m_3m(symbol)
            amount_1m = amt.get("amount_1m", 0)
            amount_3m = amt.get("amount_3m", 0)
            amount_avg_3m = amt.get("avg_3m", 0)
            amt_source = amt.get("source", "error")
            # ★ mock/실패 → 네이버 분봉 기반 거래대금 실측 (랜덤 금지)
            if amt_source == "mock" or amount_3m <= 0:
                _c, _t, amount_1m, amount_3m, amount_avg_3m = _naver_flow(symbol, price)
                amt_source = "naver_minute"
        except Exception as e:
            _c, _t, amount_1m, amount_3m, amount_avg_3m = _naver_flow(symbol, price)
            amt_source = "naver_minute"
            log.debug(f"거래대금 가져오기 실패 {symbol}: {e}")

        extra = {
            "체결강도": chegyul_val,
            "chegyul": chegyul_val,
            "체결강도추세": cheg_trend if cheg_trend else [chegyul_val - 10, chegyul_val - 5, chegyul_val],
            "cheg_source": cheg_source,
            "최근1분거래대금": amount_1m,
            "최근3분거래대금": amount_3m,
            "최근3분평균": amount_avg_3m,
            "amt_source": amt_source,
            "volume_ratio": 1.5,
        }

    market_data = dict(raw_price)
    market_data.update(indicators)
    market_data.update(extra)
    if not market_data.get("price"):
        market_data["price"] = price
    market_data["ema_fast"] = market_data.get("ema_12", price)
    market_data["ema_slow"] = market_data.get("ema_26", price * 0.99)
    return market_data


def calculate_position_qty(strategy_id: int, symbol: str, price: float, params: dict,
                           remaining_deposit: float = None) -> int:
    """
    포지션 사이징 - 예수금 초과 방지 포함.
    - 리스크 % 기반 수량 계산 (RISK_PER_TRADE_PCT)
    - remaining_deposit 주어지면: 매수 금액(price*qty)이 잔여 예수금 이하가 되도록 제한
    - 최대 10주 상한
    """
    if price <= 0:
        return CFG.DEFAULT_ORDER_QTY
    qty = CFG.DEFAULT_ORDER_QTY
    # 리스크 % 기반 수량 계산 (실제 주문일 때만, DRY_RUN이면 기본값)
    if not CFG.DRY_RUN:
        try:
            balance_info = client.get_balance()
            deposit = None
            if isinstance(balance_info, dict):
                deposit = balance_info.get("entr") or balance_info.get("deposit") or balance_info.get("cash")
                if not deposit:
                    for k in ["output", "data"]:
                        if k in balance_info and isinstance(balance_info[k], dict):
                            deposit = balance_info[k].get("entr") or balance_info[k].get("cash")
                        if k in balance_info and isinstance(balance_info[k], list) and balance_info[k]:
                            deposit = balance_info[k][0].get("entr") or balance_info[k][0].get("cash")
            if deposit:
                try:
                    deposit_val = int(str(deposit).replace(",", ""))
                    risk_amount = deposit_val * (CFG.RISK_PER_TRADE_PCT / 100.0)
                    stop_loss_pct = params.get("stop_loss_pct", 2.0)
                    loss_per_share = price * (stop_loss_pct / 100.0)
                    if loss_per_share > 0:
                        qty = int(risk_amount / loss_per_share)
                        qty = max(1, min(qty, 10))
                except Exception:
                    pass
        except Exception:
            pass

    # ★ 예수금 초과 방지: 매수 금액이 잔여 예수금 이하가 되도록 수량 제한
    #   (DRY_RUN 여부와 무관하게 remaining_deposit 주어지면 적용)
    if remaining_deposit is not None and remaining_deposit > 0:
        max_qty_by_deposit = int(remaining_deposit / price) if price > 0 else 0
        if max_qty_by_deposit < 1:
            log.info(f"[예수금초과방지] {symbol} 잔여예수금 {remaining_deposit:,}원으로 "
                     f"{price:,}원 1주도 못 삼 - 매수 스킵")
            return 0
        qty = min(qty, max_qty_by_deposit)
    elif remaining_deposit is not None:
        # 잔여 예수금 0 이하 → 매수 불가
        return 0
    return qty


def run_trading_cycle(force_virtual: bool = False):
    """매매 사이클 1회.
    force_virtual=True 면 전부 가상(시뮬레이션)으로만 진행 - 실제 주문 안 나감.
    force_virtual=False 면 survivor 전략은 실제 모의/실전 주문, 나머지는 가상.
    """
    log.info(f"=== Trading Cycle Start (force_virtual={force_virtual}) ===")
    strategies = db.get_active_strategies()
    if not strategies:
        bootstrap_population()
        strategies = db.get_active_strategies()

    candidates = get_candidate_symbols()
    if not candidates:
        log.info("후보 종목 없음 - 사이클 종료")
        return

    log.info(f"후보 종목 {len(candidates)}개: {candidates[:10]}")

    market_cache = {}
    for symbol in candidates:
        md = fetch_market_data_once(symbol)
        if md and md.get("price"):
            market_cache[symbol] = md
            # 시세 스냅샷 자동 저장 (최근 1주일 자료 보관용)
            try:
                db.record_snapshot(
                    symbol, md.get("price", 0),
                    volume=md.get("volume"), chegyul=md.get("체결강도", md.get("chegyul")),
                    rsi=md.get("rsi_14", md.get("rsi")),
                    ema_fast=md.get("ema_fast"), ema_slow=md.get("ema_slow"),
                    volume_ratio=md.get("volume_ratio"),
                )
            except Exception as e:
                log.debug(f"스냅샷 저장 실패 {symbol}: {e}")
        else:
            log.warning(f"{symbol} market_data 가져오기 실패 - 스킵")
    if not market_cache:
        log.warning("모든 종목 시세 조회 실패")
        return

    scored = [{"id": s["id"], "fitness": latest_fitness(s["id"]), "row": s} for s in strategies]
    ranked = sorted(scored, key=lambda x: x["fitness"], reverse=True)
    survivor_ids = {x["id"] for x in ranked[:CFG.SURVIVOR_COUNT]}
    log.info(f"Survivor IDs (실주문 반영): {survivor_ids}")

    ai_mode = use_ai()

    # ★ 예수금 초과 방지: 실제 주문일 때 잔여 예수금 계산
    #    잔여 예수금 = 예수금 - (이미 보유한 모의/실전 포지션 매입금액 합)
    remaining_deposit = None
    held_symbols = set()
    if not force_virtual and not CFG.DRY_RUN:
        try:
            acc = client.get_account_overview()
            if acc and not acc.get("mock"):
                deposit = acc.get("entr", 0)
                # 보유 포지션 매입금액 합산 (평가금액 기준으로 대략)
                held_cost = 0
                for p in acc.get("positions", []):
                    held_symbols.add(p.get("symbol", ""))
                    held_cost += (p.get("avg_price", 0) or 0) * (p.get("qty", 0) or 0)
                remaining_deposit = max(0, deposit - held_cost)
                log.info(f"[예수금] 예수금 {deposit:,}원 - 보유 {held_cost:,}원 = 잔여 {remaining_deposit:,}원")
            else:
                # mock/실패 시에는 체크 안 함 (테스트 통과용)
                remaining_deposit = None
        except Exception as e:
            log.warning(f"예수금 조회 실패 - 초과방지 생략: {e}")
            remaining_deposit = None

    # ── 매수 ──
    for symbol, base_md in market_cache.items():
        for strat in strategies:
            params = fill_default_params(json.loads(strat["params_json"]))  # 새 DNA 자동 추가(마이그레이션)
            open_positions = db.get_open_positions(strategy_id=strat["id"])
            if len(open_positions) >= CFG.MAX_POSITIONS_PER_STRATEGY:
                continue
            if any(p["symbol"] == symbol for p in open_positions):
                continue

            market_data = dict(base_md)
            price_now = market_data.get("price") or 0

            # ★ 모의 테스트 가격 필터: 실제 주문(force_virtual=False)일 때만
            # 800원 ~ 150,000원 범위 밖 종목은 매수 스킵 (데이터 수집은 전 종목 유지)
            if not force_virtual and price_now > 0:
                if price_now < CFG.MOCK_PRICE_MIN or price_now > CFG.MOCK_PRICE_MAX:
                    log.debug(f"[가격필터] {symbol} {price_now:,}원 - "
                              f"{CFG.MOCK_PRICE_MIN:,}~{CFG.MOCK_PRICE_MAX:,}원 범위 밖, 모의 매수 스킵")
                    continue

            # ★ 종목 중복 방지: 기본(ALLOW_AVERAGING=false)은 보유 중인 종목 재매수 금지
            #   true면 보유 중이어도 조건 만족 시 추가 매수 (평균단가, 포지션은 합산 표시)
            if not force_virtual and symbol in held_symbols:
                if not CFG.ALLOW_AVERAGING:
                    log.info(f"[중복방지] {symbol} 이미 보유 중 - 재매수 스킵 (ALLOW_AVERAGING=false)")
                    continue
                else:
                    log.info(f"[추가매수] {symbol} 보유 중이지만 조건 만족 - 추가 매수 (평균단가)")

            reason = ""
            if ai_mode:
                is_buy, reason = ai_buy(symbol, market_data, client, params)
                j_engine = {"gemini": "gemini", "openai": "gpt"}.get(getattr(CFG, "AI_PROVIDER", "rule"), "rule")
            else:
                is_buy = evaluate_entry(params, market_data)
                reason = f"[params] rsi<={params.get('rsi_buy')}"
                j_engine = "params"

            # 판단 기록 저장 (매수: 매수/매수금지) - ★ 이유 상세 + 지표 스냅샷(학습용)
            try:
                rich_reason = f"{reason} | 가격 {price_now:,.0f}원 | "
                if market_data.get("체결강도"):
                    rich_reason += f"체결강도 {market_data['체결강도']:.0f} | "
                if market_data.get("rsi_14"):
                    rich_reason += f"RSI {market_data['rsi_14']:.0f} | "
                if market_data.get("최근1분거래대금"):
                    rich_reason += f"1분대금 {market_data['최근1분거래대금']/1e6:.0f}M | "
                if market_data.get("최근3분거래대금"):
                    rich_reason += f"3분대금 {market_data['최근3분거래대금']/1e8:.1f}억"
                # ★ 매수 시점 지표 스냅샷 (학습: 어떤 조건에서 매수했고 맞았는지)
                try:
                    profile = {
                        "체결강도": round(market_data.get("체결강도") or 0, 1),
                        "RSI": round(market_data.get("rsi_14") or 0, 1),
                        "1분대금": round((market_data.get("최근1분거래대금") or 0) / 1e6, 1),
                        "3분대금": round((market_data.get("최근3분거래대금") or 0) / 1e8, 1),
                        "등락률": round(market_data.get("등락률") or 0, 2),
                        "가격": round(price_now),
                    }
                except Exception:
                    profile = None
                db.record_judgment(symbol, "buy",
                                   "매수" if is_buy else "매수금지",
                                   j_engine, score=None,
                                   reason=rich_reason[:400], profile=profile)
                # ★ 전략 연구 시트 기록 (가상/모의 구분)
                r_kind = "virtual" if force_virtual else ("real" if (strat["id"] in survivor_ids) else "virtual")
                db.record_signal_to_research(symbol, "매수" if is_buy else "매수금지",
                                             j_engine, None, rich_reason[:150],
                                             price=price_now, kind=r_kind)
            except Exception:
                pass

            if not is_buy:
                continue

            is_real = strat["id"] in survivor_ids
            price = market_data.get("price")
            qty = calculate_position_qty(strat["id"], symbol, price, params,
                                         remaining_deposit=remaining_deposit if (is_real and not force_virtual) else None)

            if qty <= 0:
                log.info(f"[예수금초과방지] {symbol} 매수 불가 (잔여 예수금 부족) - 스킵")
                continue

            if is_real and not force_virtual:
                order_result = client.place_order(symbol, "buy", qty, price, order_type="00")
                kind = "mock_real" if CFG.USE_MOCK else "live_real"
                log.info(f"[매수] 전략 {strat['id']} / {symbol} {qty}주 @ {price} kind={kind} | {reason}")
                db.open_virtual_position(strat["id"], symbol, price, qty, kind=kind)
            else:
                kind = "virtual"
                log.info(f"[가상매수] 전략 {strat['id']} / {symbol} {qty}주 @ {price} | {reason}")
                db.open_virtual_position(strat["id"], symbol, price, qty, kind="virtual")
            db.record_trade(strat["id"], symbol, "buy", price, qty, kind)

    # ── 매도 ──
    log.info("보유 포지션 청산 체크 시작")
    all_open = db.get_open_positions()
    for pos in all_open:
        strat_id = pos["strategy_id"]
        symbol = pos["symbol"]
        entry_price = pos["entry_price"]
        strat_row = next((s for s in strategies if s["id"] == strat_id), None)
        if not strat_row:
            continue
        params = fill_default_params(json.loads(strat_row["params_json"]))  # 마이그레이션
        try:
            entry_time = datetime.fromisoformat(pos["entry_time"])
            holding_days = (now_kst() - entry_time).days
        except Exception:
            holding_days = 0

        market_data = market_cache.get(symbol)
        if not market_data:
            market_data = fetch_market_data_once(symbol)
            if not market_data:
                continue

        if ai_mode:
            try:
                entry_time = datetime.fromisoformat(pos["entry_time"])
                holding_minutes = (now_kst() - entry_time).total_seconds() / 60
            except Exception:
                holding_minutes = 0
            position_info = {
                "entry_price": entry_price,
                "entry_time": pos["entry_time"],
                "entry_chegyul": 100,
                "highest_price": max(entry_price, market_data.get("price", entry_price)),
                "highest_return": (max(entry_price, market_data.get("price", entry_price)) - entry_price) / entry_price * 100 if entry_price else 0,
                "holding_minutes": holding_minutes,
            }
            decision, reason = ai_sell(symbol, market_data, position_info, client, params)
            should_sell = decision in ("수익청산", "손절")
        else:
            decision = "params"
            reason = ""
            should_sell = evaluate_exit(params, market_data, entry_price, holding_days)

        # 판단 기록 저장 (매도: 수익청산/손절/보유)
        try:
            j_engine = {"gemini": "gemini", "openai": "gpt"}.get(getattr(CFG, "AI_PROVIDER", "rule"), "rule") if ai_mode else "params"
            db.record_judgment(symbol, "sell", decision, j_engine,
                               score=None, reason=reason[:200])
        except Exception:
            pass

        if should_sell:
            price = market_data.get("price")
            qty = pos["qty"]
            is_real = strat_id in survivor_ids
            ret = (price - entry_price) / entry_price * 100 if entry_price else 0
            if is_real and not force_virtual:
                order_result = client.place_order(symbol, "sell", qty, price, order_type="00")
                kind = "mock_real" if CFG.USE_MOCK else "live_real"
                log.info(f"[{decision}] 전략 {strat_id} / {symbol} {qty}주 @ {price} 수익률={ret:.2f}% | {reason}")
            else:
                kind = "virtual"
                log.info(f"[가상{decision}] 전략 {strat_id} / {symbol} {qty}주 @ {price} 수익률={ret:.2f}% | {reason}")
            db.close_virtual_position(pos["id"], price)
            db.record_trade(strat_id, symbol, "sell", price, qty, kind)

    log.info("=== Trading Cycle End ===")


def get_account_holdings():
    """키움 계좌 실제 보유 종목 (내부 DB에 없어도) - [{symbol, name, qty, avg_price}, ...]"""
    try:
        if CFG.DRY_RUN:
            return []
        acc = client.get_account_overview()
        if isinstance(acc, dict) and acc.get("positions"):
            return acc["positions"]
    except Exception as e:
        log.warning(f"[계좌보유] 조회 실패: {e}")
    return []


def liquidate_all(force_virtual: bool = False):
    """
    ★ 전체 보유 포지션 청산 (실제 주문으로 매도)
    - 내부 DB 포지션 + 키움 계좌 실제 보유 종목 모두 매도
    force_virtual=True 면 가상 포지션만 청산 처리 (실주문 없음)
    반환: 청산한 포지션 수
    """
    closed = 0
    # 1) 내부 DB 포지션
    positions = db.get_open_positions()
    for pos in positions:
        sym = pos["symbol"]
        qty = pos["qty"]
        kind = pos.get("kind", "virtual")
        try:
            q = get_quote_cached(sym, max_age_sec=300)
            price = q.get("price", 0) if q else 0
            if price <= 0:
                log.warning(f"[청산] {sym} 현재가 없음 - 스킵")
                continue
            is_real = kind in ("mock_real", "live_real") and not force_virtual
            if is_real:
                result = client.place_order(sym, "sell", qty, price, order_type="00")
                log.info(f"[청산] {sym} {qty}주 @ {price}원 매도 → {result.get('return_msg', result)}")
                db.close_virtual_position(pos["id"], price)
                db.record_trade(pos["strategy_id"], sym, "sell", price, qty, kind)
            else:
                db.close_virtual_position(pos["id"], price)
                db.record_trade(pos["strategy_id"], sym, "sell", price, qty, "virtual")
                log.info(f"[가상청산] {sym} {qty}주 @ {price}원")
            closed += 1
        except Exception as e:
            log.warning(f"[청산] {sym} 실패: {e}")

    # 2) 키움 계좌 실제 보유 종목 (내부 DB에 없어도 매도) - 실주문일 때만
    if not force_virtual:
        account_positions = get_account_holdings()
        for ap in account_positions:
            sym = ap.get("symbol", "")
            qty = ap.get("qty", 0) or 0
            if not sym or qty <= 0:
                continue
            # 이미 내부 DB에서 청산한 종목이면 스킵
            if any(p["symbol"] == sym for p in positions):
                continue
            try:
                q = get_quote_cached(sym, max_age_sec=300)
                price = q.get("price", 0) if q else 0
                if price <= 0:
                    log.warning(f"[계좌청산] {sym} 현재가 없음 - 스킵")
                    continue
                result = client.place_order(sym, "sell", qty, price, order_type="00")
                log.info(f"[계좌청산] {sym} {qty}주 @ {price}원 매도 → {result.get('return_msg', result)}")
                closed += 1
            except Exception as e:
                log.warning(f"[계좌청산] {sym} 실패: {e}")
    log.info(f"[청산] 전체 청산 완료: {closed}개")
    return closed


def liquidate_symbol(symbol: str, force_virtual: bool = False):
    """★ 특정 종목만 청산 (클릭 매도용) - 내부 DB + 계좌 보유 모두
    반환: 청산 여부"""
    positions = [p for p in db.get_open_positions() if p["symbol"] == symbol]
    sold = False
    for pos in positions:
        qty = pos["qty"]
        kind = pos.get("kind", "virtual")
        try:
            q = get_quote_cached(symbol, max_age_sec=300)
            price = q.get("price", 0) if q else 0
            if price <= 0:
                log.warning(f"[청산] {symbol} 현재가 없음")
                continue
            is_real = kind in ("mock_real", "live_real") and not force_virtual
            if is_real:
                client.place_order(symbol, "sell", qty, price, order_type="00")
            db.close_virtual_position(pos["id"], price)
            db.record_trade(pos["strategy_id"], symbol, "sell", price, qty, kind)
            log.info(f"[종목청산] {symbol} {qty}주 @ {price}원")
            sold = True
        except Exception as e:
            log.warning(f"[종목청산] {symbol} 실패: {e}")

    # 계좌에만 있는 종목 (내부 DB 없음) - 실주문일 때
    if not force_virtual and not positions:
        account_positions = get_account_holdings()
        for ap in account_positions:
            if ap.get("symbol", "") == symbol:
                qty = ap.get("qty", 0) or 0
                try:
                    q = get_quote_cached(symbol, max_age_sec=300)
                    price = q.get("price", 0) if q else 0
                    if price > 0 and qty > 0:
                        result = client.place_order(symbol, "sell", qty, price, order_type="00")
                        log.info(f"[계좌종목청산] {symbol} {qty}주 @ {price}원 → {result.get('return_msg', result)}")
                        sold = True
                except Exception as e:
                    log.warning(f"[계좌종목청산] {symbol} 실패: {e}")
    return sold


def maybe_evolve_generation(current_generation: int) -> int:
    """
    세대 교체:
    1. fitness 기준 상위 SURVIVOR_COUNT(기본 10 = 전체)는 survivor (모의투자 대상)
    2. SCREENING_ENABLED면 백테스트로 못난 전략(하위 40%) 과감히 retire
    3. survivor들은 교차/변이로 다음 세대 생성
    """
    log.info(f"세대 교체 체크: 현재 {current_generation}세대")
    strategies = db.get_active_strategies()
    scored = [{"id": s["id"],
               "params": fill_default_params(json.loads(s["params_json"])),  # 마이그레이션
               "fitness": latest_fitness(s["id"])}
              for s in strategies]
    if not scored:
        log.warning("평가할 전략 없음")
        return current_generation

    # 1) fitness 상위 N개 = survivor (실제 모의투자 대상, 기본 전체 10개)
    survivors = select_survivors(scored, CFG.SURVIVOR_COUNT)
    log.info(f"모의투자 대상 {len(survivors)}명: {[s['id'] for s in survivors]}")

    # 2) 백테스트 스크리닝: survivor 중에서도 못난 전략은 retire
    retire_ids = set()
    if CFG.SCREENING_ENABLED and len(scored) > 1:
        try:
            import backtest as _bt
            result = _bt.screen_strategies(
                [{"id": s["id"], "params": s["params"]} for s in scored],
                retire_rate=CFG.SCREENING_RETIRE_RATE,
            )
            retire_ids = set(result["retire"])
            # 스크리닝 점수 로그 (상위 5개)
            top5 = sorted(result["detail"], key=lambda x: -x["score"])[:5]
            for d in top5:
                log.info(f"  [스크리닝] 전략{d['id']}: 점수 {d['score']} (시도 {d['trials']}회)")
            log.info(f"  [스크리닝] 하위 {len(retire_ids)}개 폐기 대상: {sorted(retire_ids)}")
        except Exception as e:
            log.warning(f"백테스트 스크리닝 실패(스킵): {e}")

    # 3) 상태 결정: survivor(모의투자) / retire(폐기) / candidate(유지)
    survivor_ids = {sv["id"] for sv in survivors}
    for s in scored:
        if s["id"] in retire_ids:
            db.set_strategy_status(s["id"], "retired")
            log.info(f"  🗑 전략{s['id']} 폐기 (스크리닝 점수 하위)")
        elif s["id"] in survivor_ids:
            db.set_strategy_status(s["id"], "survivor")
        else:
            db.set_strategy_status(s["id"], "candidate")

    # 4) 다음 세대 생성: survivor(fitness 상위)들끼리 교차/변이
    keep_survivors = [s for s in scored if s["id"] in survivor_ids and s["id"] not in retire_ids]
    if not keep_survivors:
        keep_survivors = survivors  # 전부 폐기됐으면 fitness 상위 유지

    new_gen = current_generation + 1
    new_params_list = next_generation(keep_survivors, CFG.POPULATION_SIZE, CFG.MUTATION_RATE)
    existing = {json.dumps(s["params"], sort_keys=True) for s in keep_survivors}
    created = 0
    for params in new_params_list:
        if json.dumps(params, sort_keys=True) in existing:
            continue
        db.create_strategy(generation=new_gen, params=params,
                           parent_ids=[s["id"] for s in keep_survivors], status="candidate")
        created += 1
    log.info(f"세대 {current_generation} -> {new_gen} 교체 완료 "
             f"(모의투자 {len(keep_survivors)}명 유지, 폐기 {len(retire_ids)}개, 신규 {created}개)")
    return new_gen


def current_generation() -> int:
    with db.get_conn() as conn:
        row = conn.execute("SELECT MAX(generation) g FROM strategies").fetchone()
        return row["g"] if row and row["g"] is not None else 0


def get_quote_cached(symbol: str, max_age_sec: int = 600):
    """
    시세 조회 - 스냅샷(과거에 받은 데이터) 우선 사용.
    1) 최근 max_age_sec 이내 스냅샷이 있으면 API 호출 없이 그 값 사용
    2) 없으면 API로 조회 + 스냅샷 저장 (다음에 재사용)
    반환: {"price":.., "source": "snapshot"|"api"|"error", "age_sec":..}
    """
    # 1) 스냅샷 캐시 확인 (DB에 쌓인 데이터 재사용)
    try:
        snaps = db.get_snapshots(symbol=symbol, hours=24, limit=5)
        if snaps:
            last = snaps[-1]
            from datetime import datetime as _dt
            ts = _dt.fromisoformat(last["snapshot_time"])
            age = (now_kst() - ts).total_seconds()
            if 0 <= age < max_age_sec and last.get("price"):
                return {"price": last["price"], "source": "snapshot",
                        "age_sec": int(age), "symbol": symbol}
    except Exception:
        pass

    # 2) API 조회 + 저장 (재사용용)
    try:
        info = client.get_current_price(symbol)
        price = info.get("price", 0)
        if price and price > 0:
            nm = info.get("name") or symbol
            if nm and nm != symbol:
                db.save_symbol_name(symbol, nm)
            db.record_snapshot(symbol, price,
                               chegyul=info.get("chegyul"), rsi=info.get("rsi_14"))
            return {"price": price, "source": "api", "age_sec": 0, "symbol": symbol,
                    "name": nm}
        return {"price": 0, "source": "error", "symbol": symbol}
    except Exception as e:
        return {"price": 0, "source": "error", "symbol": symbol, "error": str(e)}


if __name__ == "__main__":
    db.init_db()
    bootstrap_population()
    print("엔진 로드 완료. webui.py 또는 main.py로 실행하세요.")
