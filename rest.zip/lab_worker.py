# -*- coding: utf-8 -*-
"""
🔬 장중 연구 워커 (lab_worker.py) - 2026-08-27 추가
================================================================
사용자: "장중에도 계속 테스트되어도 문제 없을 것들은 장 종료 기다리지 말고 지금 돌려라"

장중(09:40~15:30)에 놀고 있는 CPU로 '키움 API가 필요 없는' 연구 작업을 순환 실행:
  ① ⚾ 팜리그 1시즌 (로컬 일봉만 사용 - 시세/주문 API 0회)
  ② ♻️ 대기(backlog) 조건식 검증 (validate_backlog - 로컬 백테스트)
  ③ 🧱 슬롯 빌더 (2시간마다 1회 - 무거움)

안전 설계:
  - 스캘핑 집중 시간(09:00~09:40)은 쉼 (1분 주기 매매에 CPU 양보)
  - 매매/매도가드는 별도 스레드라 영향 없음 (이 워커는 계산만)
  - 장외에는 안 돎 (라운드가 같은 일을 이미 함 - 이중 실행 방지)
  - 작업 사이 3분 휴식 (CPU 독점 방지)
  - LAB_WORKER=false로 끌 수 있음

데스크톱 앱 시작 시 자동 기동 (sell_guard처럼 상시 스레드).
단독 테스트: python lab_worker.py --once
"""
import logging
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import sys
import threading
import time

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

log = logging.getLogger("lab_worker")

REST_SEC = _cfg_env_int("LAB_REST_SEC", 180)          # 작업 사이 휴식 (3분)
BUILDER_EVERY_SEC = _cfg_env_int("LAB_BUILDER_SEC", 7200)  # 빌더 주기 (2시간)
START_DELAY_SEC = _cfg_env_int("LAB_START_DELAY_SEC", 180)  # ★ 앱 시작 후 대기 (2026-08-28)
# 사고: 장중에 앱을 켜면 워커가 즉시 팜리그(CPU 몇 분 독점)를 돌려
#       GUI 창/8000 대시보드가 안 뜨는 것처럼 보임 → 3분 뒤부터 일 시작

_running = False
_thread = None
_last_builder = 0.0


def _in_work_window():
    """장중 + 스캘핑 시간 이후만 (09:40~15:30 거래일)"""
    try:
        from db import is_trading_day
        now = db.now_kst()
        if not is_trading_day(now.date()):
            return False
        hm = now.hour * 100 + now.minute
        return 940 <= hm <= 1530
    except Exception:
        return False


def work_once(log_fn=None):
    """1사이클: 팜리그 → backlog 검증 → (2시간마다) 빌더. 반환: 실행한 작업 목록"""
    global _last_builder

    def L(m):
        log.info(m)
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    done = []
    # ① 팜리그 1시즌 (로컬 데이터만)
    try:
        import farm_league
        r = farm_league.run_season(log_fn=log_fn)
        if r and not r.get("error"):
            done.append(f"팜시즌{r.get('season')}")
            if r.get("debut"):
                L(f"🔬 [장중연구] 팜 데뷔 {len(r['debut'])}명 (backlog - 검증 후 운영)")
    except Exception as e:
        L(f"🔬 팜리그 오류(계속): {str(e)[:50]}")
    # ② backlog 검증 (데뷔 대기줄 처리 - 로컬 백테스트만)
    try:
        import lifecycle
        res = lifecycle.validate_backlog()
        if res:
            done.append(f"대기검증{len(res)}")
    except Exception as e:
        L(f"🔬 대기검증 오류(계속): {str(e)[:50]}")
    # ③ 슬롯 빌더 (2시간마다 - 무거움)
    try:
        if time.time() - _last_builder > BUILDER_EVERY_SEC:
            _last_builder = time.time()
            import slot_builder
            b = slot_builder.build(register=True, log_fn=log_fn)
            if b.get("registered"):
                done.append(f"빌더등록{len(b['registered'])}")
    except Exception as e:
        L(f"🔬 빌더 오류(계속): {str(e)[:50]}")
    return done


def start_worker(log_fn=None):
    """상시 워커 스레드 (앱 시작 시 호출 - 장중에만 실제 작업)"""
    global _running, _thread
    if os.getenv("LAB_WORKER", "true").lower() != "true":
        return False
    if _thread is not None and _thread.is_alive():
        return False

    def _loop():
        log.info("🔬 장중 연구 워커 시작 (09:40~15:30 · 팜리그/대기검증/빌더 - 키움 API 미사용)")
        # ★ 낮은 우선순위 (Windows): GUI/서버/매매 스레드에 CPU 양보
        try:
            if sys.platform == "win32":
                import ctypes
                ctypes.windll.kernel32.SetThreadPriority(
                    ctypes.windll.kernel32.GetCurrentThread(), -2)  # BELOW_NORMAL
        except Exception:
            pass
        # ★ 앱 완전 기동 대기 (창/대시보드/브라우저 먼저)
        for _ in range(START_DELAY_SEC):
            if not _running:
                return
            time.sleep(1)
        while _running:
            try:
                if _in_work_window():
                    done = work_once(log_fn=log_fn)
                    if done and log_fn:
                        try:
                            log_fn(f"🔬 [장중연구] {' · '.join(done)} 완료 (매매와 병행)")
                        except Exception:
                            pass
                # 휴식 (장외/점심엔 그냥 대기)
            except Exception as e:
                log.warning(f"🔬 워커 오류(계속): {str(e)[:60]}")
            for _ in range(REST_SEC):
                if not _running:
                    break
                time.sleep(1)

    _running = True
    _thread = threading.Thread(target=_loop, daemon=True)
    _thread.start()
    return True


def stop_worker():
    global _running
    _running = False


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--once", action="store_true", help="윈도우 무시하고 1사이클")
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    db.init_db()
    if args.once:
        print("실행:", work_once(log_fn=print))
    else:
        print("장중 윈도우:", _in_work_window())
