@echo off
REM ============================================================
REM  Find what is calling main.py (old program remnants)
REM ============================================================
setlocal
cd /d "%~dp0"

echo [1] main.py in this folder?
if exist main.py (echo   FOUND: main.py in rest folder!) else (echo   OK: no main.py here)
echo.
echo [2] Old exe files in this folder and dist:
dir /b *.exe 2>nul
dir /b dist\*.exe 2>nul
echo.
echo [3] Old spec files (PyInstaller build leftovers):
dir /b *.spec 2>nul
echo.
echo [4] Startup programs containing kiwoom/main/stock:
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" 2>nul | findstr /i "kiwoom main stock auto"
echo.
echo [5] Scheduled tasks containing kiwoom/stock:
schtasks /query /fo list 2>nul | findstr /i "kiwoom stock main"
echo.
echo [6] Currently running python/exe processes:
tasklist | findstr /i "python KiwoomAI main"
echo.
echo Copy ALL output above and send it.
pause
