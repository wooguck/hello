@echo off
title Collect Data - Auto Daily
cd /d %~dp0
echo.
echo ============================================
echo  Auto data collector (keep this window open)
echo  - Collects automatically after market close
echo  - Works on weekends too (waits for next day)
echo  - Close window to stop. Ctrl+C to exit.
echo ============================================
python collect_data.py --watch
pause
