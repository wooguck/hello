# -*- coding: utf-8 -*-
"""
🏆 명예의 전당 성적표 (hof_report.py)
======================================
명예의 전당에 오른 조건식들의 "등재 당시 성적"과 "그 후 실제 성적"을 비교.
등재됐다고 끝이 아니라 - 지금도 잘하고 있는지 추적하는 도구.

표시:
  - 등재 성적 (등재 시점의 승률/PF)
  - 실전 성적 (모의매매 청산 기록 기준 - 최신)
  - 최근 성적 (최근 7일 청산만)
  - 판정: 유지 / 식어감(등재 때보다 하락) / 표본부족

실행:
  python hof_report.py
"""
import json
import sys

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db


def cond_live_stats(cond_key, days=None):
    """조건식의 실제 모의매매 청산 성적"""
    q = ("SELECT ret_pct FROM paper_positions WHERE status='closed' AND cond_key=?")
    args = [str(cond_key)]
    if days:
        q += " AND exit_time > datetime('now', ?)"
        args.append(f"-{days} days")
    with db.get_conn() as conn:
        rows = conn.execute(q, args).fetchall()
    rets = [r["ret_pct"] or 0 for r in rows]
    if not rets:
        return None
    wins = [r for r in rets if r > 0]
    gl = abs(sum(r for r in rets if r <= 0)) or 0.001
    return {"n": len(rets), "win_rate": round(len(wins) / len(rets) * 100, 1),
            "avg": round(sum(rets) / len(rets), 2),
            "pf": round(sum(wins) / gl, 2)}


def main():
    hof_active = db.hof_list(limit=50, ranked_only=True)
    hof_all = db.hof_list(limit=200, ranked_only=False)
    print("=" * 74)
    print(f"🏆 명예의 전당 성적표  (활성 {len(hof_active)}건 · 이력 {len(hof_all)}건)")
    print("=" * 74)
    if not hof_all:
        print("아직 등재된 조건식 없음 (모의매매 청산 3건+ & 승률 50%+ 되면 자동 등재)")
        return

    print(f"\n{'조건식':34} {'등재성적':>12} {'전체실전':>14} {'최근7일':>12} 판정")
    print("-" * 84)
    for h in hof_all:
        txt = (h.get("cond_txt") or "")[:32]
        ck = h.get("cond_key")
        enroll = f"{h.get('best_win_rate') or 0:.0f}%/{h.get('best_pf') or 0:.1f}"
        live = cond_live_stats(ck)
        recent = cond_live_stats(ck, days=7)
        ranked = "🏆" if h.get("ranked") else "  "
        if live is None:
            lt, rt, verdict = "-", "-", "표본 없음"
        else:
            lt = f"{live['win_rate']:.0f}%/{live['n']}건/{live['avg']:+.1f}%"
            rt = (f"{recent['win_rate']:.0f}%/{recent['n']}건" if recent else "-")
            # 판정: 최근이 등재 성적보다 크게 식었나
            if live["n"] < 5:
                verdict = "표본부족(5건 미만)"
            elif recent and recent["n"] >= 3 and recent["win_rate"] < 40:
                verdict = "🔻 식어감 - 주시"
            elif live["win_rate"] >= (h.get("best_win_rate") or 50) - 10:
                verdict = "✅ 유지"
            else:
                verdict = "🟡 등재 때보다 하락"
        print(f"{ranked}{txt:34} {enroll:>12} {lt:>14} {rt:>12} {verdict}")

    print("\n읽는 법:")
    print("  등재성적 = 명예의 전당에 오를 때의 승률/PF (그 순간의 성적)")
    print("  전체실전 = 지금까지 모의매매 청산 전체 (승률/건수/평균수익)")
    print("  최근7일  = 최근에도 잘하고 있는가 (식어가는 조건식 조기 발견)")
    print("  🏆 = 현재 활성(상위 랭킹) · 없으면 이력만 보존")


if __name__ == "__main__":
    main()
