"""
조건식 관리자 (condition_manager.py) — 모의 매매 성적표의 핵심
================================================================
사용자 요청: "검색식 모의로 테스트, 10개씩 돌리고, 싹수없는 건 뒤로 빼고,
매수 없으면 추가, 너무 많이 매수되면 변형. Gemini가 자동 변형.
원형 1,2,3... 변형 1-1, 1-2, 1-1-1... 저장. 승률만 보면 됨."

기능:
  - init_conditions(): 사진 조건식 템플릿 → 원형 조건식 1,2,3... 등록 (첫 실행 시)
  - batch_to_test(n=10): 테스트할 활성 조건식 10개 (테스트 적게 된 순) → cond_key 목록
  - run_batch(): 10개 배치를 전 종목 스캔해 모의 매수/청산 (paper_test) → rounds_tested++
  - manage(): 싹수없는 것 backlog 이동 / 매수 0건 → 완화 변형 / 과다 매수 → 강화 변형
    (Gemini 키 있으면 Gemini가 변형 생성, 없으면 규칙 변형)
  - ledger(cid): 조건식이 매수한 종목 목록 (UI 클릭 → 차트)

실행: python condition_manager.py --init / --batch / --manage / --list
"""
import json
import logging
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import random

import db
from config import CFG

log = logging.getLogger("cond_mgr")

BACKLOG_ROUNDS = _cfg_env_int("COND_BACKLOG_ROUNDS", 3)   # N라운드 테스트 후 0매수/승률 낮으면 뒤로
MIN_WIN_RATE = _cfg_env_float("COND_MIN_WIN_RATE", 45.0)  # 이 승률 미만이면 뒤로
MAX_BUYS = _cfg_env_int("COND_MAX_BUYS", 25)              # 이보다 많이 매수되면 과다 → 강화 변형
ZERO_SIGNAL_ROUNDS = _cfg_env_int("COND_ZERO_ROUNDS", 2)  # N라운드 매수 0이면 완화 변형


def init_conditions():
    """사진 조건식 템플릿 → 원형 1,2,3... 등록 (조건식 없을 때만)"""
    if db.get_conditions():
        return 0
    try:
        from photo_conditions import PHOTO_TEMPLATES, template_slots, template_txt
    except Exception as e:
        log.warning(f"사진 템플릿 로드 실패: {e}")
        return 0
    # ★ 봉 기준 표기 맵 (사진 조건식의 [일]/[주]/[월]/[3분] 등)
    TF_TXT = {"day": "[일]", "week": "[주]", "month": "[월]",
              "min1": "[1분]", "min3": "[3분]", "min15": "[15분]"}
    n = 0
    for tpl in PHOTO_TEMPLATES:
        slots = template_slots(tpl)
        tf = tpl.get("tf", "day")
        no = db.next_cond_no()
        # ★ 봉 기준을 텍스트 맨 앞에 표시 (예: "[3분] MACD Signal 상향돌파 ...")
        txt = f"{TF_TXT.get(tf, '[일]')} {template_txt(slots)}"
        db.create_condition(no, txt, slots, source="photo", tf=tf)
        n += 1
    log.info(f"원형 조건식 {n}개 등록 (사진 템플릿 · 봉 기준 포함)")
    return n


def list_conditions_with_stats(include_retired=False):
    """조건식 + 모의 매매 성적표 (UI 테이블용)
    반환: [{id, cond_no, cond_txt, status, rounds_tested, stats:{...}}]
    ★ 2026-09-01 사용자: "퇴출된 조건식도 안 보이게" - 기본은 retired 제외
      (보고 싶으면 include_retired=True 또는 revive_retired.py --list)
    """
    conds = db.get_conditions(status=None)
    if not include_retired:
        conds = [c for c in conds if c.get("status") != "retired"]
    stats = db.paper_stats_per_condition()
    out = []
    for c in conds:
        st = stats.get(str(c["id"]), {})
        out.append({**c, "stats": st})
    return out


def batch_to_test(n=10):
    """테스트할 활성 조건식 n개: (매수건수 적은 순 → cond_no 순) - 10개씩"""
    conds = db.get_conditions(status="active")
    if not conds:
        return []
    stats = db.paper_stats_per_condition()
    def _key(c):
        st = stats.get(str(c["id"]), {})
        return (st.get("buys", 0), c["cond_no"])
    conds.sort(key=_key)
    return conds[:n]


def _slots_of(cond):
    try:
        return json.loads(cond.get("slots_json") or "[]")
    except Exception:
        return []


def run_batch(n=10):
    """★ 10개 배치 모의 매매: 전 종목 스캔 → 진입/청산
    반환: {"conditions": n, "entered": k, "exited": k, "ledger": [...], "log": [...]}
    """
    import paper_test
    conds = batch_to_test(n=n)
    if not conds:
        return {"conditions": 0, "entered": 0, "exited": 0, "ledger": [], "log": ["등록된 조건식 없음 - init 필요"]}
    cond_list = [{"cond_key": str(c["id"]), "cond_no": c["cond_no"],
                  "cond_txt": c["cond_txt"], "slots": _slots_of(c),
                  "tf": c.get("tf") or "day"} for c in conds]
    r = paper_test.run_paper_once(conditions=cond_list, scan_all=True)
    for c in conds:
        db.touch_condition_tested(c["id"])
    r["conditions"] = len(conds)
    r["log"] = [f"조건식 {len(conds)}개 배치 · 진입 {len(r.get('entered', []))}건 · "
                f"청산 {len(r.get('exited', []))}건"]
    return r


def _variation_rule(cond, direction):
    """규칙 기반 변형: 방향에 따라 파라미터 완화/강화 + 슬롯 교체"""
    slots = _slots_of(cond)
    if not slots:
        return None
    # 1) 파라미터 튜닝 (있는 슬롯 중)
    import copy
    new_slots = copy.deepcopy(slots)
    tweaked = False
    for i, (k, p) in enumerate(new_slots):
        if k == "mom5_up":
            p["x"] = max(1, p.get("x", 3) + (-1 if direction == "loosen" else 1))
            tweaked = True
        elif k == "mom5_down":
            p["x"] = max(3, p.get("x", 5) + (1 if direction == "loosen" else -1))
            tweaked = True
        elif k == "vol_ratio20":
            p["x"] = round(max(1.0, p.get("x", 2.0) + (-0.5 if direction == "loosen" else 0.5)), 1)
            tweaked = True
        elif k == "rsi_under":
            p["x"] = max(20, p.get("x", 34) + (5 if direction == "loosen" else -4))
            tweaked = True
        elif k == "rsi_overbought" or k == "rsi_oversold":
            p["x"] = p.get("x", 60)
            tweaked = True
        if tweaked:
            break
    if not tweaked:
        # 2) 슬롯 1개 교체 (더 느슨/엄격한 조건으로)
        from screener import SLOTS
        keys = list(SLOTS.keys())
        if direction == "loosen":
            rep = "ma_above"          # 추세 조건 (가볍게)
        else:
            rep = "high_break"        # 강한 조건
        if len(new_slots) >= 2:
            new_slots[-1] = (rep, {})
            tweaked = True
    if not tweaked:
        return None
    from screener import slot_txt
    txt = " AND ".join(slot_txt(k, p) for k, p in new_slots)
    return {"slots": new_slots, "txt": txt}


def _variation_gemini(cond):
    """Gemini 변형 생성 (키 있으면) - 2~3개 제안, 없으면 None"""
    try:
        from ai_judge import call_llm
        from screener import SLOTS, slot_txt
        import json as _json
        cur = " AND ".join(slot_txt(k, p) for k, p in _slots_of(cond))
        # ★ 봉 기준(tf) 전달: 사진 조건식의 [일]/[주]/[월]/[분] 유지
        tf = cond.get("tf") or "day"
        tf_txt = {"day": "일봉", "week": "주봉", "month": "월봉",
                  "min1": "1분봉", "min3": "3분봉", "min15": "15분봉"}.get(tf, "일봉")
        prompt = (
            f"당신은 조건검색식(주식) 튜닝 전문가입니다. 아래 조건식의 '변형 3개'를 만들어주세요.\n"
            f"★ 중요: 이 조건식은 [{tf_txt}] 기준입니다. 변형도 반드시 같은 봉 기준({tf_txt})으로 만들어야 합니다.\n"
            "변형은 (1) 파라미터를 조금 바꾸거나 (2) 조건 하나를 비슷한 다른 조건으로 교체한 것입니다.\n"
            f"원본: {cur}\n\n"
            f"사용 가능한 조건: {list(SLOTS.keys())}\n"
            "JSON 배열만 출력하세요: [{\"slots\": [[\"슬롯키\", {\"파라미터\": 값}], ...], \"txt\": \"조건식 문장\"}, ...]"
        )
        raw = call_llm("조건검색식 변형 전문가", prompt)
        s = raw.strip()
        if s.startswith("```"):
            s = s.strip("`").lstrip("json")
        i1, i2 = s.find("["), s.rfind("]")
        if i1 < 0 or i2 <= i1:
            return []
        arr = _json.loads(s[i1:i2 + 1])
        out = []
        for item in arr[:3]:
            slots = item.get("slots") or []
            if not slots:
                continue
            txt = item.get("txt") or " AND ".join(slot_txt(k, p) for k, p in slots)
            out.append({"slots": slots, "txt": txt[:120]})
        return out
    except Exception:
        return []


def manage(max_variations=3):
    """★ 자동 관리 (라운드마다 호출):
    - 매수 0건 N라운드 / 승률 낮음 → backlog(뒤로)
    - 매수 0건 (아직 backlog 아님) → 완화 변형 1-1 생성
    - 과다 매수(MAX_BUYS+) → 강화 변형 1-2 생성
    - Gemini 변형 우선, 실패 시 규칙 변형
    반환: {"backlogged":[...], "variations":[{no, parent, txt}...], "log":[...]}
    """
    log_info = []
    def _log(m):
        log_info.append(m)
        log.info(m)
    stats = db.paper_stats_per_condition()
    conds = db.get_conditions(status="active")
    backlogged, variations = [], []

    for c in conds:
        cid = c["id"]
        st = stats.get(str(cid), {})
        buys = st.get("buys", 0)
        closed = st.get("sells", 0)
        wr = st.get("win_rate", 0)
        # 1) 싹수없는 것 → backlog (뒤로)
        if c["rounds_tested"] >= BACKLOG_ROUNDS and closed >= 3 and wr < MIN_WIN_RATE:
            db.set_condition_status(cid, "backlog")
            backlogged.append(c["cond_no"])
            _log(f"뒤로: {c['cond_no']} (승률 {wr}% < {MIN_WIN_RATE}%)")
            continue
        if c["rounds_tested"] >= BACKLOG_ROUNDS and buys == 0:
            db.set_condition_status(cid, "backlog")
            backlogged.append(c["cond_no"])
            _log(f"뒤로: {c['cond_no']} (매수 0건 {c['rounds_tested']}라운드)")
            continue
        # 2) 변형 대상: 매수 0건(완화) / 과다 매수(강화)
        direction = None
        if c["rounds_tested"] >= ZERO_SIGNAL_ROUNDS and buys == 0:
            direction = "loosen"
        elif buys >= MAX_BUYS:
            direction = "tighten"
        if not direction:
            continue
        # ★ 표본 부족 가드: 매도 3건 미만이면 변형 대신 더 테스트 (우연한 3건으로 변형 도배 방지)
        if closed < 3:
            _log(f"변형 대기: {c['cond_no']} 매도 {closed}건(3건 미만) - 더 테스트 후 변형")
            continue
        if len(variations) >= max_variations:
            break
        # ★ 중복 방지: 기존 활성 조건식(부모 포함)과 같은 내용이면 변형을 만들지 않음
        #   (순서만 바뀐/미세 수치만 다른 것은 정규화 시그니처로 동일 판정)
        existing_sigs = set()
        try:
            for ec in db.get_conditions(status="active"):
                try:
                    existing_sigs.add(db.normalize_slots(_slots_of(ec)))
                except Exception:
                    pass
        except Exception:
            pass
        # Gemini 변형 시도 → 실패 시 규칙
        vlist = _variation_gemini(c) if direction else []
        if not vlist:
            v = _variation_rule(c, "loosen" if direction == "loosen" else "tighten")
            vlist = [v] if v else []
        for v in vlist[:2]:
            try:
                vsig = db.normalize_slots(v["slots"])
            except Exception:
                vsig = None
            if vsig and vsig in existing_sigs:
                _log(f"변형 스킵: 기존 조건식과 동일 내용 (순서/수치만 다름 - 중복 방지)")
                continue
            if vsig:
                existing_sigs.add(vsig)
            no = db.next_cond_no(c["cond_no"])
            # ★ 봉 기준(tf) 유지: 부모와 같은 봉 기준으로 변형 저장
            # ★ 원본은 그대로 유지 (parent_no만 기록 - 변형은 별도 번호)
            _vcid = db.create_condition(no, v["txt"], v["slots"],
                                        source="gemini" if direction else "rule",
                                        parent_no=c["cond_no"], tf=c.get("tf") or "day")
            # ★ 2026-09-02: 변형도 backlog부터 (기존엔 기본값 active라 검증 없이 매수에 쓰임
            #   - 사용자: "새 조건식이 전체 검증을 받은 게 아니라서 애매함")
            #   lifecycle 대기검증(400종목) → 통과해야 운영행. 부모는 그대로 운영 유지.
            try:
                if _vcid:
                    db.set_condition_status(_vcid, "backlog")
            except Exception:
                pass
            # ★ 변형 diff 기록: 원본과 무엇이 달라졌는지 (가상 검증용)
            try:
                diff = _diff_slots(_slots_of(c), v["slots"])
            except Exception:
                diff = ""
            variations.append({"no": no, "parent": c["cond_no"], "txt": v["txt"][:60],
                               "diff": diff, "direction": direction})
            _log(f"변형 {no} (부모 {c['cond_no']}, {'완화' if direction=='loosen' else '강화'}): "
                 f"{v['txt'][:40]} | 변경: {diff[:50]}")
    return {"backlogged": backlogged, "variations": variations, "log": log_info}


def ledger(cid):
    """조건식의 매수 종목 내역 (UI 클릭 → 종목 → 차트)"""
    rows = db.condition_ledger(cid)
    out = []
    for r in rows:
        ret = r.get("ret_pct")
        out.append({"symbol": r["symbol"], "name": db.get_symbol_name(r["symbol"]),
                    "entry": r["entry_price"], "qty": r["qty"], "status": r["status"],
                    "ret": ret, "exit": r.get("exit_price")})
    return out


# ══════════════════════════════════════════════════════════════
# ★ 1) 사진 원형 전체 실제 모의 매매 (사용자: "사진 검색식 한번씩 실제로 다 돌려보고")
# ══════════════════════════════════════════════════════════════

def run_all_originals(batch_size=10, max_new_per_cond=5):
    """원형(1~N, 부모 없는 조건식) 전부를 실제 모의 매매로 돌리기 (배치로 나눠)
    반환: {"conditions": n, "entered": k, "log": [...]}
    """
    import paper_test
    log_info = []
    def _log(m):
        log_info.append(m)
        log.info(m)
    originals = [c for c in db.get_conditions(status="active") if "-" not in c["cond_no"]]
    if not originals:
        return {"conditions": 0, "entered": 0, "log": ["원형 조건식 없음 - '🧬 원형 등록(사진)' 먼저"]}
    cond_list = [{"cond_key": str(c["id"]), "cond_no": c["cond_no"],
                  "cond_txt": c["cond_txt"], "slots": _slots_of(c),
                  "tf": c.get("tf") or "day"} for c in originals]
    total_entered = 0
    # 배치로 나눠 실제 모의 매매 (각 조건식 최대 max_new_per_cond건)
    for i in range(0, len(cond_list), batch_size):
        batch = cond_list[i:i + batch_size]
        r = paper_test.run_paper_once(conditions=batch, max_new=batch_size * max_new_per_cond,
                                      scan_all=True)
        total_entered += len(r.get("entered", []))
        _log(f"배치 {i//batch_size+1}: {len(batch)}개 → 진입 {len(r.get('entered', []))}건")
        for c in [x for x in originals if any(b["cond_key"] == str(x["id"]) for b in batch)]:
            db.touch_condition_tested(c["id"])
    _log(f"원형 {len(originals)}개 전부 실제 모의 매매 완료 · 총 진입 {total_entered}건")
    return {"conditions": len(originals), "entered": total_entered, "log": log_info}


# ══════════════════════════════════════════════════════════════
# ★ 2) 가상 백테스트 (백필 데이터로 같은 조건식 재현 - 실제 vs 가상 비교용)
# ══════════════════════════════════════════════════════════════



def _diff_slots(old_slots, new_slots):
    """★ 변형 diff: 원본과 무엇이 바뀌었는지 사람이 읽는 텍스트
    예: "vol_ratio20 x: 1.5→2.0 · ma_align 제거" (가상 검증/리포트용)
    """
    from screener import slot_txt
    o = {slot_txt(k, p): (k, p) for k, p in (old_slots or [])}
    n = {slot_txt(k, p): (k, p) for k, p in (new_slots or [])}
    parts = []
    # 추가된 것
    for txt, (k, p) in n.items():
        if txt not in o:
            parts.append(f"+{txt}")
    # 제거된 것
    for txt, (k, p) in o.items():
        if txt not in n:
            parts.append(f"-{txt}")
    # 파라미터 변경
    for txt, (k, p) in o.items():
        if txt in n:
            np_ = n[txt][1]
            for pk in set(p) | set(np_):
                ov, nv = p.get(pk), np_.get(pk)
                if ov != nv:
                    parts.append(f"{k}.{pk}: {ov}→{nv}")
    return " | ".join(parts) if parts else "(변경 없음)"

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="조건식 관리자")
    parser.add_argument("--init", action="store_true")
    parser.add_argument("--batch", action="store_true")
    parser.add_argument("--manage", action="store_true")
    parser.add_argument("--list", action="store_true")
    args = parser.parse_args()
    db.init_db()
    logging.basicConfig(level=logging.INFO)
    if args.init:
        print("원형 등록:", init_conditions())
    elif args.list:
        for c in list_conditions_with_stats():
            st = c["stats"]
            print(f"{c['cond_no']:>6} {c['status']:>7} 매수{st.get('buys',0):>3} "
                  f"매도{st.get('sells',0):>3} 순손익{st.get('net',0):>8,} "
                  f"승률{st.get('win_rate',0):>5}%  {c['cond_txt'][:45]}")
    elif args.batch:
        r = run_batch()
        print(r["log"])
    elif args.manage:
        m = manage()
        for l in m["log"]:
            print(l)


def virtual_validate_variation(parent_id, variation_id, max_symbols=60):
    """★ 변형 가상 검증: 원본(parent) vs 변형(variation) 성과 비교 리포트
    - 둘 다 동일 데이터로 검증(validation 엔진) → 승률/평균/등급 비교
    - diff(무엇이 바뀌었는지)와 함께 "이 변형이 성과에 미친 영향" 요약
    - 결과: {parent_grade, var_grade, better/worse, diff, note}
    """
    try:
        import validation
        from screener import slot_txt
        parent = db.get_condition_by_id(parent_id)
        var = db.get_condition_by_id(variation_id)
        if not parent or not var:
            return {"error": "조건식 없음"}
        p_slots = json.loads(parent.get("slots_json") or "[]")
        v_slots = json.loads(var.get("slots_json") or "[]")
        # 둘 다 같은 종목/기간으로 검증
        p_r = validation.validate_condition(
            {"cond_key": f"P{parent_id}", "cond_txt": parent["cond_txt"], "slots": p_slots},
            max_symbols=max_symbols)
        v_r = validation.validate_condition(
            {"cond_key": f"V{variation_id}", "cond_txt": var["cond_txt"], "slots": v_slots},
            max_symbols=max_symbols)
        p_s, v_s = p_r.get("stats") or {}, v_r.get("stats") or {}
        p_grade, v_grade = p_r.get("grade", "기각"), v_r.get("grade", "기각")
        p_wr, v_wr = p_s.get("win_rate", 0), v_s.get("win_rate", 0)
        p_avg, v_avg = p_s.get("avg_ret", 0), v_s.get("avg_ret", 0)
        diff = _diff_slots(p_slots, v_slots)
        # 판정
        grade_rank = {"채택 후보": 0, "조건부": 1, "수익만": 2, "기각": 3}
        better = grade_rank.get(v_grade, 9) < grade_rank.get(p_grade, 9) or \
                 (v_grade == p_grade and v_avg > p_avg)
        note = (f"원본 승률 {p_wr}%·평균 {p_avg}% → 변형 승률 {v_wr}%·평균 {v_avg}% | "
                f"변경: {diff}")
        return {"parent_grade": p_grade, "var_grade": v_grade,
                "parent_win_rate": p_wr, "var_win_rate": v_wr,
                "parent_avg": p_avg, "var_avg": v_avg,
                "better": better, "diff": diff, "note": note}
    except Exception as e:
        return {"error": str(e)[:80]}
