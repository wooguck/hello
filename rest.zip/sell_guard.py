# -*- coding: utf-8 -*-
"""
🛡 매도 가드 (sell_guard.py) - 라운드와 무관하게 손절/지침을 지키는 독립 감시자
==============================================================================
문제(사용자 보고): 자동 파일럿 라운드가 1단계(자료수집)에서 오래 걸리면
매도 체크(라운드 3단계)까지 도달하지 못해 손절가를 지나쳐도 매도가 안 나감.

해결: 매도 판단만 하는 "가드 스레드"를 라운드와 별개로 상시 가동.
  - 90초마다 보유 포지션 검사 (장중에만 주문)
  - 지침 손절가(stop_price) 이탈 / 하드손절(-3%) → 즉시 매도 (AI 안 기다림)
  - 수집/검증이 몇 시간 걸려도 손절은 절대 놓치지 않음
  - AI 매도(수익청산 등)는 기존 라운드가 계속 담당 (가드는 '안전벨트'만)

데스크톱 앱 시작 시 자동 기동 (desktop_app.main → start_guard()).
단독 실행: python sell_guard.py   (테스트/보조용)
"""
import logging
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import sys
import threading
import time
from datetime import datetime

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db
from config import CFG

log = logging.getLogger("sell_guard")

CHECK_SEC = _cfg_env_int("SELL_GUARD_SEC", 45)   # 검사 주기 (90→45초 - 2026-08-28 고점 추적 강화)


def check_once(log_fn=None):
    """보유 포지션 1회 검사 → 손절 조건이면 즉시 매도.
    반환: {"checked": n, "sold": [...], "note": str}
    ★ 새벽 점검 시간대(04:30~07:30)는 검사 자체를 생략 (키움/시세 API 오류 방지)
    """
    try:
        from kiwoom_client import KiwoomClient
        if KiwoomClient._in_maintenance_window():
            return {"checked": 0, "sold": [], "note": "새벽 점검시간 - 감시 일시정지 (07:30 재개)"}
    except Exception:
        pass

    def _log(msg):
        log.info(msg)
        if log_fn:
            try:
                log_fn(msg)
            except Exception:
                pass

    import paper_test
    # ★ 2026-08-28 키움 실체결가 동기화 (사용자: "키움서버와 매수/매도 내용 정확 일치")
    #   실제 계좌 보유의 '평균단가'로 real 포지션 entry_price 보정 (기록가 ≠ 체결가 괴리 제거)
    try:
        if not CFG.DRY_RUN and paper_test._in_market_hours():
            _hold = paper_test._real_account_holdings(None)
            if _hold:
                for _pos in db.get_paper_open():
                    if _pos.get("order_kind") != "real":
                        continue
                    _h = _hold.get(_pos["symbol"])
                    if not _h or not _h.get("avg_price"):
                        continue
                    _ap = float(_h["avg_price"])
                    _ep = float(_pos["entry_price"] or 0)
                    if _ep > 0 and abs(_ap - _ep) / _ep > 0.001:   # 0.1%+ 괴리만 보정
                        with db.get_conn() as _c:
                            _c.execute("UPDATE paper_positions SET entry_price=? WHERE id=?",
                                       (_ap, _pos["id"]))
                        _log(f"🔄 [체결동기화] {_pos['symbol']} 기록가 {_ep:,.0f} → "
                             f"키움 체결단가 {_ap:,.0f}")
    except Exception:
        pass
    in_market = paper_test._in_market_hours()
    hard = float(getattr(CFG, "HARD_STOP_LOSS_PCT", 3.0))
    scalp_sl = _cfg_env_float("SCALP_SL_PCT", 0.4)
    # ★ 2026-08-28 이익보호선 (사용자: "많이 올랐는데 안 팔다가 떨어져서 매도" 수정)
    #   최고수익이 트리거(기본 +3%) 이상 찍히면 → 그 수익의 KEEP(기본 50%)을 바닥으로 잠금
    #   예: 최고 +8% → 바닥 +4%. 가격이 +4%로 내려오면 즉시 청산 (번 것 절반은 무조건 사수)
    #   90초 가드가 감시하므로 라운드/매매루프 지연과 무관
    pf_trig = _cfg_env_float("PROFIT_FLOOR_TRIGGER", 3.0)
    pf_keep = _cfg_env_float("PROFIT_FLOOR_KEEP", 0.5)
    sold = []
    opens = db.get_paper_open()
    for pos in opens:
        # ★ 2026-08-28: 가드는 신선한 가격으로 (기본 _get_price는 5분 캐시 - 90초 가드에 부적합)
        price = None
        try:
            from engine import get_quote_cached
            q = get_quote_cached(pos["symbol"], max_age_sec=60)
            price = q.get("price") if q else None
        except Exception:
            pass
        if not price:
            price = paper_test._get_price(pos["symbol"])
        if not price or price <= 0:
            continue
        ep = pos["entry_price"] or price
        ret = (price - ep) / ep * 100 if ep else 0
        # ★ 최고수익률 갱신 (2026-08-28 강화 - 사용자: "상승분 다 까먹고 매도, 고점에서 매도 안 됨")
        #   기존: 가드가 '검사 순간의 현재가'만 봐서 90초 사이 순간고점을 놓침
        #   수정: 당일 고가(fetch_live_quote의 high)로 재구성 - 검사 사이에 찍힌 고점도 반영
        hi = pos.get("highest_return") or 0
        try:
            _entry_day = str(pos.get("entry_time") or "")[:10]
            _today = db.now_kst().strftime("%Y-%m-%d")
            if _entry_day == _today:      # 당일 매수분: 당일 고가 = 보유 중 고점 (정확)
                from leader import fetch_live_quote
                _q = fetch_live_quote(pos["symbol"])
                if _q and _q.get("high") and ep:
                    _hi_day = (_q["high"] - ep) / ep * 100
                    if _hi_day > hi:
                        hi = round(_hi_day, 2)
                        db.update_paper_highest(pos["id"], hi)
        except Exception:
            pass
        if ret > hi:
            try:
                db.update_paper_highest(pos["id"], round(ret, 2))
            except Exception:
                pass
            hi = ret
        reason = None
        stp = pos.get("stop_price") or 0
        is_scalp = str(pos.get("cond_key") or "").startswith("SCALP")
        if stp and price <= stp:
            reason = f"[가드] 지침 손절가 {stp:,.0f} 이탈 ({ret:+.1f}%)"
        elif is_scalp and ret <= -max(scalp_sl, 0.2):
            # ★ 스캘핑 포지션은 자체 손절(-0.4%) 기준으로 가드 (하드손절 -3%까지 방치 방지)
            #   scalp 엔진이 죽거나 윈도우 밖에 남은 잔여 포지션 안전벨트
            reason = f"[가드] 스캘핑 손절 {ret:+.2f}% ≤ -{scalp_sl}%"
        elif hard > 0 and ret <= -hard:
            reason = f"[가드] 하드손절 {ret:+.1f}% ≤ -{hard}%"
        elif pf_trig > 0 and hi >= pf_trig and ret <= hi * pf_keep:
            # ★ 이익보호선: 최고 +hi% 찍었으면 hi×keep% 아래로 절대 안 내려가게
            reason = (f"[가드] 이익보호 청산 {ret:+.2f}% "
                      f"(최고 {hi:+.1f}%의 {pf_keep*100:.0f}%선 {hi*pf_keep:+.1f}% 이탈)")
        if not reason:
            continue
        # 장외면 주문 불가 - 다음 장중 검사에서 실행 (기록만)
        if not in_market:
            _log(f"🛡 {pos['symbol']} 손절 조건 감지({reason}) - 장외라 대기 (개장 후 즉시 매도)")
            continue
        order = None
        if not CFG.DRY_RUN:
            order = paper_test._place_real_order(pos["symbol"], "sell", pos["qty"], price)
            if order and order.get("status") == "error":
                _log(f"🛡⚠️ {pos['symbol']} 매도 주문 실패: {order.get('message', '')[:60]}")
                continue
        db.close_paper_position(pos["id"], price, ret, reason=reason)
        # ★ 2026-09-01: 가드 청산도 judgments에 기록 (현황판 'AI 판정 이력'에 근거로 표시)
        try:
            db.record_judgment(pos["symbol"], "sell", "손절" if ret < 0 else "수익청산",
                               "guard", reason=reason[:300])
        except Exception:
            pass
        sold.append({"symbol": pos["symbol"], "ret": round(ret, 2), "reason": reason})
        _log(f"🛡 [매도가드] 청산 {pos['symbol']} {ret:+.2f}% | {reason}"
             + (" (실제주문)" if order else ""))
    return {"checked": len(opens), "sold": sold,
            "note": "장중" if in_market else "장외(감시만)"}


# ── 상시 가드 스레드 ─────────────────────────────────────
_thread = None
_running = False


def start_guard(log_fn=None):
    """가드 스레드 시작 (앱에서 호출 - 이미 돌고 있으면 스킵)"""
    global _thread, _running
    if _thread is not None and _thread.is_alive():
        return False

    def _loop():
        log.info(f"🛡 매도 가드 시작 (주기 {CHECK_SEC}초 - 라운드와 무관하게 손절 감시)")
        while _running:
            try:
                check_once(log_fn=log_fn)
            except Exception as e:
                log.warning(f"🛡 가드 오류(계속 진행): {str(e)[:80]}")
            for _ in range(CHECK_SEC):
                if not _running:
                    break
                time.sleep(1)

    _running = True
    _thread = threading.Thread(target=_loop, daemon=True)
    _thread.start()
    return True


def stop_guard():
    global _running
    _running = False


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    db.init_db()
    print(f"🛡 매도 가드 단독 실행 (주기 {CHECK_SEC}초, Ctrl+C 종료)")
    r = check_once()
    print(f"첫 검사: 보유 {r['checked']}건 · 매도 {len(r['sold'])}건 · {r['note']}")
    start_guard()
    try:
        while True:
            time.sleep(60)
    except KeyboardInterrupt:
        stop_guard()
