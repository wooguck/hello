# -*- coding: utf-8 -*-
"""
🔗 매수 채널 자동 실행기 (channels_auto.py)
=============================================
유기성 감사에서 발견된 구멍: AI픽/급등/세력선/기준선 채널이 수동 전용
→ 장중 하루 1회씩 자동 실행 (모의매매 사이클에 연결)

- 각 채널은 독립 실행 (하나 실패해도 나머지 진행)
- 하루 1회 제한 (strategy/channels_state.json)
- 시간대 분배: 기준선/AI픽 09:10+ · 급등 10:00+ (초반 노이즈 회피) · 세력선 14:00+
- 채널별 on/off: .env (CH_AIPICK/CH_MOMENTUM/CH_FORCE/CH_BASELINE, 기본 true)
"""
import json
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import sys

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

STATE = os.path.join("strategy", "channels_state.json")


def _state():
    try:
        st = json.load(open(STATE, encoding="utf-8"))
        if st.get("date") != db.now_kst().strftime("%Y-%m-%d"):
            return {"date": db.now_kst().strftime("%Y-%m-%d"), "done": []}
        return st
    except Exception:
        return {"date": db.now_kst().strftime("%Y-%m-%d"), "done": []}


def _save(st):
    os.makedirs("strategy", exist_ok=True)
    json.dump(st, open(STATE, "w", encoding="utf-8"), ensure_ascii=False)


def _on(key):
    return os.getenv(key, "true").lower() == "true"


def run_channels(log_fn=None):
    """장중 사이클마다 호출 - 시간 되고 아직 안 한 채널만 실행. 반환: 실행 목록"""
    def _log(m):
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    now = db.now_kst()
    hm = now.hour * 100 + now.minute
    if not (900 <= hm <= 1500):
        return []
    # ★ 일일 손실 서킷브레이커: 한도 초과 시 채널 매수도 전부 정지 (RADAR 기록은 무해하지만 통일)
    try:
        import paper_test as _pt
        ok_cb, pnl_cb, lim_cb = _pt.daily_circuit_ok()
        if not ok_cb:
            _log(f"🚫 [서킷브레이커] 오늘 손실 {pnl_cb:+,.0f}원 > 한도 - 채널 매수 정지 (내일 해제)")
            return []
    except Exception:
        pass
    st = _state()
    ran = []

    # ★ 채널 실행 시각 (.env로 조절 가능 - 기본값은 개장 직후로 최대한 당김)
    #   BASELINE/AI_PICK: 전일 데이터 기반이라 9시 정각 매수 가능
    #   RADAR(갭스캔)/MOMENTUM: 당일 거래대금이 몇 분은 쌓여야 진짜/가짜 구분 가능
    #   FORCE_LINE: 투자자별(기관/외인) 수급은 장중 오후에나 윤곽 - 이르면 무의미
    #   ★★ 우선순위: strategy/channel_times.json (현황판에서 수정) > .env > 기본값
    _file_times = {}
    try:
        _file_times = json.load(open(os.path.join("strategy", "channel_times.json"),
                                     encoding="utf-8"))
    except Exception:
        pass

    def _t(key, default):
        if key in _file_times:
            try:
                return int(_file_times[key])
            except Exception:
                pass
        try:
            return int(os.getenv(key, str(default)))
        except Exception:
            return default
    T_BASELINE = _t("CH_T_BASELINE", 900)   # 9시 정각 (전일 데이터 - 지연 이유 없음)
    T_AIPICK = _t("CH_T_AIPICK", 901)       # 9시 1분 (전일 데이터 + AI 호출 시간)
    T_RADAR = _t("CH_T_RADAR", 902)         # 9시 2분 (개장 2분 거래대금으로 갭 진위 판별)
    T_MOMENTUM = _t("CH_T_MOMENTUM", 930)   # 9시 30분 (시초 가짜 급등 걸러진 후)
    T_FORCE = _t("CH_T_FORCE", 1400)        # 14시 (수급 데이터 윤곽 나온 후)

    def _try(name, min_hm, fn):
        if name in st["done"] or hm < min_hm:
            return
        try:
            fn()
            ran.append(name)
            _log(f"🔗 [채널] {name} 자동 실행 완료")
        except Exception as e:
            _log(f"🔗⚠️ [채널] {name} 실패(계속 진행): {str(e)[:50]}")
        st["done"].append(name)   # 실패해도 오늘은 재시도 안 함 (스팸 방지)

    # 📡 개장 직후: 급등 레이더 (시초 갭 스캔 - 매수 아님, 후보 기록만)
    def _radar():
        import preopen_radar as pr
        gaps = pr.opening_gap_scan()
        pr.save("opening_gap", gaps)
        if gaps:
            _log(f"📡 시초 갭 후보 {len(gaps)}개: "
                 + ", ".join(f"{g['name']}+{g['chg']:.0f}%" for g in gaps[:5]))
    _try("RADAR", T_RADAR, _radar)

    if _on("CH_BASELINE"):
        def _baseline():
            import baseline_channel as bc
            pool = bc.liquid_pool()
            if len(pool) >= 2:
                import random
                held = {p["symbol"] for p in db.get_paper_open()}
                picks = random.sample([s for s in pool if s not in held], 2)
                bc_buy(picks)
        def bc_buy(picks):
            import paper_test
            from config import CFG
            budget = _cfg_env_float("BASELINE_BUDGET", 0) or paper_test.buy_budget()  # ★ 공용 예산 (비율/금액)
            for sym in picks:
                price = paper_test._get_price(sym) or 0
                if price <= 0:
                    continue
                qty = int(budget / price)
                if qty < 1:
                    continue   # 가격 > 종목당 예산 - 스킵
                o = None
                if paper_test.REAL_PAPER_ORDER and not CFG.DRY_RUN:
                    o = paper_test._place_real_order(sym, "buy", qty, price)
                    if o and o.get("status") == "error":
                        continue
                # ★ 진입 슬리피지 (조건식 경로와 동일 - 5채널 비교 공정성, 2026-08-27)
                ep = price if (o and not CFG.DRY_RUN) else paper_test.entry_slip(price)
                db.open_paper_position("BASELINE", "[기준선] 무작위 (대조군)", sym, ep, qty,
                                       order_kind=("real" if o else "virtual"))
        _try("BASELINE", T_BASELINE, _baseline)

    if _on("CH_AIPICK"):
        def _aipick():
            import ai_picks
            cands = ai_picks.score_universe()
            picks = ai_picks.ai_select(cands, n=_cfg_env_int("AI_PICKS_PER_DAY", 3))
            ai_picks.buy_picks(picks, dry=False)
        _try("AI_PICK", T_AIPICK, _aipick)

    if _on("CH_MOMENTUM"):
        def _momentum():
            import momentum_channel as mc
            cands = mc.scan()
            mc.buy(cands, n=2)
        _try("MOMENTUM", T_MOMENTUM, _momentum)

    # 🎯 테마 헌터 (2026-08-27): 1일 1회가 아니라 장중 반복 - '그물에 N개 쌓이는 순간'이
    #   언제일지 모르므로 15분마다 재확인. 하루 매수 상한(THEME_MAX_BUY)은 내부에서 제어.
    if _on("CH_THEME") and hm >= _t("CH_T_THEME", 920):
        try:
            _tp = os.path.join("strategy", "theme_hunter.json")
            _stale = True
            try:
                _th = json.load(open(_tp, encoding="utf-8"))
                from datetime import datetime as _dtt
                _stale = (db.now_kst() - _dtt.fromisoformat(_th["updated_at"])).total_seconds() > 900
            except Exception:
                pass
            if _stale:
                import theme_hunter as _thm
                _st = _thm.hunt(log_fn=_log)
                if _st.get("leaders"):
                    _b = _thm.buy_leaders(_st, log_fn=_log)
                    if _b:
                        ran.append("THEME")
        except Exception as e:
            _log(f"🎯⚠️ 테마헌터 실패(계속): {str(e)[:50]}")

    if _on("CH_FORCE"):
        def _force():
            import force_line as fl
            syms = fl.liquid_symbols(top=100)
            names = {}
            try:
                for u in db.get_universe():
                    names[u.get("symbol")] = u.get("name") or ""
            except Exception:
                pass
            import time
            ranked = []
            for s in syms:
                rows = fl.fetch_trend(s)
                sc = fl.force_score(rows)
                if sc and sc["score"] >= 60:
                    ranked.append({"symbol": s, "name": names.get(s, ""), **sc})
                time.sleep(0.3)
            ranked.sort(key=lambda x: -x["score"])
            # 매집중(아직 안 오른 것)만 2종목
            import paper_test
            from config import CFG
            from ai_consult import build_sell_plan
            n = 0
            held = {p["symbol"] for p in db.get_paper_open()}
            for r in ranked:
                if n >= 2 or r["symbol"] in held or r["chg20"] > 15:
                    continue
                price = paper_test._get_price(r["symbol"]) or r["price"]
                qty = int((_cfg_env_float("AI_PICKS_BUDGET", 0) or paper_test.buy_budget()) / price)
                if qty < 1:
                    continue   # 가격 > 종목당 예산 - 스킵
                o = None
                if paper_test.REAL_PAPER_ORDER and not CFG.DRY_RUN:
                    o = paper_test._place_real_order(r["symbol"], "buy", qty, price)
                    if o and o.get("status") == "error":
                        continue
                # ★ 진입 슬리피지 (조건식 경로와 동일 - 5채널 비교 공정성, 2026-08-27)
                ep = price if (o and not CFG.DRY_RUN) else paper_test.entry_slip(price)
                plan = None
                try:
                    plan = build_sell_plan(r["symbol"], ep, qty)
                except Exception:
                    pass
                db.open_paper_position("FORCE_LINE",
                                       f"[세력선] 점수{r['score']} 20일 {r['cum20']:+,}주",
                                       r["symbol"], ep, qty,
                                       order_kind=("real" if o else "virtual"),
                                       target_price=(plan or {}).get("target_price"),
                                       stop_price=(plan or {}).get("stop_price"))
                n += 1
        _try("FORCE_LINE", T_FORCE, _force)

    if ran:
        _save(st)
    elif st["done"]:
        _save(st)
    return ran
