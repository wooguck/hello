@echo off
REM ============================================================
REM  DEBUG build: without --noconsole (console window stays open)
REM  When the exe crashes, the reason is shown in the console.
REM  Output: dist\KiwoomAIAuto_debug.exe
REM  After finding the cause, rebuild with build_exe.bat
REM ============================================================
setlocal
cd /d "%~dp0"

python -m PyInstaller --version >nul 2>&1
if errorlevel 1 pip install pyinstaller

python -m PyInstaller --onefile --name KiwoomAIAuto_debug ^
  --hidden-import engine ^
  --hidden-import ai_judge ^
  --hidden-import ai_consult ^
  --hidden-import backtest ^
  --hidden-import genetic ^
  --hidden-import strategy ^
  --hidden-import kiwoom_client ^
  --hidden-import db ^
  --hidden-import universe ^
  --hidden-import config ^
  --hidden-import web_status ^
  --hidden-import live_trader ^
  --hidden-import scalp ^
  --hidden-import leader ^
  --hidden-import validation ^
  --hidden-import collect_data ^
  --hidden-import value_watch ^
  --hidden-import surge_mining ^
  --hidden-import fundamentals ^
  --hidden-import cleanup_old ^
  --hidden-import realtime_bridge ^
  --hidden-import condition_manager ^
  --hidden-import photo_conditions ^
  --hidden-import daily_report ^
  --hidden-import charting ^
  --hidden-import auto_pilot ^
  --hidden-import teams ^
  --hidden-import strategy_auto ^
  --hidden-import backfill_history ^
  --hidden-import screener ^
  --hidden-import paper_test ^
  --hidden-import sell_guard ^
  --hidden-import lifecycle ^
  --hidden-import ai_coach ^
  --hidden-import governor ^
  --hidden-import channels_auto ^
  --hidden-import preopen_radar ^
  --hidden-import error_center ^
  --hidden-import baseline_channel ^
  --hidden-import momentum_channel ^
  --hidden-import ai_picks ^
  --hidden-import force_line ^
  --hidden-import robust_check ^
  --hidden-import pilot_board ^
  --hidden-import name_conditions ^
  --hidden-import param_optimizer ^
  --hidden-import visual_lab ^
  --hidden-import weekly_report ^
  --hidden-import trade_stats ^
  --hidden-import hof_report ^
  --hidden-import system_doctor ^
  --hidden-import quality_gate ^
  --hidden-import uprank_watch ^
  --hidden-import slot_builder ^
  --hidden-import multi_tf ^
  --hidden-import farm_league ^
  --hidden-import lab_worker ^
  --hidden-import us_sector ^
  --hidden-import theme_hunter ^
  --hidden-import gate_report ^
  --hidden-import sell_shadow ^
  --hidden-import loss_lessons ^
  --hidden-import spot_research ^
  --hidden-import revive_retired ^
  --noconfirm ^
  desktop_app.py

echo.
echo DONE! Run: dist\KiwoomAIAuto_debug.exe
echo (console window stays - crash reason will be visible there)
pause
