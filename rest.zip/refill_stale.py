# -*- coding: utf-8 -*-
"""
🔧 오래된(1월 멈춤) 종목 전용 재수집 + 소스 진단 (refill_stale.py)
==================================================================
"마지막 봉이 7일 이상 오래된" 종목만 골라서 네이버→다음→Yahoo 체인으로
다시 받습니다. 동시에 각 소스가 실제로 되는지/안 되는지 통계를 보여줘서
"왜 안 받아지는지"를 확정합니다.

실행:
  python refill_stale.py            # stale 전 종목 재수집
  python refill_stale.py --limit 20 # 20종목만 (빠른 진단용 - 먼저 이걸로!)
"""
import argparse
import os
import sqlite3
import sys
import time
from collections import Counter
from datetime import datetime, timedelta

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db
import backfill_history as bf
from config import CFG


def find_stale(days_old=7):
    """마지막 일봉이 days_old일보다 오래된 종목 (봉 30개 이상인 것만 - stale 전용)"""
    stocks_dir = os.path.join(db.DATA_DIR, "stocks")
    cut = (datetime.now() - timedelta(days=days_old)).strftime("%Y-%m-%d")
    stale = []
    if not os.path.isdir(stocks_dir):
        return stale
    dead = bf._load_dead()
    for f in os.listdir(stocks_dir):
        if not f.endswith(".db"):
            continue
        sym = f[:-3]
        if sym in dead:
            continue
        try:
            c = sqlite3.connect(os.path.join(stocks_dir, f))
            r = c.execute("SELECT COUNT(*), MAX(bar_date) FROM daily_bars").fetchone()
            c.close()
            if r and (r[0] or 0) >= 30 and (r[1] or "") < cut:
                stale.append((sym, r[1]))
        except Exception:
            continue
    stale.sort(key=lambda x: x[1])
    return stale


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=0, help="N종목만 (진단용)")
    args = ap.parse_args()

    print("=" * 64)
    print("🔧 오래된 종목 재수집 + 소스 진단")
    print("=" * 64)

    stale = find_stale()
    print(f"📋 오래된(7일+) 종목: {len(stale)}개")
    if stale:
        print(f"   가장 오래된 것: {stale[0][0]} (마지막 {stale[0][1]})")
    if not stale:
        print("✅ 오래된 종목 없음!")
        return
    targets = stale[: args.limit] if args.limit else stale

    days = int(getattr(CFG, "BACKFILL_DAYS", 1000))
    src_cnt = Counter()
    ok = fail = saved = 0
    t0 = time.time()
    fail_syms = []
    for i, (sym, last) in enumerate(targets):
        rows = bf.fetch_daily_retry(sym, days=days, tries=2)
        if rows:
            src = rows[0].get("source", "naver")
            src_cnt[src] += 1
            n = bf.save_daily_to_snapshots(sym, rows)
            saved += n
            ok += 1
            new_last = rows[-1]["date"]
            # ★ 재수집 성공했는데도 마지막 봉이 옛날(30일+ 전)이면 = 상장폐지 종목
            #   (네이버가 폐지 전 데이터만 보유) → 폐지 등록해 stale에서 영구 제외
            old_cut = (datetime.now() - timedelta(days=30)).strftime("%Y%m%d")
            if new_last < old_cut:
                bf._mark_dead(sym, f"재수집 후에도 마지막 봉 {new_last} - 상장폐지 추정")
                src_cnt["폐지등록"] += 1
        else:
            src_cnt["실패"] += 1
            fail += 1
            fail_syms.append(sym)
            new_last = "-"
        el = time.time() - t0
        eta = ""
        if i >= 4:
            eta = f" · 남은 {int(el / (i + 1) * (len(targets) - i - 1) // 60)}분"
        sys.stdout.write(f"\r  ⏳ {i+1}/{len(targets)} {sym} ({last}→{new_last}) · "
                         f"성공 {ok} · 실패 {fail} · {saved:,}봉 · {el:.0f}초{eta}   ")
        sys.stdout.flush()
        time.sleep(float(getattr(CFG, "BACKFILL_SLEEP_SEC", 0.5)))
    print()

    print()
    print("📊 [소스별 결과] ← 이게 진단 핵심!")
    for src, n in src_cnt.most_common():
        print(f"   {src}: {n}종목")
    # 실패 원인 집계 (backfill_history의 _FAIL_STATS)
    fs = getattr(bf, "_FAIL_STATS", {})
    parts = []
    if fs.get("dns"):
        parts.append(f"DNS {fs['dns']}")
    if fs.get("timeout"):
        parts.append(f"타임아웃 {fs['timeout']}")
    for code, n in (fs.get("http") or {}).items():
        parts.append(f"{code} {n}")
    if fs.get("other"):
        parts.append(f"기타 {fs['other']}")
    if parts:
        print(f"   실패 원인: {' · '.join(parts)}")
    if fail_syms:
        print(f"   실패 종목 예: {fail_syms[:10]}")

    print()
    if ok and not fail:
        print(f"✅ 전부 성공! ({ok}종목 {saved:,}봉)")
        if args.limit:
            print("   → 이제 전체 실행: python refill_stale.py")
    elif ok:
        print(f"🟡 부분 성공 {ok} / 실패 {fail} - 위 실패 원인을 복사해서 공유해 주세요")
    else:
        print("🔴 전부 실패 - 위 소스별 결과/실패 원인을 복사해서 공유해 주세요")
        print("   (naver 0 · daum 0 · yahoo 0 이면 세 소스 모두 이 PC에서 차단/불통)")


if __name__ == "__main__":
    main()
