@echo off
title System Status Dashboard
cd /d %~dp0
echo.
echo ============================================
echo  Starting system status dashboard server
echo  URL: http://localhost:8000
echo  - Keep this window open
echo  - Close window to stop server
echo ============================================
echo.
rem Open browser automatically (after 1.5s so server is up)
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:8000"
python web_status.py
pause
