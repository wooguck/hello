# -*- coding: utf-8 -*-
"""
💎 저평가 주식 추적 (value_watch.py) — 버핏 관점
================================================
아이디어: "저평가된 주식이 실제로 어떻게 올랐나 확인 → 그런 종목이 나오면 매수"
- 저PER/고ROE 등 저평가 필터로 종목 발굴 → 관찰 등록(value_watch)
- 매일 현재가 갱신 → '저평가가 실제로 회복되는지' 추적 (+15% = 회복 완료)
- 회복 이력(평균 수익률)이 쌓이면 → '저평가 매수 전략' 검증 → 조건식으로 승격 가능

실행:
  python value_watch.py --scan       # 저평가 종목 스캔 → 관찰 등록
  python value_watch.py --update     # 관찰 종목 현재가 갱신 (매일)
  python value_watch.py --list       # 관찰 목록/요약
"""
import argparse
import logging
import os
import sys
import time

logging.basicConfig(level=logging.WARNING)
try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db
from config import CFG

log = logging.getLogger("value")


def _is_value(fund, max_per=None, min_roe=None):
    """저평가 판정: PER ≤ 15 (낮을수록 쌈) + ROE ≥ 8 (수익성 좋음)"""
    if not fund:
        return False, ""
    max_per = max_per or float(getattr(CFG, "FUND_VALUE_MAX_PER", 15.0))
    min_roe = min_roe or float(getattr(CFG, "FUND_VALUE_MIN_ROE", 8.0))
    per, roe, pbr = fund.get("PER"), fund.get("ROE"), fund.get("PBR")
    parts = []
    ok = True
    if per:
        parts.append(f"PER{per:.0f}")
        if per > max_per:
            ok = False
    if roe:
        parts.append(f"ROE{roe:.0f}")
        if roe < min_roe:
            ok = False
    if pbr:
        parts.append(f"PBR{pbr:.1f}")
    return ok, " ".join(parts)


def scan_value_symbols(max_symbols=80, batch=20):
    """★ 저평가 종목 스캔: 관심/거래대금 상위에서 PER/ROE 확인 → 관찰 등록
    - 순위 상위 종목 + 일봉 있는 종목에서 펀더멘털 조회 (네이버 폴백 - 영웅문 있으면 우선)
    """
    import fundamentals as _f
    # 후보: 거래대금/거래량 상위 + 유니버스 샘플
    cands = []
    try:
        from leader import scalp_candidates
        cands = scalp_candidates(max_n=max_symbols)
    except Exception:
        pass
    if not cands:
        try:
            syms = [u["symbol"] for u in db.get_universe()][:max_symbols]
            cands = syms
        except Exception:
            cands = []
    registered = []
    for i, sym in enumerate(cands[:max_symbols]):
        try:
            # 영웅문 연결이면 opt10001, 아니면 네이버
            kiwoom = None
            try:
                import live_trader as _lt
                if _lt.is_realtime():
                    kiwoom = _lt._state.get("kiwoom")
            except Exception:
                pass
            fund = _f.get_fundamentals(sym, kiwoom)
            if not fund:
                continue
            ok, reason = _is_value(fund)
            if ok:
                price = 0
                try:
                    from leader import fetch_live_quote
                    q = fetch_live_quote(sym)
                    price = q["price"] if q else 0
                except Exception:
                    pass
                nm = db.get_symbol_name(sym)
                db.add_value_watch(sym, nm or sym, fund.get("PER"), fund.get("PBR"),
                                   fund.get("ROE"), fund.get("div_yield"), price)
                registered.append({"symbol": sym, "name": nm or sym, "reason": reason})
        except Exception as e:
            log.warning(f"{sym} 펀더멘털 실패: {e}")
        if (i + 1) % batch == 0:
            print(f"  진행 {i+1}/{min(len(cands), max_symbols)} · 등록 {len(registered)}개")
    return {"registered": registered, "scanned": min(len(cands), max_symbols)}


def update_all():
    """관찰 종목 현재가 갱신 (매일 - 저평가가 올랐나 추적)"""
    rows = db.value_watch_list(limit=100)
    updated = 0
    for r in rows:
        sym = r["symbol"]
        try:
            from leader import fetch_live_quote
            q = fetch_live_quote(sym)
            if q and q["price"]:
                db.update_value_watch(sym, q["price"])
                updated += 1
        except Exception:
            continue
        time.sleep(0.1)
    return {"updated": updated}


def show_list():
    st = db.value_watch_stats()
    print("=" * 64)
    print("💎 저평가 주식 추적")
    print("=" * 64)
    print(f"  관찰 중 {st['watching']}개 · +15% 회복 {st['up']}개 · "
          f"회복 평균 최고수익 {st['avg_peak_return']}%")
    print("-" * 64)
    rows = db.value_watch_list(limit=20)
    for r in rows:
        status = "🟢 회복" if r["status"] == "up" else "👀 관찰"
        print(f"  {status} {r['symbol']} {r['name'] or ''} | PER {r.get('per') or '-'} "
              f"PBR {r.get('pbr') or '-'} ROE {r.get('roe') or '-'} | "
              f"관찰 {r['watch_date']} · 최고 {r.get('peak_return') or 0:+.1f}%")
    print("=" * 64)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="저평가 주식 추적")
    parser.add_argument("--scan", action="store_true", help="저평가 스캔→관찰 등록")
    parser.add_argument("--update", action="store_true", help="관찰 종목 현재가 갱신")
    parser.add_argument("--list", action="store_true", help="관찰 목록")
    args = parser.parse_args()
    db.init_db()
    if args.scan:
        res = scan_value_symbols()
        print(f"\n✅ 저평가 관찰 등록: {len(res['registered'])}개 (스캔 {res['scanned']}개)")
        for r in res["registered"][:10]:
            print(f"   {r['symbol']} {r['name']} ({r['reason']})")
    elif args.update:
        res = update_all()
        print(f"✅ 관찰 종목 {res['updated']}개 갱신")
    else:
        show_list()
