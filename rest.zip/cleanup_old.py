# -*- coding: utf-8 -*-
"""
🧹 구버전 가상/모의 기록 정리 (cleanup_old.py)
==============================================
계좌 탭에 '가상으로 DB에 받아둔' 이상한 종목이 보이는 경우 실행하세요.

무엇을 하는가:
  1) virtual_positions 테이블의 구버전 기록(가상/모의)을 확인
     - 이 테이블은 이전 버전 시스템의 '가상 매매' 기록입니다 (현재는 안 씀)
     - 계좌 탭은 '실제 키움 계좌'만 보여야 하는데, 구버전 앱이 이 기록을
       '실제 보유'처럼 대체 표시할 수 있었음
  2) 삭제 (backup 후)

실행:
  python cleanup_old.py          # 확인만
  python cleanup_old.py --purge  # 백업 후 삭제
"""
import logging
import os
import shutil
import sys
from datetime import datetime

logging.basicConfig(level=logging.WARNING)

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db


def show():
    print("=" * 60)
    print("🧹 구버전 가상/모의 기록 확인")
    print("=" * 60)
    try:
        with db.get_conn() as c:
            total = c.execute("SELECT COUNT(*) FROM virtual_positions").fetchone()[0]
            open_n = c.execute("SELECT COUNT(*) FROM virtual_positions WHERE status='open'").fetchone()[0]
            kinds = {}
            for r in c.execute("SELECT kind, COUNT(*) n FROM virtual_positions GROUP BY kind").fetchall():
                kinds[r["kind"]] = r["n"]
            rows = c.execute(
                "SELECT symbol, qty, entry_price, status, kind FROM virtual_positions "
                "ORDER BY id DESC LIMIT 15").fetchall()
        print(f"\n  전체 기록: {total}건 (보유 {open_n}건)")
        print(f"  종류별: {kinds}")
        print("\n  최근 15건:")
        for r in rows:
            print(f"    {r['symbol']} qty={r['qty']} entry={r['entry_price']:,.0f} "
                  f"status={r['status']} kind={r['kind']}")
        print("\n  → 이 기록들은 이전 버전 '가상 매매' 잔여분입니다.")
        print("    현재 계좌 탭은 실제 키움 계좌만 보여주므로, 이 기록은 UI에 안 나옵니다.")
        print("    (그래도 남아있으면 정리하려면: python cleanup_old.py --purge)")
    except Exception as e:
        print(f"  조회 실패: {e}")


def purge():
    print("=" * 60)
    print("🧹 구버전 가상/모의 기록 삭제 (백업 후)")
    print("=" * 60)
    backup = f"backup_virtual_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    try:
        shutil.copy(db.DB_PATH, backup)
        print(f"  ✅ 백업: {backup}")
    except Exception as e:
        print(f"  ⚠️ 백업 실패(계속 진행): {e}")
    try:
        with db.get_conn() as c:
            n = c.execute("DELETE FROM virtual_positions").rowcount
        print(f"  ✅ virtual_positions {n}건 삭제 완료")
        # paper_positions는 모의실전 기록이라 유지 (실제 주문 확인용)
        with db.get_conn() as c:
            pp = c.execute("SELECT COUNT(*) FROM paper_positions").fetchone()[0]
        print(f"  ✅ paper_positions {pp}건 유지 (모의실전 주문 기록 - 계좌 탭 최근 거래에 표시)")
    except Exception as e:
        print(f"  ❌ 삭제 실패: {e}")
    print("\n  이제 앱을 다시 실행하세요 (계좌 탭 = 실제 키움 계좌만)")


if __name__ == "__main__":
    db.init_db()
    if "--purge" in sys.argv:
        purge()
    else:
        show()
        print("\n  실행: python cleanup_old.py --purge  (정리)")
