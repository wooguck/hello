# -*- coding: utf-8 -*-
"""
🗼 다중 시간축 정렬 (multi_tf.py) - 2026-08-27 추가
================================================================
사용자 질문: "월봉·주봉·일봉상 오를 수 있는 종목에서 분봉상 오르는 종목을
찾을 수 있을지? 확률적으로 뭐가 좋은지?"

이 도구가 하는 일 2가지:

[--stats] 확률 측정 (먼저 이걸로 '정말 나은지' 확인):
  전 종목 × 과거 모든 날에 대해 '정렬 단계'를 매기고, 그 후 5일 수익률을 집계
    0단계: 아무 정렬 없음 (기준선)
    1단계: 일봉 상승 (종가 > MA20 & MA20 상승)
    2단계: 일봉 + 주봉 상승 (주봉 종가 > 주봉MA10 & 상승)
    3단계: 일봉 + 주봉 + 월봉 상승 (월봉 종가 > 전월 & 월봉 저점 상승)
  → 단계가 올라갈수록 5일 후 수익 확률/평균이 정말 좋아지는지 숫자로 확인
  → 미래누출 없음: 판정일까지의 봉만 사용, 성적은 판정일 '다음날부터'

[기본 실행] 오늘 후보 스캔:
  월봉↑ & 주봉↑ & 일봉↑ 3단 정렬 종목 랭킹
  + 분봉 있으면(사용자 PC): 당일 VWAP 위 & 오전 고점 갱신 = 진입 타이밍 표시
  (분봉이 없으면 3단 정렬까지만 - 분봉 축적되면 자동으로 4단계까지)

실행:
  python multi_tf.py --stats           # 확률 측정 (과거 전체)
  python multi_tf.py                   # 오늘 3단(+분봉 4단) 정렬 후보
  python multi_tf.py --stats --days 10 # 보유일 바꿔 측정
"""
import argparse
import json
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import sys

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

MAX_SYMBOLS = _cfg_env_int("MTF_MAX_SYMBOLS", 400)


def _log(m=""):
    print(m, flush=True)


def _load(sym):
    from validation import _load_bars
    return _load_bars(sym, max_days=1000)


def _resample(bars, tf):
    from screener import resample_daily
    return resample_daily(bars, tf)


def _idx_of(bars, date):
    """date 이하의 마지막 봉 인덱스 (그 시점에 '보이는' 봉)"""
    lo, hi, ans = 0, len(bars) - 1, -1
    while lo <= hi:
        mid = (lo + hi) // 2
        if bars[mid]["date"] <= date:
            ans = mid
            lo = mid + 1
        else:
            hi = mid - 1
    return ans


def _ma(closes, i, w):
    if i + 1 < w:
        return None
    return sum(closes[i - w + 1:i + 1]) / w


def tier_at(bars_d, bars_w, bars_m, i):
    """일봉 인덱스 i 시점의 정렬 단계 (0~3) - i까지의 정보만 사용
    ★ 주봉/월봉의 '마지막 봉'은 진행 중인 미완성 봉이라 그대로 쓰면
      미래(그 주/월의 남은 날) 정보가 섞임 → 완성된 직전 봉까지만 사용"""
    d = bars_d[i]["date"]
    cd = [b["close"] for b in bars_d]
    # 1) 일봉: 종가 > MA20 이고 MA20이 5봉 전보다 위 (상승 추세)
    ma20 = _ma(cd, i, 20)
    ma20p = _ma(cd, i - 5, 20) if i >= 5 else None
    day_up = bool(ma20 and ma20p and bars_d[i]["close"] > ma20 and ma20 > ma20p)
    if not day_up:
        return 0
    # 2) 주봉: 완성된 주봉 기준 종가 > 주봉MA10 & MA10 상승
    wi = _idx_of(bars_w, d) - 1          # ★ 진행 중 주봉 제외 (완성봉만)
    if wi < 10:
        return 1
    cw = [b["close"] for b in bars_w]
    wma = _ma(cw, wi, 10)
    wmap = _ma(cw, wi - 2, 10) if wi >= 2 else None
    week_up = bool(wma and wmap and cw[wi] > wma and wma > wmap)
    if not week_up:
        return 1
    # 3) 월봉: 완성된 월봉 기준 종가 > 전월 종가 & 저점 상승 (2개월 연속)
    mi = _idx_of(bars_m, d) - 1          # ★ 진행 중 월봉 제외
    if mi < 2:
        return 2
    m0, m1, m2 = bars_m[mi], bars_m[mi - 1], bars_m[mi - 2]
    month_up = (m0["close"] > m1["close"] and
                (m0["low"] or m0["close"]) >= (m1["low"] or m1["close"]) >
                0 and (m1["low"] or m1["close"]) >= (m2["low"] or m2["close"]))
    return 3 if month_up else 2


def run_stats(hold=5, max_symbols=MAX_SYMBOLS, log_fn=None):
    """정렬 단계별 이후 hold일 수익률 통계 (전 종목 × 과거 전체)"""
    def L(m):
        _log(m)
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    try:
        cov = db.backfill_coverage(min_days=60)
        symbols = [s for s, c in cov["symbols"].items() if c >= 60][:max_symbols]
    except Exception:
        symbols = []
    if not symbols:
        L("데이터 부족")
        return None
    stats = {t: [] for t in (0, 1, 2, 3)}
    pmin = _cfg_env_float("MOCK_PRICE_MIN", 800)
    pmax = _cfg_env_float("MOCK_PRICE_MAX", 100000)
    amin = _cfg_env_float("VALIDATE_MIN_AMOUNT", 300000000)
    n_sym = 0
    for sym in symbols:
        bd = _load(sym)
        if len(bd) < 60:
            continue
        bw = _resample(bd, "week")
        bm = _resample(bd, "month")
        n_sym += 1
        cd = [b["close"] for b in bd]
        vd = [b["volume"] or 0 for b in bd]
        for i in range(30, len(bd) - hold):
            c0 = cd[i]
            if c0 <= 0 or c0 < pmin or c0 > pmax:
                continue
            if i >= 5:
                amt5 = sum(cd[k] * vd[k] for k in range(i - 4, i + 1)) / 5
                if amt5 < amin:
                    continue          # 실전-검증 일치 필터 (잡주 제외)
            t = tier_at(bd, bw, bm, i)
            ret = (cd[i + hold] / c0 - 1) * 100
            stats[t].append((ret, bd[i]["date"][:4]))   # (수익률, 연도) - 연도별 분해용
    out = {"hold": hold, "symbols": n_sym, "tiers": {}}
    L("=" * 66)
    L(f"🗼 다중 시간축 정렬 → {hold}일 후 수익률 (종목 {n_sym} · 실전일치 필터 적용)")
    L("=" * 66)
    names = {0: "0단계: 정렬 없음(기준선)   ", 1: "1단계: 일봉↑              ",
             2: "2단계: 일봉↑+주봉↑        ", 3: "3단계: 일봉↑+주봉↑+월봉↑  "}
    base_avg = None
    for t in (0, 1, 2, 3):
        rs_pairs = stats[t]
        if not rs_pairs:
            L(f"  {names[t]} 표본 0")
            out["tiers"][t] = None
            continue
        rs = [x[0] for x in rs_pairs]
        avg = sum(rs) / len(rs)
        win = len([r for r in rs if r > 0]) / len(rs) * 100
        # ★ 2026-08-27 보강: 평균만 보면 '소수 대박' 착시에 속음 (사용자 실측에서 발견)
        #   중앙값 = 보통의 거래가 겪는 경험 / 상위1% 제거 평균 = 대박 의존도
        srt = sorted(rs)
        med = srt[len(srt) // 2]
        cut = max(1, len(srt) // 100)
        trimmed = sum(srt[:-cut]) / max(1, len(srt) - cut)   # 상위 1% 제외 평균
        if t == 0:
            base_avg = avg
        edge = f" (기준선 {avg - base_avg:+.2f}%p)" if (base_avg is not None and t > 0) else ""
        L(f"  {names[t]} 표본 {len(rs):7,d} · 평균 {avg:+.3f}% · 중앙값 {med:+.3f}% · "
          f"승률 {win:.1f}%{edge}")
        L(f"  {'':26s} └ 상위1% 대박 제거 시 평균 {trimmed:+.3f}% "
          f"(평균과 차이 크면 = 복권형 분포)")
        # 연도별 분해 (시기 의존인지 - 한 해가 다 만든 성적인지)
        from collections import defaultdict
        by_yr = defaultdict(list)
        for ret, yr in rs_pairs:
            by_yr[yr].append(ret)
        yr_txt = " · ".join(f"{y}: {sum(v)/len(v):+.2f}%({len(v):,})"
                            for y, v in sorted(by_yr.items()))
        L(f"  {'':26s} └ 연도별: {yr_txt}")
        out["tiers"][t] = {"n": len(rs), "avg": round(avg, 3), "median": round(med, 3),
                           "trimmed_avg": round(trimmed, 3), "win": round(win, 1),
                           "by_year": {y: {"n": len(v), "avg": round(sum(v)/len(v), 3)}
                                       for y, v in sorted(by_yr.items())}}
    L("-" * 66)
    L("  ★ 판단 기준 (평균 착시 방지):")
    L("    · 채택 = 중앙값도 플러스 & 연도별로 고르게 우위 (한 해 몰빵 아님)")
    L("    · 기각 = 평균만 높고 중앙값 마이너스 (복권형 - 보통은 잃는 구조)")
    os.makedirs("strategy", exist_ok=True)
    json.dump(out, open(os.path.join("strategy", "multi_tf_stats.json"), "w",
                        encoding="utf-8"), ensure_ascii=False, indent=1)
    L("📄 저장: strategy/multi_tf_stats.json")
    return out


def _minute_check(sym):
    """당일 분봉 확인 (분봉 있을 때만): VWAP 위 + 오전 고점 갱신 여부
    반환 None=분봉 없음 / dict=판정"""
    import sqlite3
    p = os.path.join(db.DATA_DIR, "stocks", f"{sym}.db")
    if not os.path.exists(p):
        return None
    today = db.now_kst().strftime("%Y-%m-%d")
    try:
        c = sqlite3.connect(p, timeout=5)
        # ★ 실제 분봉 스키마: (bar_time, price, volume, cum_volume)
        rows = c.execute(
            "SELECT bar_time, price, volume FROM minute_bars "
            "WHERE bar_time LIKE ? ORDER BY bar_time", (today + "%",)).fetchall()
        c.close()
    except Exception:
        return None
    if len(rows) < 10:
        return None
    closes = [r[1] for r in rows]
    vols = [max(r[2] or 0, 0) for r in rows]
    pv = sum(c * v for c, v in zip(closes, vols))
    vv = sum(vols)
    vwap = pv / vv if vv else 0
    cur = closes[-1]
    hi_early = max(closes[:len(closes) * 2 // 3])
    return {"above_vwap": bool(vwap and cur > vwap),
            "new_high": cur >= hi_early,
            "cur": cur, "vwap": round(vwap, 1), "bars": len(rows)}


def scan_today(top=20, max_symbols=MAX_SYMBOLS, log_fn=None):
    """오늘의 3단 정렬 후보 (+분봉 있으면 4단계 진입 타이밍 표시)"""
    def L(m):
        _log(m)
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    try:
        cov = db.backfill_coverage(min_days=60)
        symbols = [s for s, c in cov["symbols"].items() if c >= 60][:max_symbols]
    except Exception:
        symbols = []
    names = {}
    try:
        for u in db.get_universe():
            names[u.get("symbol")] = u.get("name") or ""
    except Exception:
        pass
    out = []
    for sym in symbols:
        bd = _load(sym)
        if len(bd) < 60:
            continue
        bw = _resample(bd, "week")
        bm = _resample(bd, "month")
        i = len(bd) - 1
        t = tier_at(bd, bw, bm, i)
        if t < 2:
            continue                       # 최소 일+주 정렬
        # 20일 고점까지 거리 (돌파 임박일수록 좋음)
        hi20 = max((b["high"] or b["close"]) for b in bd[-20:])
        gap_to_hi = (hi20 / bd[i]["close"] - 1) * 100 if bd[i]["close"] else 99
        row = {"symbol": sym, "name": names.get(sym, ""), "tier": t,
               "price": bd[i]["close"], "gap_to_high20": round(gap_to_hi, 1)}
        mc = _minute_check(sym)
        if mc:
            row["minute"] = mc
            if mc["above_vwap"] and mc["new_high"]:
                row["tier"] = 4            # 분봉까지 정렬 = 최고 단계
        out.append(row)
    out.sort(key=lambda x: (-x["tier"], x["gap_to_high20"]))
    out = out[:top]
    L("=" * 66)
    L("🗼 오늘의 다중 시간축 정렬 후보 (월↑주↑일↑ 우선, 분봉확인 시 🔥)")
    L("=" * 66)
    if not out:
        L("  후보 없음 (정렬 조건을 만족하는 종목이 오늘은 없음)")
    for r in out:
        icon = {4: "🔥4단(+분봉)", 3: "🟢3단(월주일)", 2: "🟡2단(주일)"}.get(r["tier"], "")
        m = r.get("minute")
        mtxt = (f" · 분봉: VWAP{'↑' if m['above_vwap'] else '↓'}"
                f"{' 고점갱신' if m['new_high'] else ''}" if m else " · 분봉없음")
        L(f"  {icon} {r['symbol']} {r['name'][:8]:10s} {r['price']:>10,.0f}원 · "
          f"20일고점까지 {r['gap_to_high20']:+.1f}%{mtxt}")
    os.makedirs("strategy", exist_ok=True)
    json.dump({"at": db.now_kst_iso(), "rows": out},
              open(os.path.join("strategy", "multi_tf_today.json"), "w",
                   encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
    L("📄 저장: strategy/multi_tf_today.json")
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--stats", action="store_true", help="정렬 단계별 확률 측정")
    ap.add_argument("--days", type=int, default=5, help="보유 거래일 (기본 5)")
    ap.add_argument("--top", type=int, default=20)
    ap.add_argument("--max-symbols", type=int, default=MAX_SYMBOLS,
                    help="측정 종목 수 (전 종목 = 4000)")
    args = ap.parse_args()
    db.init_db()
    if args.stats:
        run_stats(hold=args.days, max_symbols=args.max_symbols)
    else:
        scan_today(top=args.top)
