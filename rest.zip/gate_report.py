# -*- coding: utf-8 -*-
"""
⚖️ AI 매수 게이트 성적표 (gate_report.py) - 2026-08-28 추가
================================================================
사용자 질문: "조건식 신호에서 AI가 판정해 사는 것과 그냥 사는 것,
둘 다 데이터로 확인하고 있나? 나중에 어느 쪽이 나은지 확인되나?"

답을 만드는 도구:
  [A그룹] AI 게이트 통과 → 실제 매수된 거래들의 성적 (paper_positions)
  [B그룹] AI 게이트 거부 → 안 샀지만 '그때 샀다면'의 가상 성적 (gate_shadow + 이후 일봉)

  B그룹 가상 성적 = 거부 시점 가격 → 이후 실전과 같은 규칙(익절+5/손절-3/최대10일) 근사

판정:
  A평균 > B평균  → AI 게이트가 밥값함 (거른 게 실제로 나빴음) - 유지
  A평균 < B평균  → AI가 좋은 걸 거르는 중 - 게이트 완화/프롬프트 수정 근거
  차이 미미      → 게이트 무의미 - 단순화 검토

실행: python gate_report.py           (기본 최근 30일)
자동: 주간 리포트에 포함
"""
import argparse
import os
import sys

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

TP, SL, MAX_HOLD = 5.0, 3.0, 10   # 실전 근사 청산 규칙 (validation과 동일)


def _log(m=""):
    print(m, flush=True)


def shadow_outcome(symbol, at, price):
    """거부 시점(at, price) 이후 '샀다면'의 결과 근사 (일봉 기준)
    반환 None=아직 데이터 없음 / float=수익률%"""
    from validation import _load_bars
    if not price or price <= 0:
        return None
    bars = _load_bars(symbol, max_days=60)
    d0 = str(at)[:10]
    fut = [b for b in bars if b["date"] > d0]
    if not fut:
        return None
    tp_p, sl_p = price * (1 + TP / 100), price * (1 - SL / 100)
    for b in fut[:MAX_HOLD]:
        if (b["open"] or 0) >= tp_p:
            return (b["open"] / price - 1) * 100
        if (b["open"] or 0) <= sl_p and b["open"]:
            return (b["open"] / price - 1) * 100
        if (b["high"] or 0) >= tp_p:
            return TP
        if (b["low"] or 0) <= sl_p:
            return -SL
    last = fut[min(MAX_HOLD, len(fut)) - 1]
    return (last["close"] / price - 1) * 100 if last["close"] else None


def report(days=30, log_fn=None):
    def L(m):
        _log(m)
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    # A그룹: 게이트 통과 → 실제 매수 청산분
    with db.get_conn() as conn:
        a_rows = conn.execute(
            "SELECT ret_pct FROM paper_positions WHERE status='closed' "
            "AND exit_time > datetime('now', ?)", (f"-{days} days",)).fetchall()
        try:
            b_rows = conn.execute(
                "SELECT symbol, at, price, reason FROM gate_shadow "
                "WHERE at > datetime('now', ?)", (f"-{days} days",)).fetchall()
        except Exception:
            b_rows = []
    a = [r["ret_pct"] or 0 for r in a_rows]
    b, pending = [], 0
    reasons = {}
    for r in b_rows:
        out = shadow_outcome(r["symbol"], r["at"], r["price"])
        if out is None:
            pending += 1
            continue
        b.append(out)
        key = (r["reason"] or "")[:20]
        reasons.setdefault(key, []).append(out)

    L("=" * 62)
    L(f"⚖️ AI 매수 게이트 성적표 (최근 {days}일)")
    L("=" * 62)
    if not a and not b:
        L("  표본 없음 - 매매/거부 기록이 쌓이면 여기서 비교됩니다")
        return {"a_n": 0, "b_n": 0}
    a_avg = sum(a) / len(a) if a else None
    b_avg = sum(b) / len(b) if b else None
    L(f"  [A] 게이트 통과·실제 매수: {len(a)}건 · 평균 "
      f"{(f'{a_avg:+.2f}%' if a_avg is not None else '-')}")
    L(f"  [B] 게이트 거부 (샀다면):  {len(b)}건 · 평균 "
      f"{(f'{b_avg:+.2f}%' if b_avg is not None else '-')}"
      + (f" (판정대기 {pending}건)" if pending else ""))
    if a_avg is not None and b_avg is not None:
        diff = a_avg - b_avg
        L(f"  ─────────────────────")
        L(f"  게이트 기여도: {diff:+.2f}%p")
        if diff > 0.3:
            L("  → ✅ AI 게이트 밥값함: 거른 것들이 실제로 더 나빴음 - 유지")
        elif diff < -0.3:
            L("  → 🔴 AI가 좋은 걸 거르는 중: 프롬프트/임계 완화 검토 근거")
        else:
            L("  → 🟡 차이 미미: 게이트 효과 불분명 - 표본 더 필요")
    if reasons:
        L("\n  거부 사유별 '샀다면' 성적 (사유가 옳았는지):")
        for k, v in sorted(reasons.items(), key=lambda x: sum(x[1]) / len(x[1])):
            avg = sum(v) / len(v)
            verdict = "거부 잘함" if avg < 0 else "거부 아까움"
            L(f"    {k:22s} {len(v):3d}건 · 샀다면 {avg:+.2f}% → {verdict}")
    return {"a_n": len(a), "a_avg": a_avg, "b_n": len(b), "b_avg": b_avg}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=30)
    args = ap.parse_args()
    db.init_db()
    report(days=args.days)
