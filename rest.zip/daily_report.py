"""
일일 복기 리포트 (daily_report.py) — 하루 매매를 돌아보는 뷰어용 리포트
=====================================================================
사용자 요청: "검증 결과 나중에 확인 가능하도록 뷰어로. 매수/매도 타점 차트.
어떤 부분이 부족했는지 AI와 토의. 하루 매매 복기 → 그날짜 리포트 → 확인/검토/토의 → 수정 보완."

기능:
  - generate_daily_report(date): 그날의 매매 복기 리포트 생성 + 저장
    · 매수/매도 내역 (조건식별)
    · 매수 종목별 타점 차트 PNG (reports/charts/)
    · 조건식 성적 요약 · 개선 포인트 (AI/규칙)
  - 저장: reports/YYYY-MM-DD.md (+ charts/)
  - list_reports(): 날짜 목록 (뷰어용)
  - get_report(date): 리포트 내용 (뷰어 표시용)

실행: python daily_report.py [--date 2026-08-15] [--list]
"""
import json
import logging
import os
from datetime import datetime

import db

log = logging.getLogger("daily_report")

REPORT_DIR = "reports"


def _report_path(d):
    return os.path.join(REPORT_DIR, f"{d}.md")


def _chart_dir():
    p = os.path.join(REPORT_DIR, "charts")
    os.makedirs(p, exist_ok=True)
    return p


def generate_daily_report(target_date=None):
    """그날짜 매매 복기 리포트 생성 + 저장
    반환: {"date", "path", "text", "summary", "charts":[...]} / None(데이터 없음)
    """
    if target_date is None:
        target_date = db.now_kst().strftime("%Y-%m-%d")
    os.makedirs(REPORT_DIR, exist_ok=True)
    os.makedirs(_chart_dir(), exist_ok=True)

    # ── 1) 그날 매수/매도 내역 (paper_positions 기준) ──
    buys, sells, held = [], [], []
    try:
        with db.get_conn() as conn:
            rows = conn.execute("SELECT * FROM paper_positions ORDER BY id").fetchall()
        for r in rows:
            r = dict(r)
            entry_d = (r.get("entry_time") or "")[:10]
            exit_d = (r.get("exit_time") or "")[:10]
            cond = f"{r['cond_no']}번" if r.get("cond_no") else (r.get("cond_txt") or "")[:30]
            if entry_d == target_date:
                buys.append({"symbol": r["symbol"], "name": db.get_symbol_name(r["symbol"]),
                             "price": r["entry_price"], "qty": r["qty"], "cond": cond,
                             "time": (r.get("entry_time") or "")[11:19]})
            if exit_d == target_date and r.get("exit_price"):
                ret = r.get("ret_pct")
                sells.append({"symbol": r["symbol"], "name": db.get_symbol_name(r["symbol"]),
                              "price": r["exit_price"], "qty": r.get("qty") or 0,
                              "ret": ret, "cond": cond,
                              "time": (r.get("exit_time") or "")[11:19]})
            if r.get("status") == "open" and entry_d <= target_date:
                held.append({"symbol": r["symbol"], "name": db.get_symbol_name(r["symbol"]),
                             "entry": r["entry_price"], "qty": r["qty"], "cond": cond})
    except Exception:
        pass

    # ── 2) 조건식 성적 요약 ──
    cond_stats = []
    try:
        import condition_manager as cm
        for c in cm.list_conditions_with_stats()[:15]:
            st = c["stats"]
            if st.get("buys", 0) or st.get("sells", 0):
                cond_stats.append({"no": c["cond_no"], "txt": c["cond_txt"][:40],
                                   "buys": st.get("buys", 0), "sells": st.get("sells", 0),
                                   "win": st.get("win_rate", 0), "net": st.get("net", 0)})
    except Exception:
        pass

    # ── 3) 매수 종목 타점 차트 PNG (뷰어에서 그림으로) - 데이터 부족 시 제외 ──
    charts = []
    for b in buys[:8]:
        try:
            import charting
            p = os.path.join(_chart_dir(), f"{target_date}_{b['symbol']}.png")
            made = charting.draw_candle_chart(b["symbol"], days=45, save_path=p,
                                              title=f"{b['name']} ({b['symbol']}) 매수타점 · {b['cond']}")
            if made and os.path.exists(made):  # ★ 데이터 부족(None)이면 목록에 넣지 않음
                charts.append({"symbol": b["symbol"], "name": b["name"], "path": made})
        except Exception as e:
            log.warning(f"차트 생성 실패 {b.get('symbol')}: {e}")  # ★ 숨기지 않고 로그

    # ── 4) 요약 통계 ──
    rets = [s["ret"] for s in sells if s["ret"] is not None]
    n_sell = len(rets)
    wins = [r for r in rets if r > 0]
    win_rate = len(wins) / n_sell * 100 if n_sell else 0
    total_pnl = sum((s["ret"] / 100) * s["price"] * s["qty"] for s in sells if s["ret"] is not None)
    summary = {"date": target_date, "buys": len(buys), "sells": n_sell,
               "win_rate": round(win_rate, 1), "total_pnl": round(total_pnl),
               "held": len(held), "charts": len(charts)}

    # ── 5) 텍스트 리포트 ──
    lines = [f"# 📋 {target_date} 매매 복기 리포트", "=" * 44, ""]
    lines.append(f"**요약**: 매수 {len(buys)} · 매도 {n_sell} · 승률 {win_rate:.0f}% · "
                 f"손익 {total_pnl:+,}원 · 보유 {len(held)}")
    lines.append("")
    lines.append("## ✅ 매수 내역")
    if buys:
        for b in buys:
            lines.append(f"- {b['time']} **{b['name']} ({b['symbol']})** {b['qty']}주 "
                         f"@ {b['price']:,.0f}원 · [{b['cond']}]")
    else:
        lines.append("- (매수 없음)")
    lines.append("")
    lines.append("## 💰 매도(청산) 내역")
    if sells:
        for s in sells:
            mark = "🟢" if (s["ret"] or 0) >= 0 else "🔴"
            lines.append(f"- {s['time']} {mark} **{s['name']} ({s['symbol']})** "
                         f"수익률 {s['ret']:+.2f}% @ {s['price']:,.0f}원 · [{s['cond']}]")
    else:
        lines.append("- (청산 없음 - 아직 보유 중)")
    lines.append("")
    lines.append("## 📊 조건식 성적")
    if cond_stats:
        lines.append("| 번 | 조건식 | 매수 | 매도 | 승률 | 순손익 |")
        lines.append("|---|---|---|---|---|---|")
        for c in cond_stats:
            lines.append(f"| {c['no']} | {c['txt']} | {c['buys']} | {c['sells']} | "
                         f"{c['win']:.0f}% | {c['net']:+,} |")
    else:
        lines.append("- (조건식 성적 없음)")
    lines.append("")
    lines.append("## 🖼 매수 타점 차트")
    if charts:
        for c in charts:
            lines.append(f"- [{c['name']} ({c['symbol']}) 차트]({c['path']})")
    else:
        lines.append("- (차트 없음)")
    lines.append("")

    # ── 6) 개선 포인트 (규칙 + AI) ──
    lines.append("## 💡 오늘의 개선 포인트")
    tips = []
    if n_sell == 0:
        tips.append("- 오늘은 청산이 없었습니다. 보유 종목의 수익률을 확인하고, 익절/손절 기준이 "
                    "적절했는지 다음날 검토하세요.")
    if win_rate < 50 and n_sell >= 3:
        tips.append(f"- 승률 {win_rate:.0f}%로 손실 우위. 손절이 늦었는지, 매수 조건이 너무 "
                    "느슨했는지 점검 필요.")
    if len(buys) == 0:
        tips.append("- 오늘 매수 신호가 없었습니다. 조건식이 너무 엄격한지, 시장 상황이 나빴는지 확인.")
    if len(buys) > 10:
        tips.append("- 매수가 많습니다(과다). 조건식을 더 엄격하게(강화 변형) 해보세요.")
    if not tips:
        tips.append("- 전반적으로 안정적입니다. 계속 데이터를 쌓아 승률의 신뢰도를 높이세요.")
    for t in tips:
        lines.append(f"- {t}")
    lines.append("")
    lines.append("> 🤖 이 리포트를 프로그램의 '리포트 탭'에서 열고 'AI 토의'를 누르면 "
                 "개선 방안을 논의할 수 있습니다.")

    text = "\n".join(lines)
    path = _report_path(target_date)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    # 상태 기록
    try:
        os.makedirs("strategy", exist_ok=True)
        st = {}
        try:
            st = json.load(open(os.path.join("strategy", "control_state.json"), encoding="utf-8"))
        except Exception:
            pass
        st["last_report"] = {"date": target_date, "summary": summary}
        with open(os.path.join("strategy", "control_state.json"), "w", encoding="utf-8") as f:
            json.dump(st, f, ensure_ascii=False, indent=2)
    except Exception:
        pass
    return {"date": target_date, "path": path, "text": text,
            "summary": summary, "charts": charts}


def list_reports():
    """저장된 리포트 날짜 목록 (최신순)"""
    if not os.path.isdir(REPORT_DIR):
        return []
    return sorted([f[:-3] for f in os.listdir(REPORT_DIR) if f.endswith(".md")], reverse=True)


def get_report(target_date):
    """저장된 리포트 내용"""
    p = _report_path(target_date)
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8") as f:
        return f.read()


def get_report_charts(target_date):
    """그날 리포트의 차트 PNG 목록"""
    d = _chart_dir()
    if not os.path.isdir(d):
        return []
    prefix = f"{target_date}_"
    return sorted([os.path.join(d, f) for f in os.listdir(d) if f.startswith(prefix) and f.endswith(".png")])


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="일일 복기 리포트")
    parser.add_argument("--date", default=None, help="YYYY-MM-DD (기본 오늘)")
    parser.add_argument("--list", action="store_true")
    args = parser.parse_args()
    db.init_db()
    if args.list:
        for d in list_reports():
            print(d)
    else:
        r = generate_daily_report(args.date)
        print(r["path"] if r else "데이터 없음")
        if r:
            print(r["text"][:600])
