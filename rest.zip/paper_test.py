"""
상위 조건식 자동 모의 실전 테스트 (Paper Trading)
=================================================
과거 스크리너(조건식 대량 테스트)에서 상위로 검증된 조건식들을
자동으로 '가상 주문'으로 실전 테스트합니다 (사용자 요청:
"전에 테스트한 거 중에서 상위에 있는 것들을 자동으로 테스트").

동작:
  1) db.screener_results 에서 상위 조건식 선정 (OOS 검증 통과 우선 + 승률/손익비)
  2) 매 사이클(장중 정각): 각 조건식의 '오늘 신호' 종목 감지 (일봉 최신 봉 기준)
     - 신호 & 미보유 & 가격필터 → 진입 (가상 잔고 기준 수량)
  3) 보유 종목 매도 시점: ★ AI/매도 프롬프트가 판단 (AI 키 없으면 규칙·트레일링스탑)
     - AI가 '보유'면 고정 익절 없이 계속 보유, '수익청산/손절'이면 청산
     - 하드손절(-3%)·최대 보유일수(10일)는 절대 규칙
     - 슬리피지 반영(DRY_RUN 경로): 매수 +0.15%, 매도 -0.15% (보수적 체결)
  4) 결과(승률/손익비/총손익) 집계 → UI '🖥 모의 실전' 버튼으로 시작/정지/조회

실행:
    python paper_test.py --once        # 1회 체크 (진입/청산)
    python paper_test.py --status      # 현황 조회
    python paper_test.py --summary     # 성과 요약
"""
import json
import logging
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import time
from datetime import datetime, timedelta

import db
from config import CFG

log = logging.getLogger("paper")

# ── 가상 매매 규칙 (보수 기본값 - .env로 조절 가능) ──
VIRTUAL_CASH = _cfg_env_int("PAPER_CASH", 10000000)   # 시작 가상 잔고 1천만원
TAKE_PROFIT_PCT = _cfg_env_float("PAPER_TP_PCT", 5.0)  # +5% 익절
STOP_LOSS_PCT = _cfg_env_float("PAPER_SL_PCT", 3.0)    # -3% 손절
MAX_HOLD_DAYS = int(float(db.auto_param("PAPER_HOLD_DAYS", "10")))  # 보유일 (auto_params>env>기본)
MAX_QTY = _cfg_env_int("PAPER_MAX_QTY", 10)            # 종목당 최대 주 (BUY_MODE=qty일 때)
# ★ 매수 방식: amount(금액 기준 - 종목당 N원, 수익률 비교 공정) | qty(기존 - 10주씩)
#   사용자: "10개씩 사면 비교가 어려움" → 금액 기준이면 모든 종목이 같은 투자금 = 비교 공정
BUY_MODE = os.getenv("PAPER_BUY_MODE", "amount").lower()
BUY_AMOUNT = _cfg_env_float("PAPER_BUY_AMOUNT", 1000000)  # 종목당 매수 금액 (기본 100만원)
BUY_PCT = _cfg_env_float("PAPER_BUY_PCT", 10.0)           # ★ pct 모드: 가상자본의 % (기본 10%)


def buy_budget():
    """★ 종목당 매수 예산 (2026-08-27: 비율 모드 추가 - 사용자 '종목당 비율로 매수')
    PAPER_BUY_MODE:
      amount = 고정 금액 (PAPER_BUY_AMOUNT, 기본 100만원)
      pct    = 가상자본의 % (PAPER_BUY_PCT, 기본 10% → 1천만원이면 100만원)
    모든 채널(조건식/AI픽/급등/세력선/기준선)이 이 함수 하나를 씀 - 비교 공정성 유지
    """
    if BUY_MODE == "pct":
        return VIRTUAL_CASH * max(0.5, min(BUY_PCT, 100.0)) / 100.0
    return BUY_AMOUNT


def _calc_qty(price, cash_left):
    """매수 수량: 금액(amount)/비율(pct) 기준 또는 수량 기준"""
    if price <= 0:
        return 0
    if BUY_MODE in ("amount", "pct"):
        budget = min(buy_budget(), cash_left)
        return max(0, int(budget / price))
    return min(MAX_QTY, int(cash_left / price))
TOP_N_CONDITIONS = _cfg_env_int("PAPER_TOP_N", 20)     # ★ 2026-08-28 사용자: 상위 20위까지 실매매


def top_conditions(n=None, min_signals=30):
    """★ 상위 조건식 선정: 명예의 전당 우선 → 그 다음 스크리너 OOS 통과/성적순
    반환: [{"cond_key","cond_txt","slots","win_rate","oos_pass",...}]
    ★ 중복 방지: 같은 조건식이 예약(0)+검증통과(0.5)+명전(1)에 겹쳐도 1번만
      (사용자 지적: '예약이랑 명예의 전당이랑 겹치는 거 아닌지' - 맞았음)
    """
    if n is None:
        n = TOP_N_CONDITIONS
    out = []
    _seen = set()   # cond_key 중복 방지

    def _add(item):
        ck = str(item.get("cond_key"))
        if ck in _seen:
            return False
        _seen.add(ck)
        out.append(item)
        return True

    # 0) ★ 검증 통과 → 오늘 예약된 모의매매 풀 (다음날 실제 모의투자 - 우선순위 1)
    try:
        sched = db.get_scheduled_paper(mark_used=False)
        for s in sched[:n]:
            slots = s.get("slots") or []
            if not slots:
                continue
            tf = s.get("tf") or "day"
            tf_txt = {"day": "[일]", "week": "[주]", "month": "[월]",
                      "min1": "[1분]", "min3": "[3분]", "min15": "[15분]"}.get(tf, "")
            _add({"cond_key": s["cond_key"],
                        "cond_txt": f"📅예약 {s.get('grade','')} {tf_txt} {s['cond_txt'][:40]}",
                        "slots": slots, "win_rate": None,
                        "oos_pass": 1, "pf": None, "signal_count": 0,
                        "validated": True, "scheduled": True})
            if len(out) >= n:
                return out
    except Exception:
        pass
    # 0.5) ★ 엄밀 검증 통과(채택 후보/조건부) 조건식 최우선 - '이름 붙여서' 모의매매에 올림
    try:
        from validation import get_validation_top
        vtop = get_validation_top(limit=n)
        for v in vtop:
            ck = str(v.get("cond_key", ""))
            cond = None
            try:
                for c in db.get_conditions(status="active"):
                    if str(c["id"]) == ck:
                        cond = c
                        break
            except Exception:
                cond = None
            if not cond:
                continue
            try:
                slots = json.loads(cond.get("slots_json") or "[]")
            except Exception:
                slots = []
            if not slots:
                continue
            # ★ 이름 붙이기: cond_txt 앞에 등급 표시 (예: "🏆검증통과[채택] 사진1 ...")
            badge = "🏆검증통과" if v.get("grade") == "채택 후보" else "✅검증통과"
            _add({"cond_key": ck,
                        "cond_txt": f"{badge} {cond.get('cond_txt', '')}",
                        "slots": slots, "win_rate": v.get("avg_ret"),
                        "oos_pass": 1, "pf": None,
                        "signal_count": v.get("trades", 0), "validated": True})
            if len(out) >= n:
                return out
    except Exception:
        pass
    # 1) 명예의 전당 (가장 검증된 조건식 - 우선)
    try:
        hof = db.hof_list(limit=n * 2, ranked_only=True)  # ★ 상위 랭킹만 (중복 제외)
        for h in hof:
            try:
                slots = json.loads(h.get("slots_json") or "[]")
            except Exception:
                slots = []
            if not slots:
                continue
            _add({"cond_key": h["cond_key"], "cond_txt": h["cond_txt"],
                        "slots": slots, "win_rate": h.get("best_win_rate"),
                        "oos_pass": 1, "pf": h.get("best_pf"),
                        "signal_count": h.get("sample_count", 0)})
            if len(out) >= n:
                return out
    except Exception:
        pass
    # 2) 명예의 전당 부족 시: 스크리너 OOS 통과 우선 + 성적순
    rows = db.get_screener_results(limit=50, min_signals=min_signals)
    def _key(r):
        oos_bonus = 1000 if r.get("oos_pass") else 0
        w = r.get("win_rate") or 0
        pf = r.get("pf") or 0
        s = r.get("signal_count") or 0
        return oos_bonus + w * max(min(pf, 5), -5) * min(1, s / 100)
    rows.sort(key=_key, reverse=True)
    for r in rows:
        if len(out) >= n:
            break
        try:
            slots = json.loads(r.get("slots_json") or "[]")
        except Exception:
            slots = []
        if not slots:
            continue
        _add({"cond_key": r["cond_key"], "cond_txt": r["cond_txt"],
                    "slots": slots, "win_rate": r.get("win_rate"),
                    "oos_pass": r.get("oos_pass"), "pf": r.get("pf"),
                    "signal_count": r.get("signal_count")})
    return out


# ── 포지션 관리 (paper_positions 테이블) ─────────────────

def _check_signal(slots, symbol, cur_price):
    """조건식 신호 체크: 오늘 최신 일봉(백필/실시간 fetch) 기준
    반환: (bool, 이유)
    """
    try:
        from screener import build_features, SLOTS as S
        from strategy_auto import get_daily_series
        from backfill_history import fetch_daily
        bars = get_daily_series(symbol, max_days=90)
        if len(bars) < 30:
            fd = fetch_daily(symbol, days=90)
            if len(fd) >= 30:
                bars = [{"close": b["close"], "high": b["high"],
                         "low": b["low"], "volume": b["volume"]} for b in fd]
        if len(bars) < 30:
            return False, "일봉 부족"
        # 오늘 봉 합성 (현재가)
        last = bars[-1]
        bars = bars + [{"close": cur_price, "high": max(cur_price, last["high"]),
                        "low": min(cur_price, last["low"]), "volume": last.get("volume") or 0}]
        f = build_features(bars)
        if not f:
            return False, "지표 계산 불가"
        i = len(f["close"]) - 1
        for k, p in slots:
            if k not in S:
                return False, f"모르는 슬롯 {k}"
            try:
                if not S[k][3](f, i, p):
                    return False, f"조건 불충족 {S[k][0].format(**p) if S[k][1] else S[k][0]}"
            except Exception:
                return False, f"조건 평가 오류 {k}"
        return True, "신호 발생"
    except Exception as e:
        return False, f"오류 {e}"


def _signals_all_conditions(conditions, max_symbols=3000):
    """★ 전 종목 스캔: 백필 일봉 있는 모든 종목에서 조건식별 신호 감지
    ★ 봉 기준(tf) 반영: 주봉/월봉 조건식은 일봉을 리샘플링해 평가 (사진 조건식의 [주]/[월])
      분봉(min*) 조건식은 전 종목 분봉이 없으므로 일봉 근사로 평가 (스캘핑은 scalp 경로)
    conditions: [{cond_key, slots, tf, ...}]
    반환: {cond_key: [symbol, ...]} (신호 난 종목)
    """
    from screener import load_features, SLOTS as S
    try:
        # 백필 30일+ 있는 종목 (전 종목 - 순위/감시 풀 무관)
        cov = db.backfill_coverage(min_days=30)
        syms = [s for s, cnt in cov["symbols"].items() if cnt >= 30][:max_symbols]
        if not syms:
            return {}
    except Exception as e:
        log.warning(f"전 종목 지표 로드 실패: {e}")
        return {}
    # ★ 봉 기준별로 나눠 로드 (주봉/월봉은 리샘플링 - 일봉 1000봉이면 주봉~200, 월봉~48)
    feats_cache = {}
    out = {}
    for cond in conditions:
        slots = cond.get("slots") or []
        if not slots:
            continue
        keys = [k for k, _p in slots]
        prms = [p for _k, p in slots]
        if any(k not in S for k in keys):
            continue
        tf = cond.get("tf", "day")
        # 분봉(min*)은 전 종목 분봉 부족 → 일봉 근사 (표시는 분봉 유지)
        scan_tf = tf if tf in ("week", "month") else "day"
        try:
            if scan_tf not in feats_cache:
                # ★ 메모리 최적화: 배치 처리 (한 번에 500종목씩 - RAM 튀는 것 방지)
                feats_cache[scan_tf] = {}
                _batch = 500
                for _i in range(0, len(syms), _batch):
                    _chunk = load_features(syms[_i:_i + _batch], max_symbols=_batch, tf=scan_tf)
                    feats_cache[scan_tf].update(_chunk)
        except Exception:
            feats_cache[scan_tf] = feats_cache.get(scan_tf, {})
        feats = feats_cache.get(scan_tf, {})
        hits = []
        for sym, f in feats.items():
            if not f:
                continue
            i = len(f["close"]) - 1
            ok = True
            for k, p in zip(keys, prms):
                try:
                    if not S[k][3](f, i, p):
                        ok = False
                        break
                except Exception:
                    ok = False
                    break
            if ok:
                hits.append(sym)
        if hits:
            out[cond["cond_key"]] = hits
    return out


def _get_price(symbol):
    """현재가 (5분 스냅샷 캐시 → API)"""
    try:
        from engine import get_quote_cached
        q = get_quote_cached(symbol, max_age_sec=300)
        if q and q.get("price"):
            return q["price"]
    except Exception:
        pass
    return db.get_latest_price(symbol) or 0


def daily_circuit_ok():
    """★ 일일 손실 서킷브레이커 (2026-08-27 추가)
    당일 실현손실이 가상자본의 DAILY_LOSS_STOP_PCT(기본 3%)를 넘으면
    → 신규 매수 전면 정지 (조건식/채널/스캘핑 전부). 매도·손절·가드는 계속.
    '나쁜 날 물타기로 계좌 녹이는' 사고 방지 - 내일 리셋.
    반환: (ok: bool, today_pnl_won: float, limit_won: float)
    """
    try:
        limit_pct = _cfg_env_float("DAILY_LOSS_STOP_PCT", 3.0)
    except Exception:
        limit_pct = 3.0
    if limit_pct <= 0:
        return True, 0.0, 0.0  # 0이면 비활성
    limit_won = VIRTUAL_CASH * limit_pct / 100.0
    try:
        today = db.now_kst().strftime("%Y-%m-%d")
        with db.get_conn() as conn:
            row = conn.execute(
                "SELECT COALESCE(SUM((exit_price-entry_price)*qty),0) v "
                "FROM paper_positions WHERE status='closed' AND date(exit_time)=?",
                (today,)).fetchone()
        pnl = float(row["v"] or 0)
    except Exception:
        return True, 0.0, limit_won
    return (pnl > -limit_won), pnl, limit_won


def entry_slip(price):
    """★ 채널 공용 진입가 슬리피지 (2026-08-27)
    조건식 경로는 DRY_RUN 기록 시 +SLIPPAGE_PCT를 붙이는데 채널(AI픽/급등/세력선/기준선)은
    안 붙여서 채널 성적이 공짜로 유리했음 → 5채널 비교 공정성 위해 통일.
    (실제 모의주문 체결가를 쓰는 경로는 그대로 - 이 함수는 기록용 가격에만)
    """
    try:
        slip = float(getattr(CFG, "SLIPPAGE_PCT", 0.15)) / 100.0
        return price * (1 + slip)
    except Exception:
        return price


def _cash_used():
    """가상 사용 중 금액 (오픈 포지션 매입액)"""
    try:
        with db.get_conn() as conn:
            rows = conn.execute(
                "SELECT COALESCE(SUM(entry_price*qty),0) v FROM paper_positions WHERE status='open'"
            ).fetchone()
        return rows["v"] if rows else 0
    except Exception:
        return 0


# ── 실제 모의투자 주문 (가짜 돈 - 키움 모의계좌) ──
# ★ 조건식 신호 → 키움 모의계좌에 실제 주문 (장중 09:00~15:30, 가짜 돈)
#   DRY_RUN=true면 주문 생략(로그만), false면 실제 모의주문 체결
REAL_PAPER_ORDER = True  # 실제 모의투자 주문 사용 (가짜 돈이라 무관)


def _in_market_hours():
    """장중 여부 (09:00~15:30, 주말/공휴일 제외) - 주문은 장중만"""
    try:
        from db import is_trading_day, now_kst
        now = now_kst()
        if not is_trading_day(now.date()):
            return False
        return 9 <= now.hour < 15 or (now.hour == 15 and now.minute <= 30)
    except Exception:
        return False


def _index_risk():
    """★ 시장(지수) 위험 레벨 - 네이버 실시간 코스피/코스닥 등락률 기준 (키 없이 동작)
    반환: {"level": "normal"|"warning"|"danger", "pct": float, "reason": str, "indices": [...]}
    - INDEX_ENABLED=false면 항상 normal
    - 정상(≥WARN): 진입 OK / 주의(≤WARN): 진입 중단 / 위험(≤CRASH): 진입 중단 + 보유 청산
    - WARN/CRASH가 0이면 해당 레벨 비활성
    """
    index_enabled = getattr(CFG, "INDEX_ENABLED", True)
    warn = float(getattr(CFG, "INDEX_WARN_PCT", -1.0))
    crash = float(getattr(CFG, "INDEX_CRASH_PCT", -2.0))
    indices = []
    try:
        from backfill_history import fetch_index
        for nm in ("KOSPI", "KOSDAQ"):
            try:
                ix = fetch_index(nm)
                if ix:
                    indices.append(ix)
                    try:
                        db.record_index(ix["name"], ix["value"], ix["change_pct"])
                    except Exception:
                        pass
            except Exception:
                continue
    except Exception:
        pass
    if not indices:
        # DB 폴백: 오늘 저장된 지수 최신값
        try:
            for r in db.get_index_summary():
                if r.get("change_pct") is not None:
                    indices.append({"name": r["index_name"], "symbol": r["index_name"],
                                    "value": r["last_value"], "change_pct": r["change_pct"]})
        except Exception:
            pass
    if not indices:
        return {"level": "normal", "pct": 0.0, "reason": "지수 데이터 없음", "indices": []}
    # 코스피·코스닥 중 더 나쁜 쪽 기준 (보수적 - 어느 지수든 급락하면 시장 위험)
    ref = min(indices, key=lambda i: i["change_pct"])
    pct = ref["change_pct"]
    if crash < 0 and pct <= crash:
        level = "danger"
    elif warn < 0 and pct <= warn:
        level = "warning"
    else:
        level = "normal"
    reason = " · ".join(f"{i['name']} {i['change_pct']:+.2f}%" for i in indices)
    # ★ 모의 단계(INDEX_ENABLED=false): 레벨은 normal(필터 없음)로 두되 지수는 수집·로그 유지
    if not index_enabled:
        return {"level": "normal", "pct": pct, "reason": f"지수참고 {reason}", "indices": indices}
    return {"level": level, "pct": pct, "reason": reason, "indices": indices}


def _place_real_order(symbol, side, qty, price):
    """키움 실제 모의주문 (가짜 돈). 반환: result dict"""
    from kiwoom_client import client
    return client.place_order(symbol, side, qty, price, order_type="00")


# ── ★ 조건식 × 지수 국면 점수제 (나중에 쌓인 데이터로 AI가 판단) ──

def _regime_ai_scores(force=False):
    """AI 국면 점수 캐시 (하루 1회 갱신 - 전략/작업 폴더에 저장)
    반환: (scores: {cond_key: int/None}, provider: "gemini"|"rule")
    """
    import os as _os
    import json as _json
    path = _os.path.join("strategy", "index_scores.json")
    try:
        if not force and _os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                data = _json.load(f)
            from db import now_kst
            if (data.get("at") or "")[:10] == now_kst().strftime("%Y-%m-%d"):
                return data.get("scores", {}), data.get("provider", "rule")
    except Exception:
        pass
    try:
        from ai_consult import review_index_regimes
        r = review_index_regimes()
        scores = {k: (int(v) if v is not None else None) for k, v in r["scores"].items()}
        try:
            _os.makedirs("strategy", exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                _json.dump({"at": db.now_kst_iso(), "provider": r["provider"],
                            "scores": scores}, f, ensure_ascii=False)
        except Exception:
            pass
        return scores, r["provider"]
    except Exception:
        return {}, "rule"


def _regime_blocked(cond_key, cond_txt, cur_index_pct, _log):
    """★ 하락장 국면에서 조건식 국면 점수 미달 시 진입 차단 (점수제)
    - 현재 지수가 하락 국면(INDEX_WARN_PCT 이하)이 아니면 통과
    - 해당 조건식 하락 표본 < MIN_SELLS → 통과 (미평가 = 데이터 쌓일 때까지 허용)
    - AI 점수 우선, 없으면 규칙 점수. 점수 < INDEX_COND_MIN_SCORE → 차단
    """
    if not getattr(CFG, "INDEX_COND_ENABLED", True):
        return False
    try:
        warn = float(getattr(CFG, "INDEX_WARN_PCT", -1.0))
        if cur_index_pct is None or cur_index_pct > warn:
            return False  # 하락 국면이 아니면 통과
        ai_scores, _prov = _regime_ai_scores()
        score = ai_scores.get(str(cond_key))
        if score is None:
            cs = db.index_condition_stats().get(str(cond_key), {})
            score = db.regime_rule_score(cs)
        if score is None:
            return False  # ★ 표본 부족 - 미평가 (제한 없음)
        min_score = float(getattr(CFG, "INDEX_COND_MIN_SCORE", 50))
        if score < min_score:
            _log(f"⛔ [국면점수] {str(cond_txt)[:28]} 하락장 점수 {score}점 < {min_score:.0f} - 진입 제한")
            return True
    except Exception:
        pass
    return False


def run_paper_once(conditions=None, symbols=None, max_new=12, log_out=None, scan_all=False):
    """
    ★ 모의 매매 1사이클 (실제 모의투자 주문 - 가짜 돈)
    - 장중(09:00~15:30): 조건식 신호 종목 → 키움 모의계좌 실제 주문 (매수/매도)
    - 장외: 신호만 기록(대기) - 다음 장중에 주문
    - DRY_RUN=true면 주문 생략(로그만) / false면 실제 모의주문 체결
    반환: {entered, exited, held, cash, summary, signals, note}
    """
    from db import now_kst
    if conditions is None:
        conditions = top_conditions(TOP_N_CONDITIONS)
    # ★ 조건식이 없어도 즉시 반환하지 않음! (치명적 버그 수정)
    #   기존: 여기서 바로 return → 수동 매수 동기화·매도 루프(하드손절)까지 전부 스킵
    #   → 조건식 0개인 동안 손매수 종목이 -7%가 돼도 손절이 안 나가던 원인
    #   수정: 진입(매수)만 건너뛰고, 계좌 동기화 + 매도/손절 루프는 항상 실행
    no_conditions = not conditions

    def _log(msg):
        if log_out:
            log_out(msg)
        log.info(msg)

    in_market = _in_market_hours()
    # ★ 수동 매수 반영: 실제 계좌 보유(수동 매수 포함)를 감지해 포지션 등록/갱신
    #   → 이후 AI 매도 판단이 이 종목들도 평가·청산 (AI가 알아서 매도)
    #   (계좌 조회 실패 시에는 원인 로그가 남고 None 반환 → 조용히 넘어가지 않음)
    _real = _real_account_holdings(_log)
    if _real:
        _m = sync_manual_holdings(_real, _log)
        if _m.get("added", 0) > 0:
            _log(f"📥 수동 매수 반영: 실제 계좌 {_m['added']}종목 자동 등록 (AI 매도 관리 대상)")
        # AI 매도 판단용으로 risk에 실제 보유 전달
        try:
            risk = risk or {}
            risk["real_hold"] = _real
        except Exception:
            pass
    # ★ 시장(지수) 위험 스위치 — ★ 모의투자 단계: 지수 필터 완전 해제 (사용자 요청)
    #   "지금은 -2%여도 상관없어. 하락장에서도 빛을 발하는 검색이 있을 수 있으니 전체 전부 확인"
    #   → warning/danger 모두 진입 진행. 지수는 로그로만 기록 (검증용 데이터로 쌓임)
    #   실전 전환 시 INDEX_ENABLED=true 로 되돌리면 급락 방어가 다시 켜짐
    risk = _index_risk()
    if risk["level"] != "normal":
        _log(f"📊 지수 참고({risk['level']}): {risk['reason']} - 모의라 진입 진행 (실전 시 INDEX_ENABLED로 방어)")
    if no_conditions:
        # ★ 조건식 없음: 신규 진입만 생략 - 아래 매도/손절 루프는 그대로 진행
        _log("⚠️ 상위 조건식 없음 - 신규 진입 생략 (보유 종목 매도/하드손절 관리는 계속)")
        entered, exited = [], []
    elif in_market and REAL_PAPER_ORDER:
        entered, exited = _paper_execute(conditions, max_new, _log, scan_all, risk)
    elif not in_market and REAL_PAPER_ORDER:
        _log("⏰ 장외 - 실제 모의주문은 장중(09:00~15:30)에만. 신호만 수집해 대기합니다.")
        # 장외: 신호만 감지해 기록 (다음 장중에 주문하도록 DB에 pending 기록은 생략 - 단순화)
        # 여기서는 청산 체크만 하고 진입은 대기
        entered, exited = [], []
    else:
        entered, exited = _paper_execute(conditions, max_new, _log, scan_all, risk)
    held_count = db.count_paper_open()
    # ── 2) 청산: ★ AI/매도 프롬프트가 매도 시점 결정 (키 없으면 규칙·트레일링스탑) ──
    #    · AI가 '보유'면 고정 익절 없이 계속 보유 (사용자 요청: 이익난 종목은 AI가 매도 시점 판단)
    #    · 단, 하드손절(-3%)과 최대 보유일수는 절대 규칙 (evaluate_sell 내부에서 하드손절 처리)
    #    · 슬리피지 반영: DRY_RUN/기록 경로는 매도가 -SLIPPAGE_PCT로 보수적 체결 (실제 모의주문은 키움 체결가)
    slip = float(getattr(CFG, "SLIPPAGE_PCT", 0.15)) / 100.0
    for pos in db.get_paper_open():
        price = _get_price(pos["symbol"])
        if not price or price <= 0:
            continue
        exit_price = price * (1 - slip) if CFG.DRY_RUN else price
        ret = (exit_price - pos["entry_price"]) / pos["entry_price"] * 100
        hold_days = 0
        try:
            hold_days = (now_kst() - datetime.fromisoformat(pos["entry_time"])).days
        except Exception:
            pass
        # 최고/최저 수익률 갱신 (AI 매도 판단용 - 매수후최고/최저수익률 추적)
        cur_ret_p = (price - pos["entry_price"]) / pos["entry_price"] * 100
        if cur_ret_p > (pos.get("highest_return") or 0):
            db.update_paper_highest(pos["id"], round(cur_ret_p, 2))
            pos["highest_return"] = round(cur_ret_p, 2)
        if cur_ret_p < (pos.get("lowest_return") or 0):
            db.update_paper_lowest(pos["id"], round(cur_ret_p, 2))
            pos["lowest_return"] = round(cur_ret_p, 2)
        reason = None
        # ⓪ ★ 지수 급락 전량 매도 — 모의 단계에선 해제 (사용자: 하락장에서도 전체 확인)
        #   INDEX_EMERGENCY_SELL=true(기본 false)면 다시 켜짐 (실전 전환 시)
        if getattr(CFG, "INDEX_EMERGENCY_SELL", False) and risk["level"] == "danger":
            reason = f"[시장리스크] 지수 급락({risk['reason'][:40]}) - 전량 매도"
        # ⓪-1 ★ 매수 시점 매도 지침: 손절가 이탈 → 무조건 손절 (AI와 무관한 절대 규칙)
        #   (매수할 때 build_sell_plan이 정한 손절가 - 20일 저점/하드손절 중 보수한 쪽)
        stp = pos.get("stop_price") or 0
        if not reason and stp and price <= stp:
            reason = f"[매도지침] 손절가 {stp:,.0f}원 이탈({ret:+.1f}%) - 지침대로 무조건 손절"
        # ⓪-2 ★ 목표가 도달 안내 (강제 익절 아님 - AI/트레일링이 '더 오를지' 판단해 유동적으로)
        #   AI가 보유면 계속 보유 + 최고수익률 추적(트레일링)이 매도 시점 결정
        tgt = pos.get("target_price") or 0
        if not reason and tgt and price >= tgt:
            _log(f"🎯 [매도지침] {pos['symbol']} 목표가 {tgt:,.0f}원 도달({ret:+.1f}%) - "
                 f"AI/트레일링이 익절 시점 판단")
        # ① AI/매도 프롬프트 매도 판단 (AI_SELL_GATE=true일 때만 - 기본 ON)
        #    시장리스크(⓪)/지침 손절(⓪-1)이 이미 매도 결정이면 AI 판단은 건너뜀
        if not reason and getattr(CFG, "AI_SELL_GATE", True):
            try:
                from ai_judge import evaluate_sell
                if CFG.AI_JUDGE_ENABLED:
                    md = {"price": price, "현재가": price,
                          "전일고가": pos["entry_price"] * 1.02,
                          "전일저가": pos["entry_price"] * 0.98,
                          "전일종가": pos["entry_price"],
                          "체결강도": 100, "최근1분거래대금": price * 100000,
                          "최근3분거래대금": price * 300000,
                          "저가": price * 0.99, "고점갱신": False,
                          "거래대금동시증가": False, "중심선아래약세": False}
                    decision, _r = evaluate_sell(pos["symbol"], md, {
                        "entry_price": pos["entry_price"],
                        "highest_return": pos.get("highest_return") or 0,
                        "lowest_return": pos.get("lowest_return") or 0,
                        "holding_minutes": max(1, hold_days * 24 * 60),
                        # ★ 매수 시점 매도 지침을 AI 판단에도 전달 (AI가 목표/손절 참고)
                        "target_price": tgt or 0,
                        "stop_price": stp or 0,
                        "sell_plan": pos.get("sell_plan") or ""})
                    # ★ 2026-09-01: AI 매도 판단도 judgments에 기록 (보유 판단 포함)
                    #   (사용자: "매수 매도시 AI가 처리함이 확인 되는지" - 증거 남기기)
                    try:
                        _eng = "ai" if str(_r).startswith("[AI]") else "rule"
                        db.record_judgment(pos["symbol"], "sell", decision, _eng,
                                           reason=str(_r)[:300])
                    except Exception:
                        pass
                    if decision in ("수익청산", "손절"):
                        reason = f"[AI매도] {decision}: {_r[:55]}"
            except Exception:
                pass
        # ② 최대 보유일수는 AI와 무관한 절대 규칙
        if not reason and hold_days >= MAX_HOLD_DAYS:
            reason = f"보유 {hold_days}일 경과 청산 ({ret:+.1f}%)"
        if reason:
            # ★ 장외 + 실주문 모드: 주문 없이 기록만 청산하면 실제 모의계좌와 어긋남
            #   (계좌엔 종목이 남는데 내부는 '청산됨') → sell_guard처럼 '감지-대기'로 통일
            #   다음 장중 사이클(또는 매도가드)이 실제 주문과 함께 청산 (2026-08-27 수정)
            if REAL_PAPER_ORDER and not in_market and not CFG.DRY_RUN:
                _log(f"⏰ {pos['symbol']} 매도 조건 감지({reason[:40]}) - 장외라 대기 "
                     f"(개장 후 실제 주문과 함께 청산)")
                continue
            # 실제 모의주문 매도 (장중만 / DRY_RUN 생략)
            order = None
            if REAL_PAPER_ORDER and in_market and not CFG.DRY_RUN:
                order = _place_real_order(pos["symbol"], "sell", pos["qty"], price)
                if order and order.get("status") in ("error",):
                    _log(f"⚠️ 매도 주문 실패 {pos['symbol']}: {order.get('message','')}")
                    continue
            db.close_paper_position(pos["id"], exit_price, ret,
                                    exit_index_pct=risk.get("pct"), reason=reason)
            exited.append({"symbol": pos["symbol"], "ret": round(ret, 2), "reason": reason,
                           "cond": pos["cond_txt"][:50]})
            _log(f"[모의실전] 청산 {pos['symbol']} {ret:+.2f}% | {reason}" + (" (실제주문)" if order else ""))

    held_count = db.count_paper_open()
    summary = paper_summary()
    return {"entered": entered, "exited": exited, "held": held_count,
            "cash": summary.get("cash", VIRTUAL_CASH), "summary": summary, "note": "",
            "in_market": in_market, "risk": risk}


def _real_account_holdings(_log=None):
    """★ 실제 키움 계좌 보유 종목 (거짓 없는 진짜 보유)
    - DRY_RUN=false + 키/계좌 정상 → kt00005 실제 보유 반환
    - DRY_RUN=true / 키 없음 / 실패 → None (실제 계좌를 못 봄 → 매수 진행 불가 표시)
    - ★ 왜 안 보이는지 원인을 로그로 남김 (사용자: '손매수 종목이 안 보임' → 원인 확인용)
    반환: {"symbol": {"qty": n, "avg_price": p}} / None(계좌 연동 불가)
    """
    def _warn(msg):
        if _log:
            try:
                _log(msg)
            except Exception:
                pass
        try:
            log.warning(msg)
        except Exception:
            pass

    try:
        if CFG.DRY_RUN:
            _warn("⚠️ DRY_RUN=true → 실제 계좌 조회를 하지 않습니다 (손매수 종목도 표시 안 됨). "
                  ".env에서 DRY_RUN=false로 바꿔야 실제 보유가 보입니다.")
            return None
        from kiwoom_client import client
        acc = client.get_account_overview()
        if not isinstance(acc, dict):
            _warn("⚠️ 실제 계좌 조회 응답 이상 (dict 아님) - 손매수 종목 표시 불가")
            return None
        if acc.get("mock"):
            _warn("⚠️ 계좌 응답이 mock(키 없음/모의 기본값) - 실제 보유를 못 봅니다. "
                  "모의/실전용 키(.env APP_KEY/SECRET)와 계좌번호(ACCOUNT_NO) 확인 필요")
            return None
        if acc.get("errors"):
            _warn(f"⚠️ 실제 계좌 조회 오류: {' | '.join(str(e) for e in acc['errors'][:3])} "
                  "- 키/계좌번호/서버(모의·실전) 확인 필요")
        if not acc.get("positions"):
            _warn("⚠️ 실제 계좌 보유 종목 0개 (kt00005 응답은 성공했으나 보유 내역 없음) - "
                  "계좌에 종목이 없거나 응답 구조가 다름")
            return None
        out = {}
        for p in acc["positions"]:
            sym = p.get("symbol", "")
            if sym:
                out[sym] = {"qty": p.get("qty", 0) or 0, "avg_price": p.get("avg_price", 0) or 0}
        return out
    except Exception as e:
        _warn(f"⚠️ 실제 계좌 보유 조회 예외: {str(e)[:80]} - 손매수 종목 표시 불가")
        return None


def sync_manual_holdings(real_hold, _log=None):
    """★ 수동 매수 반영: 실제 계좌 보유 종목(사용자가 직접 산 것 포함)을
    paper_positions에 'MANUAL' 포지션으로 자동 등록/갱신.
    - 이후 AI 매도 판단 루프가 이 포지션도 평가·청산 (AI가 알아서 매도)
    - 이미 등록된 종목은 갱신만 (중복 없음)
    반환: {"added": n, "total": m, "already": k}
    """
    if not real_hold:
        return {"added": 0, "total": 0, "already": 0}
    added = 0
    already = 0
    for sym, info in real_hold.items():
        try:
            with db.get_conn() as conn:
                ex = conn.execute(
                    "SELECT id FROM paper_positions WHERE symbol=? AND cond_key='MANUAL' "
                    "AND status='open'", (sym,)).fetchone()
                if ex:
                    # 수량/평단 갱신 (최신 계좌 반영)
                    conn.execute(
                        "UPDATE paper_positions SET qty=?, entry_price=? WHERE id=?",
                        (info["qty"], info["avg_price"] or 0, ex["id"]))
                    already += 1
                    continue
                # 새 수동 포지션 등록
                conn.execute(
                    "INSERT INTO paper_positions (cond_key, cond_txt, symbol, entry_price, "
                    "entry_time, qty, status, highest_return, order_kind) VALUES (?,?,?,?,?,?,?,?,?)",
                    ("MANUAL", "[수동매수] 사용자가 직접 매수한 종목 - AI가 매도 시점 판단",
                     sym, info["avg_price"] or 0, db.now_kst_iso(), info["qty"], "open", 0.0,
                     "real"))   # 실제 계좌에서 온 것 = real
            added += 1
        except Exception:
            continue
    if _log:
        try:
            _log(f"📥 수동 매수 동기화: 신규 {added} · 기존 유지 {already} (계좌 보유 {len(real_hold)}종목)")
        except Exception:
            pass
    return {"added": added, "total": len(real_hold), "already": already}


def _paper_execute(conditions, max_new, _log, scan_all, risk=None):
    """진입 실행 (장중 실제 모의주문)"""
    from db import now_kst
    slip = float(getattr(CFG, "SLIPPAGE_PCT", 0.15)) / 100.0  # 매수는 +슬리피지 (보수적)
    cur_index_pct = (risk or {}).get("pct")                   # 진입 시점 지수 등락률 (국면 점수제)
    entered = []
    # ★ 일일 손실 서킷브레이커: 오늘 실현손실이 한도 초과면 신규 매수 정지 (매도는 계속)
    ok_cb, pnl_cb, lim_cb = daily_circuit_ok()
    if not ok_cb:
        _log(f"🚫 [서킷브레이커] 오늘 실현손실 {pnl_cb:+,.0f}원이 한도 -{lim_cb:,.0f}원 초과 "
             f"- 신규 매수 전면 정지 (매도/손절은 계속, 내일 자동 해제)")
        return entered, []
    # ★ 거짓 없는 실제 계좌 기준: 실제 보유 종목을 조회해 중복 매수 방지 + 현황 표시
    real_hold = _real_account_holdings(_log)
    if real_hold is None:
        _log("⚠️ 실제 계좌 연동 불가 - 보유는 내부 기록 기준으로만 표시됩니다 (실제 주문 아님). "
             "위 원인 로그 참고")
    else:
        _log(f"💰 실제 계좌 보유 {len(real_hold)}종목 (거짓 없음 - kt00005 연동)")
    held_count = db.count_paper_open()
    if held_count >= MAX_QTY * 10:
        return entered, []
    # ★ 매수 스킵 사유 집계 (사용자: '왜 안 사고 있나 확인')
    skip = {"대장주제외": 0, "이미보유": 0, "가격필터": 0, "국면점수": 0,
            "등급게이트": 0, "자금부족": 0, "최대건수": 0, "AI매수게이트": 0}
    if scan_all:
        sig_map = _signals_all_conditions(conditions)
        # ★ 검색/신호 현황 명확 표시 (사용자: '검색되고 있는지 모르겠다')
        try:
            cov = db.backfill_coverage(min_days=30)
            n_ready = cov.get("ready", 0)
            n_sig = sum(len(v) for v in sig_map.values())
            n_cond = len([v for v in sig_map.values() if v])
            _log(f"🔎 전 종목 스캔: 30봉+ {n_ready}종목 · 신호 {n_sig}건 ({n_cond}조건식)")
            if n_ready == 0:
                _log("⚠️ 아직 백필 30봉+ 종목이 없어 검색이 안 됩니다 - 데이터 수집 계속 진행 중 (장마감 후 라운드가 채웁니다)")
        except Exception:
            pass
        # ── ★👑 대장주 공략: 신호 종목 중 '오늘 강한 종목'만 골라 저점매수 ──
        #    (LEADER_ENABLED=true면 대장주만 진입 / false면 기존처럼 전부 진입)
        leader_picks = None
        try:
            # ★ CFG.LEADER_ENABLED 기준 (leader 모듈 전역이 아닌 - 설정 통일)
            from leader import pick_leaders
            if getattr(CFG, "LEADER_ENABLED", True):
                all_hits = []
                for _v in sig_map.values():
                    all_hits += _v
                all_hits = list(dict.fromkeys(all_hits))
                if all_hits:
                    _lp = pick_leaders(all_hits)
                    _picks = _lp.get("picks", [])
                    if _picks:
                        leader_picks = {p["symbol"]: p for p in _picks}
                        _log(f"👑 [대장주] {_lp.get('note', '')}: "
                             + ", ".join(f"{p['symbol']} {p.get('name', '')}" for p in _picks))
                    else:
                        # ★ 대장주 후보 없음/실패 → 전체 신호 진입 폴백 (안전 - 매매 중단 방지)
                        _log(f"👑 대장주 선별 실패/후보 없음({_lp.get('note', '')[:30]}) "
                             f"→ 전체 신호 진입")
                        leader_picks = None
        except Exception:
            leader_picks = None
        for cond in conditions:
            cond_key = cond["cond_key"]
            for sym in sig_map.get(cond_key, []):
                if len(entered) >= max_new:
                    skip["최대건수"] += 1
                    break
                if leader_picks is not None and sym not in leader_picks:
                    skip["대장주제외"] += 1
                    continue  # ★ 대장주 공략: 선별된 종목만 진입
                if cond_key == "MANUAL":
                    continue  # 수동 매수는 사용자가 이미 샀음 - 진입 대상 아님
                if db.paper_has_open(sym, cond_key):
                    skip["이미보유"] += 1
                    continue
                if real_hold and sym in real_hold:
                    skip["이미보유"] += 1
                    _log(f"🚫 {sym} 실제 계좌에 이미 보유 중 ({real_hold[sym]['qty']}주) - 재매수 방지")
                    continue
                price = _get_price(sym)
                if price <= 0 or price < CFG.MOCK_PRICE_MIN or price > CFG.MOCK_PRICE_MAX:
                    skip["가격필터"] += 1
                    continue
                # ★ 국면 점수제: 하락장에서 점수 미달인 조건식은 진입 제한 (AI/규칙 판단)
                if _regime_blocked(cond_key, cond["cond_txt"], cur_index_pct, _log):
                    skip["국면점수"] += 1
                    continue
                # ★ AI 매수 게이트 (설정 ON일 때만 - 매수 시 AI 판단 신뢰도 통과해야 진입)
                #   기본 OFF = 지금 방향 (검증된 조건식 신호로만 매수)
                if getattr(CFG, "AI_BUY_GATE", False):
                    try:
                        from ai_judge import evaluate_buy
                        md = {"price": price, "현재가": price,
                              "전일고가": price * 1.02, "전일저가": price * 0.98,
                              "전일종가": price, "체결강도": 100,
                              "최근1분거래대금": price * 100000, "최근3분거래대금": price * 300000,
                              "저가": price * 0.99, "고점갱신": False,
                              "거래대금동시증가": False, "중심선아래약세": False}
                        ok_buy, reason_buy = evaluate_buy(sym, md)
                        # ★ 2026-09-01: AI 매수 판단을 judgments에 기록 (통과/거부 모두)
                        #   현황판 거래 클릭 → "AI 판정 이력"에 뜨는 근거 (사용자: "AI가 처리함이 확인되는지")
                        try:
                            _eng = "ai" if reason_buy.startswith("[AI]") else "rule"
                            db.record_judgment(sym, "buy",
                                               "매수" if ok_buy else "매수금지",
                                               _eng, reason=reason_buy[:300])
                        except Exception:
                            pass
                        if not ok_buy:
                            skip["AI매수게이트"] += 1
                            db.log_gate_reject(cond_key, sym, price, reason_buy)  # ★ 그림자 추적
                            _log(f"⛔ [AI매수] {sym} 매수금지: {reason_buy[:60]}")
                            continue
                    except Exception:
                        pass
                # ★ 엄밀 검증 등급 게이트 (VALIDATE_GATE_ENABLED=true면 허용 등급만)
                try:
                    from validation import grade_gate_pass
                    if not grade_gate_pass(str(cond_key)):
                        skip["등급게이트"] += 1
                        continue
                except Exception:
                    pass
                cash_left = VIRTUAL_CASH - _cash_used()
                qty = _calc_qty(price, cash_left)
                if qty < 1:
                    skip["자금부족"] += 1
                    continue
                # ★ 실제 모의주문 매수 (가짜 돈 - DRY_RUN이면 생략)
                entry_price = price * (1 + slip) if CFG.DRY_RUN else price
                order = None
                if REAL_PAPER_ORDER and not CFG.DRY_RUN:
                    order = _place_real_order(sym, "buy", qty, price)
                    if order and order.get("status") in ("error", "dry_run_skipped"):
                        _log(f"⚠️ 매수 주문 안됨 {sym}: {order.get('message','')[:50]}")
                        continue
                # ★ 매수 시점 매도 지침 생성 (사용자: '매수되면 평가해서 어느 선에 매도하겠다 지침')
                #   종목 평가(적정가/레인지)로 목표가·손절가를 계산해 포지션에 저장 →
                #   이후 매도 루프가 이 지침에 따라 유동적으로 매도
                plan = None
                try:
                    from ai_consult import build_sell_plan
                    plan = build_sell_plan(sym, entry_price, qty)
                except Exception:
                    plan = None
                db.open_paper_position(cond_key, cond["cond_txt"], sym, entry_price, qty,
                                       entry_index_pct=cur_index_pct,
                                       order_kind=("real" if order else "virtual"),
                                       target_price=(plan or {}).get("target_price"),
                                       stop_price=(plan or {}).get("stop_price"),
                                       sell_plan=(plan or {}).get("plan"),
                                       plan_provider=(plan or {}).get("provider", "rule"))
                entered.append({"symbol": sym, "cond": cond["cond_txt"][:50],
                                "price": entry_price, "qty": qty})
                _log(f"[모의실전] 진입 {sym} {qty}주 @{entry_price:,.0f} | {cond['cond_txt'][:50]}"
                     + (" (실제모의주문)" if order else " (가상기록)"))
                if plan:
                    _log(f"📌 매도 지침 {sym}: 목표 {plan['target_price']:,.0f} "
                         f"(+{plan['target_pct']:.1f}%) · 손절 {plan['stop_price']:,.0f} "
                         f"({plan['stop_pct']:.1f}%) [{plan.get('provider')}] "
                         f"{plan.get('plan', '')[:50]}")
        signals = {k: len(v) for k, v in sig_map.items()}
        # ★ 매수 스킵 사유 요약 (사용자: '왜 안 사고 있나' 확인)
        reasons = " · ".join(f"{k} {v}" for k, v in skip.items() if v > 0)
        if reasons:
            _log(f"🚫 매수 대기/스킵: {reasons} | 진입 {len(entered)}건")
        elif len(entered) == 0 and sum(len(v) for v in sig_map.values()) > 0:
            _log(f"🚫 신호는 {sum(len(v) for v in sig_map.values())}건인데 스킵 없이 0건? (확인 필요)")
        # ★ 2026-08-31 스킵 카운터 일별 누적 (현황판 '왜 안 사나' 표시용)
        try:
            import json as _j
            _sp = os.path.join("strategy", "skip_stats.json")
            _today = now_kst().strftime("%Y-%m-%d")
            _st = {}
            try:
                _st = _j.load(open(_sp, encoding="utf-8"))
            except Exception:
                pass
            if _st.get("date") != _today:
                _st = {"date": _today, "skips": {}, "entered": 0, "signals": 0}
            for k, v in skip.items():
                if v:
                    _st["skips"][k] = _st["skips"].get(k, 0) + v
            _st["entered"] = _st.get("entered", 0) + len(entered)
            _st["signals"] = _st.get("signals", 0) + sum(len(v) for v in sig_map.values())
            _j.dump(_st, open(_sp, "w", encoding="utf-8"), ensure_ascii=False)
        except Exception:
            pass
    else:
        signals = {}
        if symbols is None:
            try:
                from engine import get_watch_candidates
                symbols = [c["symbol"] for c in get_watch_candidates(limit=80)]
            except Exception:
                symbols = []
            if len(symbols) < 20:
                try:
                    from screener import load_screener_symbols
                    symbols = load_screener_symbols(max_symbols=100)
                except Exception:
                    pass
        for cond in conditions:
            cond_key = cond["cond_key"]
            cnt = 0
            for sym in symbols:
                if len(entered) >= max_new:
                    break
                if db.paper_has_open(sym, cond_key):
                    continue
                price = _get_price(sym)
                if price <= 0 or price < CFG.MOCK_PRICE_MIN or price > CFG.MOCK_PRICE_MAX:
                    continue
                if _regime_blocked(cond_key, cond["cond_txt"], cur_index_pct, _log):
                    continue
                # ★ AI 매수 게이트 (설정 ON일 때만 - scan_all 경로와 동일)
                if getattr(CFG, "AI_BUY_GATE", False):
                    try:
                        from ai_judge import evaluate_buy
                        md = {"price": price, "현재가": price,
                              "전일고가": price * 1.02, "전일저가": price * 0.98,
                              "전일종가": price, "체결강도": 100,
                              "최근1분거래대금": price * 100000, "최근3분거래대금": price * 300000,
                              "저가": price * 0.99, "고점갱신": False,
                              "거래대금동시증가": False, "중심선아래약세": False}
                        ok_buy, reason_buy = evaluate_buy(sym, md)
                        # ★ 2026-09-01: AI 매수 판단 기록 (scan_all 경로와 동일)
                        try:
                            _eng = "ai" if reason_buy.startswith("[AI]") else "rule"
                            db.record_judgment(sym, "buy",
                                               "매수" if ok_buy else "매수금지",
                                               _eng, reason=reason_buy[:300])
                        except Exception:
                            pass
                        if not ok_buy:
                            db.log_gate_reject(cond_key, sym, price, reason_buy)  # ★ 그림자 추적
                            _log(f"⛔ [AI매수] {sym} 매수금지: {reason_buy[:60]}")
                            continue
                    except Exception:
                        pass
                ok, _r = _check_signal(cond["slots"], sym, price)
                if not ok:
                    continue
                cash_left = VIRTUAL_CASH - _cash_used()
                qty = _calc_qty(price, cash_left)
                if qty < 1:
                    continue
                entry_price = price * (1 + slip) if CFG.DRY_RUN else price
                order = None
                if REAL_PAPER_ORDER and not CFG.DRY_RUN:
                    order = _place_real_order(sym, "buy", qty, price)
                    if order and order.get("status") in ("error", "dry_run_skipped"):
                        continue
                # ★ 매수 시점 매도 지침 (위 scan_all 경로와 동일)
                plan = None
                try:
                    from ai_consult import build_sell_plan
                    plan = build_sell_plan(sym, entry_price, qty)
                except Exception:
                    plan = None
                db.open_paper_position(cond_key, cond["cond_txt"], sym, entry_price, qty,
                                       entry_index_pct=cur_index_pct,
                                       order_kind=("real" if order else "virtual"),
                                       target_price=(plan or {}).get("target_price"),
                                       stop_price=(plan or {}).get("stop_price"),
                                       sell_plan=(plan or {}).get("plan"),
                                       plan_provider=(plan or {}).get("provider", "rule"))
                entered.append({"symbol": sym, "cond": cond["cond_txt"][:50],
                                "price": entry_price, "qty": qty})
                cnt += 1
            signals[cond_key] = cnt
    return entered, []
    for pos in db.get_paper_open():
        price = _get_price(pos["symbol"])
        if not price or price <= 0:
            continue
        ret = (price - pos["entry_price"]) / pos["entry_price"] * 100
        hold_days = 0
        try:
            hold_days = (now_kst() - datetime.fromisoformat(pos["entry_time"])).days
        except Exception:
            pass
        reason = None
        if ret >= TAKE_PROFIT_PCT:
            reason = f"익절 +{ret:.1f}% (≥+{TAKE_PROFIT_PCT}%)"
        elif ret <= -STOP_LOSS_PCT:
            reason = f"손절 {ret:.1f}% (≤-{STOP_LOSS_PCT}%)"
        elif hold_days >= MAX_HOLD_DAYS:
            reason = f"보유 {hold_days}일 경과 청산 ({ret:+.1f}%)"
        if reason:
            db.close_paper_position(pos["id"], price, ret, reason=reason)
            exited.append({"symbol": pos["symbol"], "ret": round(ret, 2), "reason": reason,
                           "cond": pos["cond_txt"][:50]})
            _log(f"[모의실전] 청산 {pos['symbol']} {ret:+.2f}% | {reason}")

    held_count = db.count_paper_open()
    summary = paper_summary()
    sig_info = None
    if scan_all:
        try:
            sig_info = {k: v for k, v in signals.items()}
        except Exception:
            pass
    return {"entered": entered, "exited": exited, "held": held_count,
            "cash": summary.get("cash", VIRTUAL_CASH), "summary": summary, "note": "",
            "signals": sig_info}


def paper_summary():
    """모의 실전 성과 요약 (승률/손익비/총손익/현금)"""
    try:
        with db.get_conn() as conn:
            closed = conn.execute(
                "SELECT ret_pct FROM paper_positions WHERE status='closed'").fetchall()
            open_rows = conn.execute(
                "SELECT symbol, entry_price, qty FROM paper_positions WHERE status='open'").fetchall()
        rets = [r["ret_pct"] or 0 for r in closed]
        n = len(rets)
        wins = [r for r in rets if r > 0]
        losses = [r for r in rets if r <= 0]
        win_rate = len(wins) / n * 100 if n else 0
        gp = sum(wins)
        gl = abs(sum(losses))
        pf = gp / gl if gl > 0 else (999.0 if gp > 0 else 0)
        # 미실현 평가손익
        unreal = 0.0
        for o in open_rows:
            p = _get_price(o["symbol"]) or o["entry_price"]
            unreal += (p - o["entry_price"]) * o["qty"]
        realized = sum((1 + r) for r in rets) * 0  # 순수익은 아래
        total_pnl = round(sum(r for r in rets if False) + unreal)  # 미실현만
        cash = VIRTUAL_CASH - sum(o["entry_price"] * o["qty"] for o in open_rows)
        return {"trades": n, "wins": len(wins), "losses": len(losses),
                "win_rate": round(win_rate, 1), "pf": round(pf, 2),
                "open": len(open_rows), "unrealized_pnl": round(unreal),
                "cash": round(cash)}
    except Exception:
        return {"trades": 0, "wins": 0, "losses": 0, "win_rate": 0,
                "pf": 0, "open": 0, "unrealized_pnl": 0, "cash": VIRTUAL_CASH}


def paper_status():
    """오픈/청산 포지션 + 요약 (UI용)"""
    return {"summary": paper_summary(),
            "open": db.get_paper_open(),
            "closed": db.get_paper_closed(limit=30)}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="상위 조건식 모의 실전 테스트")
    parser.add_argument("--once", action="store_true", help="1사이클 실행")
    parser.add_argument("--status", action="store_true", help="현황")
    parser.add_argument("--summary", action="store_true", help="성과 요약")
    args = parser.parse_args()
    db.init_db()
    logging.basicConfig(level=logging.INFO)
    if args.once:
        r = run_paper_once()
        print(json.dumps({k: v for k, v in r.items() if k != "summary"}, ensure_ascii=False, indent=1))
        print("요약:", r.get("summary"))
    elif args.status:
        st = paper_status()
        print("요약:", st["summary"])
        for p in st["open"][:20]:
            print(f"  [보유] {p['symbol']} {p['qty']}주 @{p['entry_price']:,.0f} | {p['cond_txt'][:45]}")
    else:
        print(json.dumps(paper_summary(), ensure_ascii=False, indent=1))
