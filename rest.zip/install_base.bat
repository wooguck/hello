@echo off
title Install - Base Packages
cd /d %~dp0
echo.
echo ============================================
echo  [1/4] Python version check
echo ============================================
python --version
python -c "import struct; print('bit:', struct.calcsize('P')*8)"
echo.
echo ============================================
echo  [2/4] Install base packages (REST mode)
echo ============================================
pip install requests pillow matplotlib python-dotenv
echo.
echo ============================================
echo  [3/4] Verify
echo ============================================
python -c "import requests, PIL, matplotlib, dotenv; print('OK - base packages installed')"
echo.
echo ============================================
echo  [4/4] Next steps:
echo    1. Make .env file (copy .env.example to .env)
echo    2. python verify_final.py
echo    3. python collect_data.py --once
echo    4. python desktop_app.py
echo ============================================
echo.
pause
