@echo off
title Collect Data - Once
cd /d %~dp0
echo.
echo ============================================
echo  Collecting all stock daily data (1-3h first time)
echo  Already collected symbols are skipped.
echo ============================================
python collect_data.py --once
echo.
echo  Done. Close this window.
pause
