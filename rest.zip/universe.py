"""전체 종목 유니버스 관리 - 종목 관리 없이 전 종목 스캔 지원

- refresh_universe(): 전 종목 목록을 DB(universe 테이블)에 저장
  1순위: 키움 ka10099 (종목정보 리스트) - 최신
  2순위: 공개 GitHub stock_master CSV (코스피 1260 + 코스닥 2070 + 코넥스 186 = 3516)
- get_scan_batch(): 전체 종목을 배치로 나눠 순환 (한 사이클에 일부만, 전체 커버)
"""
import gzip
import io
import csv
import logging

import db
from config import CFG

log = logging.getLogger("universe")

GITHUB_URL = "https://github.com/FinanceData/stock_master/raw/master/stock_master.csv.gz"


def refresh_universe_from_github() -> int:
    """GitHub 공개 CSV(3516종목)로 전 종목 목록 저장. 저장한 개수 반환."""
    import requests
    r = requests.get(GITHUB_URL, timeout=30, headers={"User-Agent": "Mozilla/5.0"})
    r.raise_for_status()
    text = gzip.decompress(r.content).decode("utf-8", errors="replace")
    rows = list(csv.DictReader(io.StringIO(text)))
    saved = 0
    for x in rows:
        sym = (x.get("Symbol") or "").strip()
        name = (x.get("Name") or "").strip()
        market = (x.get("Market") or "").strip()
        if sym and len(sym) == 6 and sym.isdigit() and name:
            db.save_universe(sym, name, market)
            saved += 1
    return saved


def refresh_universe() -> dict:
    """
    전 종목 목록 갱신.
    1순위: GitHub CSV (항상 동작 - 네이버 수집과 무관하게 안전)
    2순위: 키움 ka10099 (키 있을 때만, 최신 상장 종목 보강)
    """
    result = {"method": "github", "count": 0}
    # 1) GitHub CSV (수집기·스캔의 기본 소스 - 키움 키 오류와 무관)
    try:
        n = refresh_universe_from_github()
        result = {"method": "github_csv", "count": n}
        log.info(f"[전체종목] GitHub CSV로 {n}개 저장")
    except Exception as e:
        log.warning(f"[전체종목] GitHub CSV 실패: {e}")
        result["count"] = db.count_universe()
    # 2) 키움 ka10099 (있으면 보강 - 실패해도 조용히 넘어감)
    try:
        if CFG.APP_KEY and CFG.APP_SECRET:
            from kiwoom_client import client
            lst = client.get_stock_list()
            if lst and len(lst) > 100:
                for sym, name in lst:
                    db.save_universe(sym, name, "KRX")
                result = {"method": "kiwoom_ka10099", "count": len(lst)}
                log.info(f"[전체종목] 키움 ka10099로 {len(lst)}개 저장")
                return result
    except Exception as e:
        log.warning(f"[전체종목] 키움 ka10099 생략({str(e)[:60]}) - GitHub CSV 목록 유지")
    return result


def get_scan_batch(batch_size: int = None):
    """
    전체 종목에서 다음 배치를 순환 방식으로 반환.
    반환: (symbols, pointer, total)
    """
    if batch_size is None:
        batch_size = CFG.SCAN_BATCH_SIZE
    # KONEX(거래 매우 부진) 제외하고 코스피+코스닥만 스캔
    universe = [u for u in db.get_universe() if u["market"] != "KONEX"]
    total = len(universe)
    if total == 0:
        return [], 0, 0
    pointer = db.get_scan_pointer()
    ptr = pointer % total
    batch = universe[ptr:ptr + batch_size]
    if len(batch) < batch_size:
        batch = batch + universe[:batch_size - len(batch)]
    db.set_scan_pointer(ptr + batch_size)
    return [u["symbol"] for u in batch], ptr, total


def scan_progress() -> dict:
    """스캔 진행 상태 (UI용)"""
    total = db.count_universe()
    pointer = db.get_scan_pointer()
    done = min(total, pointer % total if total else 0)
    pct = done / total * 100 if total else 0
    return {
        "total": total,
        "pointer": pointer,
        "done": done,
        "pct": round(pct, 1),
        "batch_size": CFG.SCAN_BATCH_SIZE,
    }
