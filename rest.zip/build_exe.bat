@echo off
REM ============================================================
REM  Kiwoom AI Auto Trading - EXE Builder (Windows only)
REM  Double-click to build dist\KiwoomAIAuto.exe
REM  NOTE: PyInstaller cannot cross-compile. Run this on Windows.
REM ============================================================
setlocal
cd /d "%~dp0"

echo ============================================================
echo   Kiwoom AI Auto Trading - EXE Builder
echo ============================================================
echo.

REM [0/4] Activate venv if exists
if exist ".venv\Scripts\activate.bat" (
    echo [0/4] Activating venv...
    call ".venv\Scripts\activate.bat"
) else (
    echo [0/4] No venv found - using system Python
)

REM [1/4] Check PyInstaller
echo [1/4] Checking PyInstaller...
python -m PyInstaller --version >nul 2>&1
if errorlevel 1 (
    echo   Installing PyInstaller...
    pip install pyinstaller
)

REM [2/4] Clean previous build
echo [2/4] Cleaning previous build...
if exist dist rmdir /s /q dist
if exist build rmdir /s /q build
if exist KiwoomAIAuto.spec del /q KiwoomAIAuto.spec

REM [3/4] Build EXE (1-2 min)
echo [3/4] Building EXE... (1-2 min, please wait)
echo.
python -m PyInstaller --onefile --noconsole --name KiwoomAIAuto ^
  --add-data "prompts;prompts" ^
  --hidden-import engine ^
  --hidden-import ai_judge ^
  --hidden-import ai_consult ^
  --hidden-import backtest ^
  --hidden-import genetic ^
  --hidden-import strategy ^
  --hidden-import kiwoom_client ^
  --hidden-import db ^
  --hidden-import universe ^
  --hidden-import config ^
  --hidden-import web_status ^
  --hidden-import live_trader ^
  --hidden-import scalp ^
  --hidden-import leader ^
  --hidden-import validation ^
  --hidden-import collect_data ^
  --hidden-import value_watch ^
  --hidden-import surge_mining ^
  --hidden-import fundamentals ^
  --hidden-import cleanup_old ^
  --hidden-import realtime_bridge ^
  --hidden-import condition_manager ^
  --hidden-import photo_conditions ^
  --hidden-import daily_report ^
  --hidden-import charting ^
  --hidden-import auto_pilot ^
  --hidden-import teams ^
  --hidden-import strategy_auto ^
  --hidden-import backfill_history ^
  --hidden-import screener ^
  --hidden-import paper_test ^
  --hidden-import sell_guard ^
  --hidden-import lifecycle ^
  --hidden-import ai_coach ^
  --hidden-import governor ^
  --hidden-import channels_auto ^
  --hidden-import preopen_radar ^
  --hidden-import error_center ^
  --hidden-import baseline_channel ^
  --hidden-import momentum_channel ^
  --hidden-import ai_picks ^
  --hidden-import force_line ^
  --hidden-import robust_check ^
  --hidden-import pilot_board ^
  --hidden-import name_conditions ^
  --hidden-import param_optimizer ^
  --hidden-import visual_lab ^
  --hidden-import weekly_report ^
  --hidden-import trade_stats ^
  --hidden-import hof_report ^
  --hidden-import system_doctor ^
  --hidden-import quality_gate ^
  --hidden-import uprank_watch ^
  --hidden-import slot_builder ^
  --hidden-import multi_tf ^
  --hidden-import farm_league ^
  --hidden-import lab_worker ^
  --hidden-import us_sector ^
  --hidden-import theme_hunter ^
  --hidden-import gate_report ^
  --hidden-import sell_shadow ^
  --hidden-import loss_lessons ^
  --hidden-import spot_research ^
  --hidden-import revive_retired ^
  --noconfirm ^
  desktop_app.py

if errorlevel 1 (
    echo.
    echo [ERROR] Build failed! Check the error message above.
    echo         Common causes: 32/64bit Python mismatch, pip package issues
    pause
    exit /b 1
)

REM [4/4] Clean temp artifacts (keep dist\KiwoomAIAuto.exe)
echo [4/4] Cleaning temp files...
if exist build rmdir /s /q build
if exist KiwoomAIAuto.spec del /q KiwoomAIAuto.spec

echo.
echo ============================================================
echo   BUILD COMPLETE!
echo ============================================================
echo.
echo   Output file :  dist\KiwoomAIAuto.exe
echo.
echo   How to use:
echo     1. Copy dist\KiwoomAIAuto.exe to any folder
echo     2. Put your .env file next to it (keys/account)
echo     3. trading.db is created automatically next to exe
echo     4. prompts folder auto-created on first save
echo     5. Double-click to run! No server/browser needed
echo.
echo   WARNING: Never share .env or trading.db (account info)
echo.
pause
