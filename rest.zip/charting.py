"""
매수타점 차트 시각화 (charting.py) — PIL 기반, 외부 라이브러리 불필요
====================================================================
일봉 캔들차트 + 이동평균선 + 거래량 + 실제 매수/매도 판단 타점 마커를 PNG로 생성.
사용자가 차트를 보고, AI(여기 채팅)에게 그 이미지를 올리면 설명/변경을 받을 수 있습니다.

사용법:
    python charting.py --symbol 005930 --days 60   # 차트 PNG 생성 (charts/ 폴더)
    python charting.py --symbol 005930 --signals   # 최근 매수/매도 신호 목록만
"""
import glob
import os
import sqlite3

from PIL import Image, ImageDraw, ImageFont

import db

CHART_DIR = "charts"
BG = "#0d1117"
CARD = "#161b22"
GRID = "#21262d"
UP = "#f85149"      # 한국 장은 빨강=상승
DOWN = "#3fb950"    # 파랑/초록=하락
MA5_C = "#58a6ff"
MA20_C = "#d29922"
TEXT_C = "#e6edf3"
MUTED_C = "#8b949e"


def _find_korean_font():
    """한글 지원 폰트 자동 탐색 (Windows/리눅스/맥)"""
    cands = [
        "C:/Windows/Fonts/malgun.ttf",
        "C:/Windows/Fonts/NGULIM.TTF",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
        "/System/Library/Fonts/AppleSDGothicNeo.ttc",
    ]
    for p in cands:
        if os.path.exists(p):
            return p
    return None


def load_daily_with_dates(symbol, max_days=90):
    """일봉(백필) + 날짜 로드 (차트용) - 오래된순, 날짜 중복 마지막 봉 유지
    반환: [(date, open, high, low, close, volume), ...]
    """
    # 1) 종목별 파일 (최적 - STOCK_DIR_SAVE)
    if getattr(db, "STOCK_DIR_SAVE", True):
        try:
            bars = db.get_stock_daily(symbol, max_days=max_days)
            if bars:
                return [(b["date"], b["open"], b["high"], b["low"], b["close"], b["volume"])
                        for b in bars]
        except Exception:
            pass
    # 2) 날짜별 파일 폴백
    rows = []
    data_dir = db.DATA_DIR
    if not os.path.isdir(data_dir):
        return []
    for f in sorted(os.listdir(data_dir)):
        if not f.startswith("snapshots_"):
            continue
        try:
            c = sqlite3.connect(os.path.join(data_dir, f))
            cols = [r[1] for r in c.execute("PRAGMA table_info(market_snapshots)")]
            if "source" in cols:
                q = ("SELECT snapshot_time, open_price, high_price, low_price, price, volume "
                     "FROM market_snapshots WHERE symbol=? AND source='backfill' ORDER BY id")
            else:
                q = ("SELECT snapshot_time, open_price, high_price, low_price, price, volume "
                     "FROM market_snapshots WHERE symbol=? ORDER BY id")
            for r in c.execute(q, (symbol,)):
                rows.append((r[0][:10], float(r[1] or 0), float(r[2] or 0),
                             float(r[3] or 0), float(r[4] or 0), float(r[5] or 0)))
            c.close()
        except Exception:
            continue
    by_date = {}
    for rec in rows:
        by_date[rec[0]] = rec
    out = sorted(by_date.values())
    return out[-max_days:]


def collect_signals(symbol, limit=800):
    """최근 매수/매도 판단 기록 (차트 타점 마커용)
    반환: [{date, kind(buy|sell), decision, reason}]
    """
    sigs = []
    try:
        for r in db.get_recent_judgments(limit=limit):
            if r.get("symbol") != symbol:
                continue
            sigs.append({"date": (r.get("judged_at") or "")[:10],
                         "kind": "buy" if r.get("kind") == "buy" else "sell",
                         "decision": r.get("decision", ""),
                         "reason": (r.get("reason") or "")[:50]})
    except Exception:
        pass
    return sigs


def _ma(vals, w):
    out = [None] * len(vals)
    for i in range(len(vals)):
        if i >= w - 1:
            out[i] = sum(vals[i - w + 1:i + 1]) / w
    return out


def draw_candle_chart(symbol, days=60, save_path=None, title=None):
    """
    캔들차트 PNG 생성. 반환: 저장 경로 (데이터 부족 시 None)
    - 캔들(60봉) + MA5/MA20 + 거래량 + 매수▲/매도▼ 타점 마커
    """
    os.makedirs(CHART_DIR, exist_ok=True)
    bars = load_daily_with_dates(symbol, max_days=days)
    if len(bars) < 10:
        return None
    signals = collect_signals(symbol)
    name = db.get_symbol_name(symbol)

    n = len(bars)
    closes = [b[4] for b in bars]
    highs = [b[3] for b in bars]
    lows = [b[2] for b in bars]
    vols = [b[5] for b in bars]
    ma5 = _ma(closes, 5)
    ma20 = _ma(closes, 20)

    # 신호 → 날짜 인덱스 매칭
    date_idx = {b[0]: i for i, b in enumerate(bars)}
    sig_idx = []
    for s in signals:
        if s["date"] in date_idx:
            sig_idx.append((date_idx[s["date"]], s["kind"], s["decision"], s["reason"]))

    # 레이아웃
    W, H = 1200, 780
    ML, MR, MT, MB = 90, 30, 60, 60       # 마진
    PX = (W - ML - MR) / n                # 봉당 폭
    bw = max(3, PX * 0.7)
    # 가격 영역 (상단 65%) / 거래량 영역 (하단 25%)
    price_top = MT
    price_bot = MT + (H - MT - MB) * 0.62
    vol_top = price_bot + (H - MT - MB) * 0.05
    vol_bot = H - MB

    img = Image.new("RGB", (W, H), BG)
    d = ImageDraw.Draw(img)
    font = _find_korean_font()
    f_title = ImageFont.truetype(font, 24) if font else ImageFont.load_default()
    f_lab = ImageFont.truetype(font, 15) if font else ImageFont.load_default()
    f_small = ImageFont.truetype(font, 12) if font else ImageFont.load_default()

    # 타이틀
    ttl = title or f"{name} ({symbol}) — 매수타점 차트 · 최근 {n}일"
    d.text((ML, 18), ttl, fill=TEXT_C, font=f_title)
    sig_txt = f"신호 {len(sig_idx)}건 (▲매수 {sum(1 for x in sig_idx if x[1]=='buy')} · ▼매도 {sum(1 for x in sig_idx if x[1]=='sell')})"
    d.text((W - MR - 320, 24), sig_txt, fill=MUTED_C, font=f_lab)

    # 가격 스케일
    hi = max(highs)
    lo = min(lows)
    pad = (hi - lo) * 0.08 or hi * 0.01
    y_top, y_bot = hi + pad, lo - pad
    def y_px(p):
        return price_top + (y_top - p) / (y_top - y_bot) * (price_bot - price_top)

    # 그리드 + y 라벨
    for g in range(6):
        p = y_top - (y_top - y_bot) * g / 5
        yy = y_px(p)
        d.line([(ML, yy), (W - MR, yy)], fill=GRID)
        d.text((8, yy - 8), f"{p:,.0f}", fill=MUTED_C, font=f_small)

    # 거래량 스케일
    vmax = max(vols) or 1

    # 캔들 + MA
    for i, b in enumerate(bars):
        x = ML + i * PX + PX / 2
        o, h, l, c = b[1], b[2], b[3], b[4]
        col = UP if c >= o else DOWN
        # 심지(wick)
        d.line([(x, y_px(h)), (x, y_px(l))], fill=col, width=1)
        # 몸통
        yo, yc = y_px(o), y_px(c)
        d.rectangle([x - bw / 2, min(yo, yc), x + bw / 2, max(yo, yc)], fill=col)
        # 거래량 바
        vh = vol_top + (vol_bot - vol_top) * (b[5] / vmax)
        d.rectangle([x - bw / 2, vh, x + bw / 2, vol_bot], fill=col if c >= o else col)
    # MA5 / MA20
    def draw_ma(vals, color):
        pts = []
        for i, v in enumerate(vals):
            if v is not None:
                pts.append((ML + i * PX + PX / 2, y_px(v)))
        if len(pts) > 1:
            d.line(pts, fill=color, width=2)
    draw_ma(ma5, MA5_C)
    draw_ma(ma20, MA20_C)
    d.text((ML + 4, price_top + 2), "MA5", fill=MA5_C, font=f_small)
    d.text((ML + 42, price_top + 2), "MA20", fill=MA20_C, font=f_small)

    # 타점 마커 (매수▲ / 매도▼)
    for idx, kind, decision, reason in sig_idx:
        x = ML + idx * PX + PX / 2
        c = closes[idx]
        if kind == "buy":
            yy = y_px(c) - 26
            d.polygon([(x, yy + 16), (x - 9, yy - 6), (x + 9, yy - 6)], fill=UP)
            d.text((x + 6, yy - 4), "매수", fill=UP, font=f_small)
        else:
            yy = y_px(c) + 10
            d.polygon([(x, yy - 14), (x - 9, yy + 6), (x + 9, yy + 6)], fill=DOWN)
            d.text((x + 6, yy - 12), "매도", fill=DOWN, font=f_small)

    # x축 날짜 라벨 (몇 개)
    for i in range(0, n, max(1, n // 8)):
        x = ML + i * PX + PX / 2
        d.text((x - 20, H - MB + 8), bars[i][0][5:], fill=MUTED_C, font=f_small)

    # 하단 범례
    d.text((ML, vol_top + 2), "거래량", fill=MUTED_C, font=f_small)
    leg = " | ".join(f"{s[2]} {s[3][:24]}" for s in sig_idx[-3:])
    if leg:
        d.text((ML, H - 22), "최근 신호: " + leg, fill=MUTED_C, font=f_small)

    if save_path is None:
        save_path = os.path.join(CHART_DIR, f"chart_{symbol}.png")
    # ★ save_path의 상위 폴더가 없으면 생성 (reports/charts 등 - 실패 방지)
    try:
        _dir = os.path.dirname(save_path)
        if _dir:
            os.makedirs(_dir, exist_ok=True)
    except Exception:
        pass
    img.save(save_path, "PNG")
    return save_path


def recent_signals_text(symbol, limit=10):
    """최근 매수/매도 신호 텍스트 (AI 설명용)"""
    sigs = collect_signals(symbol, limit=800)
    lines = []
    for s in sigs[-limit:][::-1]:
        lines.append(f"{s['date']} {s['kind']} [{s['decision']}] {s['reason']}")
    return "\n".join(lines)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="매수타점 차트")
    parser.add_argument("--symbol", required=True)
    parser.add_argument("--days", type=int, default=60)
    parser.add_argument("--signals", action="store_true")
    args = parser.parse_args()
    db.init_db()
    if args.signals:
        print(recent_signals_text(args.symbol) or "(신호 기록 없음)")
    else:
        p = draw_candle_chart(args.symbol, days=args.days)
        print("저장:", p if p else "데이터 부족")
