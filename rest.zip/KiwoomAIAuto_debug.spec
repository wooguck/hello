# -*- mode: python ; coding: utf-8 -*-


block_cipher = None


a = Analysis(
    ['desktop_app.py'],
    pathex=[],
    binaries=[],
    datas=[],
    hiddenimports=['engine', 'ai_judge', 'ai_consult', 'backtest', 'genetic', 'strategy', 'kiwoom_client', 'db', 'universe', 'config', 'web_status', 'live_trader', 'scalp', 'leader', 'validation', 'collect_data', 'value_watch', 'surge_mining', 'fundamentals', 'cleanup_old', 'realtime_bridge', 'condition_manager', 'photo_conditions', 'daily_report', 'charting', 'auto_pilot', 'teams', 'strategy_auto', 'backfill_history', 'screener', 'paper_test', 'sell_guard', 'lifecycle', 'ai_coach', 'governor', 'channels_auto', 'preopen_radar', 'error_center', 'baseline_channel', 'momentum_channel', 'ai_picks', 'force_line', 'robust_check', 'pilot_board', 'name_conditions', 'param_optimizer', 'visual_lab', 'weekly_report', 'trade_stats', 'hof_report', 'system_doctor', 'quality_gate', 'uprank_watch', 'slot_builder', 'multi_tf', 'farm_league', 'lab_worker', 'us_sector', 'theme_hunter'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='KiwoomAIAuto_debug',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
