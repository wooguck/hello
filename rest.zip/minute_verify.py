# -*- coding: utf-8 -*-
"""
🔍 과거 매매 분봉 재검증 (minute_verify.py)
=============================================
일봉 백테스트가 계산한 과거 매매를 **분봉으로 다시 재생**해서
"정말 익절이 먼저였나 / 손절이 먼저였나 / 체결가는 현실적이었나"를 검증합니다.

왜 필요한가 (구버전 과적합의 5대 원인 중 하나):
  일봉만 보면 같은 날 고가가 익절가를, 저가가 손절가를 '둘 다' 스쳤을 때
  어느 쪽이 먼저였는지 알 수 없음 → 낙관 가정이면 승률이 부풀려짐.
  분봉으로 그날을 분 단위로 재생하면 순서가 확정됨.

동작:
  1) 선택한 조건식으로 일봉 백테스트 (validation.run_backtest_detail 그대로)
  2) 각 매매의 진입~청산 구간에 '분봉이 있는' 매매만 골라 분 단위 재생:
     · 진입: 다음날 시가 (일봉과 동일 가정)
     · 이후 분봉 흐름에서 TP/SL/트레일링이 어느 시각에 먼저 걸리는지 추적
  3) 일봉 결과 vs 분봉 재생 결과 비교 리포트:
     · 판정 일치율 · 수익률 오차 · "일봉이 낙관했던" 매매 목록 (익절→실은 손절)

한계(정직하게):
  - 분봉이 있는 기간의 매매만 재검증 가능 (현재 분봉 보유: 최근 ~한 달, 일부 종목)
  - 분봉은 매일 자동 누적되므로 시간이 갈수록 재검증 범위가 넓어짐

실행:
  python minute_verify.py                 # 활성 조건식 1번째
  python minute_verify.py --cond 2        # 조건식 번호 지정 (--list로 목록)
  python minute_verify.py --list          # 조건식 목록
  python minute_verify.py --days 30       # 최근 30일 매매만
"""
import argparse
import json
import os
import sys
from datetime import datetime, timedelta

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db
import validation as V


def _log(msg=""):
    print(msg, flush=True)


def list_conds():
    out = []
    try:
        for c in db.get_conditions(status="active"):
            try:
                slots = json.loads(c.get("slots_json") or "[]")
            except Exception:
                slots = []
            if slots:
                out.append({"id": c["id"], "txt": (c.get("cond_txt") or "")[:70], "slots": slots})
    except Exception:
        pass
    if not out:
        try:
            from photo_conditions import PHOTO_TEMPLATES, template_slots, template_txt
            for t in PHOTO_TEMPLATES:
                slots = [[k, p] for k, p in template_slots(t)]
                out.append({"id": f"photo{t['photo']}",
                            "txt": f"[사진{t['photo']}] {t['name']}", "slots": slots})
        except Exception:
            pass
    return out


def minute_bars_of_day(symbol, day):
    """해당 종목·날짜의 분봉 (시간순) - 없으면 []"""
    try:
        bars = db.get_minute_bars(symbol, days=3, start=day, end=day)
    except Exception:
        return []
    out = []
    for b in bars:
        bt = str(b.get("bar_time") or "")
        if bt[:10] == day and (b.get("price") or 0) > 0:
            out.append({"t": bt[11:16], "p": float(b["price"])})
    return out


def replay_trade(trade, tp, sl, trail, max_hold):
    """매매 1건을 분봉으로 재생.
    반환: {"covered": 일수커버율, "exit_reason", "ret_pct", "exit_time", "detail"} / None(분봉없음)
    """
    sym = trade["symbol"]
    entry = trade["entry"]
    d0 = trade["entry_date"]
    d1 = trade["exit_date"]
    tp_price = entry * (1 + tp / 100)
    sl_price = entry * (1 - sl / 100)
    # 진입~청산 사이 날짜들 (달력 아님 - 실제 그 종목 일봉 날짜 사용이 정확하나 근사로 date 범위)
    try:
        days = []
        cur = datetime.strptime(d0, "%Y-%m-%d")
        end = datetime.strptime(d1, "%Y-%m-%d")
        while cur <= end:
            if cur.weekday() < 5:
                days.append(cur.strftime("%Y-%m-%d"))
            cur += timedelta(days=1)
    except Exception:
        return None
    if not days:
        return None
    highest = entry
    covered = 0
    for day in days:
        mb = minute_bars_of_day(sym, day)
        if len(mb) < 10:
            continue                      # 이 날 분봉 없음
        covered += 1
        for b in mb:
            p = b["p"]
            highest = max(highest, p)
            # 우선순위: 같은 분봉에서 SL을 먼저 검사 (보수적 - 구버전 낙관 반대)
            if p <= sl_price:
                return {"covered": covered / len(days), "exit_reason": "손절(SL)",
                        "ret_pct": (sl_price / entry - 1) * 100,
                        "exit_time": f"{day} {b['t']}",
                        "detail": f"분봉 {day} {b['t']} 가격 {p:,.0f} ≤ SL {sl_price:,.0f}"}
            if p >= tp_price:
                return {"covered": covered / len(days), "exit_reason": "익절(TP)",
                        "ret_pct": (tp_price / entry - 1) * 100,
                        "exit_time": f"{day} {b['t']}",
                        "detail": f"분봉 {day} {b['t']} 가격 {p:,.0f} ≥ TP {tp_price:,.0f}"}
            if trail > 0 and highest > entry:
                trail_price = highest * (1 - trail / 100)
                if p <= trail_price and trail_price > entry:
                    return {"covered": covered / len(days), "exit_reason": "트레일링",
                            "ret_pct": (trail_price / entry - 1) * 100,
                            "exit_time": f"{day} {b['t']}",
                            "detail": f"고점 {highest:,.0f} 대비 -{trail}% 이탈"}
    if covered == 0:
        return None                       # 전 구간 분봉 없음 → 재검증 불가
    # 재생 구간 내 미청산 → 마지막 분봉가 기준
    last_day = None
    for day in reversed(days):
        mb = minute_bars_of_day(sym, day)
        if mb:
            last_day = (day, mb[-1])
            break
    if not last_day:
        return None
    p = last_day[1]["p"]
    return {"covered": covered / len(days), "exit_reason": "기간종료(보유)",
            "ret_pct": (p / entry - 1) * 100,
            "exit_time": f"{last_day[0]} {last_day[1]['t']}",
            "detail": "재생 구간 내 TP/SL 미도달"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cond", type=int, default=1, help="조건식 번호 (1부터)")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--days", type=int, default=45, help="최근 N일 매매만 (분봉 있는 기간)")
    ap.add_argument("--max-symbols", type=int, default=300)
    args = ap.parse_args()

    conds = list_conds()
    if args.list or not conds:
        _log(f"조건식 {len(conds)}개:")
        for i, c in enumerate(conds):
            _log(f"  {i+1}. [{c['id']}] {c['txt']}")
        return
    c = conds[min(max(args.cond - 1, 0), len(conds) - 1)]
    slots = [(k, p) for k, p in ([tuple(s) for s in c["slots"]])]

    _log("=" * 68)
    _log(f"🔍 과거 매매 분봉 재검증  |  조건식: {c['txt']}")
    _log("=" * 68)

    start = (db.now_kst() - timedelta(days=args.days)).strftime("%Y-%m-%d")
    _log(f"[1] 일봉 백테스트 (최근 {args.days}일 매매만)...")
    try:
        cov = db.backfill_coverage(min_days=60)
        symbols = [s for s, n in cov["symbols"].items() if n >= 60][:args.max_symbols]
    except Exception:
        symbols = []
    res = V.run_backtest_detail(symbols, slots, start=start, max_symbols=args.max_symbols)
    trades = res["trades"]
    _log(f"    매매 {len(trades)}건 ({res['symbols_tested']}종목 · {res['elapsed']}초)")
    if not trades:
        _log("    이 기간 매매 없음 - --days 늘리거나 다른 조건식 (--list)")
        return

    _log(f"[2] 분봉 재생 중...")
    tp, sl, trail, hold = V.TP_PCT, V.SL_PCT, V.TRAIL_PCT, V.MAX_HOLD
    matched = 0
    mismatched = []
    no_minute = 0
    ret_diffs = []
    for t in trades:
        r = replay_trade(t, tp, sl, trail, hold)
        if r is None:
            no_minute += 1
            continue
        day_reason = (t.get("exit_reason") or "")
        min_reason = r["exit_reason"]
        same = (("익절" in day_reason or "TP" in day_reason) and "익절" in min_reason) or \
               (("손절" in day_reason or "SL" in day_reason) and "손절" in min_reason) or \
               (("트레일" in day_reason) and "트레일" in min_reason) or \
               (("보유" in day_reason or "기간" in day_reason or "만기" in day_reason)
                and "보유" in min_reason)
        ret_diffs.append(r["ret_pct"] - t["ret_pct"])
        if same:
            matched += 1
        else:
            mismatched.append((t, r))

    checked = matched + len(mismatched)
    _log(f"\n📊 [결과] 분봉으로 재검증 가능: {checked}건 / 분봉 없음: {no_minute}건")
    if checked == 0:
        _log("    ⚠️ 재검증 가능한 매매가 없습니다 - 분봉이 아직 부족")
        _log("    분봉은 매일 자동 누적 중 (약 30종목×19일 보유) → 몇 주 뒤 다시 실행하면 커버율 상승")
        return
    _log(f"    ✅ 판정 일치: {matched}건 ({matched/checked*100:.0f}%)")
    _log(f"    ⚠️ 판정 불일치: {len(mismatched)}건")
    if ret_diffs:
        avg_d = sum(ret_diffs) / len(ret_diffs)
        _log(f"    수익률 오차(분봉-일봉) 평균: {avg_d:+.2f}%p "
             f"{'(일봉이 낙관적이었음 - 주의)' if avg_d < -0.3 else '(허용 범위)'}")
    if mismatched:
        _log(f"\n  ── 불일치 상세 (일봉 판정 → 분봉 실제) ──")
        for t, r in mismatched[:10]:
            _log(f"    {t['symbol']} {t['entry_date']}: "
                 f"일봉 [{t.get('exit_reason','')} {t['ret_pct']:+.1f}%] → "
                 f"분봉 [{r['exit_reason']} {r['ret_pct']:+.1f}%] @{r['exit_time']}")
            _log(f"        {r['detail']}")
        if len(mismatched) > 10:
            _log(f"    ... 외 {len(mismatched)-10}건")
    _log(f"\n💡 해석: 불일치 비율이 높거나 오차가 음수로 크면 → 일봉 백테스트 성적을")
    _log(f"   그만큼 할인해서 봐야 합니다. (분봉이 쌓일수록 이 검증의 커버율이 올라갑니다)")


if __name__ == "__main__":
    main()
