# -*- coding: utf-8 -*-
"""
🌒 매도 그림자 리포트 (sell_shadow.py) - 2026-08-28 추가
================================================================
gate_report(매수 그림자)의 짝: "판 시점에 안 팔고 뒀다면 어땠나?"

각 청산 거래에 대해:
  실제 매도가  vs  이후 N일(기본 3/5일) 보유했다면의 가격
  → 팔고 나서 더 간 놈 (조기 매도 - 아까움)
  → 팔고 나서 떨어진 놈 (잘 판 것)

청산 사유별로 집계 → 어떤 매도 장치가 너무 성급한지/적절한지 판정:
  예: '트레일링 스탑' 청산 후 +3% 더 갔다면 → 트레일 폭이 좁다는 근거
      '이익보호' 청산 후 -5% 빠졌다면 → 보호선이 밥값한다는 근거
  → 매도 파라미터(트레일%/보호선 KEEP)를 감이 아니라 데이터로 조정

실행: python sell_shadow.py            (기본 최근 30일, 3일/5일 후 비교)
"""
import argparse
import sys

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db


def _log(m=""):
    print(m, flush=True)


def after_exit(symbol, exit_time, exit_price, days):
    """청산 후 days거래일 뒤 종가 대비 - '안 팔았다면' 추가 수익률%"""
    from validation import _load_bars
    if not exit_price or exit_price <= 0:
        return None
    bars = _load_bars(symbol, max_days=60)
    d0 = str(exit_time)[:10]
    fut = [b for b in bars if b["date"] > d0]
    if len(fut) < days:
        return None
    p1 = fut[days - 1]["close"]
    return (p1 / exit_price - 1) * 100 if p1 else None


def report(days_window=30, holds=(3, 5), log_fn=None):
    def L(m):
        _log(m)
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    with db.get_conn() as conn:
        rows = conn.execute(
            "SELECT symbol, exit_time, exit_price, ret_pct, exit_reason, cond_txt "
            "FROM paper_positions WHERE status='closed' "
            "AND exit_time > datetime('now', ?) AND exit_price > 0",
            (f"-{days_window} days",)).fetchall()
    L("=" * 64)
    L(f"🌒 매도 그림자: 판 뒤에 어떻게 됐나 (최근 {days_window}일 · {len(rows)}건)")
    L("=" * 64)
    if not rows:
        L("  청산 표본 없음 - 거래가 쌓이면 여기서 '조기 매도 여부'가 보입니다")
        return {}

    by_reason = {}
    pending = 0
    for r in rows:
        # 사유 정규화 (앞 토큰)
        why = (r["exit_reason"] or "기타")
        for key in ("트레일링", "이익보호", "하드손절", "지침 손절", "손절", "수익청산",
                    "보유", "익절", "시장리스크"):
            if key in why:
                why = key
                break
        else:
            why = why[:12]
        outs = {}
        for h in holds:
            o = after_exit(r["symbol"], r["exit_time"], r["exit_price"], h)
            if o is not None:
                outs[h] = o
        if not outs:
            pending += 1
            continue
        a = by_reason.setdefault(why, {"n": 0, "real": [], **{f"after{h}": [] for h in holds}})
        a["n"] += 1
        a["real"].append(r["ret_pct"] or 0)
        for h, o in outs.items():
            a[f"after{h}"].append(o)

    verdicts = {}
    for why, a in sorted(by_reason.items(), key=lambda x: -x[1]["n"]):
        real_avg = sum(a["real"]) / len(a["real"])
        line = f"  [{why:8s}] {a['n']:3d}건 · 실제 {real_avg:+.2f}%"
        for h in holds:
            v = a.get(f"after{h}") or []
            if v:
                m = sum(v) / len(v)
                line += f" · 판 뒤 {h}일 {m:+.2f}%"
        L(line)
        a5 = a.get(f"after{holds[-1]}") or []
        if a5:
            m5 = sum(a5) / len(a5)
            if m5 > 1.0:
                verdict = f"⚠️ 조기 매도 경향 (+{m5:.1f}% 더 감) - 파라미터 완화 검토"
            elif m5 < -1.0:
                verdict = f"✅ 잘 팖 (판 뒤 {m5:.1f}%) - 유지"
            else:
                verdict = "🟡 적절 (판 뒤 큰 움직임 없음)"
            L(f"            → {verdict}")
            verdicts[why] = round(m5, 2)
    if pending:
        L(f"  (판정대기 {pending}건 - 청산 후 데이터 부족)")
    L("")
    L("  ※ 해석: '판 뒤 5일'이 크게 +면 그 매도 장치가 성급한 것.")
    L("     단, 오르는 장에선 모든 매도가 아까워 보임 - 지수 상승분과 같이 볼 것")
    return verdicts


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=30)
    args = ap.parse_args()
    db.init_db()
    report(days_window=args.days)
