# -*- coding: utf-8 -*-
"""
🎯 테마 헌터 채널 (theme_hunter.py) - 2026-08-27 추가
================================================================
사용자 아이디어 (외부 프로그램 방식 벤치마크):
  "검색식은 개별 종목용이 아니라 '범용 그물'로. 그물에 N개 쌓이면
   그 종목들을 분석해 대표 테마를 찾고 → 테마 대장주만 매수 후보로 →
   AI가 다시 매수 판단 → 매도는 기존 로직 그대로"

동작 (장중, channels_auto에서 자동):
  [1] 범용 그물: 당일 상승 상위 + 거래대금 폭발 종목 수집 (개별 패턴 아님)
      - THEME_USE_UP=true    : 상승률 상위 (기본 켬)
      - THEME_USE_AMOUNT=true: 거래대금 상위 (기본 켬)
  [2] 시작 문턱: 그물에 THEME_MIN_CATCH(기본 10)개 쌓여야 분석 시작
      → 문턱 전엔 "그물 N/10 - 대기" (조용한 날은 안 움직임 = 과매매 방지)
  [3] 테마 분석: AI(Gemini)가 종목명 목록을 보고 공통 테마 묶기
      → AI 없으면 규칙 폴백: 미국섹터 키워드 + 종목명 공통 단어로 근사
  [4] 대장주 선정: 테마별 편입 종목 중 거래대금 1위 = 대장 (돈이 가장 몰린 곳)
  [5] AI 매수 게이트: 대장주를 evaluate_buy(기존 AI/규칙 판단)에 넣어 최종 결정
  [6] 매수: cond_key='THEME' 채널 (공용 예산 buy_budget) → 매도는 기존
      AI판단→동적트레일링→하드손절→sell_guard 4중 그대로

과적합/과매매 방지:
  - 하루 최대 THEME_MAX_BUY(기본 2)종목
  - 문턱 미달 날은 매수 0 (테마 없는 날 억지 매수 안 함)
  - trade_stats에서 THEME 채널로 BASELINE과 성적 비교됨 (2주 후 판정 가능)

실행: python theme_hunter.py          # 지금 그물→테마→대장 (매수 없이 보기)
      python theme_hunter.py --buy    # 실제 채널 실행 (장중)
"""
import argparse
import json
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import sys
import time
from collections import Counter, defaultdict

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import requests

import db

H = {"User-Agent": "Mozilla/5.0"}
OUT = os.path.join("strategy", "theme_hunter.json")

USE_UP = os.getenv("THEME_USE_UP", "true").lower() == "true"          # 그물1: 상승상위
USE_AMOUNT = os.getenv("THEME_USE_AMOUNT", "true").lower() == "true"  # 그물2: 거래대금 폭발
MIN_CATCH = _cfg_env_int("THEME_MIN_CATCH", 10)                   # 분석 시작 문턱
MAX_BUY = _cfg_env_int("THEME_MAX_BUY", 2)                        # 하루 매수 상한 (buy_all 아닐 때)
# ★ 2026-08-28 사용자: "테마 여러 개고 특정 점수 이상이면 다 사자 (AI 기준 부합 시)"
BUY_ALL = os.getenv("THEME_BUY_ALL", "true").lower() == "true"        # 강한 테마 전부 매수 모드
STRONG_SCORE = _cfg_env_float("THEME_STRONG_SCORE", 60)           # '강한 테마' 기준 점수
BUY_ALL_CAP = _cfg_env_int("THEME_BUY_ALL_CAP", 6)                # buy_all 안전 상한 (예산 보호)
MIN_CHG = _cfg_env_float("THEME_MIN_CHG", 3.0)                    # 상승 그물 최소 %
MIN_AMT_억 = _cfg_env_float("THEME_MIN_AMT", 100)                  # 대금 그물 최소 (억)


def _log(m=""):
    print(m, flush=True)


def _n(v):
    try:
        return float(str(v).replace(",", ""))
    except Exception:
        return 0.0


def cast_net():
    """범용 그물: 상승상위 + 거래대금 폭발 (네이버 - 키 불필요)
    반환: [{symbol, name, chg, amount_억, price, net}] (net='up'/'amt'/'both')"""
    got = {}
    if USE_UP:
        try:
            import momentum_channel as mc
            for s in mc.fetch_up_ranks(max_n=80):
                if s["chg"] >= MIN_CHG and s["amount_억"] >= 30:
                    got[s["symbol"]] = {**s, "net": "up"}
        except Exception:
            pass
    if USE_AMOUNT:
        # 거래대금 상위 (상승 여부 무관 - 돈이 몰리는 곳)
        for mk in ("KOSPI", "KOSDAQ"):
            try:
                r = requests.get(f"https://m.stock.naver.com/api/stocks/trading_value/{mk}",
                                 params={"page": 1, "pageSize": 30}, headers=H, timeout=10)
                for s in (r.json().get("stocks") or []):
                    if s.get("stockEndType") != "stock":
                        continue
                    sym = s["itemCode"]
                    amt = _n(s.get("accumulatedTradingValue")) / 100
                    chg = _n(s.get("fluctuationsRatio"))
                    if amt < MIN_AMT_억 or chg < 0:
                        continue                     # 대금 커도 하락 중이면 제외
                    if sym in got:
                        got[sym]["net"] = "both"
                    else:
                        got[sym] = {"symbol": sym, "name": s.get("stockName", "")[:10],
                                    "price": _n(s.get("closePrice")), "chg": chg,
                                    "amount_억": amt, "net": "amt"}
            except Exception:
                continue
    return list(got.values())


def _ai_theme(stocks):
    """AI(Gemini)로 테마 묶기. 반환 {테마명: [symbol,...]} 또는 None(AI 불가)"""
    try:
        from ai_judge import call_llm
        from config import CFG
        if not (getattr(CFG, "GEMINI_API_KEY", "") or os.getenv("GEMINI_API_KEY")):
            return None
        names = ", ".join(f"{s['name']}({s['symbol']})" for s in stocks[:30])
        ans = call_llm(
            "당신은 한국 주식 테마 분석가입니다. JSON만 출력하세요.",
            f"다음 종목들을 공통 테마로 묶고, 각 테마 자체를 평가하세요.\n"
            f"종목: {names}\n"
            f"테마 평가 기준: 지속성(정책/실적 기반=높음, 단발 뉴스=낮음) 0~100점과 한줄 이유.\n"
            f'출력: {{"테마명": {{"codes": ["코드",...], "ai_score": 75, "why": "이유"}}, ...}} '
            f"(테마 최대 5개, JSON만)")
        j = json.loads(ans[ans.index("{"):ans.rindex("}") + 1])
        out = {}
        valid = {s["symbol"] for s in stocks}
        for theme, body in j.items():
            if isinstance(body, list):            # 구형식 호환
                body = {"codes": body, "ai_score": None, "why": ""}
            ok = [x for x in (body.get("codes") or []) if x in valid]
            if len(ok) >= 2:                      # 2종목 이상이어야 '테마'
                out[str(theme)[:20]] = {"codes": ok,
                                        "ai_score": body.get("ai_score"),
                                        "why": str(body.get("why", ""))[:60]}
        return out or None
    except Exception:
        return None


def _rule_theme(stocks):
    """규칙 폴백: 미국섹터 키워드 + 종목명 공통 토큰으로 근사 테마"""
    groups = defaultdict(list)
    # 1) 미국섹터 키워드 재사용
    try:
        from us_sector import SECTORS
        for s in stocks:
            for _etf, (kname, kws) in SECTORS.items():
                if any(k.lower() in (s["name"] or "").lower() for k in kws):
                    groups[kname].append(s["symbol"])
                    break
    except Exception:
        pass
    # 2) 이름 공통 토큰 (제약/바이오/전자 등 - 2글자 이상 겹침)
    toks = Counter()
    for s in stocks:
        nm = s["name"] or ""
        for t in ("제약", "바이오", "전자", "화학", "건설", "증권", "은행", "철강",
                  "조선", "게임", "엔터", "로봇", "우주", "항공", "방산", "반도체"):
            if t in nm:
                toks[t] += 1
    for t, n in toks.items():
        if n >= 2:
            groups[t] = [s["symbol"] for s in stocks if t in (s["name"] or "")]
    return {k: {"codes": v, "ai_score": None, "why": "규칙 분류"}
            for k, v in groups.items() if len(v) >= 2}


def hunt(log_fn=None):
    """그물 → 문턱 → 테마 → 대장주. 반환 {"caught", "themes", "leaders", "status"}"""
    def L(m):
        _log(m)
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    caught = cast_net()
    today = db.now_kst().strftime("%Y-%m-%d")
    if len(caught) < MIN_CATCH:
        st = {"date": today, "status": f"그물 {len(caught)}/{MIN_CATCH} - 대기 (테마 형성 전)",
              "caught": caught, "themes": {}, "leaders": []}
        json.dump(st, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        return st
    L(f"🎯 [테마헌터] 그물 {len(caught)}종목 (문턱 {MIN_CATCH} 통과) - AI 테마 분석 중...")
    themes = _ai_theme(caught)
    engine = "AI"
    if not themes:
        themes = _rule_theme(caught)
        engine = "규칙"
    # 대장주: 테마별 거래대금 1위
    # ★ 테마 점수 채점 (2026-08-28 사용자: '테마별로 점수 채점'):
    #   규칙 점수 = 편입수(붐 강도) + 합계 거래대금(돈 규모) + 평균 상승률(힘)
    #   AI 점수  = 테마 지속성 평가 (정책/실적 기반인지 단발 뉴스인지) - AI 있을 때만
    #   최종 = 규칙 60% + AI 40% (AI 없으면 규칙 100%)
    by_sym = {s["symbol"]: s for s in caught}
    leaders = []
    for theme, body in themes.items():
        syms = body["codes"] if isinstance(body, dict) else body
        ai_score = body.get("ai_score") if isinstance(body, dict) else None
        ai_why = body.get("why", "") if isinstance(body, dict) else ""
        members = [by_sym[x] for x in syms if x in by_sym]
        if len(members) < 2:
            continue
        # 규칙 점수 (0~100 근사)
        tot_amt = sum(m["amount_억"] for m in members)
        avg_chg = sum(m["chg"] for m in members) / len(members)
        rule_score = min(40, len(members) * 8)             + min(35, tot_amt / 100)             + min(25, max(0, avg_chg) * 3)
        if ai_score is not None:
            theme_score = rule_score * 0.6 + float(ai_score) * 0.4
        else:
            theme_score = rule_score
        # ★ 🇺🇸 미국 섹터 가점 (2026-08-28 사용자: '미국 점수를 테마에 합치는지'):
        #   어젯밤 미국서 같은 계열 섹터가 +1.5% 이상 → 테마 점수 +10 (+3%면 +15)
        #   한국 낮 테마가 미국 밤장 흐름과 같은 방향이면 지속성 근거 하나 추가
        us_bonus = 0.0
        us_tag = ""
        try:
            _usd = json.load(open(os.path.join("strategy", "us_sector.json"),
                                  encoding="utf-8"))
            from us_sector import SECTORS as _USS
            for _h in (_usd.get("hot") or []):
                _kws = _USS.get(_h["etf"], ("", []))[1]
                _kname = _h["name"]
                # 테마명이 미국 섹터명과 겹치거나, 편입 종목명에 그 섹터 키워드가 있으면 매칭
                _member_names = " ".join((by_sym.get(x, {}).get("name") or "") for x in syms)
                if (_kname in theme or theme in _kname
                        or any(k in _member_names for k in _kws[:6])):
                    us_bonus = 15.0 if _h["chg"] >= 3.0 else 10.0
                    us_tag = f"미국{_kname}{_h['chg']:+.1f}%"
                    break
        except Exception:
            pass
        theme_score += us_bonus
        members.sort(key=lambda s: -s["amount_억"])
        lead = members[0]
        leaders.append({"theme": theme, "theme_score": round(theme_score, 1),
                        "rule_score": round(rule_score, 1), "ai_score": ai_score,
                        "us_bonus": us_bonus, "us_tag": us_tag,
                        "ai_why": ai_why,
                        "symbol": lead["symbol"], "name": lead["name"],
                        "price": lead["price"], "chg": lead["chg"],
                        "amount_억": lead["amount_억"],
                        "members": [m["symbol"] for m in members[:6]],
                        # ★ 순위별 상세 (2026-08-28: 대장/2등/3등주 매수 옵션용)
                        # ★ 2026-08-28: 5위까지 (사용자 '5등 안에 들어오면 사자' - 순위판 감시)
                        "ranked": [{"rank": i + 1, "symbol": m["symbol"], "name": m["name"],
                                    "price": m["price"], "chg": m["chg"],
                                    "amount_억": m["amount_억"]} for i, m in enumerate(members[:5])],
                        "n_members": len(members)})
    leaders.sort(key=lambda x: -x["theme_score"])   # ★ 테마 점수순 (대금순 아님)
    # ★ 테마 점수 하한: 미달 테마는 매수 후보에서 제외 (약한 테마 추격 방지)
    _min_ts = _cfg_env_float("THEME_MIN_SCORE", 40)
    leaders = [x for x in leaders if x["theme_score"] >= _min_ts]
    st = {"date": today, "status": f"테마 {len(themes)}개 ({engine} 분석) · 대장 {len(leaders)}",
          "caught": caught, "themes": {k: v for k, v in themes.items()},
          "leaders": leaders, "engine": engine, "updated_at": db.now_kst_iso()}
    json.dump(st, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for ld in leaders[:5]:
        L(f"  🎯 [{ld['theme']}] 점수 {ld['theme_score']:.0f}"
          + (f" (AI {ld['ai_score']}: {ld['ai_why'][:20]})" if ld.get("ai_score") is not None else " (규칙)")
          + (f" +🇺🇸{ld['us_tag']}" if ld.get("us_bonus") else "")
          + f" · 대장 {ld['name']}({ld['symbol']}) +{ld['chg']:.1f}% · "
          f"{ld['amount_억']:.0f}억 · 편입 {ld['n_members']}종목")
    return st


def buy_leaders(st=None, log_fn=None):
    """대장주 → AI 매수 게이트 → 매수 (cond_key='THEME'). 하루 상한 MAX_BUY"""
    def L(m):
        _log(m)
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    import paper_test
    from config import CFG
    st = st or hunt(log_fn=log_fn)
    leaders = st.get("leaders") or []
    if not leaders:
        return []
    # 오늘 이미 산 THEME 수 (상한)
    today = db.now_kst().strftime("%Y-%m-%d")
    with db.get_conn() as conn:
        r = conn.execute("SELECT COUNT(*) n FROM paper_positions WHERE cond_key='THEME' "
                         "AND entry_time LIKE ?", (today + "%",)).fetchone()
        # ★ 오늘 산 적 있는 종목 (청산했어도) - 재매수 금지 (사용자: '샀던 건 빼고')
        _bs = conn.execute("SELECT DISTINCT symbol FROM paper_positions WHERE cond_key='THEME' "
                           "AND entry_time LIKE ?", (today + "%",)).fetchall()
    bought_today = r["n"] if r else 0
    bought_syms = {x["symbol"] for x in _bs}
    held = {p["symbol"] for p in db.get_paper_open()}
    out = []
    # ★ 매수 대상 펼치기 (2026-08-28): THEME_BUY_RANKS=1 대장만 / 2 대장+2등 / 3 3등까지
    #   테마 순서(대금순) 우선 → 같은 테마 안에서 순위순
    ranks = max(1, min(5, _cfg_env_int("THEME_BUY_RANKS", 5)))   # 5등 안 = 매수 대상
    targets = []
    for ld in leaders:
        for m in (ld.get("ranked") or [{"rank": 1, "symbol": ld["symbol"], "name": ld["name"],
                                        "price": ld["price"], "chg": ld["chg"],
                                        "amount_억": ld["amount_억"]}])[:ranks]:
            targets.append({**m, "theme": ld["theme"], "n_members": ld["n_members"],
                            "theme_score": ld.get("theme_score", 0)})
    # ★ buy_all 모드: STRONG_SCORE 이상 테마의 후보는 상한을 BUY_ALL_CAP까지 확장
    #   (약한 테마는 여전히 MAX_BUY 안에서만 - '특정 이상이면 다 산다'의 그 기준)
    for ld in targets:
        _strong = BUY_ALL and float(ld.get("theme_score") or 0) >= STRONG_SCORE
        _cap = BUY_ALL_CAP if _strong else MAX_BUY
        if bought_today + len(out) >= _cap:
            if _strong:
                L(f"  ⚠️ [테마] 안전 상한 {BUY_ALL_CAP}종목 도달 - 이후 후보 생략 (예산 보호)")
            break
        sym = ld["symbol"]
        if sym in held or sym in bought_syms:
            continue                      # 보유 중이거나 오늘 이미 샀던 것 = 스킵 (신규 편입만)
        price = paper_test._get_price(sym) or ld["price"]
        if price <= 0:
            continue
        # ★ AI 매수 게이트 (기존 evaluate_buy - 사용자: 'AI가 다시 매수 결정')
        try:
            from ai_judge import evaluate_buy
            md = {"price": price, "현재가": price, "전일종가": price / (1 + ld["chg"] / 100),
                  "체결강도": 110, "최근1분거래대금": ld["amount_억"] * 1e8 / 390,
                  "최근3분거래대금": ld["amount_억"] * 1e8 / 130,
                  "저가": price * 0.98, "전일고가": price * 0.99, "전일저가": price * 0.95}
            ok_buy, why = evaluate_buy(sym, md)
            if not ok_buy:
                db.log_gate_reject("THEME", sym, price, why)  # ★ 그림자 추적
                L(f"  ⛔ [테마] {ld['name']} AI 매수 보류: {why[:40]}")
                continue
        except Exception:
            pass
        budget = paper_test.buy_budget()
        qty = int(budget / price)
        if qty < 1:
            continue
        order = None
        if paper_test.REAL_PAPER_ORDER and not CFG.DRY_RUN and paper_test._in_market_hours():
            order = paper_test._place_real_order(sym, "buy", qty, price)
            if order and order.get("status") == "error":
                continue
        ep = price if (order and not CFG.DRY_RUN) else paper_test.entry_slip(price)
        plan = None
        try:
            from ai_consult import build_sell_plan
            plan = build_sell_plan(sym, ep, qty)
        except Exception:
            pass
        _rk = {1: "대장", 2: "2등주", 3: "3등주"}.get(ld.get("rank", 1), "대장")
        db.open_paper_position(
            "THEME", f"[테마:{ld['theme']}] {_rk} · 편입{ld['n_members']} · {ld['amount_억']:.0f}억",
            sym, ep, qty,
            order_kind=("real" if order else "virtual"),
            target_price=(plan or {}).get("target_price"),
            stop_price=(plan or {}).get("stop_price"),
            sell_plan=(plan or {}).get("plan"))
        out.append(sym)
        L(f"  ✅ [테마] 매수 {ld['name']}({sym}) {qty}주 @{ep:,.0f} "
          f"[{ld['theme']} {_rk}]" + (" 실제모의" if order else " 가상기록"))
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--buy", action="store_true", help="대장주 매수까지 (장중)")
    args = ap.parse_args()
    db.init_db()
    st = hunt(log_fn=None)
    print()
    print("상태:", st["status"])
    for ld in (st.get("leaders") or [])[:8]:
        print(f"  [{ld['theme']}] {ld['name']} +{ld['chg']:.1f}% {ld['amount_억']:.0f}억 "
              f"(편입 {ld['n_members']})")
    if args.buy:
        print()
        print("매수:", buy_leaders(st))
