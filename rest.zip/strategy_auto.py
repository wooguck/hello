"""
자동 전략 생성 (30일+ 데이터 → 전략 자동 갱신)
=================================================
백필(네이버 과거 일봉) 데이터가 쌓이면 자동으로:

1. 종목별 일봉(OHLCV)을 모아 시장 상태 분석 (추세/변동성/거래량)
2. 8가지 후보 전략을 90일치 데이터에 백테스트 (5일 보유 기준)
3. 통과 조건(샘플 수 · 승률 · 손익비 · 시장 평균 대비 우위)을 충족한
   최고 전략만 매수/매도 프롬프트에 [📊 자동 전략 분석] 블록으로 반영
4. 조건 미달이면 절대 강제 적용하지 않음 (보수 원칙)

★ 안전장치 (아부지의 맘):
- 하드 손절 / 최소 익절 / 신뢰도 임계값은 절대 자동 변경하지 않음
- 적용 전 prompts/backup/ 에 자동 백업 (되돌리기 가능)
- 사용자가 직접 수정한 프롬프트 본문은 보존 (블록만 삽입/교체)
- 재분석은 7일(쿨다운)에 한 번만

저장:
- strategy/auto_strategy.json  : 적용 상태/전략/시장 분석 (UI 표시용)
- research/strategy_history.csv : 전략 생성 이력
"""
import json
import logging
import os
import shutil
import time
from datetime import datetime, timedelta

import db
from config import CFG
from db import now_kst, now_kst_iso

log = logging.getLogger("strategy_auto")

BUY_PROMPT_PATH = "prompts/buy_prompt.txt"
SELL_PROMPT_PATH = "prompts/sell_prompt.txt"
STATE_PATH = os.path.join("strategy", "auto_strategy.json")

# ── 프롬프트 자동 블록 마커 ─────────────────────────
AUTO_START = "[📊 자동 전략 분석"
AUTO_END = "[자동 전략 분석 끝]"

# ── 후보 전략 (일봉 기반, 5일 보유) ─────────────────
RULES = ["r_mom_break", "r_high_break", "r_ma_align", "r_oversold_rebound",
         "r_vol_surge_up", "r_pullback", "r_momentum_strong", "r_low_rebound"]

RULE_NAMES = {
    "r_mom_break": "모멘텀 돌파 (5일 +2% · 20일선 위 · 거래량 1.5배)",
    "r_high_break": "20일 고점 돌파",
    "r_ma_align": "이동평균 정배열 (5>10>20)",
    "r_oversold_rebound": "과매도 반등 (5일 -6% 후 반등)",
    "r_vol_surge_up": "거래량 폭발 양봉 (2배 이상)",
    "r_pullback": "상승추세 눌림매수 (20일 +5% · 5일 -3~0%)",
    "r_momentum_strong": "강한 모멘텀 (5일 +5% · 20일선 위)",
    "r_low_rebound": "20일 저점 반등 + 거래량",
}

# 전략별 → 데이터 기반 강조 조건 (프롬프트 블록에 삽입)
RULE_GUIDANCE = {
    "r_mom_break": [
        "5일 수익률이 +2% 이상인 상승 종목",
        "20일선(MA20) 위에서 거래되는 종목",
        "거래량이 최근 20일 평균의 1.5배 이상 확대된 종목",
    ],
    "r_high_break": [
        "20일 최고가 근처(98% 이상)에서 상승하는 종목",
        "20일선(MA20) 위에 있는 종목",
        "상승 돌파 시 거래량이 동반되는 종목",
    ],
    "r_ma_align": [
        "단기 이동평균 정배열(5일 > 10일 > 20일) 종목",
        "현재가가 5일선 위인 종목",
    ],
    "r_oversold_rebound": [
        "5일 동안 -6% 이상 급락했지만 오늘 저가 위에서 반등하는 종목",
        "20일선 아래라도 반등 신호(저가 상승)가 확인된 종목",
    ],
    "r_vol_surge_up": [
        "거래량이 최근 20일 평균의 2배 이상 폭발한 종목",
        "양봉(종가 > 시가) + 5일 수익률 플러스인 종목",
    ],
    "r_pullback": [
        "20일 수익률 +5% 이상 상승추세에서 5일간 -3%~0% 눌림 중인 종목",
    ],
    "r_momentum_strong": [
        "5일 수익률 +5% 이상의 강한 모멘텀 종목",
        "20일선(MA20) 위에 있는 종목",
    ],
    "r_low_rebound": [
        "20일 최저가 부근에서 반등 + 거래량 1.5배 이상인 종목",
    ],
}


# ── 유틸 ──────────────────────────────────────────

def _read_file(path, fallback=""):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return fallback


def _write_file(path, content):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return True
    except Exception:
        return False


def _load_state():
    try:
        with open(STATE_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_state(state):
    try:
        os.makedirs(os.path.dirname(STATE_PATH), exist_ok=True)
        with open(STATE_PATH, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def _median(xs):
    if not xs:
        return 0.0
    xs = sorted(xs)
    m = len(xs) // 2
    return xs[m] if len(xs) % 2 else (xs[m - 1] + xs[m]) / 2


# ── 데이터 로드 ────────────────────────────────────

def get_daily_series(symbol, max_days=120):
    """특정 종목의 일봉 시리즈 (오래된순)
    ★ 종목별 저장 우선(data/stocks/{symbol}.db) - 없으면 날짜별 파일에서 수집
    """
    import sqlite3
    # 1) 종목별 파일 (최적)
    if getattr(db, "STOCK_DIR_SAVE", True):
        try:
            bars = db.get_stock_daily(symbol, max_days=max_days)
            if bars:
                return [{"date": b["date"], "open": b["open"], "high": b["high"],
                         "low": b["low"], "close": b["close"], "volume": b["volume"]}
                        for b in bars]
        except Exception:
            pass
    # 2) 날짜별 파일 폴백
    if not os.path.isdir(db.DATA_DIR):
        return []
    rows = []
    for f in sorted(os.listdir(db.DATA_DIR)):
        if not (f.startswith("snapshots_") and f.endswith(".db")):
            continue
        try:
            c = sqlite3.connect(os.path.join(db.DATA_DIR, f))
            cols = [r[1] for r in c.execute("PRAGMA table_info(market_snapshots)")]
            if "source" in cols:
                q = ("SELECT open_price, high_price, low_price, price, volume "
                     "FROM market_snapshots WHERE symbol=? AND source='backfill' ORDER BY id")
            else:
                q = ("SELECT open_price, high_price, low_price, price, volume "
                     "FROM market_snapshots WHERE symbol=? ORDER BY id")
            rows += [tuple(r) for r in c.execute(q, (symbol,))]
            c.close()
        except Exception:
            continue
        if len(rows) >= max_days:
            break
    out = []
    for (o, h, l, cl, v) in rows:
        try:
            out.append({"open": float(o or 0), "high": float(h or 0), "low": float(l or 0),
                        "close": float(cl or 0), "volume": float(v or 0)})
        except Exception:
            continue
    out = [b for b in out if b["close"] > 0 and b["high"] >= b["low"]]
    return out[:max_days]


def _load_all_series(symbols, max_days=120):
    """여러 종목 일봉을 한 번의 파일 순회로 로드 (성능)"""
    import sqlite3
    data = {s: [] for s in symbols}
    if not os.path.isdir(db.DATA_DIR):
        return data
    for f in sorted(os.listdir(db.DATA_DIR)):
        if not (f.startswith("snapshots_") and f.endswith(".db")):
            continue
        try:
            c = sqlite3.connect(os.path.join(db.DATA_DIR, f))
            cols = [r[1] for r in c.execute("PRAGMA table_info(market_snapshots)")]
            if "source" in cols:
                q = ("SELECT symbol, open_price, high_price, low_price, price, volume "
                     "FROM market_snapshots WHERE source='backfill' ORDER BY id")
            else:
                q = ("SELECT symbol, open_price, high_price, low_price, price, volume "
                     "FROM market_snapshots ORDER BY id")
            for r in c.execute(q):
                sym = r[0]
                if sym not in data:
                    continue
                try:
                    data[sym].append({"open": float(r[1] or 0), "high": float(r[2] or 0),
                                      "low": float(r[3] or 0), "close": float(r[4] or 0),
                                      "volume": float(r[5] or 0)})
                except Exception:
                    continue
            c.close()
        except Exception:
            continue
    out = {}
    for sym, bars in data.items():
        bars = [b for b in bars if b["close"] > 0 and b["high"] >= b["low"]]
        if bars:
            out[sym] = bars[:max_days]
    return out


# ── 커버리지 / 준비 상태 ───────────────────────────

_coverage_cache = {"t": 0.0, "data": None}


def _coverage_cached():
    now = time.time()
    if _coverage_cache["data"] is None or now - _coverage_cache["t"] > 300:
        _coverage_cache["data"] = db.backfill_coverage(min_days=CFG.STRATEGY_MIN_DAYS)
        _coverage_cache["t"] = now
    return _coverage_cache["data"]


def data_readiness():
    """데이터가 전략 자동 생성에 충분한가 (일봉 ≥ N일 종목이 target 이상)"""
    cov = _coverage_cached()
    ready_count = cov["ready"]
    target = max(1, int(getattr(CFG, "STRATEGY_MIN_SYMBOLS", 500)))
    total = max(0, cov["total"])
    pct = min(100.0, ready_count / target * 100.0)
    return {
        "ready": ready_count >= target and total > 0,
        "ready_count": ready_count,
        "target": target,
        "total": total,
        "min_days": cov["min_days"],
        "pct": round(pct, 1),
    }


# ── 시장 분석 + 후보 전략 백테스트 ─────────────────

def _rule_flags(i, close, high, low, op, vol, ma5, ma10, ma20, mom5, mom20, volr, h20, l20):
    m5 = mom5[i]
    m20 = mom20[i]
    vr = volr[i]
    c = close[i]
    o = op[i]
    ma5v = ma5[i]
    ma10v = ma10[i]
    ma20v = ma20[i]
    h20v = h20[i]
    l20v = l20[i]
    near_high = c / h20v if h20v else 1.0
    near_low = c / l20v if l20v else 1.0
    return {
        "r_mom_break": m5 > 0.02 and c > ma20v and vr > 1.5,
        "r_high_break": near_high >= 0.985,
        "r_ma_align": ma5v > ma10v > ma20v and c > ma5v,
        "r_oversold_rebound": m5 < -0.06 and c < ma20v * 0.97 and c > low[i],
        "r_vol_surge_up": vr >= 2.0 and c > o and m5 > 0,
        "r_pullback": m20 > 0.05 and -0.03 < m5 < 0,
        "r_momentum_strong": m5 > 0.05 and c > ma20v,
        "r_low_rebound": near_low <= 1.02 and vr > 1.5,
    }


def _simulate_all(series_map):
    """series_map: {sym: [bars...]} → (market, rule_aggs, baseline_agg, rule_aggs3, baseline_agg3)
    ★ 거래 비용(왕복 수수료+세금, 기본 0.2%)을 모든 수익률에 반영 → 수익 과대평가 방지
    """
    fee = float(getattr(CFG, "FEE_ROUND_TRIP_PCT", 0.2)) / 100.0
    rule_buckets = {rid: [] for rid in RULES}
    rule_buckets3 = {rid: [] for rid in RULES}
    baseline = []
    baseline3 = []
    breadth_up = breadth_n = 0
    mom20s, volrs, ranges = [], [], []

    for bars in series_map.values():
        n = len(bars)
        if n < 26:
            continue
        close = [b["close"] for b in bars]
        high = [b["high"] for b in bars]
        low = [b["low"] for b in bars]
        op = [b["open"] for b in bars]
        vol = [b["volume"] for b in bars]

        ma5 = [None] * n
        ma10 = [None] * n
        ma20 = [None] * n
        mom5 = [0.0] * n
        mom20 = [0.0] * n
        volr = [0.0] * n
        h20 = [None] * n
        l20 = [None] * n
        for i in range(n):
            if i >= 4:
                ma5[i] = sum(close[i - 4:i + 1]) / 5
            if i >= 9:
                ma10[i] = sum(close[i - 9:i + 1]) / 10
            if i >= 19:
                ma20[i] = sum(close[i - 19:i + 1]) / 20
                h20[i] = max(high[i - 19:i + 1])
                l20[i] = min(low[i - 19:i + 1])
            if i >= 5 and close[i - 5] > 0:
                mom5[i] = close[i] / close[i - 5] - 1
            if i >= 20 and close[i - 20] > 0:
                mom20[i] = close[i] / close[i - 20] - 1
            if i >= 20:
                vbase = sum(vol[i - 20:i]) / 20
                if vbase > 0:
                    volr[i] = vol[i] / vbase

        # 최신 상태 (시장 진단)
        j = n - 1
        if ma20[j] is not None:
            breadth_n += 1
            if close[j] > ma20[j]:
                breadth_up += 1
        if mom20[j]:
            mom20s.append(mom20[j])
        if volr[j] > 0:
            volrs.append(volr[j])
        for k in range(max(0, n - 10), n):
            if close[k] > 0 and high[k] >= low[k]:
                ranges.append((high[k] - low[k]) / close[k])

        # 후보 전략 시뮬레이션 (5일 보유 + 3일 보유 - 수수료 반영)
        for i in range(21, n - 5):
            c0 = close[i]
            if c0 <= 0:
                continue
            fwd5 = close[i + 5] / c0 - 1 - fee
            fwd3 = close[i + 3] / c0 - 1 - fee
            baseline.append(fwd5)
            baseline3.append(fwd3)
            fl = _rule_flags(i, close, high, low, op, vol,
                             ma5, ma10, ma20, mom5, mom20, volr, h20, l20)
            for rid, hit in fl.items():
                if hit:
                    rule_buckets[rid].append(fwd5)
                    rule_buckets3[rid].append(fwd3)

    breadth = breadth_up / breadth_n * 100 if breadth_n else 0.0
    trend = "상승장" if breadth >= 55 else ("하락장" if breadth <= 45 else "혼조장")
    market = {
        "trend": trend,
        "breadth": round(breadth, 1),          # 20일선 위 종목 비율 %
        "median_mom20": round(_median(mom20s), 4),
        "median_vol_ratio": round(_median(volrs), 2),
        "median_daily_range": round(_median(ranges), 4),  # 일평균 등락폭
    }
    rule_aggs = {rid: _agg(rule_buckets[rid]) for rid in RULES}
    baseline_agg = _agg(baseline)
    rule_aggs3 = {rid: _agg(rule_buckets3[rid]) for rid in RULES}
    baseline_agg3 = _agg(baseline3)
    return market, rule_aggs, baseline_agg, rule_aggs3, baseline_agg3


def _agg(vals):
    n = len(vals)
    if n == 0:
        return {"trades": 0}
    wins = [v for v in vals if v > 0]
    losses = [v for v in vals if v <= 0]
    gp = sum(wins)
    gl = abs(sum(losses))
    pf = gp / gl if gl > 0 else (999.0 if gp > 0 else 0.0)
    return {
        "trades": n,
        "win_rate": round(len(wins) / n * 100, 2),
        "avg_ret": round(sum(vals) / n, 5),
        "pf": round(pf, 2),
    }


def analyze_intraday(symbols, days=8, max_symbols=60, min_day_bars=10):
    """
    ★ 분봉 기반 장중 분석 (네이버 분봉: 분당 종가 + 누적거래량)
    - 오전 30분(09:00~09:30) 수익률과 당일 수익률의 관계 → 장중 추세 지속/반전 판단
    - 오전 거래량 비중, 장중 변동성(분봉 종가 기준)
    반환: {"available": bool, ...} — 데이터 없으면 available=False
    """
    import math
    am_rets, day_rets, ranges, am_shares = [], [], [], []
    bars_total = 0
    syms_used = 0
    for sym in symbols[:max_symbols]:
        bars = db.get_minute_bars(sym, days=days)
        if len(bars) < min_day_bars * 2:
            continue
        bars_total += len(bars)
        syms_used += 1
        per_day = {}
        for b in bars:
            per_day.setdefault(b["bar_time"][:10], []).append(b)
        for d, bs in per_day.items():
            bs.sort(key=lambda x: x["bar_time"])
            if len(bs) < min_day_bars:
                continue
            p0 = bs[0]["price"]
            last = bs[-1]["price"]
            if p0 <= 0:
                continue
            day_ret = last / p0 - 1
            # 오전 30분: 09:31 이전 봉들의 첫가→마지막가
            am = [b for b in bs if b["bar_time"][11:16] <= "09:30"]
            if len(am) >= 2 and am[0]["price"] > 0:
                am_ret = am[-1]["price"] / am[0]["price"] - 1
            else:
                am_ret = None
            prices = [b["price"] for b in bs]
            lo = min(prices)
            hi = max(prices)
            if lo > 0:
                ranges.append((hi - lo) / lo)
            vols = [b.get("volume") or 0 for b in bs]
            tot_v = sum(vols)
            if tot_v > 0:
                am_v = sum(b.get("volume") or 0 for b in bs
                           if b["bar_time"][11:13] in ("09", "10", "11"))
                am_shares.append(am_v / tot_v)
            day_rets.append(day_ret)
            am_rets.append(am_ret)

    pairs = [(a, d) for a, d in zip(am_rets, day_rets) if a is not None]
    if len(pairs) < 10 or not day_rets:
        return {"available": False}

    # 상관계수 (Pearson)
    corr = 0.0
    xs = [p[0] for p in pairs]
    ys = [p[1] for p in pairs]
    mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
    num = sum((x - mx) * (y - my) for x, y in pairs)
    den = math.sqrt(sum((x - mx) ** 2 for x in xs) * sum((y - my) ** 2 for y in ys))
    if den > 0:
        corr = num / den

    am_up = [(a, d) for a, d in pairs if a > 0]
    am_dn = [(a, d) for a, d in pairs if a <= 0]
    am_strong_hold = sum(1 for a, d in am_up if d > 0) / len(am_up) if am_up else 0.0
    am_weak_hold = sum(1 for a, d in am_dn if d <= 0) / len(am_dn) if am_dn else 0.0

    if am_strong_hold >= 0.6 and am_weak_hold >= 0.6:
        regime = "장중 추세 지속"
    elif am_strong_hold < 0.5 and am_weak_hold < 0.5:
        regime = "장중 반전 잦음"
    else:
        regime = "장중 혼조"

    return {
        "available": True,
        "symbols": syms_used,
        "bars": bars_total,
        "day_samples": len(pairs),
        "am_day_corr": round(corr, 3),
        "am_strong_hold": round(am_strong_hold, 3),
        "am_weak_hold": round(am_weak_hold, 3),
        "median_range": round(_median(ranges), 4),
        "am_share": round(_median(am_shares), 4),
        "regime": regime,
    }


def _pick_best(rule_aggs, min_trades=None):
    if min_trades is None:
        min_trades = int(getattr(CFG, "STRATEGY_MIN_TRADES", 500))
    cands = []
    for rid, a in rule_aggs.items():
        if a["trades"] < min_trades:
            continue
        score = a["win_rate"] * max(min(a["avg_ret"], 0.10), -0.20)
        cands.append((score, rid, a))
    if not cands:
        return None
    cands.sort(key=lambda x: -x[0])
    _, rid, a = cands[0]
    return {"id": rid, "name": RULE_NAMES.get(rid, rid), **a}


def _qualify(best, baseline, best3=None, min_winrate=None, min_pf=None):
    if not best:
        return False
    if min_winrate is None:
        min_winrate = float(getattr(CFG, "STRATEGY_APPLY_MIN_WINRATE", 52.0))
    if min_pf is None:
        min_pf = float(getattr(CFG, "STRATEGY_APPLY_MIN_PF", 1.05))
    if best["win_rate"] < min_winrate:
        return False
    if best["pf"] < min_pf:
        return False
    if best["avg_ret"] <= baseline.get("avg_ret", 0):
        return False  # 시장 평균 대비 우위 없으면 적용 안 함
    # ★ 수평 일관성: 5일 보유 전략이 3일 보유로도 플러스여야 (실전 괴리 방지)
    if best3 and best3.get("trades", 0) >= 50 and best3.get("avg_ret", 0) <= 0:
        return False
    return True


# ── 프롬프트 블록 생성 / 삽입 ──────────────────────

def _build_buy_block(report):
    r = report.get("rule") or {}
    m = report.get("market") or {}
    ver = report.get("version", "?")
    applied = now_kst().strftime("%Y-%m-%d")
    lines = [
        f"[📊 자동 전략 분석 — {applied} v{ver}]",
        f"시장 상태: {m.get('trend', '-')} (20일선 위 {m.get('breadth', 0):.0f}% · "
        f"중위 20일 모멘텀 {m.get('median_mom20', 0) * 100:+.1f}% · "
        f"일평균 등락 {m.get('median_daily_range', 0) * 100:.1f}%)",
    ]
    if r:
        lines += [
            f"자동 선정 전략: '{r['name']}' — 승률 {r['win_rate']:.1f}% · "
            f"평균수익 {r['avg_ret'] * 100:+.2f}% · 손익비 {r['pf']:.2f} · "
            f"샘플 {r['trades']:,}회 (전체 평균 대비 우위)",
            "데이터 기반 강조 조건 (우선순위 높음):",
        ]
        for g in RULE_GUIDANCE.get(r.get("id", ""), []):
            lines.append(f"- {g}")
    else:
        lines.append("현재 데이터로는 안정적인 전략이 검출되지 않아 기존 기준을 유지합니다.")
    # 분봉 기반 장중 분석 (데이터 있으면)
    id_ = report.get("intraday") or {}
    if id_.get("available"):
        lines.append(
            f"장중 분석(분봉): {id_.get('regime', '-')} — 오전 30분 강세 종목의 당일 플러스 마감 "
            f"{id_.get('am_strong_hold', 0) * 100:.0f}% · 오전 약세 종목의 마이너스 지속 "
            f"{id_.get('am_weak_hold', 0) * 100:.0f}% · 오전 거래량 비중 "
            f"{id_.get('am_share', 0) * 100:.0f}%")
        if id_.get("regime") == "장중 추세 지속":
            lines.append("- 장중 추세가 이어지는 종목(오전 강세 유지)을 우선 고려")
        elif id_.get("regime") == "장중 반전 잦음":
            lines.append("- 장중 반전이 잦은 시장 — 급등 추격 매수 주의, 눌림 후 재확인 필요")
    lines += [
        "보수 원칙:",
        "- 아래 [매수 조건]의 매수 금지 조항은 절대 완화하지 않습니다.",
        "- 신뢰도 임계값(대시보드 🎯)과 손절/최소익절(설정 탭)은 자동 변경되지 않습니다.",
        AUTO_END,
    ]
    return "\n".join(lines)


def _build_sell_block(report):
    m = report.get("market") or {}
    id_ = report.get("intraday") or {}
    applied = now_kst().strftime("%Y-%m-%d")
    lines = [
        f"[📊 자동 전략 분석 — {applied}]",
        f"시장 변동성: 일평균 등락폭 {m.get('median_daily_range', 0) * 100:.1f}% "
        f"(손절/트레일링 판단은 아래 [판단 순서]를 그대로 따름)",
    ]
    if id_.get("available"):
        lines.append(
            f"장중 변동성: 분봉 기준 고저 등락 중위 {id_.get('median_range', 0) * 100:.1f}% — "
            f"트레일링/손절 판단에 참고 (기준은 설정값 유지)")
    lines += [
        "보수 원칙: 하드 손절(설정값)과 최소 익절 기준은 자동 변경되지 않습니다.",
        AUTO_END,
    ]
    return "\n".join(lines)


def _upsert_auto_block(content, block):
    """[📊 자동 전략 분석 ... [자동 전략 분석 끝]] 블록 교체, 없으면 맨 앞에 삽입"""
    import re
    pat = re.compile(r"(?s)\[📊 자동 전략 분석.*?" + re.escape(AUTO_END) + r"\n?")
    if pat.search(content):
        return pat.sub(block + "\n", content)
    return block + "\n\n" + content


def _apply_prompts(report):
    try:
        os.makedirs(os.path.join("prompts", "backup"), exist_ok=True)
        ts = now_kst().strftime("%Y%m%d_%H%M%S")
        for src in (BUY_PROMPT_PATH, SELL_PROMPT_PATH):
            if os.path.exists(src):
                shutil.copy2(src, os.path.join("prompts", "backup",
                                               f"auto_{os.path.basename(src)}.{ts}"))
        buy = _read_file(BUY_PROMPT_PATH)
        sell = _read_file(SELL_PROMPT_PATH)
        ok1 = _write_file(BUY_PROMPT_PATH, _upsert_auto_block(buy, _build_buy_block(report)))
        ok2 = _write_file(SELL_PROMPT_PATH, _upsert_auto_block(sell, _build_sell_block(report)))
        return ok1 and ok2
    except Exception as e:
        log.warning(f"전략 프롬프트 적용 실패: {e}")
        return False


def _append_history(report, applied):
    try:
        os.makedirs(db.RESEARCH_DIR, exist_ok=True)
        path = os.path.join(db.RESEARCH_DIR, "strategy_history.csv")
        r = report.get("rule") or {}
        m = report.get("market") or {}
        headers = ["시각", "버전", "적용", "분석종목수", "시장상태", "20일선위%",
                   "전략", "샘플", "승률%", "평균수익%", "손익비", "사유"]
        row = [
            now_kst().strftime("%Y-%m-%d %H:%M:%S"),
            report.get("version", "-"),
            "적용" if applied else "미적용",
            report.get("symbols_analyzed", 0),
            m.get("trend", "-"),
            round(m.get("breadth", 0), 1),
            r.get("name", "-") if r else "-",
            r.get("trades", 0) if r else 0,
            round(r.get("win_rate", 0), 1) if r else 0,
            round((r.get("avg_ret", 0) or 0) * 100, 2) if r else 0,
            r.get("pf", 0) if r else 0,
            (report.get("reason") or "")[:80],
        ]
        new_file = not os.path.exists(path)
        with open(path, "a", encoding="utf-8-sig") as f:
            if new_file:
                f.write(",".join(headers) + "\n")
            f.write(",".join(str(x) for x in row) + "\n")
    except Exception:
        pass


# ── 메인 진입 ──────────────────────────────────────

def generate_strategy(force=False):
    """
    ★ 자동 전략 생성: 데이터 분석 → 최고 전략 선정 → 프롬프트 반영
    force=True 면 준비/쿨다운 무시하고 지금 실행 (단, 통과 조건은 그대로)
    반환: report dict (applied=True 면 프롬프트 반영됨)
    """
    rd = data_readiness()
    report = {
        "ok": True, "applied": False, "ready": rd["ready"],
        "ready_count": rd["ready_count"], "target": rd["target"],
        "total": rd["total"], "min_days": rd["min_days"], "pct": rd["pct"],
    }
    if not force and not rd["ready"]:
        report["reason"] = "데이터 부족 (대기 중)"
        return report

    cov = _coverage_cached()
    syms = [s for s, c in sorted(cov["symbols"].items(), key=lambda x: -x[1])
            if c >= int(getattr(CFG, "STRATEGY_MIN_DAYS", 30))]
    syms = syms[:int(getattr(CFG, "STRATEGY_MAX_SYMBOLS", 1500))]
    if not syms:
        report["reason"] = "분석 대상 종목 없음"
        report["ok"] = False
        return report

    series_map = _load_all_series(syms)
    series_map = {s: bars for s, bars in series_map.items()
                  if len(bars) >= int(getattr(CFG, "STRATEGY_MIN_DAYS", 30))}
    report["symbols_analyzed"] = len(series_map)
    if len(series_map) < 50 and not force:
        report["reason"] = f"분석 대상 종목 부족 ({len(series_map)})"
        report["ok"] = False
        return report

    market, rule_aggs, baseline, rule_aggs3, baseline3 = _simulate_all(series_map)
    report["market"] = market
    report["baseline"] = baseline
    report["baseline3"] = baseline3
    report["rules"] = rule_aggs
    report["rules3"] = rule_aggs3

    # 분봉 기반 장중 분석 (분봉 데이터 있는 종목 대상 - 관심/보유 종목)
    try:
        min_syms = db.get_minute_symbols(days=8)
        report["intraday"] = (analyze_intraday(min_syms, days=8, max_symbols=60)
                              if min_syms else {"available": False})
    except Exception:
        report["intraday"] = {"available": False}

    best = _pick_best(rule_aggs)
    report["rule"] = best
    best3 = rule_aggs3.get(best["id"]) if best else None
    report["rule3"] = best3
    qualified = _qualify(best, baseline, best3=best3)
    report["qualified"] = qualified
    report["reason"] = ("조건 통과 → 적용" if qualified else
                        "조건 미달 (승률/손익비/시장 대비 우위) - 기존 기준 유지")

    if not qualified:
        _save_state({**_load_state(), "last_run_at": now_kst_iso(),
                     "last_check_result": report["reason"]})
        _append_history(report, applied=False)
        return report

    # ── 적용 ──
    report["version"] = int(_load_state().get("version", 0)) + 1
    if not _apply_prompts(report):
        report["reason"] = "프롬프트 저장 실패 - 적용 안 됨"
        report["ok"] = False
        return report

    report["applied"] = True
    report["applied_at"] = now_kst_iso()
    state = {
        **_load_state(),
        "version": report["version"],
        "applied_at": report["applied_at"],
        "last_run_at": report["applied_at"],
        "rule_id": best["id"],
        "rule": {k: v for k, v in best.items() if k != "id"},
        "market": market,
        "intraday": report.get("intraday") or {},
        "baseline": baseline,
        "baseline3": baseline3,
        "rule3": best3,
        "fee_pct": float(getattr(CFG, "FEE_ROUND_TRIP_PCT", 0.2)),
        "last_check_result": "적용 완료",
    }
    _save_state(state)
    _append_history(report, applied=True)
    log.info(f"🧠 자동 전략 생성·적용 완료: v{report['version']} '{best['name']}' "
             f"(승률 {best['win_rate']:.1f}% · 손익비 {best['pf']:.2f})")
    return report


def maybe_auto_generate(force=False):
    """백필 후 자동 호출: 준비·쿨다운 확인 후 generate_strategy"""
    if not getattr(CFG, "AUTO_STRATEGY_GEN", True) and not force:
        return {"skipped": "AUTO_STRATEGY_GEN=false (설정에서 켜면 자동 생성)"}
    rd = data_readiness()
    if not rd["ready"] and not force:
        return {"skipped": "데이터 충분하지 않음", "ready": False,
                "ready_count": rd["ready_count"], "target": rd["target"],
                "min_days": rd["min_days"], "pct": rd["pct"]}
    st = _load_state()
    if not force and st.get("last_run_at"):
        try:
            last = datetime.fromisoformat(st["last_run_at"])
            days = (now_kst() - last).days
            cd = int(getattr(CFG, "STRATEGY_COOLDOWN_DAYS", 7))
            if days < cd:
                nxt = (last + timedelta(days=cd)).strftime("%Y-%m-%d")
                return {"skipped": f"쿨다운 {cd}일 (다음 {nxt} 이후 자동 재분석)"}
        except Exception:
            pass
    return generate_strategy(force=force)


def auto_strategy_status():
    """UI 표시용 상태"""
    rd = data_readiness()
    st = _load_state()
    out = {
        "enabled": getattr(CFG, "AUTO_STRATEGY_GEN", True),
        "ready": rd["ready"],
        "ready_count": rd["ready_count"],
        "target": rd["target"],
        "total": rd["total"],
        "pct": rd["pct"],
        "min_days": rd["min_days"],
        "version": st.get("version"),
        "applied_at": st.get("applied_at"),
        "rule_id": st.get("rule_id"),
        "rule": st.get("rule"),
        "market": st.get("market"),
        "intraday": st.get("intraday"),
        "last_run_at": st.get("last_run_at"),
        "last_check_result": st.get("last_check_result"),
    }
    if st.get("last_run_at"):
        try:
            last = datetime.fromisoformat(st["last_run_at"])
            nxt = last + timedelta(days=int(getattr(CFG, "STRATEGY_COOLDOWN_DAYS", 7)))
            out["next_check"] = nxt.strftime("%Y-%m-%d")
        except Exception:
            pass
    return out


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="자동 전략 생성 (데이터 기반)")
    parser.add_argument("--force", action="store_true", help="준비/쿨다운 무시하고 지금 실행")
    parser.add_argument("--status", action="store_true", help="상태만 표시")
    args = parser.parse_args()
    db.init_db()
    if args.status:
        print(json.dumps(auto_strategy_status(), ensure_ascii=False, indent=2))
    else:
        res = generate_strategy(force=args.force)
        print(json.dumps(res, ensure_ascii=False, indent=2, default=str))
