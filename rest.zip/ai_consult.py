"""AI 컨설턴트 모듈 - Gemini/GPT/규칙 기반 상담

기능:
- ask(): 프롬프트 기준 검토, 전략 분석, 세대교체 판단 등 자유 질문
- Gemini REST API 사용 (추가 패키지 불필요, requests만 사용)
- OPENAI_API_KEY 있으면 GPT, GEMINI_API_KEY 있으면 Gemini, 둘 다 없으면 규칙 기반

제공 함수:
- ask(user_text, system="")                  -> AI 답변
- review_prompts(buy, sell)                  -> 매수/매도 프롬프트 기준 검토
- analyze_strategies()                       -> 현재 전략 상태 분석
- recommendation()                           -> 생존자/세대교체 추천
- risk_check()                               -> 오픈 포지션 리스크 점검
"""
import json
import os
import sqlite3
from datetime import datetime
import db
from db import now_kst

from config import CFG
import ai_judge as _aj   # ★ 쿨다운 헬퍼 공유 (AI 실패 시 반복 호출 방지)

DB_PATH = "trading.db"

try:
    import requests
    _HAS_REQUESTS = True
except ImportError:
    _HAS_REQUESTS = False


def _provider():
    """현재 사용 가능한 AI 공급자 결정"""
    if CFG.AI_PROVIDER == "gemini" and (CFG.GEMINI_API_KEY or os.getenv("GEMINI_API_KEY")):
        return "gemini"
    if CFG.AI_PROVIDER == "openai" and (CFG.OPENAI_API_KEY or os.getenv("OPENAI_API_KEY")):
        return "openai"
    if CFG.GEMINI_API_KEY or os.getenv("GEMINI_API_KEY"):
        return "gemini"
    if CFG.OPENAI_API_KEY or os.getenv("OPENAI_API_KEY"):
        return "openai"
    return "rule"


def is_ai_available() -> dict:
    """AI 사용 가능 여부 + 이유 (UI용)"""
    p = _provider()
    if p == "gemini":
        return {"available": True, "provider": "gemini", "msg": "Gemini 연결됨"}
    if p == "openai":
        return {"available": True, "provider": "openai", "msg": "GPT 연결됨"}
    return {"available": False, "provider": "rule",
            "msg": "API 키 미설정 - 규칙 기반 모드 (설정 탭에서 GEMINI_API_KEY 또는 OPENAI_API_KEY 입력)"}


# Gemini 404(모델 없음) 대비 최신 모델 fallback 목록 (순서대로 시도)
GEMINI_MODELS = [
    os.getenv("GEMINI_MODEL", ""),
    "gemini-2.0-flash",
    "gemini-1.5-flash",
    "gemini-1.5-flash-latest",
    "gemini-1.5-pro",
    "gemini-flash-latest",
]


def _gemini_rest(prompt: str, system: str = "") -> str:
    """Gemini REST API 직접 호출 (404 모델없음 → 자동 다음 모델 시도)
    ★ 429/503 실패 시 ai_judge 쿨다운 공유 - 쿨다운 중엔 빈 문자열(규칙 폴백)"""
    # ★ AI 실패 쿨다운 중이면 호출 생략 (ai_judge와 공유 - 반복 실패 방지)
    if _aj._ai_cooldown_take():
        return ""
    key = CFG.GEMINI_API_KEY or os.getenv("GEMINI_API_KEY", "")
    if not key or not _HAS_REQUESTS:
        return ""
    models = [m for m in GEMINI_MODELS if m]
    if not models:
        models = ["gemini-1.5-flash"]
    parts = []
    if system:
        parts.append({"text": system})
    parts.append({"text": prompt})
    payload = {"contents": [{"parts": parts}]}
    last_err = ""
    for model in models:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
        # ★ 새 키 형식(AQ...)은 X-goog-api-key 헤더로 전달 (쿼리 파라미터 인증 실패)
        headers = {"Content-Type": "application/json", "X-goog-api-key": key}
        try:
            r = requests.post(url, json=payload, headers=headers, timeout=10)
            if r.status_code == 404:
                last_err = f"모델 '{model}' 없음(404) → 다음 모델 시도"
                continue
            if r.status_code != 200:
                # ★ 429(할당량)/503(과부하) → 쿨다운 설정 (ai_judge와 공유)
                if r.status_code in (429, 500, 503):
                    _aj._ai_cooldown_set(f"Gemini 오류 {r.status_code}", code=r.status_code)
                return f"(Gemini 오류 {r.status_code}: {r.text[:200]})"
            data = r.json()
            try:
                return data["candidates"][0]["content"]["parts"][0]["text"].strip()
            except Exception:
                return f"(Gemini 응답 파싱 실패: {str(data)[:200]})"
        except Exception as e:
            last_err = f"호출 실패: {e}"
    return f"(Gemini 실패: {last_err})"


def _openai_call(prompt: str, system: str = "") -> str:
    key = CFG.OPENAI_API_KEY or os.getenv("OPENAI_API_KEY", "")
    if not key or not _HAS_REQUESTS:
        return ""
    url = "https://api.openai.com/v1/chat/completions"
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    msgs = []
    if system:
        msgs.append({"role": "system", "content": system})
    msgs.append({"role": "user", "content": prompt})
    payload = {"model": CFG.AI_MODEL, "messages": msgs, "temperature": 0.3, "max_tokens": 800}
    try:
        r = requests.post(url, headers=headers, json=payload, timeout=25)
        data = r.json()
        return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        return f"(OpenAI 호출 실패: {e})"


def ask(user_text: str, system: str = "") -> str:
    """프로바이더 자동 선택해서 질문"""
    p = _provider()
    if p == "gemini":
        return f"[Gemini] {_gemini_rest(user_text, system)}"
    if p == "openai":
        return f"[GPT] {_openai_call(user_text, system)}"
    return _rule_answer(user_text, system)


# ── DB 유틸 ──

def _q(sql, params=()):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _state_snapshot() -> dict:
    strategies = _q("""
        SELECT s.id, s.generation, s.status, s.params_json,
               (SELECT COUNT(*) FROM trades t WHERE t.strategy_id=s.id) as trade_cnt,
               (SELECT fitness_score FROM daily_performance d
                 WHERE d.strategy_id=s.id ORDER BY d.id DESC LIMIT 1) as fitness
        FROM strategies s ORDER BY s.id
    """)
    open_pos = _q("SELECT * FROM virtual_positions WHERE status='open'")
    closed = _q("SELECT entry_price, exit_price, symbol FROM virtual_positions WHERE status='closed'")
    stats = {}
    try:
        conn = sqlite3.connect(DB_PATH)
        stats["total_trades"] = conn.execute("SELECT COUNT(*) c FROM trades").fetchone()[0]
        conn.close()
    except Exception:
        stats["total_trades"] = 0
    gen_row = _q("SELECT MAX(generation) g FROM strategies")
    generation = gen_row[0]["g"] if gen_row and gen_row[0]["g"] is not None else 0
    return {
        "generation": generation,
        "strategies": strategies,
        "open_positions": open_pos,
        "closed": closed,
        "total_trades": stats["total_trades"],
        "provider": _provider(),
    }


# ── 규칙 기반 답변 (API 키 없을 때) ──

def _rule_answer(text: str, system: str = "") -> str:
    """AI 키가 없을 때 기본적인 규칙 기반 응답"""
    s = _state_snapshot()
    low = text.lower()
    if "매수" in text and ("프롬프트" in text or "기준" in text or "조건" in text):
        return _rule_review_prompts(short=True)
    if "전략" in text and ("분석" in text or "상태" in text):
        return _rule_analyze(s)
    if "세대" in text or "진화" in text or "생존" in text:
        return _rule_recommend(s)
    if "리스크" in text or "위험" in text or "포지션" in text:
        return _rule_risk(s)
    return (
        "🤖 현재 [규칙 기반] 모드입니다 (AI 키 미설정).\n\n"
        "💡 Gemini 무료 키로 AI 상담을 받으려면:\n"
        "  1. https://aistudio.google.com/app/apikey 에서 키 발급\n"
        "  2. 설정 탭에서 GEMINI_API_KEY 입력 + 저장\n"
        "  3. 앱 재시작 후 다시 질문!\n\n"
        "지금도 가능한 질문:\n"
        " - '매수 프롬프트 기준을 평가해줘'\n"
        " - '지금 전략 상태 분석해줘'\n"
        " - '세대교체를 해도 될까?'\n"
        " - '리스크 점검해줘'\n\n"
        f"현재 상태: {s['generation']}세대 / 전략 {len(s['strategies'])}개 / "
        f"오픈 {len(s['open_positions'])} / 총 거래 {s['total_trades']}건"
    )


def _rule_analyze(s: dict) -> str:
    lines = [f"📊 현재 {s['generation']}세대 / 전략 {len(s['strategies'])}개 / 총 거래 {s['total_trades']}건\n"]
    for st in s["strategies"][:12]:
        fit = st["fitness"] if st["fitness"] is not None else -999
        lines.append(f"  전략#{st['id']} [{st['status']}] 거래 {st['trade_cnt']} fitness {fit:.1f}")
    if s["open_positions"]:
        lines.append(f"\n⚠️ 오픈 포지션 {len(s['open_positions'])}개:")
        for p in s["open_positions"][:8]:
            lines.append(f"  {p['symbol']} 진입 {p['entry_price']:,.0f} (전략{p['strategy_id']})")
    else:
        lines.append("\n✅ 오픈 포지션 없음")
    return "\n".join(lines)


def _rule_recommend(s: dict) -> str:
    scored = [st for st in s["strategies"] if st["trade_cnt"] > 0]
    scored.sort(key=lambda x: -(x["fitness"] if x["fitness"] is not None else -999))
    if not scored:
        return "아직 거래가 쌓이지 않아 평가 불가 (거래 20건 이상이면 fitness 산출)."
    lines = [f"🧬 현재 {s['generation']}세대 - 세대교체 추천:"]
    for i, st in enumerate(scored[:5]):
        lines.append(f"  {i+1}. 전략#{st['id']} fitness={st['fitness']:.1f} 거래 {st['trade_cnt']}")
    lines.append("\n💡 규칙 기반 판단: 거래 20건 미만은 fitness -999 → 탈락 대상.")
    lines.append("   (AI 키 설정하면 더 정밀한 추천이 가능합니다)")
    return "\n".join(lines)


def _rule_risk(s: dict) -> str:
    if not s["open_positions"]:
        return "✅ 현재 오픈 포지션이 없어 리스크 없음."
    total_val = sum(p["entry_price"] * p["qty"] for p in s["open_positions"])
    lines = [f"⚠️ 오픈 포지션 {len(s['open_positions'])}개 / 총 진입금액 약 {total_val:,.0f}원"]
    for p in s["open_positions"]:
        lines.append(f"  {p['symbol']} x{p['qty']} @ {p['entry_price']:,.0f}")
    lines.append("\n💡 손절 기준: 손절% 초과 시 자동 청산, 보유기간 초과 시 자동 청산")
    return "\n".join(lines)


def _rule_review_prompts(short: bool = False) -> str:
    base = [
        "📝 매수/매도 프롬프트 기준 점검 (규칙 기반):",
        "  ✅ 매수: 금지조건 우선 판단(2차지지선/전일저가 아래 → 즉시 거부)",
        "  ✅ 매수: 체결강도 100↑ + 1분/3분 거래대금 동시 증가 = 강한 신호",
        "  ✅ 매수: 전일고가 돌파 + 고점갱신 = 최고 신호",
        "  ⚠️ 개선 제안: 1분 거래대금만 급증(3분 부진)은 추격매수 금지 명시됨",
        "  ✅ 매도: 트레일링 스탑 2.0%p = 최종 수익청산 확정",
        "  ✅ 매도: 손절은 가격 하락이 반드시 수반되어야 함 (체결만 약해도 손절 안 함)",
        "  ✅ 매도: 보유조건 3개 이상이면 보유",
    ]
    if short:
        return "\n".join(base)
    return "\n".join(base + [
        "",
        "💡 더 정확한 검토는 AI 키 설정 후 '🤖 AI 기준 검토' 버튼 사용을 추천합니다.",
    ])


# ── 공개 상담 함수 ──

def review_prompts(buy_text: str, sell_text: str) -> str:
    """매수/매도 프롬프트 기준 검토 - AI가 개선안 제시"""
    p = _provider()
    if p in ("gemini", "openai"):
        system = "당신은 한국 주식 단타/스윙 전문가이자 프롬프트 엔지니어입니다. 사용자의 매수/매도 규칙을 검토하고, 모순/누락/개선점을 구체적으로 제안하세요."
        prompt = (
            "아래는 자동매매 AI가 사용할 매수/매도 프롬프트입니다.\n"
            "1) 각 규칙이 명확하고 실행 가능한지, 2) 모순이나 중복은 없는지, "
            "3) 빠진 중요한 리스크 조건은 없는지, 4) 개선된 프롬프트 제안\n\n"
            f"[매수 프롬프트]\n{buy_text}\n\n[매도 프롬프트]\n{sell_text}"
        )
        if p == "gemini":
            return f"[Gemini 검토]\n{_gemini_rest(prompt, system)}"
        return f"[GPT 검토]\n{_openai_call(prompt, system)}"
    return _rule_review_prompts()


def analyze_strategies() -> str:
    """현재 전략 상태 분석"""
    s = _state_snapshot()
    if _provider() in ("gemini", "openai"):
        summary = _rule_analyze(s)
        system = "당신은 퀀트 전략 분석가입니다. 아래 데이터를 보고 각 전략의 문제점과 개선 방향을 제시하세요."
        prompt = f"현재 자동매매 전략 상태:\n{summary}\n\n어떤 전략을 유지/폐기/변경할지, fitness 개선 방법을 알려주세요."
        if _provider() == "gemini":
            return f"[Gemini 분석]\n{_gemini_rest(prompt, system)}"
        return f"[GPT 분석]\n{_openai_call(prompt, system)}"
    return _rule_analyze(s)


def recommendation() -> str:
    """세대교체/생존자 추천"""
    s = _state_snapshot()
    if _provider() in ("gemini", "openai"):
        data = _rule_recommend(s)
        system = "당신은 유전알고리즘 트레이딩 전문가입니다. fitness/거래수를 보고 생존자 3개와 폐기 대상을 추천하세요."
        prompt = f"현재 전략 fitness:\n{data}\n\n생존자 3개를 고르고 이유를 설명해주세요."
        if _provider() == "gemini":
            return f"[Gemini 추천]\n{_gemini_rest(prompt, system)}"
        return f"[GPT 추천]\n{_openai_call(prompt, system)}"
    return _rule_recommend(s)


def risk_check() -> str:
    """오픈 포지션 리스크 점검"""
    s = _state_snapshot()
    if _provider() in ("gemini", "openai"):
        data = _rule_risk(s)
        system = "당신은 리스크 관리 전문가입니다. 아래 포지션 상태를 보고 청산/보유 추천을 주세요."
        prompt = f"오픈 포지션 상태:\n{data}\n\n각 포지션 청산/보유를 추천해주세요."
        if _provider() == "gemini":
            return f"[Gemini 리스크]\n{_gemini_rest(prompt, system)}"
        return f"[GPT 리스크]\n{_openai_call(prompt, system)}"
    return _rule_risk(s)


def analyze_chart(symbol, days=60):
    """
    ★ 매수타점 차트 AI 분석: 최근 데이터(추세/MA/RSI/신호)를 요약해
    AI(제미나이/GPT, 없으면 규칙)가 해석·설명하고, 무엇을 변경하면 좋은지 제안.
    - 시각화된 차트(charting)는 사용자가 직접 보고, 이 설명을 곁들여 판단.
    - PNG를 이 채팅에 올려도 AI가 직접 보고 설명해드릴 수 있습니다.
    """
    import charting
    bars = charting.load_daily_with_dates(symbol, max_days=days)
    if len(bars) < 20:
        return f"{symbol}: 일봉 데이터 부족 ({len(bars)}봉). '📥 데이터 수집' 후 재시도."
    closes = [b[4] for b in bars]
    highs = [b[3] for b in bars]
    lows = [b[2] for b in bars]
    cur = closes[-1]
    # 지표 요약
    ma5 = sum(closes[-5:]) / 5
    ma20 = sum(closes[-20:]) / 20
    ma60 = sum(closes[-60:]) / 60 if len(closes) >= 60 else None
    mom5 = (cur / closes[-6] - 1) * 100 if closes[-6] else 0
    mom20 = (cur / closes[-21] - 1) * 100 if len(closes) >= 21 and closes[-21] else 0
    high60 = max(highs)
    low60 = min(lows)
    # RSI(14)
    gains = losses = 0.0
    for i in range(len(closes) - 14, len(closes)):
        ch = closes[i] - closes[i - 1]
        gains += max(0, ch)
        losses += max(0, -ch)
    rsi = 100.0 if losses == 0 else 100 - 100 / (1 + gains / losses)
    signals = charting.collect_signals(symbol)
    recent_sig = signals[-6:][::-1]

    lines = [
        f"[{symbol} {db.get_symbol_name(symbol)}] 최근 {len(closes)}일 분석",
        "=" * 46,
        f"· 현재가 {cur:,.0f}원 (MA5 {ma5:,.0f} · MA20 {ma20:,.0f}" +
        (f" · MA60 {ma60:,.0f})" if ma60 else ")"),
        f"· 5일 {mom5:+.1f}% · 20일 {mom20:+.1f}% · RSI(14) {rsi:.0f}",
        f"· 60일 고가 {high60:,.0f} / 저가 {low60:,.0f} "
        f"(고가대비 {(cur/high60-1)*100:+.1f}% · 저가대비 {(cur/low60-1)*100:+.1f}%)",
        f"· 최근 신호 {len(recent_sig)}건",
    ]
    for s in recent_sig:
        lines.append(f"    - {s['date']} {'매수▲' if s['kind']=='buy' else '매도▼'} "
                     f"[{s['decision']}] {s['reason'][:40]}")
    # 방향 판단 (규칙)
    trend = "상승" if cur > ma20 > (ma60 or 0) else ("하락" if cur < ma20 else "횡보")
    if rsi < 30:
        rsi_txt = "과매도 (반등 가능 구간)"
    elif rsi > 70:
        rsi_txt = "과매수 (추격 주의)"
    else:
        rsi_txt = "중립"
    lines.append(f"\n[규칙 판단] 추세 {trend} · RSI {rsi_txt}")
    if cur > ma5 > ma20:
        lines.append("→ 단기 강세 (MA5>MA20, 가격 상승) - 타점 유효 구간")
    elif cur < ma20:
        lines.append("→ 20일선 아래 - 보수적으로 접근 (반등 확인 후 진입 권장)")
    else:
        lines.append("→ 혼조 - 명예의 전당 조건식 재확인 필요")
    lines.append("\n[변경 제안]")
    lines.append("· 매수타점이 궁금하면 이 차트 PNG를 채팅에 올려주세요 — AI가 직접 보고 설명/변경 제안.")
    lines.append("· 또는 테스트 탭 '🏆 명예의 전당' 조건식을 이 종목에 적용해 신호 확인.")
    summary = "\n".join(lines)

    # AI 키 있으면 LLM 해석
    try:
        avail = is_ai_available()
        if avail.get("available"):
            prompt = (f"당신은 차트 분석가입니다. 아래 한국 주식 {symbol} 데이터 요약을 보고 "
                      f"(1) 현재 추세와 매수타점 판단 (2) 위험 요소 (3) 무엇을 바꾸면 좋은지 제안하세요.\n\n{summary}")
            ai_txt = ask(prompt)
            return summary + "\n\n[AI 해석]\n" + ai_txt
    except Exception:
        pass
    return summary


def discuss_daily_report(target_date=None, question=""):
    """
    ★ 일일 복기 리포트 AI 토의: 그날 매매를 보고 '무엇이 부족했는지/어떻게 개선할지' 논의
    question: 사용자 의견 (예: "손절이 늦었어" / "이 조건식이 별로인데")
    - AI 키 있으면 LLM 토의, 없으면 규칙 기반 개선 제안
    """
    import daily_report
    r = daily_report.generate_daily_report(target_date) if target_date else None
    if r is None:
        # 저장된 리포트 확인
        if target_date:
            txt = daily_report.get_report(target_date)
        else:
            dates = daily_report.list_reports()
            txt = daily_report.get_report(dates[0]) if dates else None
            target_date = dates[0] if dates else "오늘"
        if not txt:
            return "리포트가 없습니다. 먼저 매매 내역을 쌓은 뒤 '일일 리포트'를 생성하세요."
    else:
        txt = r["text"]
        target_date = r["date"]

    lines = [f"📋 {target_date} 복기 리포트 기반 토의", "=" * 50]
    # 요약 부분: 요약줄 + 매수/매도 내역 + 개선 포인트 (토의 재료)
    for ln in txt.splitlines():
        if ln.startswith("**요약**") or ln.startswith("- "):
            lines.append(ln)
        elif ln.startswith("## 💡") or ln.startswith("## ✅") or ln.startswith("## 💰"):
            lines.append(ln)
    if question:
        lines.append(f"\n[사용자 의견] {question}")
    lines.append("")

    # AI 키 있으면 LLM 토의
    try:
        avail = is_ai_available()
        if avail.get("available"):
            prompt = (f"아래는 한국 주식 자동매매 시스템의 {target_date} 일일 복기 리포트입니다.\n"
                      f"이 리포트를 보고 (1) 무엇이 부족했는지 (2) 어떻게 개선하면 좋을지 "
                      f"(3) 다음 매매에 적용할 구체적 조치를 제안하세요.\n"
                      f"사용자 의견이 있으면 반영하세요: {question or '(없음)'}\n\n{txt}")
            ai_txt = ask(prompt)
            return "\n".join(lines) + "\n[AI 토의]\n" + ai_txt
    except Exception:
        pass

    # 규칙 기반 토의
    s = txt
    lines.append("[규칙 토의 - 개선 제안]")
    if "승률 0%" in s or "손실 우위" in s:
        lines.append("- 손실 우위: 매수 조건을 더 엄격하게(신뢰도 상향/조건식 강화 변형) 해보세요.")
    if "매수 없음" in s or "매수 신호가 없었" in s:
        lines.append("- 매수 부재: 조건식 완화 변형 + 시장 활력 시간대 확인이 필요합니다.")
    if "과다" in s:
        lines.append("- 매수 과다: 조건식 강화(추가 필터)로 신호를 줄여보세요.")
    if question:
        lines.append(f"- 의견 반영: '{question}' — 관련 조건식/기준을 조정해 다음 리포트에서 확인합니다.")
    lines.append("- 참고: 'AI 토의'는 데이터가 쌓일수록 정확해집니다 (현재 규칙 기반).")
    return "\n".join(lines)


def review_buy_results():
    """
    ★ AI 피드백 루프: 최근 매수 기록 + 결과를 AI가 분석해 프롬프트 수정안 제안
    - 매수한 종목: 언제/왜(이유)/엔진/그 후 수익률
    - AI가 "어떤 조건이 좋았고/나빴는지" → 매수 프롬프트 개선안 제시
    - 참고용 (자동 적용 안 됨) - 사용자가 프롬프트 탭에서 반영
    """
    buys = db.get_buy_history_for_ai(limit=30)
    if not buys:
        return "아직 매수 기록이 없습니다. 모의투자/시뮬레이션을 먼저 실행하세요."

    # 요약 텍스트 구성
    lines = ["📋 최근 매수 내역 (판단 이유 + 결과)", "=" * 50]
    for b in buys[:20]:
        res = b["result"]
        if res and res.get("ret_pct") is not None:
            res_txt = f"→ 결과 {res['ret_pct']:+.2f}% (청산)"
        else:
            res_txt = "→ 보유 중/미청산"
        lines.append(f"[{b['judged_at'][:16]}] {b['symbol']} {b['name']} ({b['engine']}) {res_txt}")
        lines.append(f"    이유: {(b['reason'] or '')[:120]}")

    # AI 분석 요청 (Gemini/GPT 있으면, 없으면 규칙)
    p = _provider()
    if p in ("gemini", "openai"):
        system = ("당신은 한국 주식 단타 전략 분석가입니다. 매수 기록과 결과를 보고 "
                  "어떤 조건이 수익/손실로 이어졌는지 패턴을 찾고, 매수 프롬프트 개선안을 제시하세요. "
                  "결과는 '개선안' 섹션을 포함해 주세요.")
        prompt = ("아래는 자동매매가 매수한 종목들의 판단 이유와 결과입니다.\n"
                  "1) 수익난 매수의 공통 조건, 2) 손실난 매수의 공통 조건, "
                  "3) 매수 프롬프트 수정 제안(구체적으로) 을 분석하세요.\n\n" + "\n".join(lines))
        if p == "gemini":
            return f"[Gemini 분석]\n{_gemini_rest(prompt, system)}"
        return f"[GPT 분석]\n{_openai_call(prompt, system)}"

    # 규칙 기반
    wins = [b for b in buys if b["result"] and b["result"].get("ret_pct") is not None and b["result"]["ret_pct"] > 0]
    losses = [b for b in buys if b["result"] and b["result"].get("ret_pct") is not None and b["result"]["ret_pct"] <= 0]
    open_b = [b for b in buys if not b["result"]]
    summary = ["\n[요약]",
               f"  매수 {len(buys)}건 중 청산 {len(wins)+len(losses)}건 (승 {len(wins)} / 패 {len(losses)}) · 보유 {len(open_b)}건"]
    if wins:
        avg_w = sum(b["result"]["ret_pct"] for b in wins) / len(wins)
        summary.append(f"  수익 평균: +{avg_w:.2f}%")
    if losses:
        avg_l = sum(b["result"]["ret_pct"] for b in losses) / len(losses)
        summary.append(f"  손실 평균: {avg_l:.2f}%")
    summary.append("\n💡 Gemini/GPT 키를 넣으면 구체적 개선안을 제시합니다 (설정 탭에서 GEMINI_API_KEY).")
    return "\n".join(lines + summary)


def analyze_symbol(symbol: str):
    """
    ★ 검증마스터 유사: 순위/조건식 편입 종목 심층 분석
    - 편입 데이터: 최근 스냅샷(가격/체결강도/거래량/고저) + 판단 기록
    - AI(Gemini/GPT)에게 분석 의뢰: 뉴스/이슈/내일 추세/테마
    - 키 없으면 데이터 요약만
    """
    snaps = db.get_snapshots(symbol=symbol, hours=24, limit=50)
    judgments = db.get_recent_judgments(limit=50)
    j_for_sym = [j for j in judgments if j["symbol"] == symbol]

    name = db.get_symbol_name(symbol)
    if not snaps:
        return f"{symbol} {name}: 최근 스냅샷 데이터 없음 (수집 대기 중)"

    # ── 편입 데이터 요약 (검증마스터 스타일) ──
    prices = [s["price"] for s in snaps if s.get("price")]
    first, last = prices[0], prices[-1]
    high = max(prices)
    low = min(prices)
    chegyuls = [s.get("chegyul") for s in snaps if s.get("chegyul")]
    vols = [s.get("volume") for s in snaps if s.get("volume")]
    times = [s["snapshot_time"][11:19] for s in snaps]

    summary = [
        f"📊 {symbol} {name} - 종목 분석",
        "=" * 50,
        f"  편입(최초수집): {snaps[0]['snapshot_time'][:19]}",
        f"  현재가: {last:,.0f}원 (최초 {first:,.0f}원, {(last-first)/first*100:+.2f}%)",
        f"  최고가: {high:,.0f}원 / 최저가: {low:,.0f}원",
        f"  체결강도: 최신 {chegyuls[-1] if chegyuls else '-'} / 평균 {sum(chegyuls)/len(chegyuls) if chegyuls else 0:.0f}",
        f"  거래량: 최신 {vols[-1] if vols else '-'}",
        f"  수집 시간대: {times[0]} ~ {times[-1]}",
    ]
    if j_for_sym:
        summary.append(f"  최근 판단: {j_for_sym[0]['decision']} ({j_for_sym[0]['engine']}) {(j_for_sym[0]['reason'] or '')[:80]}")
    summary.append("")

    # ── AI 분석 의뢰 (뉴스/이슈/내일 추세/테마) ──
    p = _provider()
    if p in ("gemini", "openai"):
        system = ("당신은 한국 주식 리서치 전문가입니다. 주어진 종목 데이터를 보고 "
                  "① 공시/뉴스/최근 이슈 ② 오늘 수급 분석 ③ 내일 추세 예상 ④ 테마/시황 "
                  "을 분석하세요. 정확한 팩트가 없으면 '추정'임을 명시하세요.")
        prompt = ("아래 종목의 편입 데이터를 분석해주세요. " + "\n".join(summary[1:]) +
                  "\n\n① 최근 이슈/뉴스 ② 체결강도·거래량 수급 해석 ③ 내일 추세 예상 ④ 테마/시황")
        if p == "gemini":
            summary.append("[Gemini 분석]")
            summary.append(_gemini_rest(prompt, system))
        else:
            summary.append("[GPT 분석]")
            summary.append(_openai_call(prompt, system))
    else:
        summary.append("💡 Gemini/GPT 키를 넣으면 뉴스/이슈/내일 추세 분석이 가능합니다 (설정 탭 → GEMINI_API_KEY).")

    return "\n".join(summary)


def review_index_regimes(stats=None):
    """★ 조건식 × 하락장 국면 점수 (AI 판단 우선, 키 없으면 규칙)
    - stats: db.index_condition_stats() 결과 (없으면 자동 조회)
    - AI가 각 조건식에 0~100 점수 부여 (하락장에서도 잘 버는 조건식 = 높은 점수)
    - 하락 표본이 INDEX_COND_MIN_SELLS 미만이면 미평가(표본 쌓일 때까지)
    반환: {"provider": "gemini"|"rule", "scores": {cond_key: int/None}, "note": str}
    """
    import db as _db
    import json as _json
    import re as _re
    if stats is None:
        stats = _db.index_condition_stats()
    min_sells = int(getattr(CFG, "INDEX_COND_MIN_SELLS", 5))
    rule_scores = {}
    for ck, cs in stats.items():
        rule_scores[ck] = _db.regime_rule_score(cs)
    evaluable = {ck: cs for ck, cs in stats.items()
                 if (cs.get("down") or {}).get("sells", 0) >= min_sells}
    if not evaluable:
        return {"provider": "rule", "scores": rule_scores,
                "note": "하락장 표본 부족 - 아직 평가 없음 (데이터 쌓이면 자동 평가)"}
    # ── AI 판단 프롬프트 ──
    lines = []
    for ck, cs in sorted(evaluable.items()):
        d = cs.get("down") or {}
        lines.append(f"- 조건식 {ck}: 하락장 표본 {d.get('sells',0)}건 · "
                     f"승률 {d.get('win_rate',0):.1f}% · 평균수익 {d.get('avg_ret',0):+.2f}%")
    system = ("당신은 주식 조건검색식 리스크 평가 전문가입니다. "
              "각 조건식이 지수 하락장에서도 수익을 내는지 0~100점으로 평가하세요. "
              "JSON만 출력하세요.")
    prompt = (
        "다음은 각 조건식이 '지수 하락장(코스피 -1% 이하)에 진입한 포지션'의 실제 모의 매매 성적입니다.\n"
        f"{chr(10).join(lines)}\n\n"
        "각 조건식에 '하락장 적합 점수'(0~100)를 부여하세요.\n"
        "- 70점 이상: 하락장에서도 잘 버는 조건식 (계속 사용)\n"
        "- 50~69점: 보통 (유지하되 관찰)\n"
        "- 50점 미만: 하락장에서 수익을 내기 어려운 조건식 (하락장 진입 제한 권장)\n"
        "- ★ 표본 신뢰도: 표본 20~39건은 '평가 시작 단계'라 보수적으로(점수를 ±10점 수축, 50점 근처로)\n"
        "  표본 40건 이상이면 정상 평가. 표본이 우연한 결과일 가능성을 항상 고려하세요.\n"
        '응답 형식(JSON만): {"조건식키": 0~100, ...}'
    )
    ai_txt = _gemini_rest(prompt, system)
    scores, note = {}, ""
    try:
        m = _re.search(r"\{.*\}", ai_txt, _re.S)
        if m:
            parsed = _json.loads(m.group(0))
            for k, v in parsed.items():
                try:
                    scores[str(k)] = max(0, min(100, int(float(v))))
                except Exception:
                    continue
    except Exception:
        scores = {}
    if scores:
        # AI가 평가하지 않은 조건식은 규칙 점수로 보완
        for ck in evaluable:
            if ck not in scores:
                scores[ck] = rule_scores.get(ck)
        note = f"AI(Gemini) 평가 {len(scores)}개 조건식 (하락장 표본≥{min_sells})"
        return {"provider": "gemini", "scores": scores, "note": note}
    note = "AI 평가 실패/미설정 - 규칙 점수 사용 (승률·평균수익 기준)"
    return {"provider": "rule", "scores": rule_scores, "note": note}


def analyze_index_time(question=""):
    """★ 지수 국면 × 시간대 분석 (AI 해석 - 키 있으면 Gemini, 없으면 규칙)
    - index_time_stats()로 시장 전체의 '지수대 × 시간대' 성적을 집계
    - AI가 '어떤 지수대에 어떤 시간대가 강한지' 해석 + 매매 시간대 전략 제안
    반환: {"provider": "gemini"|"rule", "text": str, "rows": [...]}
    """
    import db as _db
    res = _db.index_time_stats(min_sells=3)
    rows = res.get("rows", [])
    if not rows:
        return {"provider": "rule", "text": "아직 지수×시간대 표본이 없습니다. 장중 진입이 쌓이면 분석됩니다.",
                "rows": []}
    lines = []
    for r in sorted(rows, key=lambda x: x["regime"]):
        lines.append(f"- 지수 {r['regime']} · {r['bucket']}시간대: 매매 {r['sells']}건 · "
                     f"승률 {r['win_rate']}% · 평균 {r['avg_ret']:+.2f}%")
    prompt = (
        "다음은 한국 주식 모의매매에서 '진입 시점 지수 등락률 × 진입 시간대'별 실제 성적입니다.\n"
        f"{chr(10).join(lines)}\n\n"
        "1) 어떤 지수 상태에서 어떤 시간대가 가장 강한지 / 가장 약한지 해석해주세요.\n"
        "2) '오전 개장 초반은 강세장에서 좋다', '하락장에선 오후 2시 이후 피하라' 같은 "
        "실전에 쓸 수 있는 매매 시간대 가이드를 3줄로 제안해주세요.\n"
        f"추가 질문: {question or '(없음)'}"
    )
    try:
        txt = _gemini_rest(prompt, "당신은 한국 주식 시간대 전략 분석가입니다.")
        if txt and not txt.startswith("(Gemini"):
            return {"provider": "gemini", "text": txt, "rows": rows}
    except Exception:
        pass
    # 규칙 폴백: 가장 좋은/나쁜 조합
    best = res.get("best", [])
    rule = "규칙 분석: 표본 있는 조합 중 승률 상위:\n"
    for b in best[:3]:
        rule += f"- 지수 {b['regime']} · {b['bucket']}: 승률 {b['win_rate']}%·{b['avg_ret']:+.2f}%\n"
    rule += "\n(표본이 더 쌓이면 AI(Gemini)가 상세 해석을 제공합니다)"
    return {"provider": "rule", "text": rule, "rows": rows}


def evaluate_holding(symbol, position=None, market_data=None):
    """★ 보유 종목 AI 평가 (수동 매수 포함) - 매도/보유/평가 의견
    - 키 있으면 Gemini: 현재 수익률/최고수익/보유기간으로 판단
    - 키 없으면 규칙: 트레일링스탑/하드손절/추세 기반 평가
    반환: {"verdict": "보유"|"수익청산"|"손절", "reason": str, "provider": "gemini"|"rule"}
    """
    import ai_judge
    price = 0
    try:
        from paper_test import _get_price
        price = _get_price(symbol) or 0
    except Exception:
        pass
    if price <= 0:
        return {"verdict": "평가불가", "reason": "가격 조회 실패", "provider": "rule"}
    pos = position or {}
    entry = pos.get("entry_price") or price
    highest = pos.get("highest_return") or 0
    hold_min = pos.get("holding_minutes") or 0
    ret = (price - entry) / entry * 100 if entry else 0
    md = market_data or {"price": price, "현재가": price,
                         "전일고가": entry * 1.02, "전일저가": entry * 0.98,
                         "전일종가": entry, "체결강도": 100,
                         "최근1분거래대금": price * 100000, "최근3분거래대금": price * 300000,
                         "저가": price * 0.99, "고점갱신": False,
                         "거래대금동시증가": False, "중심선아래약세": False}
    try:
        decision, reason = ai_judge.evaluate_sell(
            symbol, md, {"entry_price": entry, "highest_return": highest,
                         "lowest_return": pos.get("lowest_return") or 0,
                         "holding_minutes": hold_min})
        prov = "gemini" if reason.startswith("[AI]") else "rule"
        return {"verdict": decision, "reason": reason[:120], "provider": prov,
                "ret": round(ret, 2), "price": price}
    except Exception as e:
        return {"verdict": "평가불가", "reason": str(e)[:80], "provider": "rule"}


def _tech_profile(symbol, price, entry=None, bars=None):
    """★ 기술적 위치 프로필 (로컬 일봉으로 계산 - API 호출 없음)
    - MA5/20/60, RSI14, 최근 20·60일 고/저(레인지), 현재가 레인지 위치%
    - 적정가 라벨(밴드 기준), 매수 위치 평가(평단가 위치), 매도 제안(목표가/손절가)
    반환: dict / None(데이터 부족)
    """
    if bars is None:
        try:
            bars = db.get_stock_daily(symbol, max_days=120)
        except Exception:
            bars = []
    closes = [b.get("close") or 0 for b in bars]
    closes = [c for c in closes if c > 0]
    if len(closes) < 20:
        return None
    price = price or closes[-1]
    entry = entry or 0

    def _ma(n):
        if len(closes) < n:
            return None
        return sum(closes[-n:]) / n

    ma5, ma20, ma60 = _ma(5), _ma(20), _ma(60)
    # RSI14 (Wilder 단순 근사)
    rsi = None
    if len(closes) >= 15:
        gains = losses = 0.0
        for i in range(len(closes) - 14, len(closes)):
            ch = closes[i] - closes[i - 1]
            if ch >= 0:
                gains += ch
            else:
                losses += -ch
        if gains + losses > 0:
            rsi = round(gains / (gains + losses) * 100, 1)
    hi20 = max(closes[-20:])
    lo20 = min(closes[-20:])
    hi60 = max(closes[-60:]) if len(closes) >= 60 else hi20
    lo60 = min(closes[-60:]) if len(closes) >= 60 else lo20
    rng20 = (hi20 - lo20) or 1
    rng60 = (hi60 - lo60) or 1
    pos20 = round((price - lo20) / rng20 * 100, 1)      # 현재가가 20일 레인지의 어디(0~100%)
    pos60 = round((price - lo60) / rng60 * 100, 1)
    # 적정가 라벨 (밴드 + RSI)
    if rsi is not None and rsi >= 75 and pos20 >= 85:
        fair = "고평가(과열)"
        fair_note = f"RSI {rsi} · 20일 고점 부근(레인지 {pos20}%)"
    elif rsi is not None and rsi <= 30 and pos20 <= 15:
        fair = "저평가(침체)"
        fair_note = f"RSI {rsi} · 20일 저점 부근(레인지 {pos20}%)"
    elif ma20 and price >= ma20 * 1.05 and pos20 >= 70:
        fair = "다소 고평가"
        fair_note = f"20일선 대비 +{(price / ma20 - 1) * 100:.1f}% · 레인지 {pos20}%"
    elif ma20 and price <= ma20 * 0.95 and pos20 <= 30:
        fair = "다소 저평가"
        fair_note = f"20일선 대비 {(price / ma20 - 1) * 100:.1f}% · 레인지 {pos20}%"
    else:
        fair = "적정(중립)"
        fair_note = f"20일 레인지 {pos20}% · RSI {rsi if rsi is not None else '-'}"
    # 매수 위치 평가 (평단가가 레인지/MA 대비 어디서 샀는지)
    entry_pos = "?"
    entry_note = ""
    if entry > 0:
        ep20 = round((entry - lo20) / rng20 * 100, 1)
        if entry <= lo20:
            entry_pos, entry_note = "좋음", f"20일 저점({lo20:,.0f}) 아래에서 매수 - 바닥권 진입"
        elif ep20 <= 25:
            entry_pos, entry_note = "좋음", f"20일 저점 부근에서 매수 (레인지 {ep20}%)"
        elif ep20 >= 80:
            entry_pos, entry_note = "나쁨", f"20일 고점 부근에서 매수 (레인지 {ep20}%)"
        else:
            entry_pos, entry_note = "보통", f"20일 레인지 중간대 매수 (레인지 {ep20}%)"
        if ma20 and entry:
            if entry < ma20:
                entry_note += " · 20일선 아래 진입(저점매수)"
            else:
                entry_note += " · 20일선 위 진입"
    # 매도 제안: 목표가(저항) / 손절가(지지)
    target = hi20
    target_note = f"20일 고점 {hi20:,.0f}"
    stop = lo20
    # 하드손절(기본 -3%)과 지지선 중 더 낮은 쪽으로 보수 선택
    hard_stop = price * (1 - float(getattr(CFG, "HARD_STOP_LOSS_PCT", 3.0)) / 100)
    stop = min(stop, hard_stop)
    stop_note = f"20일 저점 {lo20:,.0f} · 하드손절 {hard_stop:,.0f}"
    return {
        "price": price, "ma5": ma5, "ma20": ma20, "ma60": ma60, "rsi": rsi,
        "hi20": hi20, "lo20": lo20, "hi60": hi60, "lo60": lo60,
        "pos20": pos20, "pos60": pos60,
        "fair": fair, "fair_note": fair_note,
        "entry_pos": entry_pos, "entry_note": entry_note,
        "target": round(target, 2), "target_note": target_note,
        "stop": round(stop, 2), "stop_note": stop_note,
    }


def build_sell_plan(symbol, entry_price, qty=0, name=None, price=None, bars=None):
    """★ 매수 시점 매도 지침 생성 (사용자: '매수되면 평가해서 어느 선에 매도하겠다 지침을 만들고 유동적으로 매도')
    - 로컬 일봉(_tech_profile)으로 목표가(저항)/손절가(지지) 계산
    - Gemini 키 있으면 그 위에 AI가 매도 지침 문구 생성 (몇 %에서 익절/손절, 보유 전략)
    - 키 없으면 규칙 지침 (목표가 도달 시 트레일링, 손절가 무조건 손절)
    반환: {"target_price", "stop_price", "target_pct", "stop_pct", "plan", "provider", "tech"}
    """
    if price is None:
        try:
            from paper_test import _get_price
            price = _get_price(symbol) or 0
        except Exception:
            price = 0
    tech = _tech_profile(symbol, price if price else entry_price, entry=entry_price, bars=bars)
    if not tech:
        # 데이터 부족 → 최소한 하드손절 기준만
        sl = float(getattr(CFG, "HARD_STOP_LOSS_PCT", 3.0))
        stop = entry_price * (1 - sl / 100)
        target = entry_price * 1.05
        return {"target_price": round(target, 2), "stop_price": round(stop, 2),
                "target_pct": 5.0, "stop_pct": -sl, "plan": f"데이터 부족 - 손절가 {stop:,.0f}(-{sl:.1f}%)",
                "provider": "rule", "tech": tech}
    target = tech["target"]
    stop = tech["stop"]
    # ★ 보정: 손절가는 반드시 진입가 아래, 목표가는 반드시 진입가 위
    #   (상승 중 매수면 20일 저점이 진입가보다 높을 수 있음 - 매수 즉시 이탈 방지)
    hard_sl = float(getattr(CFG, "HARD_STOP_LOSS_PCT", 3.0))
    min_tp = float(getattr(CFG, "MIN_TAKE_PROFIT_PCT", 0.5))
    if entry_price > 0:
        if stop >= entry_price:
            stop = entry_price * (1 - hard_sl / 100)
        # ★ 손절가 하한 보정 (2026-08-27): 로컬 일봉이 낡아 실시간가와 크게 다르면
        #   손절가가 -90%대로 계산돼 지침 손절이 무력화됨 (예: 일봉 4.6만 vs 실시간 173만)
        #   → 진입가 대비 하드손절의 2배(-6%)보다 아래면 데이터 불일치로 보고 하드손절선으로
        if stop < entry_price * (1 - 2 * hard_sl / 100):
            stop = entry_price * (1 - hard_sl / 100)
        if target <= entry_price:
            target = entry_price * (1 + max(min_tp, 1.0) / 100)
        # ★ 목표가 상한 보정: 같은 이유로 +100% 넘는 목표가는 비현실 - +15%로 캡
        if target > entry_price * 2.0:
            target = entry_price * 1.15
    target_pct = (target - entry_price) / entry_price * 100 if entry_price else 0
    stop_pct = (stop - entry_price) / entry_price * 100 if entry_price else 0
    fair = tech.get("fair", "적정(중립)")
    plan = (f"목표가 {target:,.0f}원(+{target_pct:.1f}%) 도달 시 트레일링스탑 시작, "
            f"손절가 {stop:,.0f}원({stop_pct:.1f}%) 이탈 시 무조건 손절 "
            f"· 매수 위치 {tech.get('entry_pos', '?')} · 적정가 {fair}")
    provider = "rule"
    # ★ AI(Gemini) 지침: 키 있으면 매도 지침을 자연어로 생성 (한 번만 호출 - 가벼움)
    try:
        if CFG.AI_PROVIDER == "gemini" and (CFG.GEMINI_API_KEY or os.getenv("GEMINI_API_KEY")):
            prompt = (
                f"신규 매수한 종목의 매도 지침을 한 문장으로 작성하세요.\n"
                f"종목: {name or symbol} · 진입가 {entry_price:,.0f}원\n"
                f"기술적 위치: 20일 고점 {tech.get('hi20', 0):,.0f} / 저점 {tech.get('lo20', 0):,.0f} "
                f"· RSI {tech.get('rsi', '-')} · 레인지 위치 {tech.get('pos20', '-')}%\n"
                f"AI가 자동 매도 판단에 참고할 지침: 목표 수익률(몇 %에 익절 고려), "
                f"손절 기준(몇 % 손실 시 무조건 손절), 보유 기간(며칠까지), "
                f"이익 실현 후 후속 전략(트레일링 여부)을 구체적으로."
            )
            out = _gemini_rest(prompt)
            if out and "Error" not in out and len(out.strip()) > 10:
                plan = out.strip()[:150]
                provider = "gemini"
    except Exception:
        pass
    return {"target_price": round(target, 2), "stop_price": round(stop, 2),
            "target_pct": round(target_pct, 1), "stop_pct": round(stop_pct, 1),
            "plan": plan, "provider": provider, "tech": tech}


def evaluate_holding_adv(symbol, position=None):
    """★ 보유 종목 종합 평가 (웹 대시보드/UI용) - 적정가·매수 위치·매도 제안 포함
    반환: {symbol, name, price, entry_price, qty, ret, verdict, reason, provider,
           tech: {...} or None}
    """
    price = 0
    try:
        from paper_test import _get_price
        price = _get_price(symbol) or 0
    except Exception:
        pass
    pos = position or {}
    entry = pos.get("entry_price") or 0
    qty = pos.get("qty") or 0
    ret = (price - entry) / entry * 100 if (price and entry) else 0
    # ★ 매수 시점 매도 지침 병합 (호출자가 안 넘겼으면 paper_positions에서 같은 종목 검색)
    if not pos.get("sell_plan"):
        try:
            for _p in db.get_paper_open():
                if _p.get("symbol") == symbol:
                    pos["sell_plan"] = _p.get("sell_plan") or ""
                    pos["plan_provider"] = _p.get("plan_provider") or ""
                    pos["target_price"] = _p.get("target_price") or 0
                    pos["stop_price"] = _p.get("stop_price") or 0
                    break
        except Exception:
            pass
    ev = evaluate_holding(symbol, pos)
    tech = _tech_profile(symbol, price if price else None, entry=entry)
    # 매수 시점 지침 목표/손절이 없으면 기술지표(20일 고저)로 보완
    tgt = pos.get("target_price") or 0
    stp = pos.get("stop_price") or 0
    if not tgt and tech:
        tgt = tech.get("target") or 0
    if not stp and tech:
        stp = tech.get("stop") or 0
    return {
        "symbol": symbol,
        "name": (pos.get("name") or db.get_symbol_name(symbol) or symbol),
        "price": price, "entry_price": entry, "qty": qty,
        "ret": round(ret, 2),
        "verdict": ev.get("verdict", "평가불가"),
        "reason": ev.get("reason", ""),
        "provider": ev.get("provider", "rule"),
        "target_price": tgt, "stop_price": stp,
        "sell_plan": pos.get("sell_plan") or "",
        "plan_provider": pos.get("plan_provider") or "rule",
        "tech": tech,
    }
