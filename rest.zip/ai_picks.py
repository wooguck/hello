# -*- coding: utf-8 -*-
"""
🎲 AI 데일리 픽 (ai_picks.py) - 하루 3종목 AI 추천 매수
========================================================
"조건식 신호 기다리는 매수 말고, AI가 매일 3종목을 골라서 사보는" 실험 채널.

동작:
  1) 로컬 일봉으로 전 종목 스코어링 (추세/거래량/눌림 등 - API 호출 없음)
  2) 상위 후보 30종목 → AI(Gemini 키 있으면)가 3개 선정 + 이유
     · 키 없으면: 상위 후보에서 가중 무작위 3개 (무작위성 요청 반영)
  3) 기존 모의매매와 같은 경로로 진입:
     · cond_key='AI_PICK' 포지션 등록 → 매도 지침(build_sell_plan) 생성
     · 이후 기존 매도 루프(AI 매도/하드손절/트레일링)가 자동 관리
  4) 하루 3종목 제한 (이미 오늘 3개 찍었으면 스킵) · 보유 중복 방지
  5) 성과는 trade_stats.py에서 'AI_PICK' 전략으로 따로 집계됨
     → 조건식 매수 vs AI 픽 매수 성적 비교 가능!

실행:
  python ai_picks.py            # 오늘의 3종목 선정 + 모의 매수 (장중이면 실제 모의주문)
  python ai_picks.py --dry      # 선정만 하고 매수 안 함 (미리보기)
  python ai_picks.py --n 3      # 종목 수 변경
매일 자동: 앱/collect_data --watch가 돌 때 장 시작 후 1회 호출하거나,
           작업 스케줄러로 09:05에 python ai_picks.py 실행 등록
"""
import argparse
import json
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import random
import sys
from datetime import datetime

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db
from config import CFG

PICKS_PER_DAY = _cfg_env_int("AI_PICKS_PER_DAY", 3)
STATE_PATH = os.path.join("strategy", "ai_picks_state.json")


def _log(msg):
    print(msg, flush=True)


def _today():
    return db.now_kst().strftime("%Y-%m-%d")


def _picked_today():
    try:
        with open(STATE_PATH, encoding="utf-8") as f:
            st = json.load(f)
        if st.get("date") == _today():
            return st.get("picked", [])
    except Exception:
        pass
    return []


def _save_picked(picked):
    os.makedirs("strategy", exist_ok=True)
    with open(STATE_PATH, "w", encoding="utf-8") as f:
        json.dump({"date": _today(), "picked": picked}, f, ensure_ascii=False, indent=1)


def score_universe(min_bars=60, max_price=200000, min_price=1000,
                   min_amount=300_000_000):
    """로컬 일봉으로 전 종목 스코어링 → 후보 목록
    점수: 정배열 + 20일선 위 + 거래대금 증가 + 단기 눌림 후 반등 (과열 제외)
    """
    from validation import _load_bars
    import sqlite3
    stocks_dir = os.path.join(db.DATA_DIR, "stocks")
    if not os.path.isdir(stocks_dir):
        return []
    names = {}
    try:
        for u in db.get_universe():
            names[u.get("symbol")] = u.get("name") or ""
    except Exception:
        pass
    cands = []
    files = [f[:-3] for f in os.listdir(stocks_dir) if f.endswith(".db")]
    for sym in files:
        bars = _load_bars(sym, max_days=80)
        if len(bars) < min_bars:
            continue
        c = [b["close"] for b in bars]
        v = [b["volume"] for b in bars]
        px = c[-1]
        if not (min_price <= px <= max_price):
            continue
        amt = px * (sum(v[-5:]) / 5)
        if amt < min_amount:          # 유동성 필터 (5일 평균 거래대금 3억+)
            continue
        ma5 = sum(c[-5:]) / 5
        ma20 = sum(c[-20:]) / 20
        ma60 = sum(c[-60:]) / 60
        chg1 = (c[-1] / c[-2] - 1) * 100 if c[-2] else 0
        chg5 = (c[-1] / c[-6] - 1) * 100 if len(c) > 5 and c[-6] else 0
        chg20 = (c[-1] / c[-21] - 1) * 100 if len(c) > 20 and c[-21] else 0
        volr = (sum(v[-3:]) / 3) / (sum(v[-20:]) / 20 + 1)
        score = 0.0
        if ma5 > ma20 > ma60:
            score += 3            # 정배열 (추세)
        if px > ma20:
            score += 2            # 20일선 위
        if 0 < chg20 <= 25:
            score += 2            # 한 달 완만한 상승 (과열 제외)
        if -3 <= chg5 <= 1:
            score += 2            # 단기 눌림 (추격매수 방지)
        if volr > 1.2:
            score += 1            # 거래 증가
        if chg1 > 8:
            score -= 3            # 당일 급등 추격 방지
        if score >= 5:
            cands.append({"symbol": sym, "name": names.get(sym, ""), "price": px,
                          "score": score, "chg5": round(chg5, 1), "chg20": round(chg20, 1),
                          "volr": round(volr, 2), "amt_5d": int(amt)})
    cands.sort(key=lambda x: -x["score"])
    return cands


def ai_select(cands, n=3):
    """AI(Gemini)가 후보 중 n개 선정 + 이유. 키 없으면 가중 무작위."""
    pool = cands[:30]
    if not pool:
        return []
    # Gemini 시도
    try:
        from ai_judge import call_llm, AI_ENABLED, GEMINI_API_KEY, OPENAI_API_KEY
        if AI_ENABLED and (GEMINI_API_KEY or OPENAI_API_KEY):
            lines = [f"{i+1}. {c['symbol']} {c['name']} 가격{c['price']:,.0f} "
                     f"5일{c['chg5']:+}% 20일{c['chg20']:+}% 거래배율{c['volr']}"
                     for i, c in enumerate(pool)]
            prompt = (f"다음은 오늘의 매수 후보 {len(pool)}종목입니다 (추세/눌림/유동성 필터 통과).\n"
                      + "\n".join(lines)
                      + f"\n\n이 중 서로 다른 업종/성격으로 분산되도록 {n}종목을 고르고, "
                      f"각각 한 줄 이유를 쓰세요.\n"
                      f"형식(꼭 지켜): 종목코드|이유\n예: 005930|반도체 대장주 눌림 후 반등 초입")
            res = call_llm("당신은 한국 주식 스윙 트레이더입니다. 추격매수를 피하고 분산을 중시합니다.", prompt)
            if res:
                picks = []
                by_sym = {c["symbol"]: c for c in pool}
                for ln in res.splitlines():
                    if "|" not in ln:
                        continue
                    sym = "".join(ch for ch in ln.split("|")[0] if ch.isdigit())[-6:]
                    if sym in by_sym and sym not in [p["symbol"] for p in picks]:
                        picks.append({**by_sym[sym], "reason": ln.split("|", 1)[1].strip()[:80],
                                      "provider": "AI"})
                    if len(picks) >= n:
                        break
                if picks:
                    return picks
    except Exception as e:
        _log(f"(AI 선정 실패 - 무작위 폴백: {str(e)[:60]})")
    # 폴백: 점수 가중 무작위 (사용자 요청의 '무작위 추천' 성격)
    weights = [c["score"] for c in pool]
    picks = []
    p2, w2 = list(pool), list(weights)
    while p2 and len(picks) < n:
        i = random.choices(range(len(p2)), weights=w2, k=1)[0]
        c = p2.pop(i)
        w2.pop(i)
        picks.append({**c, "reason": f"점수 {c['score']}점 (정배열/눌림/거래) 가중 무작위 선정",
                      "provider": "random"})
    return picks


def buy_picks(picks, dry=False):
    """선정 종목을 기존 모의매매 경로로 매수 (cond_key=AI_PICK)"""
    import paper_test
    held = {p["symbol"] for p in db.get_paper_open()}
    in_market = paper_test._in_market_hours()
    bought = []
    for c in picks:
        sym = c["symbol"]
        if sym in held:
            _log(f"  ⏭ {sym} {c['name']}: 이미 보유 - 스킵")
            continue
        price = paper_test._get_price(sym) or c["price"]
        if price <= 0:
            _log(f"  ⏭ {sym}: 가격 조회 실패 - 스킵")
            continue
        budget = _cfg_env_float("AI_PICKS_BUDGET", 0) or paper_test.buy_budget()  # ★ 기본: 공용 예산(비율/금액 - 5채널 통일)
        qty = int(budget / price)
        if qty < 1:
            _log(f"  ⏭ {sym}: 가격 {price:,.0f} > 종목당 예산 {budget:,.0f} - 스킵")
            continue
        if dry:
            _log(f"  🔍 [미리보기] {sym} {c['name']} {qty}주 @{price:,.0f} - {c['reason']}")
            continue
        order = None
        if paper_test.REAL_PAPER_ORDER and in_market and not CFG.DRY_RUN:
            order = paper_test._place_real_order(sym, "buy", qty, price)
            if order and order.get("status") == "error":
                _log(f"  ⚠️ {sym} 주문 실패: {order.get('message', '')[:50]}")
                continue
        plan = None
        try:
            from ai_consult import build_sell_plan
            plan = build_sell_plan(sym, price, qty)
        except Exception:
            pass
        # ★ 진입 슬리피지 (조건식 경로와 동일 - 채널 비교 공정성, 2026-08-27)
        entry_p = price if (order and not CFG.DRY_RUN) else paper_test.entry_slip(price)
        db.open_paper_position(
            "AI_PICK", f"[AI픽{c['provider']}] {c['reason'][:60]}", sym, entry_p, qty,
            order_kind=("real" if order else "virtual"),
            target_price=(plan or {}).get("target_price"),
            stop_price=(plan or {}).get("stop_price"),
            sell_plan=(plan or {}).get("plan"),
            plan_provider=(plan or {}).get("provider", "rule"))
        bought.append(sym)
        _log(f"  ✅ 매수 {sym} {c['name']} {qty}주 @{price:,.0f}"
             + (" (실제모의주문)" if order else " (가상기록)")
             + f"\n     이유: {c['reason']}")
        if plan:
            _log(f"     📌 지침: 목표 {plan['target_price']:,.0f} · 손절 {plan['stop_price']:,.0f}")
    return bought


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=PICKS_PER_DAY)
    ap.add_argument("--dry", action="store_true", help="선정만 (매수 안 함)")
    ap.add_argument("--force", action="store_true", help="오늘 이미 픽했어도 다시")
    args = ap.parse_args()

    print("=" * 60)
    print(f"🎲 AI 데일리 픽 - 하루 {args.n}종목 추천 매수  ({_today()})")
    print("=" * 60)

    prev = _picked_today()
    if prev and not args.force and not args.dry:
        _log(f"오늘 이미 {len(prev)}종목 픽 완료: {prev} (--force로 재실행 가능)")
        return

    _log("📊 전 종목 스코어링 중 (로컬 일봉)...")
    cands = score_universe()
    _log(f"   후보 {len(cands)}종목 (필터: 정배열/눌림/유동성/과열제외)")
    if not cands:
        _log("⛔ 후보 없음 - 데이터 수집 상태 확인 필요")
        return

    picks = ai_select(cands, n=args.n)
    _log(f"\n🎯 오늘의 픽 ({picks[0]['provider'] if picks else '-'} 선정):")
    for c in picks:
        _log(f"   {c['symbol']} {c['name']} @{c['price']:,.0f} (점수 {c['score']}) - {c['reason']}")

    _log("")
    bought = buy_picks(picks, dry=args.dry)
    if not args.dry and bought:
        _save_picked(_picked_today() + bought)
        _log(f"\n✅ 완료: {len(bought)}종목 매수 - 이후 매도는 기존 AI/하드손절 루프가 자동 관리")
        _log("   성과 확인: python trade_stats.py (전략 'AI_PICK'으로 따로 집계)")


if __name__ == "__main__":
    main()
