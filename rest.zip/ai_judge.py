"""AI 매수/매도 보조 시스템 - 사용자 프롬프트 기반

기능:
1. prompts/buy_prompt.txt, prompts/sell_prompt.txt 를 직접 수정 가능 (매수/매도 조건)
2. 키움 API 데이터로 중심선, 지지선, 전일고저, 체결강도, 1분/3분 거래대금 계산
3. AI_PROVIDER=rule : 무료 룰 기반 (프롬프트 로직을 코드로 구현)
   AI_PROVIDER=openai : GPT (OPENAI_API_KEY 필요)
   AI_PROVIDER=gemini : Gemini 무료 티어 (GEMINI_API_KEY 필요)
"""
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import logging
import random
from datetime import datetime
from typing import Dict, Tuple

import db
from config import CFG

log = logging.getLogger("ai_judge")

# ★ AI 실패 쿨다운 상태 (429/503 등 - 반복 호출·로그 도배 방지)
#   call_llm/_ai_cooldown_set이 실패 코드에 따라 쿨다운을 걸고,
#   쿨다운 중에는 AI 호출을 건너뛰고 조용히 규칙 폴백 (로그는 진입 시 1번만)
_AI_COOLDOWN = {"until": 0.0, "last_err": "", "logged": False}


def _ai_cooldown_remaining() -> float:
    """AI 호출 쿨다운 남은 초 (0이면 사용 가능)"""
    import time as _t
    left = _AI_COOLDOWN.get("until", 0.0) - _t.time()
    return max(0.0, left)


def _ai_cooldown_set(err: str, code: int = 0):
    """실패 원인에 따라 쿨다운 설정 (이미 더 긴 쿨다운이 걸려 있으면 유지)
    429=할당량 초과(길게), 503=모델 과부하(짧게), 기타=중간
    """
    import time as _t
    now = _t.time()
    if _ai_cooldown_remaining() > 0:
        return  # 이미 쿨다운 중 - 유지
    if code == 429:
        sec = int(getattr(CFG, "AI_COOLDOWN_429_SEC", 600))
    elif code == 503:
        sec = int(getattr(CFG, "AI_COOLDOWN_503_SEC", 120))
    else:
        sec = int(getattr(CFG, "AI_COOLDOWN_OTHER_SEC", 60))
    _AI_COOLDOWN["until"] = now + sec
    _AI_COOLDOWN["last_err"] = err
    _AI_COOLDOWN["logged"] = False


def _ai_cooldown_take() -> bool:
    """쿨다운 진입 시 1번만 로그 → True (AI 호출 건너뜀)"""
    import time as _t
    left = _ai_cooldown_remaining()
    if left <= 0:
        return False
    if not _AI_COOLDOWN.get("logged"):
        _AI_COOLDOWN["logged"] = True
        log.warning(f"⏸ AI 호출 중단 {int(left)}초 (최근 실패: {_AI_COOLDOWN.get('last_err', '')[:60]}) "
                    f"→ 규칙 폴백 사용 중 (쿨다운 후 자동 복귀)")
    return True

BUY_PROMPT_PATH = "prompts/buy_prompt.txt"
SELL_PROMPT_PATH = "prompts/sell_prompt.txt"

PROVIDER = CFG.AI_PROVIDER
AI_ENABLED = CFG.AI_JUDGE_ENABLED
AI_MODEL = CFG.AI_MODEL
OPENAI_API_KEY = CFG.OPENAI_API_KEY
GEMINI_API_KEY = CFG.GEMINI_API_KEY


def load_prompt(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return ""


def save_prompt(path: str, content: str) -> bool:
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return True
    except Exception as e:
        log.warning(f"프롬프트 저장 실패 {path}: {e}")
        return False


def compute_pivot_levels(prev_high: float, prev_low: float, prev_close: float) -> Dict[str, float]:
    """중심선(피봇) = (H+L+C)/3, 1차지지 = 2P-H, 2차지지 = P-(H-L)"""
    if not prev_high or not prev_low or not prev_close:
        return {}
    pivot = (prev_high + prev_low + prev_close) / 3
    return {
        "중심선": pivot,
        "1차지지선": 2 * pivot - prev_high,
        "2차지지선": pivot - (prev_high - prev_low),
        "1차저항선": 2 * pivot - prev_low,
        "전일고가": prev_high,
        "전일저가": prev_low,
        "전일종가": prev_close,
    }


def _to_float(v):
    try:
        s = str(v).replace(",", "").replace("+", "").replace("-", "").strip()
        return float(s) if s else 0.0
    except Exception:
        return 0.0


# ── 실측 장중 지표 (분봉 데이터 기반 - 랜덤 추정 금지) ──────────────
# 분봉이 없으면 None → 보수적 기본값(False/0) 사용 (거짓 신호 방지)
_intraday_cache = {"t": 0.0, "data": {}}


def _intraday_features(symbol: str) -> dict:
    """
    분봉(네이버, 최근 7거래일)으로 실제 장중 지표 계산
    반환: {고점갱신, 저점하락추세, 고저점하락추세, 반등, 체결강도추세,
           최근1분거래대금, 최근3분거래대금, 최근3분평균, 거래대금동시증가, 거래대금증가}
    데이터 부족 시 None (보수 처리)
    """
    import time as _t
    try:
        now = _t.time()
        if now - _intraday_cache["t"] > 45:  # 45초 캐시 (사이클 내 중복 호출 최적화)
            _intraday_cache["t"] = now
            _intraday_cache["data"] = {}
        if symbol in _intraday_cache["data"]:
            return _intraday_cache["data"][symbol]

        bars = db.get_minute_bars(symbol, days=2)
        if not bars or len(bars) < 3:
            _intraday_cache["data"][symbol] = None
            return None
        prices = [b["price"] for b in bars]
        vols = [b.get("volume") or 0 for b in bars]
        cur = prices[-1]
        today = [b for b in bars if b["bar_time"][:10] == bars[-1]["bar_time"][:10]]
        if len(today) < 3:
            _intraday_cache["data"][symbol] = None
            return None
        day_prices = [b["price"] for b in today]
        day_low = min(day_prices)
        day_high = max(day_prices)
        prev = [b for b in bars if b["bar_time"][:10] != bars[-1]["bar_time"][:10]]
        prev_high = max((b["price"] for b in prev), default=day_high)

        # 최근 1분/3분 거래대금 (분봉 거래량 × 가격)
        vol_1m = vols[-1] if len(vols) >= 1 else 0
        vol_3m = sum(vols[-3:]) if len(vols) >= 3 else vol_1m
        amount_1m = vol_1m * cur
        amount_3m = vol_3m * cur

        # 체결강도추세: 최근 3분봉 거래량 추이 (v1 < v2 < v3 → 상승)
        v3 = vols[-3:] if len(vols) >= 3 else vols
        cheg_trend = list(v3)

        # 저점하락추세: 최근 10분 저점이 당일 저점보다 낮고, 장 초반 저점 대비 하락
        low_now = min(day_prices[-10:]) if len(day_prices) >= 10 else day_low
        morning_low = min(day_prices[:10]) if len(day_prices) >= 10 else day_low
        low_decline = low_now <= day_low * 1.001 and day_low < morning_low * 0.998

        # 고점하락추세: 최근 고점이 장 초반 고점보다 낮음
        high_now = max(day_prices[-10:]) if len(day_prices) >= 10 else day_high
        high_decline = high_now < day_high * 0.998

        feat = {
            "고점갱신": cur >= prev_high * 0.998,          # 최근 2일 고가 근처/돌파
            "저점하락추세": low_decline,
            "고저점하락추세": low_decline and high_decline,
            "반등": cur > day_low * 1.002,                # 당일 저가 대비 상승 중
            "체결강도추세": cheg_trend,
            "최근1분거래대금": amount_1m,
            "최근3분거래대금": amount_3m,
            "최근3분평균": amount_3m / 3,
            "거래대금증가": amount_1m > (amount_3m / 3),
            "거래대금동시증가": amount_1m > (amount_3m / 3) and len(v3) >= 3 and v3[-1] > v3[0],
            "당일고가": day_high,
            "당일저가": day_low,
        }
        _intraday_cache["data"][symbol] = feat
        return feat
    except Exception:
        _intraday_cache["data"][symbol] = None
        return None


def enrich_market_data(raw_data: dict, client_obj=None, symbol=None) -> dict:
    """프롬프트 판단에 필요한 모든 필드 계산
    ★ 랜덤 추정 제거: 장중 지표는 분봉 실측, 없으면 보수적 기본값(False/0)
    """
    data = dict(raw_data)
    price = _to_float(data.get("price", data.get("cur_prc", 0)))
    data["현재가"] = price
    data["price"] = price
    if symbol is None:
        symbol = data.get("symbol", "")

    raw = data.get("raw", {})
    if isinstance(raw, dict):
        prev_high = raw.get("250hgst") or raw.get("high_pric") or raw.get("oyr_hgst") or 0
        prev_low = raw.get("250lwst") or raw.get("low_pric") or raw.get("oyr_lwst") or 0
        prev_close = raw.get("base_pric") or raw.get("upl_pric") or 0
    else:
        prev_high = prev_low = prev_close = 0

    prev_high = _to_float(data.get("전일고가", prev_high))
    prev_low = _to_float(data.get("전일저가", prev_low))
    prev_close = _to_float(data.get("전일종가", prev_close))

    if prev_high == 0:
        prev_high = price * 1.03
    if prev_low == 0:
        prev_low = price * 0.97
    if prev_close == 0:
        prev_close = price * 0.99

    data["전일고가"], data["전일저가"], data["전일종가"] = prev_high, prev_low, prev_close
    data.update(compute_pivot_levels(prev_high, prev_low, prev_close))

    low_price = _to_float(data.get("저가", data.get("low_pric", prev_low)))
    data["저가"] = low_price
    data["저가대비상승"] = price > low_price

    # ★ 분봉 실측 지표 (없으면 보수적 기본값 - 랜덤 금지)
    feat = _intraday_features(symbol) if symbol else None
    data["고점갱신"] = data.get("고점갱신", bool(feat and feat["고점갱신"]))
    data["저점하락추세"] = data.get("저점하락추세", bool(feat and feat["저점하락추세"]))
    data["고저점하락추세"] = data.get("고저점하락추세", bool(feat and feat["고저점하락추세"]))
    data["반등"] = data.get("반등", bool(feat and feat["반등"]))
    data["당일고가"] = feat.get("당일고가", 0) if feat else 0
    data["당일저가"] = feat.get("당일저가", 0) if feat else 0

    chegyul = _to_float(data.get("체결강도", data.get("chegyul", 100)))
    if chegyul == 0:
        chegyul = 100  # 중립값 (랜덤 아님)
    data["체결강도"] = chegyul
    # 체결강도추세: API 데이터 있으면 그대로, 없으면 분봉 거래량 추이, 없으면 중립
    cheg_trend_input = data.get("체결강도추세")
    if cheg_trend_input and isinstance(cheg_trend_input, (list, tuple)) and len(cheg_trend_input) >= 2:
        data["체결강도추세"] = [float(x) for x in cheg_trend_input]
    elif feat and feat.get("체결강도추세"):
        data["체결강도추세"] = [float(x) for x in feat["체결강도추세"]]
    else:
        data["체결강도추세"] = [chegyul, chegyul, chegyul]  # 중립

    amount_1m = _to_float(data.get("최근1분거래대금", 0))
    amount_3m = _to_float(data.get("최근3분거래대금", 0))
    if amount_3m <= 0 and feat:
        amount_1m = feat["최근1분거래대금"]
        amount_3m = feat["최근3분거래대금"]
    data["최근1분거래대금"] = amount_1m
    data["최근3분거래대금"] = amount_3m
    data["최근3분평균"] = amount_3m / 3 if amount_3m else 0

    avg_3m = data["최근3분평균"]
    data["거래대금증가"] = avg_3m > 0 and amount_1m > avg_3m
    if "거래대금동시증가" not in data or data.get("거래대금동시증가") is None:
        data["거래대금동시증가"] = bool(feat and feat["거래대금동시증가"])

    pivot = data.get("중심선", price)
    data["중심선아래약세"] = price < pivot  # 실측 (랜덤 제거)
    data["symbol"] = symbol
    return data


# ── ★ 자동 전략(데이터 기반) 필터 - rule 모드 실전 반영 ──────────
# strategy_auto가 생성해 prompts에 넣은 전략이 실제 매수에도 적용됩니다.
# strategy/auto_strategy.json 의 rule_id 조건을 일봉 데이터로 실측 체크.

_auto_rule_cache = {"t": 0.0, "id": None}


def _load_auto_rule_id():
    """현재 적용된 자동 전략 rule_id (없으면 None) - 30초 캐시"""
    import time as _t
    try:
        if _t.time() - _auto_rule_cache["t"] > 30:
            _auto_rule_cache["t"] = _t.time()
            _auto_rule_cache["id"] = None
            with open(os.path.join("strategy", "auto_strategy.json"), encoding="utf-8") as f:
                import json as _json
                st = _json.load(f)
                rid = st.get("rule_id")
                if rid and rid.startswith("r_"):
                    _auto_rule_cache["id"] = rid
    except Exception:
        pass
    return _auto_rule_cache["id"]


# 자동 전략 체크 결과 캐시: (symbol, rule_id, 날짜) → (ok, reason) - 당일 재사용 (성능)
_auto_check_cache = {}


def _auto_check_cached(rule_id, symbol, cur_price):
    """check_auto_rule 캐시 (당일 기준 - 자동 전략은 일봉 기반이라 장중 불변)"""
    import db as _db
    today = _db.now_kst().strftime("%Y-%m-%d")
    key = (symbol, rule_id, today)
    if key in _auto_check_cache:
        return _auto_check_cache[key]
    res = check_auto_rule(rule_id, symbol, cur_price)
    _auto_check_cache[key] = res
    return res


def check_auto_rule(rule_id: str, symbol: str, cur_price: float):
    """
    자동 전략 조건을 일봉(최근 40봉)으로 실측 체크
    반환: (None, 이유) = 데이터 부족(판단 불가 - 기존 기준 유지)
          (True, 이유)  = 조건 충족
          (False, 이유) = 조건 미충족 → 매수금지 (보수 원칙)
    """
    try:
        from strategy_auto import get_daily_series
    except Exception:
        return None, "자동전략 로드 불가"
    try:
        bars = get_daily_series(symbol, max_days=40)
    except Exception:
        bars = []
    if len(bars) < 26:
        return None, f"일봉 부족({len(bars)}/26) - 자동전략 미적용"
    # 오늘 봉: 현재가로 합성 (장중이라 오늘 일봉은 아직 백필 안 됨)
    last = bars[-1]
    bars = bars + [{"open": cur_price, "high": cur_price, "low": cur_price,
                    "close": cur_price, "volume": last.get("volume") or 0}]
    closes = [b["close"] for b in bars]
    highs = [b["high"] for b in bars]
    lows = [b["low"] for b in bars]
    vols = [b["volume"] or 0 for b in bars]
    n = len(closes)
    c = cur_price
    if closes[-6] <= 0 or closes[-21] <= 0:
        return None, "기준가 부족"
    ma5 = sum(closes[-5:]) / 5
    ma10 = sum(closes[-10:]) / 10
    ma20 = sum(closes[-20:]) / 20
    mom5 = c / closes[-6] - 1
    mom20 = c / closes[-21] - 1
    h20 = max(highs[-20:])
    l20 = min(lows[-20:])
    vbase = sum(vols[-21:-1]) / 20
    volr = vols[-1] / vbase if vbase > 0 else 0
    op = bars[-1]["open"] or c
    low_now = min(lows[-1], c)

    cond = {
        "r_mom_break": mom5 > 0.02 and c > ma20 and volr > 1.5,
        "r_high_break": (c / h20 if h20 else 0) >= 0.985,
        "r_ma_align": ma5 > ma10 > ma20 and c > ma5,
        "r_oversold_rebound": mom5 < -0.06 and c < ma20 * 0.97 and c >= low_now,
        "r_vol_surge_up": volr >= 2.0 and c > op and mom5 > 0,
        "r_pullback": mom20 > 0.05 and -0.03 < mom5 < 0,
        "r_momentum_strong": mom5 > 0.05 and c > ma20,
        "r_low_rebound": (c / l20 if l20 else 0) <= 1.02 and volr > 1.5,
    }.get(rule_id)

    if cond is None:
        return None, f"모르는 전략 {rule_id}"
    detail = (f"MA5 {ma5:,.0f}/MA10 {ma10:,.0f}/MA20 {ma20:,.0f} · "
              f"5일 {mom5*100:+.1f}% · 20일 {mom20*100:+.1f}% · "
              f"거래량 {volr:.1f}배")
    if cond:
        return True, f"자동전략 {rule_id} 충족 ({detail})"
    return False, f"자동전략 {rule_id} 미충족 ({detail})"


# ── 룰 기반 (무료, 프롬프트 로직 그대로) ──────────────

def evaluate_buy_rule_based(enriched: dict, score_threshold: int = 5) -> Tuple[bool, str, int]:
    score = 0
    reasons = []
    price = enriched.get("현재가", 0)
    pivot = enriched.get("중심선", 0)
    s1 = enriched.get("1차지지선", 0)
    s2 = enriched.get("2차지지선", 0)
    prev_high = enriched.get("전일고가", 0)
    prev_low = enriched.get("전일저가", 0)
    prev_close = enriched.get("전일종가", price)
    chegyul = enriched.get("체결강도", 0)
    amount_1m = enriched.get("최근1분거래대금", 0)
    amount_3m = enriched.get("최근3분거래대금", 0)
    avg_3m = enriched.get("최근3분평균", 0)

    # ── 매수 금지 조건 (하나라도 해당하면 즉시 거부) ──
    if s2 and price < s2:
        return False, f"매수금지: 현재가 {price} < 2차지지선 {s2:.0f}", -10
    if prev_low and price < prev_low:
        return False, f"매수금지: 현재가 {price} < 전일저가 {prev_low:.0f}", -10
    # ★ 고점 추격 금지 (2026-08-28 사용자: '너무 높은 구간 방지')
    day_low = enriched.get("당일저가") or enriched.get("저가") or 0
    if day_low and price > 0 and (price / day_low - 1) * 100 >= 7.0:
        return False, f"매수금지: 당일 저가 대비 +{(price/day_low-1)*100:.1f}% (고점 추격)", -10
    if prev_close and price > 0 and (price / prev_close - 1) * 100 >= 12.0:
        return False, f"매수금지: 전일 대비 +{(price/prev_close-1)*100:.1f}% (상한 부근 추격)", -10
    # ★ 하락 구간 회피 (사용자: '떨어질 구간 방지') - 당일 고점 대비 -3%+ 밀렸으면 반등 확인 전 금지
    day_high = enriched.get("당일고가") or enriched.get("고가") or 0
    if day_high and price > 0 and (1 - price / day_high) * 100 >= 3.0             and not enriched.get("반등"):
        return False, f"매수금지: 당일 고점 대비 -{(1-price/day_high)*100:.1f}% 하락 중 (칼날)", -10
    if enriched.get("중심선아래약세"):
        return False, "매수금지: 중심선 아래 지속 약세", -10
    if chegyul < 100 and pivot and price < pivot:
        return False, f"매수금지: 체결강도 {chegyul:.0f} < 100 약한 하락", -10
    if avg_3m and amount_1m < avg_3m * 0.5:
        return False, "매수금지: 1분거래대금 급감 (3분평균 50% 미만)", -5
    if avg_3m and amount_1m > avg_3m * 1.5 and amount_3m < avg_3m * 2.5:
        return False, "매수금지: 1분만 일시적 증가, 3분 뒷받침 없음", -5

    # ── ★ 하락 중 종목 매수 금지 (추가) - -3% 중인데 매수하는 문제 해결 ──
    # 전일대비 등락률: prev_close 대비 현재가
    if prev_close and prev_close > 0:
        chg = (price - prev_close) / prev_close * 100
        if chg < 0:
            return False, f"매수금지: 전일대비 {chg:.1f}% 하락 중 - 하락 종목 매수 안 함", -8
    # 등락률 정보가 있으면 그것도 체크 (raw 데이터)
    flu_rt = enriched.get("flu_rt")
    if flu_rt is not None:
        try:
            flu = float(str(flu_rt).replace("+", "").replace("%", ""))
            if flu < 0:
                return False, f"매수금지: 등락률 {flu:.1f}% 하락 중", -8
        except Exception:
            pass

    # ── ① 가격 위치 ──
    if pivot and price >= pivot:
        score += 1
        reasons.append(f"현재가 {price:,.0f} >= 중심선 {pivot:,.0f} (+1)")
    if s1 and price >= s1:
        score += 1
        reasons.append(f"1차지지선 {s1:,.0f} 위 유지 (+1)")
    if prev_high and price > prev_high:
        score += 2
        reasons.append(f"전일고가 {prev_high:,.0f} 돌파 매우 긍정 (+2)")

    # ── ② 흐름 판단 ──
    if enriched.get("저가대비상승"):
        score += 1
        reasons.append("저가 대비 상승 (+1)")
    if prev_close and abs(price - prev_close) / prev_close < 0.05:
        score += 1
        reasons.append("전일종가 대비 과도한 이탈 없음 (+1)")
    if enriched.get("고점갱신"):
        score += 2
        reasons.append("고점 지속 갱신 매우 긍정 (+2)")

    # ── ③ 수급 및 체결 ──
    if chegyul >= 100:
        score += 1
        reasons.append(f"체결강도 {chegyul:.0f} >= 100 (+1)")
    entry_chegyul = enriched.get("편입체결강도", chegyul - 10)
    if chegyul > entry_chegyul:
        score += 1
        reasons.append(f"체결강도 증가 {entry_chegyul:.0f}→{chegyul:.0f} (+1)")
    trend = enriched.get("체결강도추세", [])
    if len(trend) >= 3 and trend[0] < trend[1] < trend[2]:
        score += 2
        reasons.append("체결강도 지속 상승 매우 긍정 (+2)")

    if avg_3m and amount_1m > avg_3m:
        score += 1
        reasons.append(f"1분대금 {amount_1m/1e6:.0f}M > 3분평균 {avg_3m/1e6:.0f}M 단기 매수세 강화 (+1)")
    if enriched.get("거래대금동시증가"):
        score += 2
        reasons.append("1분·3분 동시 증가 강한 자금유입 (+2)")
    if amount_3m > 100_000_000:
        score += 1
        reasons.append(f"3분대금 {amount_3m/1e8:.1f}억 큼 - 기관자금 가능성 (+1)")
    if enriched.get("저가대비상승") and avg_3m and amount_1m > avg_3m:
        score += 2
        reasons.append("가격상승 + 거래대금증가 가장 강한 신호 (+2)")

    is_buy = score >= score_threshold
    reason_str = f"점수 {score} | " + ", ".join(reasons) if reasons else "조건 미충족"
    return is_buy, reason_str, score


def evaluate_sell_rule_based(enriched: dict, position: dict, trailing_stop_pct: float = 2.0) -> Tuple[str, str]:
    price = enriched.get("현재가", 0)
    entry_price = position.get("entry_price", price)
    chegyul = enriched.get("체결강도", 100)
    entry_chegyul = position.get("entry_chegyul", chegyul)
    amount_1m = enriched.get("최근1분거래대금", 0)
    amount_3m = enriched.get("최근3분거래대금", 0)
    avg_3m = enriched.get("최근3분평균", 0)
    s2 = enriched.get("2차지지선", 0)
    prev_low = enriched.get("전일저가", 0)
    pivot = enriched.get("중심선", 0)

    if entry_price <= 0:
        return "보유", "진입가 없음"

    current_return = (price - entry_price) / entry_price * 100
    highest_return = position.get("highest_return", current_return)
    highest_price = position.get("highest_price", price)
    if price > highest_price:
        highest_price = price
        highest_return = current_return
    drawdown_from_top = highest_return - current_return

    holding_minutes = position.get("holding_minutes", 0)

    # ── [차익 실현] 수익 > 0 ──
    if current_return > 0:
        # ★ 동적 트레일링 (사용자: '최고점에서 많이 빠진 다음에 매도됨' 수정)
        #   수익이 작을 때는 좁게, 클 때는 넓게 - 작은 수익을 다 반납하지 않게
        #   최고 +1%면 0.6%p만 빠져도 청산 / +3%면 1.2%p / +6% 이상이면 설정값(기본 2%p)
        eff_trail = trailing_stop_pct
        try:
            if highest_return < 2.0:
                eff_trail = min(trailing_stop_pct, max(0.6, highest_return * 0.6))
            elif highest_return < 5.0:
                eff_trail = min(trailing_stop_pct, max(1.0, highest_return * 0.4))
        except Exception:
            pass
        if drawdown_from_top >= eff_trail:
            return "수익청산", f"트레일링 스탑({eff_trail:.1f}%): 최고 {highest_return:.2f}% 대비 {drawdown_from_top:.2f}%p 하락"
        # ★ 이익보호선 (2026-08-28): 최고 +3%↑였다면 그 절반 이탈 시 무조건 청산
        #   (sell_guard 90초 감시와 같은 규칙 - AI/규칙 판단도 동일 철학 공유)
        try:
            _pft = _cfg_env_float("PROFIT_FLOOR_TRIGGER", 3.0)
            _pfk = _cfg_env_float("PROFIT_FLOOR_KEEP", 0.5)
            if _pft > 0 and highest_return >= _pft and current_return <= highest_return * _pfk:
                return "수익청산", (f"이익보호선: 최고 {highest_return:.1f}%의 "
                                  f"{_pfk*100:.0f}%선({highest_return*_pfk:.1f}%) 이탈")
        except Exception:
            pass
        if drawdown_from_top > 0.5 and chegyul < entry_chegyul and avg_3m and amount_1m < avg_3m:
            return "수익청산", "최고갱신 멈추고 하락 + 체결·거래대금 감소"
        if holding_minutes >= 60 and drawdown_from_top > 0.3:
            return "수익청산", f"1시간 보유, 최고갱신 없음, 현재 {current_return:.2f}%"

    # ── [즉시 손절] 수익 <= 0 ──
    if current_return <= 0:
        if s2 and price < s2:
            return "손절", f"2차지지선 {s2:.0f} 아래 하락, 수익률 {current_return:.2f}%"
        if prev_low and price < prev_low:
            return "손절", f"전일저가 {prev_low:.0f} 아래 하락"
        if pivot and price < pivot and amount_1m < avg_3m and amount_3m < avg_3m * 2:
            return "손절", "중심선 아래 + 거래대금 모두 감소"
        if chegyul < entry_chegyul * 0.7 and price < entry_price:
            return "손절", f"체결강도 크게 약화 {entry_chegyul:.0f}→{chegyul:.0f} + 가격 하락"
        if enriched.get("저점하락추세"):
            return "손절", "저점 계속 낮추는 하락 추세"
        if enriched.get("고저점하락추세"):
            return "손절", "고점·저점 모두 낮추는 하락 추세"

    # ── [보유] ──
    hold_score, hold_reasons = 0, []
    if pivot and price >= pivot:
        hold_score += 1
        hold_reasons.append("중심선 이상")
    if chegyul >= 100:
        hold_score += 1
        hold_reasons.append(f"체결 {chegyul:.0f}>=100")
    if chegyul >= entry_chegyul * 0.9:
        hold_score += 1
        hold_reasons.append("체결 유지/상승")
    if avg_3m and amount_1m >= avg_3m * 0.8:
        hold_score += 1
        hold_reasons.append("1분대금 유지/증가")
    if not enriched.get("저점하락추세"):
        hold_score += 1
        hold_reasons.append("저점 하락 멈춤")
    if enriched.get("반등"):
        hold_score += 1
        hold_reasons.append("반등/고점 재도전")

    if hold_score >= 3:
        return "보유", f"보유 조건 {hold_score}개 만족: {', '.join(hold_reasons)}"
    return "보유", f"보유 점수 {hold_score}/6 - 손절/익절 미충족으로 보유"


# ── GPT / Gemini 호출 ─────────────────────────

def call_llm(system_prompt: str, user_prompt: str) -> str:
    # ★ AI 실패 쿨다운 중이면 호출 생략 → 조용히 규칙 폴백 (반복 실패 방지)
    if _ai_cooldown_take():
        return ""
    try:
        if PROVIDER == "openai" and OPENAI_API_KEY:
            import openai
            # ★ DeepSeek 등 OpenAI 호환 서버 지원 (AI_BASE_URL 설정 시)
            _kw = {}
            if getattr(CFG, "AI_BASE_URL", ""):
                _kw["base_url"] = CFG.AI_BASE_URL
            oa = openai.OpenAI(api_key=OPENAI_API_KEY, timeout=10, **_kw)
            resp = oa.chat.completions.create(
                model=AI_MODEL,
                messages=[{"role": "system", "content": system_prompt},
                          {"role": "user", "content": user_prompt}],
                temperature=0.2, max_tokens=500,
            )
            return resp.choices[0].message.content.strip()
        if PROVIDER == "gemini" and GEMINI_API_KEY:
            # ★ REST API + X-goog-api-key 헤더 (새 키 형식 AQ... 지원)
            # ★ 모델 404(폐기)면 다음 모델로 자동 폴백 (ai_consult와 동일 패턴)
            import requests as _req
            models = []
            if AI_MODEL and AI_MODEL != "gpt-4o-mini":
                models.append(AI_MODEL)
            models += ["gemini-flash-latest", "gemini-2.0-flash", "gemini-2.0-flash-lite",
                       "gemini-1.5-flash", "gemini-1.5-flash-latest"]
            headers = {"Content-Type": "application/json", "X-goog-api-key": GEMINI_API_KEY}
            payload = {"contents": [{"parts": [{"text": f"{system_prompt}\n\n{user_prompt}"}]}]}
            last_err = "모델 없음"
            for model in models:
                url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
                try:
                    r = _req.post(url, json=payload, headers=headers, timeout=10)
                    if r.status_code == 404:
                        last_err = f"모델 '{model}' 폐기(404) → 다음 모델"
                        continue
                    if r.status_code == 200:
                        data = r.json()
                        return data["candidates"][0]["content"]["parts"][0]["text"].strip()
                    last_err = f"Gemini 오류 {r.status_code}: {r.text[:120]}"
                    # ★ 429(할당량)/503(과부하) → 쿨다운 설정 (반복 호출 방지)
                    if r.status_code in (429, 500, 503):
                        _ai_cooldown_set(last_err, code=r.status_code)
                    break
                except Exception as e:
                    last_err = f"Gemini 호출 실패: {e}"
                    break
            log.warning(f"Gemini 판단 실패({last_err}) → 규칙 폴백")
    except Exception as e:
        log.warning(f"LLM 호출 실패({PROVIDER}): {e}")
    return ""


def _build_llm_input(enriched: dict, symbol: str, position: dict = None) -> str:
    lines = [
        f"- 종목: {symbol}",
        f"- 현재가: {enriched.get('현재가'):,.0f}",
        f"- 중심선: {enriched.get('중심선', 0):,.0f}",
        f"- 1차지지선: {enriched.get('1차지지선', 0):,.0f}",
        f"- 2차지지선: {enriched.get('2차지지선', 0):,.0f}",
        f"- 전일고가: {enriched.get('전일고가', 0):,.0f}",
        f"- 전일저가: {enriched.get('전일저가', 0):,.0f}",
        f"- 전일종가: {enriched.get('전일종가', 0):,.0f}",
        f"- 저가: {enriched.get('저가', 0):,.0f}",
        f"- 저가대비상승: {enriched.get('저가대비상승')}",
        f"- 고점갱신: {enriched.get('고점갱신')}",
        f"- 체결강도: {enriched.get('체결강도', 0):.0f}",
        f"- 체결강도추세: {[round(x,1) for x in enriched.get('체결강도추세', [])]}",
        f"- 최근1분거래대금: {enriched.get('최근1분거래대금', 0):,.0f}",
        f"- 최근3분거래대금: {enriched.get('최근3분거래대금', 0):,.0f}",
        f"- 최근3분평균: {enriched.get('최근3분평균', 0):,.0f}",
        f"- 중심선아래약세: {enriched.get('중심선아래약세')}",
    ]
    if position:
        lines += [
            f"- 진입가: {position.get('entry_price')}",
            f"- 현재수익률: {(enriched.get('현재가',0)-position.get('entry_price',enriched.get('현재가',0)))/position.get('entry_price',1)*100:.2f}%",
            f"- 최고수익률: {position.get('highest_return', 0):.2f}%",
            f"- 최저수익률: {position.get('lowest_return', 0):.2f}%",
            f"- 보유시간: {position.get('holding_minutes', 0)}분",
        ]
        # ★ 매수 시점 매도 지침 (목표가/손절가) - AI가 이 지침을 참고해 유동적으로 판단
        _tgt = position.get("target_price") or 0
        _stp = position.get("stop_price") or 0
        if _tgt or _stp:
            lines.append(f"- [매도 지침] 목표가: {_tgt:,.0f}원" if _tgt else None)
            if _stp:
                lines.append(f"- [매도 지침] 손절가: {_stp:,.0f}원 - 이 가격 이하로 내려가면 즉시 손절")
        _plan = position.get("sell_plan") or ""
        if _plan:
            lines.append(f"- [매수 시 평가 지침] {_plan}")
    return "\n".join([l for l in lines if l])


def compute_buy_confidence(score: int, enriched: dict) -> int:
    """
    ★ AI 매수 신뢰도 (0~100%)
    - 판단 점수 (최대 16): 비중 50%
    - 체결강도: 100 이상이면 가점, 150 이상이면 고득점 (비중 20%)
    - 거래대금: 1분 > 3분평균이면 가점 (비중 15%)
    - 가격 위치: 중심선/전일고가 (비중 15%)
    """
    conf = 0
    # 1) 점수 (0~16 → 0~50%)
    max_score = 16
    conf += min(50, score / max_score * 50)

    # 2) 체결강도 (20%)
    cheg = enriched.get("체결강도", 100) or 100
    if cheg >= 150:
        conf += 20
    elif cheg >= 100:
        conf += 14
    elif cheg >= 70:
        conf += 8
    else:
        conf += 0

    # 3) 거래대금 (15%)
    amt_1m = enriched.get("최근1분거래대금", 0) or 0
    avg_3m = enriched.get("최근3분평균", 0) or 0
    if avg_3m > 0 and amt_1m > avg_3m:
        conf += 15
    elif avg_3m > 0 and amt_1m > avg_3m * 0.7:
        conf += 8

    # 4) 가격 위치 (15%)
    price = enriched.get("현재가", 0) or 0
    pivot = enriched.get("중심선", 0) or 0
    prev_high = enriched.get("전일고가", 0) or 0
    if prev_high and price > prev_high:
        conf += 15  # 전일고가 돌파
    elif pivot and price >= pivot:
        conf += 10
    elif pivot and price >= pivot * 0.98:
        conf += 5

    return min(100, int(round(conf)))


def evaluate_buy(symbol: str, market_data: dict, client_obj=None, params=None) -> Tuple[bool, str]:
    """
    매수 판단. params(전략 DNA)가 주어지면 전략별 기준을 적용:
    - buy_score_threshold: 매수 점수 문턱 (기본 5)
    - chegyul_threshold: 체결강도 문턱 (기본 100)
    ★ rule 모드에서 자동 전략(데이터 기반) 조건도 실측 적용 (프롬프트 장식 아님)
    """
    enriched = enrich_market_data(market_data, client_obj, symbol=symbol)
    enriched["symbol"] = symbol

    if AI_ENABLED and PROVIDER in ("openai", "gemini") and (OPENAI_API_KEY or GEMINI_API_KEY):
        template = load_prompt(BUY_PROMPT_PATH)
        data_block = _build_llm_input(enriched, symbol)
        user_prompt = f"{template}\n\n[현재 시장 데이터]\n{data_block}\n\n위 데이터를 매수 조건 4가지에 따라 판단하여 '매수' 또는 '매수금지'로 시작하고 사유를 설명하세요."
        result = call_llm("당신은 주식 매매 전문가입니다. 주어진 조건에 따라 매수 여부를 판단하세요.", user_prompt)
        if result:
            is_buy = result.startswith("매수") and "금지" not in result[:10]
            return is_buy, f"[AI] {result[:200]}"

    thr = int(params.get("buy_score_threshold", 5)) if params is not None else 5
    is_buy, reason, score = evaluate_buy_rule_based(enriched, score_threshold=thr)

    # ── ★ 자동 전략(데이터 기반) 실측 필터: rule 모드에서 실제 매수에 반영 ──
    #    전략 자동 생성이 만든 rule_id 조건(5일 모멘텀/MA/거래량 등)을
    #    일봉 데이터로 체크. 미충족이면 매수금지 (보수 원칙).
    auto_rule = _load_auto_rule_id()
    if auto_rule and is_buy:
        ok_auto, ar_reason = _auto_check_cached(auto_rule, symbol, enriched.get("현재가", 0))
        if ok_auto is False:
            is_buy = False
            reason = f"[자동전략 {auto_rule}] {ar_reason} → 매수금지 | {reason}"
        elif ok_auto:
            reason = f"[자동전략 {auto_rule}] {ar_reason} | {reason}"

    # ── ★ AI 매수 신뢰도 (0~100%) 계산 ──
    # 점수(최대 16) + 체결강도 + 거래대금 + 가격 위치 가중
    confidence = compute_buy_confidence(score, enriched)

    # 신뢰도 임계값 적용 (AI_BUY_CONFIDENCE=true, threshold=70 이면 70% 이상만 매수)
    if CFG.AI_BUY_CONFIDENCE and confidence < CFG.AI_BUY_CONFIDENCE_THRESHOLD:
        return False, f"[신뢰도 {confidence}% < {CFG.AI_BUY_CONFIDENCE_THRESHOLD}%] 매수금지 - 신뢰도 미달"

    if params is not None:
        cheg_thr = float(params.get("chegyul_threshold", 100))
        cheg = enriched.get("체결강도", 100)
        if cheg < cheg_thr:
            return False, f"[RULE] 체결강도 {cheg:.0f} < 전략 기준 {cheg_thr:.0f} → 매수금지"
        if not is_buy:
            return False, f"[RULE] 점수 {score} < 전략 기준 {thr} → 매수금지"
        return True, f"[RULE score={score}≥{thr}] 신뢰도 {confidence}% | {reason}"

    return is_buy, f"[RULE score={score}] 신뢰도 {confidence}% | {reason}"


def evaluate_sell(symbol: str, market_data: dict, position: dict, client_obj=None, params=None) -> Tuple[str, str]:
    """
    매도 판단. params(전략 DNA)가 주어지면 전략별 기준을 적용:
    - trailing_stop_pct: 트레일링 스탑 (최고점 대비 하락 시 청산, 기본 2.0)
    - stop_loss_pct: 손절 기준 (기본 2.0)
    """
    enriched = enrich_market_data(market_data, client_obj, symbol=symbol)
    enriched["symbol"] = symbol

    # ── ★ AI 매도 지연 안전장치: 하드손절 임계 근접(-2.5% 이하)이면 AI를 기다리지 않고
    #    즉시 규칙(하드손절) 판단 → LLM 지연/장애 시에도 급락 매도 타이밍을 놓치지 않음
    try:
        _price = enriched.get("현재가", 0)
        _ep = position.get("entry_price", _price)
        _cr = (_price - _ep) / _ep * 100 if _ep else 0
        _hard = float(getattr(CFG, "HARD_STOP_LOSS_PCT", 3.0))
        if _hard > 0 and _cr <= -_hard * 0.8:  # 예: -3% 기준 -2.4% 이하
            decision, reason = evaluate_sell_rule_based(enriched, position)
            if _cr <= -_hard:
                return "손절", f"[하드손절 긴급] {_cr:.1f}% ≤ -{_hard}% - AI 대기 없이 즉시 손절"
            return decision, f"[급락 우선] AI 대기 없이 규칙 판단: {reason}"
    except Exception:
        pass

    if AI_ENABLED and PROVIDER in ("openai", "gemini") and (OPENAI_API_KEY or GEMINI_API_KEY):
        template = load_prompt(SELL_PROMPT_PATH)
        data_block = _build_llm_input(enriched, symbol, position)
        user_prompt = f"{template}\n\n[현재 상황]\n{data_block}\n\n판단 순서대로 '수익청산' 또는 '손절' 또는 '보유'로 시작하세요."
        result = call_llm("당신은 주식 손절/익절 전문가입니다. 프롬프트 순서대로 판단하세요.", user_prompt)
        if result:
            if "수익청산" in result[:20]:
                return "수익청산", f"[AI] {result[:200]}"
            if "손절" in result[:20]:
                return "손절", f"[AI] {result[:200]}"
            return "보유", f"[AI] {result[:200]}"

    ts = float(params.get("trailing_stop_pct", 2.0)) if params is not None else 2.0
    decision, reason = evaluate_sell_rule_based(enriched, position, trailing_stop_pct=ts)

    # ── 돈 버는 시스템 핵심: 최소 익절 + 강제 손절 하드 기준 ──
    price = enriched.get("현재가", 0)
    entry_price = position.get("entry_price", price)
    cur_ret = (price - entry_price) / entry_price * 100 if entry_price else 0

    # 1) 강제 손절 (AI/rule이 '보유'라고 해도 무조건 손절) - 0이면 비활성(AI 의견 우선)
    hard_sl = float(getattr(CFG, "HARD_STOP_LOSS_PCT", 3.0))
    if hard_sl > 0 and cur_ret <= -hard_sl:
        return "손절", f"[하드손절] {cur_ret:.1f}% ≤ -{hard_sl}% - 무조건 손절"

    # 1-1) ★ 매수 시점 매도 지침 손절가 (20일 저점 등 - 하드손절보다 먼저 작동 가능)
    #      (매수할 때 build_sell_plan이 정한 가격. AI/rule이 '보유'여도 무조건 손절)
    _stp = position.get("stop_price") or 0
    if _stp and price <= _stp:
        return "손절", f"[매도지침] 손절가 {_stp:,.0f}원 이탈({cur_ret:+.1f}%) - 지침대로 손절"

    # 2) 최소 익절: '수익청산' 판단이 나와도 최소 익절 미만이면 보유 유지
    if decision == "수익청산":
        min_tp = float(getattr(CFG, "MIN_TAKE_PROFIT_PCT", 0.5))
        if cur_ret < min_tp:
            return "보유", f"[최소익절] 수익 {cur_ret:.2f}% < {min_tp}% - 아직 익절 안 함 (대기)"

    # 전략 DNA 기준 오버레이 (rule 기반 판단 결과를 전략별로 조정)
    if params is not None:
        # 손절 기준 (params 기반 - 룰이 '보유'여도 강제 손절)
        if decision == "보유":
            sl = float(params.get("stop_loss_pct", 2.0))
            if cur_ret <= -sl:
                return "손절", f"[RULE] 전략 손절 {sl}%: 현재 {cur_ret:.1f}%"

    return decision, f"[RULE] {reason}"


def engine_status() -> dict:
    """현재 매수/매도 판단 엔진 상태 (대시보드 메인 표시용)"""
    use_llm = AI_ENABLED and PROVIDER in ("openai", "gemini") and (OPENAI_API_KEY or GEMINI_API_KEY)
    provider_name = {"gemini": "Gemini", "openai": "GPT", "rule": "규칙"}.get(PROVIDER, PROVIDER)
    engine_label = f"{provider_name} 분석" if use_llm else "규칙(rule) 판단"
    return {
        "ai_enabled": AI_ENABLED,
        "provider": PROVIDER,
        "use_llm": use_llm,
        "engine_label": engine_label,
        "buy": {
            "engine": engine_label,
            "prompt": BUY_PROMPT_PATH,
            "dna": "buy_score_threshold · chegyul_threshold",
            "desc": "매수 프롬프트 + 전략 DNA(매수점수/체결강도 기준) + 분석",
        },
        "sell": {
            "engine": engine_label,
            "prompt": SELL_PROMPT_PATH,
            "dna": "trailing_stop_pct · stop_loss_pct",
            "desc": "매도 프롬프트 + 전략 DNA(트레일링/손절%) + 현재수익률 + 분석",
        },
    }
