# -*- coding: utf-8 -*-
"""
🎯 엄밀 백테스트 검증 엔진 (validation.py)
==========================================
'좋아 보이는 조건식' vs '실제로 값 있는 조건식'을 구분하는 관문.

핵심: "수익 났다"는 말을 믿지 않는다
  1) 지수 대비 — 같은 날 사고 같은 날 판 코스피 수익과 비교 (같은 시장 조류 통제)
  2) 무작위 대조군 30회 — 매매 횟수/보유일수는 그대로, 날짜만 무작위로 옮겨 재현
     실제 전략 평균수익이 무작위 대조군 30회의 몇 %를 이겼는지(백분위)
  3) 체결 현실화 — 자금/슬롯 시뮬레이션(실제 체결분만 자산곡선) +
     갭 체결(시가가 손절선 넘으면 시가 체결) + 분봉 정밀청산(분봉 있으면 순서 판정)

등급 판정 (수익률순이 아니라 등급순):
  채택 후보 : 지수도 이기고 무작위와도 구별됨 (백분위 ≥ 95 + 지수 초과수익 > 0)
  조건부    : 무작위는 이기나 지수는 못 이김
  수익만    : 돈은 벌지만 무작위와 구별 안 됨
  기각      : 위 중 어디에도 못 미침 (수익이 나도 기각)

실행:
  python validation.py --condition T1            # 조건식 1개 엄밀 검증
  python validation.py --all                     # 활성 조건식 전체 엄밀 검증 (등급순)
  python validation.py --symbol 005930 --days 250 # 특정 종목만 빠르게 (테스트용)
"""
import json
import logging
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import random
import sqlite3
import time
from datetime import date, timedelta

import db
from config import CFG

log = logging.getLogger("validation")

# ── 검증 파라미터 (.env로 조절) ──
# ★ 2026-08-28: auto_params.json(자동) > .env(수동) > 기본값 순으로 읽음 (db.auto_param)
TP_PCT = float(db.auto_param("VALIDATE_TP_PCT", "5.0"))        # 익절 %
SL_PCT = float(db.auto_param("VALIDATE_SL_PCT", "3.0"))        # 손절 %
TRAIL_PCT = float(db.auto_param("VALIDATE_TRAIL_PCT", "2.0"))  # 트레일링 %
MAX_HOLD = int(float(db.auto_param("VALIDATE_MAX_HOLD", "10")))  # 최대 보유일수
CAPITAL = _cfg_env_int("VALIDATE_CAPITAL", 10000000)       # 시작 자금 1천만
MAX_POS = _cfg_env_int("VALIDATE_MAX_POS", 10)             # 동시 보유 슬롯
FEE_PCT = float(getattr(CFG, "FEE_ROUND_TRIP_PCT", 0.2))       # 왕복 수수료 %

# ★ 실전-검증 일치 필터 (2026-08-27 추가)
#   실전 모의매수는 가격 800~10만원 + 유동성 있는 종목만 사는데,
#   검증이 그 밖의 종목(동전주/잡주)까지 백테스트하면 "실전과 다른 세상" 성적이 됨.
#   → 검증도 같은 필터 적용: 신호일 기준 가격대 + 최근 5일 평균 거래대금 하한
VALIDATE_MATCH_LIVE = os.getenv("VALIDATE_MATCH_LIVE", "true").lower() == "true"
VALIDATE_MIN_AMOUNT = _cfg_env_float("VALIDATE_MIN_AMOUNT", 300000000)  # 5일평균 3억
GAP_FILL = os.getenv("VALIDATE_GAP_FILL", "true").lower() == "true"        # 갭 체결
MINUTE_PREC = os.getenv("VALIDATE_MINUTE_PREC", "true").lower() == "true"  # 분봉 정밀청산
OPTIMISTIC = os.getenv("VALIDATE_OPTIMISTIC", "false").lower() == "true"   # 고가 우선
RANDOM_RUNS = _cfg_env_int("VALIDATE_RANDOM_RUNS", 30)     # 무작위 대조군 횟수
PERCENTILE_MIN = _cfg_env_float("VALIDATE_PERCENTILE", 95) # 무작위 대비 백분위 관문

# ── 코스피 일봉 (캐시: data/kospi_daily.json) ─────────────────
_KOSPI_CACHE = None
_KOSPI_CACHE_PATH = os.path.join("data", "kospi_daily.json")


def fetch_kospi_daily(force=False):
    """코스피 일봉 (1990년~) - 네이버 fchart, data/kospi_daily.json 캐시
    반환: [{"date": "YYYY-MM-DD", "close": float}, ...] 오래된순
    """
    global _KOSPI_CACHE
    if not force and _KOSPI_CACHE is not None:
        return _KOSPI_CACHE
    if not force and os.path.exists(_KOSPI_CACHE_PATH):
        try:
            with open(_KOSPI_CACHE_PATH, encoding="utf-8") as f:
                _KOSPI_CACHE = json.load(f)
            if _KOSPI_CACHE:
                return _KOSPI_CACHE
        except Exception:
            pass
    import re
    import requests as _req
    out = []
    try:
        r = _req.get("https://fchart.stock.naver.com/sise.nhn?symbol=KOSPI"
                     "&timeframe=day&count=1000&requestType=0",
                     headers={"User-Agent": "Mozilla/5.0"}, timeout=15)
        if r.status_code == 200:
            for m in re.finditer(r'<item data="([^"]+)"\s*/>', r.text):
                f = m.group(1).split("|")
                if len(f) >= 5:
                    d = f"{f[0][:4]}-{f[0][4:6]}-{f[0][6:]}"
                    try:
                        out.append({"date": d, "close": float(f[4])})
                    except Exception:
                        continue
            # fchart는 오래된→최신 순서로 응답 (reverse 불필요)
    except Exception as e:
        log.warning(f"코스피 일봉 fetch 실패: {e}")
    if out:
        try:
            os.makedirs("data", exist_ok=True)
            with open(_KOSPI_CACHE_PATH, "w", encoding="utf-8") as f:
                json.dump(out, f, ensure_ascii=False)
        except Exception:
            pass
    _KOSPI_CACHE = out
    return out


def _kospi_close_map():
    """{date: close} 매핑"""
    return {r["date"]: r["close"] for r in fetch_kospi_daily()}


def bench_return(entry_date, exit_date):
    """같은 날짜 구간의 코스피 수익률(%) - 없으면 None"""
    m = _kospi_close_map()
    e, x = m.get(entry_date), m.get(exit_date)
    if e and x and e > 0:
        return (x / e - 1) * 100
    return None


# ── 일봉 데이터 로드 ─────────────────────────────────────────
# ── ★ features 공유 캐시 (2026-08-27 최적화) ─────────────────
# 문제: 조건식 21개를 검증하면 같은 종목의 지표(MA/RSI/MACD...)를 21번 재계산
#       (1000봉 100종목 기준 약 103초 → 캐시 공유 시 약 5초, 실측 21배)
# 방법: (종목, 기간필터, 봉수, 마지막날짜)를 키로 features를 1회만 계산해 재사용.
#       마지막 날짜가 바뀌면(새 봉 수집) 키가 달라져 자동 무효화 - 미래누출 없음.
_FEAT_CACHE = {}
_FEAT_CACHE_MAX = _cfg_env_int("VALIDATE_FEAT_CACHE", 600)  # 종목 수 상한 (메모리 보호)


def _features_cached(symbol, bars):
    """build_features 결과 공유 캐시. bars가 같으면(끝날짜+길이) 재계산 안 함."""
    from screener import build_features as _bf
    if not bars:
        return None
    key = (symbol, len(bars), bars[0]["date"], bars[-1]["date"])
    f = _FEAT_CACHE.get(key)
    if f is not None:
        return f
    f = _bf(bars)
    if len(_FEAT_CACHE) >= _FEAT_CACHE_MAX:
        _FEAT_CACHE.clear()   # 단순 전체 비움 (검증 1배치 안에서만 살아있으면 충분)
    _FEAT_CACHE[key] = f
    return f


def _load_bars(symbol, max_days=1000):
    """종목별 일봉 (오래된순): [{date, open, high, low, close, volume}]
    date는 'YYYY-MM-DD'로 정규화 (데이터에 YYYYMMDD로 저장된 경우 변환)
    """
    bars = db.get_stock_daily(symbol, max_days=max_days)
    out = []
    for b in bars:
        try:
            d = b["date"]
            if isinstance(d, str) and "-" not in d and len(d) == 8:
                d = f"{d[:4]}-{d[4:6]}-{d[6:]}"
            out.append({"date": d, "open": float(b["open"] or 0),
                        "high": float(b["high"] or 0), "low": float(b["low"] or 0),
                        "close": float(b["close"] or 0), "volume": float(b["volume"] or 0)})
        except Exception:
            continue
    return out


# ── 분봉으로 같은 날 익절/손절 순서 판정 ────────────────────
def _minute_order(symbol, day, tp_price, sl_price, entry_price):
    """분봉 데이터로 그날 고점이 익절 먼저인지 손절 먼저인지 판정
    반환: "tp" | "sl" | None(분봉 없음/판정 불가 → None이면 보수적=손절 먼저)
    """
    if not MINUTE_PREC:
        return None
    try:
        bars = db.get_minute_bars(symbol, days=3, start=day, end=day)
    except Exception:
        return None
    if len(bars) < 30:
        return None
    seen_tp = seen_sl = False
    for b in bars:
        p = b.get("price") or 0
        if p <= 0:
            continue
        if p >= tp_price:
            seen_tp = True
        if p <= sl_price:
            seen_sl = True
        if seen_tp and not seen_sl:
            return "tp"
        if seen_sl and not seen_tp:
            return "sl"
    return None


# ── 엄밀 백테스트 (종목×날짜 상세 시뮬) ─────────────────────
def run_backtest_detail(symbols, slots, start=None, end=None, tp=TP_PCT, sl=SL_PCT,
                        trail=TRAIL_PCT, max_hold=MAX_HOLD, fee=FEE_PCT,
                        gap_fill=GAP_FILL, minute_prec=MINUTE_PREC,
                        optimistic=OPTIMISTIC, max_symbols=1000, progress=None):
    """조건식 1개를 종목들에 적용 → 매매 목록 (청산 규칙 + 체결 가정 반영)
    반환: {"trades": [{"symbol","entry_date","exit_date","entry","exit","ret_pct",
                       "hold_days","exit_reason","bench_pct"}...],
           "symbols_tested": n, "elapsed": s}
    """
    from screener import build_features, SLOTS
    from strategy_auto import get_daily_series
    t0 = time.time()
    trades = []
    n_test = 0
    loaded_bars = {}   # ★ 무작위 대조군 재사용용 (이중 로드 방지)
    for sym in symbols[:max_symbols]:
        bars = _load_bars(sym, max_days=1000)
        loaded_bars[sym] = bars
        if len(bars) < 60:
            continue
        # 기간 필터
        if start:
            bars = [b for b in bars if b["date"] >= start]
        if end:
            bars = [b for b in bars if b["date"] <= end]
        if len(bars) < 60:
            continue
        n_test += 1
        f = _features_cached(sym, bars)
        if not f:
            continue
        fns = [SLOTS[k][3] for k, _p in slots]
        prms = [p for _k, p in slots]
        n = len(bars)
        # 진입 후보 (종가 기준 신호)
        signal_idx = []
        for i in range(60, n - 1):
            if bars[i]["close"] <= 0:
                continue
            ok = True
            for fn, p in zip(fns, prms):
                try:
                    if not fn(f, i, p):
                        ok = False
                        break
                except Exception:
                    ok = False
                    break
            if ok:
                signal_idx.append(i)
        # 각 신호 → 청산 시뮬
        for i0 in signal_idx:
            entry_price = bars[i0]["close"]
            if entry_price <= 0:
                continue
            # ★ 실전-검증 일치 필터 (2026-08-27): 실전 매수가 거르는 종목은 검증도 거름
            #   ① 가격대 800~10만 (paper_test 가격필터와 동일)
            #   ② 신호일 직전 5일 평균 거래대금 3억+ (체결 가능성 - 잡주 환상수익 제거)
            if VALIDATE_MATCH_LIVE:
                if entry_price < CFG.MOCK_PRICE_MIN or entry_price > CFG.MOCK_PRICE_MAX:
                    continue
                if i0 >= 5:
                    amt5 = sum((bars[k]["close"] or 0) * (bars[k]["volume"] or 0)
                               for k in range(i0 - 4, i0 + 1)) / 5
                    if amt5 < VALIDATE_MIN_AMOUNT:
                        continue
            # ★ 상한가 잠김/거래정지 체결 모델 (2026-08-27 추가)
            #   신호일이 상한가(+29.5%↑) 마감 → 실전에선 매수 잔량에 밀려 체결 불가 → 진입 스킵
            #   신호일 거래량 0 (거래정지) → 체결 불가 → 진입 스킵
            #   (이걸 안 빼면 백테스트가 '상한가 따라잡기 성공' 환상 수익을 만들어냄)
            prev_c = bars[i0 - 1]["close"] if i0 >= 1 else 0
            if prev_c > 0 and entry_price >= prev_c * 1.295:
                continue
            if not (bars[i0].get("volume") or 0) > 0:
                continue
            tp_price = entry_price * (1 + tp / 100.0)
            sl_price = entry_price * (1 - sl / 100.0)
            peak = entry_price
            exit_price, exit_date, reason, hold = None, None, None, 0
            for j in range(i0 + 1, min(i0 + 1 + max_hold, n)):
                hold = j - i0
                b = bars[j]
                high, low = b["high"], b["low"]
                if high <= 0 or low <= 0:
                    continue
                # 갭 체결: 시가가 이미 익절/손절선 지났으면 시가에 체결
                if gap_fill:
                    if b["open"] >= tp_price:
                        exit_price, exit_date, reason = b["open"], b["date"], "갭익절"
                        break
                    if b["open"] <= sl_price:
                        exit_price, exit_date, reason = b["open"], b["date"], "갭손절"
                        break
                # 같은 날 익절/손절 동시 도달 → 분봉으로 순서 판정 (없으면 보수적=손절 먼저)
                hit_tp = high >= tp_price
                hit_sl = low <= sl_price
                if hit_tp and hit_sl:
                    order = _minute_order(sym, b["date"], tp_price, sl_price, entry_price) if minute_prec else None
                    if order == "tp":
                        exit_price, exit_date, reason = tp_price, b["date"], "익절"
                    elif order == "sl":
                        exit_price, exit_date, reason = sl_price, b["date"], "손절"
                    elif optimistic:  # 낙관 가정: 익절 먼저
                        exit_price, exit_date, reason = tp_price, b["date"], "익절(낙관)"
                    else:             # 보수 가정: 손절 먼저
                        exit_price, exit_date, reason = sl_price, b["date"], "손절(보수)"
                    break
                if hit_tp:
                    exit_price, exit_date, reason = tp_price, b["date"], "익절"
                    break
                if hit_sl:
                    exit_price, exit_date, reason = sl_price, b["date"], "손절"
                    break
                # 트레일링: 최고 종가 대비 하락
                peak = max(peak, b["close"])
                if trail > 0 and peak * (1 - trail / 100.0) > entry_price and b["close"] <= peak * (1 - trail / 100.0):
                    exit_price, exit_date, reason = b["close"], b["date"], "트레일링"
                    break
            if exit_price is None:
                # 최대 보유일 도달 → 종가 청산
                last = bars[min(i0 + max_hold, n - 1)]
                exit_price, exit_date, reason = last["close"], last["date"], "보유만료"
            ret = (exit_price / entry_price - 1) * 100 - fee
            # ★ 2026-08-28 환상수익 차단 (사용자 발견: 평균 +721% 카드):
            #   한국 주식 하루 상하한 ±30%, 최대보유 10일 → 이론상 최대도 +1300% 불가능은 아니나
            #   실제로 ±35%/일 넘는 수익률은 십중팔구 '수정주가 접합 점프'(감자/병합/소스혼합).
            #   보유일수 기준 물리 한계(일수×31%)를 넘는 거래는 데이터 오류로 보고 제외.
            _cap = max(1, hold) * 31.0
            if abs(ret) > _cap:
                continue   # 환상 거래 제외 (지표/등급 오염 방지)
            trades.append({"symbol": sym, "entry_date": bars[i0]["date"],
                           "exit_date": exit_date, "entry": round(entry_price),
                           "exit": round(exit_price), "ret_pct": round(ret, 2),
                           "hold_days": hold, "exit_reason": reason,
                           "bench_pct": bench_return(bars[i0]["date"], exit_date)})
    return {"trades": trades, "symbols_tested": n_test, "elapsed": round(time.time() - t0, 1),
            "bars_loaded": loaded_bars}


# ── 무작위 대조군 (날짜만 무작위로 옮김) ────────────────────
def _random_control(trades, symbols_bars, runs=RANDOM_RUNS, fee=FEE_PCT):
    """매매 횟수·보유일수는 그대로, 진입 날짜만 무작위로 옮긴 대조군
    반환: (runs_avg: [30개 평균수익], percentile: 실제가 대조군 몇 %를 이겼나)
    ★ 2026-08-27 재현성: 시드를 '거래 내용'에서 고정 - 같은 데이터면 항상 같은 percentile
      (시드 없으면 등급 경계(95 부근) 조건식이 검증할 때마다 채택↔기각 플래핑)
    """
    if not trades:
        return [], 0.0
    # 종목별 날짜→close 인덱스 (빠른 조회)
    idx = {}
    for sym in symbols_bars:
        bars = symbols_bars[sym]
        if len(bars) >= 60:
            idx[sym] = {b["date"]: (k, b["close"]) for k, b in enumerate(bars)}
    actual = sum(t["ret_pct"] for t in trades) / len(trades)
    # ★ 2026-08-28 속도: 매매 2000건+ 조건식은 대조군용 표본만 2000건 추출
    #   (1.5만건 × 30회 = 46만 시뮬이 대청소 병목이었음 - 2000건이면 통계적으로 동일)
    _tr = trades
    if len(_tr) > 2000:
        import random as _r
        _tr = _r.Random(42).sample(list(_tr), 2000)
    hold_days = [t["hold_days"] for t in _tr]
    symbols = [t["symbol"] for t in _tr]
    import zlib
    _sig = f"{len(trades)}|{trades[0]['symbol']}|{trades[0]['entry_date']}|" \
           f"{trades[-1].get('exit_date') or ''}"
    _seed = zlib.crc32(_sig.encode("utf-8"))   # 파이썬 hash()는 실행마다 달라짐 - crc32는 고정
    _rng = random.Random(_seed)
    run_avgs = []
    for _ in range(max(1, runs)):
        tot = 0.0
        for sym, hd in zip(symbols, hold_days):
            di = idx.get(sym)
            if not di:
                continue
            keys = list(di.keys())
            if len(keys) < 3:
                continue
            # 무작위 진입일 (보유 가능 구간 내)
            k = _rng.randint(0, len(keys) - 2)
            d0 = keys[k]
            d1 = keys[min(k + max(1, hd), len(keys) - 1)]
            p0 = di[d0][1]
            p1 = di[d1][1]
            if p0 and p0 > 0:
                tot += (p1 / p0 - 1) * 100 - fee
        run_avgs.append(tot / max(1, len(_tr)))
    # 백분위: 실제가 대조군 평균보다 높은 비율
    below = sum(1 for x in run_avgs if actual >= x)
    percentile = below / len(run_avgs) * 100 if run_avgs else 0.0
    return run_avgs, percentile


# ── 자금/슬롯 시뮬레이션 (실제 체결분 자산곡선) ─────────────
def simulate_capital(trades, capital=CAPITAL, max_pos=MAX_POS, fee=FEE_PCT):
    """자금·슬롯 제약 반영 → 실제 체결된 매매 + 자산 곡선
    반환: {"filled": [매매], "skipped": 수, "equity": [{date, equity}],
           "final", "peak", "mdd_pct", "cagr_pct", "total_pct"}
    """
    if not trades:
        return {"filled": [], "skipped": 0, "equity": [], "final": capital,
                "peak": capital, "mdd_pct": 0, "cagr_pct": 0, "total_pct": 0}
    order = sorted(trades, key=lambda t: t["entry_date"])
    cash = float(capital)
    open_pos = {}  # symbol → {"entry": , "qty": , "entry_date": }
    filled = []
    skipped = 0
    points = []
    all_dates = sorted({t["entry_date"] for t in order} | {t["exit_date"] for t in order})
    # 미청산 종목 평가용 close 맵 (1회 로드 - 성능)
    close_maps = {}
    def _close_map(sym):
        if sym not in close_maps:
            close_maps[sym] = {b["date"]: b["close"] for b in _load_bars(sym, 100)}
        return close_maps[sym]
    # 일별 진행
    by_day = {}
    for t in order:
        by_day.setdefault(t["entry_date"], []).append(t)
    exit_by_day = {}
    for t in order:
        exit_by_day.setdefault(t["exit_date"], []).append(t)
    for d in all_dates:
        # 그날 청산 먼저
        for t in exit_by_day.get(d, []):
            op = open_pos.pop(t["symbol"], None)
            if op:
                proceeds = op["qty"] * t["exit"] * (1 - fee / 200.0)  # 매도 수수료
                cash += proceeds
                filled.append({**t, "qty": op["qty"]})
        # 그날 진입
        for t in by_day.get(d, []):
            if len(open_pos) >= max_pos:
                skipped += 1
                continue
            if t["symbol"] in open_pos:   # ★ 보유 중인 종목 재매수 금지 (실제 시스템과 동일)
                skipped += 1
                continue
            price = t["entry"]
            qty = int((cash / max_pos) / price) if price > 0 else 0
            if qty < 1:
                skipped += 1
                continue
            cost = qty * price * (1 + fee / 200.0)  # 진입 수수료
            if cost > cash:
                qty = int(cash / (price * (1 + fee / 200.0)))
                if qty < 1:
                    skipped += 1
                    continue
                cost = qty * price * (1 + fee / 200.0)
            cash -= cost
            open_pos[t["symbol"]] = {"entry": price, "qty": qty, "entry_date": d}
        # 평가 (미청산 종목은 그날(또는 최근) 종가 기준 mark-to-market)
        mk = cash
        for sym, op in open_pos.items():
            cm = _close_map(sym)
            last = cm.get(d)
            if last is None and cm:
                last = cm[max(cm.keys())]  # fallback: 마지막 날짜의 종가
            if last:
                mk += op["qty"] * last
        points.append({"date": d, "equity": round(mk)})
    # 최종 자산 = 현금 + 미청산 포지션 최근 종가 평가
    final = cash
    for sym, op in open_pos.items():
        cm = _close_map(sym)
        last = cm[max(cm.keys())] if cm else 0
        final += op["qty"] * last
    equity_vals = [p["equity"] for p in points] or [capital]
    mdd = 0.0
    peak = equity_vals[0]
    for v in equity_vals:
        peak = max(peak, v)
        mdd = max(mdd, (peak - v) / peak * 100 if peak else 0)
    total_pct = (final / capital - 1) * 100
    days = max(1, (date.fromisoformat(all_dates[-1]) - date.fromisoformat(all_dates[0])).days)
    years = days / 365.0
    cagr = ((final / capital) ** (1 / years) - 1) * 100 if years > 0 and final > 0 else 0
    return {"filled": filled, "skipped": skipped, "equity": points,
            "final": round(final), "peak": round(max(equity_vals)), "mdd_pct": round(mdd, 2),
            "cagr_pct": round(cagr, 2), "total_pct": round(total_pct, 2),
            "capital": capital}


# ── 등급 판정 ───────────────────────────────────────────────
def grade_condition(trades, percentile, avg_ret, bench_avg):
    """등급: 채택 후보 / 조건부 / 수익만 / 기각"""
    if not trades or avg_ret <= 0:
        return "기각"
    if bench_avg is None:
        bench_avg = 0.0
    # ★ 2026-08-27 논리 버그 수정: 기존 index_beat = (bench_avg > 0)는
    #   "지수가 올랐나"를 봤음 → 전략이 지수한테 대패해도(+0.1% vs 지수+5%) 채택 후보,
    #   지수 압승해도(+3% vs 지수-2%) 강등되는 정반대 판정.
    #   올바른 기준 = "전략 평균수익이 같은 기간 지수 수익보다 높은가"
    index_beat = avg_ret > bench_avg
    distinct = percentile >= PERCENTILE_MIN
    # ★ 소표본 캡 (2026-08-27): 거래 20건 미만이면 최고 등급은 '조건부'까지만
    #   (5건짜리 우연 통과가 '채택 후보'로 매수 우선순위에 오르는 것 방지
    #    - lifecycle 승격 기준 20건과 일관성)
    small = len(trades) < 20
    if index_beat and distinct:
        return "조건부" if small else "채택 후보"
    if distinct:
        return "조건부"
    if index_beat:
        return "수익만"
    return "기각"


def validate_condition(cond, symbols=None, start=None, end=None, max_symbols=500,
                       capital=CAPITAL, max_pos=MAX_POS, runs=RANDOM_RUNS):
    """조건식 1개 전체 검증 파이프라인
    cond: {"cond_key", "cond_txt", "slots"}
    반환: {cond_key, txt, grade, trades, stats{...}, random_avg, percentile,
           bench_avg, equity{...}, note}
    """
    t0 = time.time()
    slots = cond.get("slots") or []
    if not slots:
        return {"cond_key": cond["cond_key"], "txt": cond.get("cond_txt", ""),
                "grade": "기각", "trades": [], "stats": {},
                "note": "슬롯 없음"}
    # 종목 목록
    if not symbols:
        try:
            cov = db.backfill_coverage(min_days=60)
            symbols = [s for s, c in cov["symbols"].items() if c >= 60][:max_symbols]
        except Exception:
            symbols = []
    if not symbols:
        symbols = ["005930", "000660", "035420"]
    # 백테스트 (bars 1회 로드 - 성능 최적화: run_backtest_detail이 로드한 bars 재사용)
    res = run_backtest_detail(symbols, slots, start=start, end=end, max_symbols=max_symbols)
    trades = res["trades"]
    if len(trades) < 5:
        return {"cond_key": cond["cond_key"], "txt": cond.get("cond_txt", ""),
                "grade": "기각", "trades": trades,
                "stats": {"trades": len(trades), "symbols": res["symbols_tested"]},
                "note": f"매매 {len(trades)}건 - 표본 부족 (검증 어려움)",
                "elapsed": res["elapsed"]}
    avg_ret = sum(t["ret_pct"] for t in trades) / len(trades)
    bench_vals = [t["bench_pct"] for t in trades if t.get("bench_pct") is not None]
    bench_avg = sum(bench_vals) / len(bench_vals) if bench_vals else None
    # 무작위 대조군 - ★ run_backtest_detail이 이미 로드한 bars 재사용 (이중 로드 제거 = 약 2배 빨라짐)
    symbols_bars = res.get("bars_loaded") or {s: _load_bars(s, 1000) for s in symbols[:max_symbols]}
    random_avgs, percentile = _random_control(trades, symbols_bars, runs=runs)
    grade = grade_condition(trades, percentile, avg_ret, bench_avg)
    # 자금/슬롯 시뮬레이션
    equity = simulate_capital(trades, capital=capital, max_pos=max_pos)
    stats = {
        "trades": len(trades),
        "symbols": res["symbols_tested"],
        "avg_ret": round(avg_ret, 2),
        "bench_avg": round(bench_avg, 2) if bench_avg is not None else None,
        "excess": round(avg_ret - (bench_avg or 0), 2),
        "percentile": round(percentile, 1),
        "random_avg": round(sum(random_avgs) / len(random_avgs), 2) if random_avgs else 0,
        "win_rate": round(len([t for t in trades if t["ret_pct"] > 0]) / len(trades) * 100, 1),
        "pf": round(sum(t["ret_pct"] for t in trades if t["ret_pct"] > 0) /
                    max(0.001, abs(sum(t["ret_pct"] for t in trades if t["ret_pct"] <= 0))), 2),
        "mdd": equity["mdd_pct"],
        "cagr": equity["cagr_pct"],
        "total_pct": equity["total_pct"],
        "filled": len(equity["filled"]),
        "skipped": equity["skipped"],
    }
    return {"cond_key": cond["cond_key"], "txt": cond.get("cond_txt", ""),
            "grade": grade, "trades": trades, "stats": stats,
            "equity": equity, "random_avgs": random_avgs,
            "note": f"{len(trades)}건 · {res['elapsed']}초", "elapsed": res["elapsed"]}


# ── 활성 조건식 전체 검증 (등급순) ─────────────────────────
def validate_active_conditions(max_symbols=300, start=None, end=None):
    """활성 조건식 전체 → 등급순 랭킹 + DB 저장(validation_results 테이블)
    반환: {"results": [validate_condition 결과...등급순], "summary": {...}}
    """
    conds = [c for c in db.get_conditions(status="active")]
    results = []
    for c in conds:
        try:
            slots = json.loads(c.get("slots_json") or "[]")
        except Exception:
            slots = []
        if not slots:
            continue
        r = validate_condition({"cond_key": str(c["id"]), "cond_txt": c["cond_txt"],
                                "slots": slots}, max_symbols=max_symbols, start=start, end=end)
        r["cond_no"] = c["cond_no"]
        results.append(r)
        log.info(f"[검증] {c['cond_no']}번 → {r['grade']} ({r['stats'].get('trades', 0)}건)")
    order = {"채택 후보": 0, "조건부": 1, "수익만": 2, "기각": 3}
    results.sort(key=lambda r: (order.get(r["grade"], 9),
                                -(r["stats"].get("percentile") or 0),
                                -(r["stats"].get("avg_ret") or 0)))
    save_validation_results(results)
    return {"results": results,
            "summary": {g: sum(1 for r in results if r["grade"] == g)
                        for g in ("채택 후보", "조건부", "수익만", "기각")},
            "total": len(results)}


def save_validation_results(results):
    """검증 결과 DB 저장 (validation_results 테이블) - 성과 순위/이력용"""
    try:
        with db.get_conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS validation_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    cond_key TEXT NOT NULL,
                    cond_no TEXT,
                    cond_txt TEXT NOT NULL,
                    grade TEXT NOT NULL,
                    trades INTEGER, avg_ret REAL, bench_avg REAL, excess REAL,
                    percentile REAL, random_avg REAL, win_rate REAL, pf REAL,
                    mdd REAL, cagr REAL, total_pct REAL, filled INTEGER, skipped INTEGER,
                    start_date TEXT, end_date TEXT, created_at TEXT NOT NULL
                )""")
            # ★🔧 2026-09-01 마이그레이션: 옛 스키마 DB는 excess/win_rate/pf 등이 없어
            #   INSERT가 조용히 실패 → 검증 이력이 안 쌓임 → lifecycle 승격(편입) 먹통.
            #   (사용자 증상: "대량 퇴출은 됐는데 편입이 안 됨"의 원인 중 하나)
            try:
                _cols = {r[1] for r in conn.execute(
                    "PRAGMA table_info(validation_results)").fetchall()}
                for _c, _t in [("excess", "REAL"), ("win_rate", "REAL"), ("pf", "REAL"),
                               ("mdd", "REAL"), ("cagr", "REAL"), ("total_pct", "REAL"),
                               ("filled", "INTEGER"), ("skipped", "INTEGER"),
                               ("start_date", "TEXT"), ("end_date", "TEXT"),
                               ("n_symbols", "INTEGER")]:
                    if _c not in _cols:
                        conn.execute(f"ALTER TABLE validation_results ADD COLUMN {_c} {_t}")
                        log.info(f"[마이그레이션] validation_results.{_c} 컬럼 추가")
            except Exception as _e:
                log.warning(f"validation_results 마이그레이션 실패: {_e}")
            now = db.now_kst_iso()
            for r in results:
                st = r.get("stats") or {}
                conn.execute(
                    "INSERT INTO validation_results (cond_key, cond_no, cond_txt, grade, "
                    "trades, avg_ret, bench_avg, excess, percentile, random_avg, win_rate, pf, "
                    "mdd, cagr, total_pct, filled, skipped, n_symbols, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (r["cond_key"], r.get("cond_no"), r["txt"], r["grade"],
                     st.get("trades"), st.get("avg_ret"), st.get("bench_avg"),
                     st.get("excess"), st.get("percentile"), st.get("random_avg"),
                     st.get("win_rate"), st.get("pf"), st.get("mdd"), st.get("cagr"),
                     st.get("total_pct"), st.get("filled"), st.get("skipped"),
                     st.get("symbols"), now))   # ★ n_symbols = 몇 종목 규모 검증인지
    except Exception as e:
        log.warning(f"검증 결과 저장 실패: {e}")


def load_validation_history(limit=50):
    """최근 검증 이력 (성과 순위 표)"""
    try:
        with db.get_conn() as conn:
            rows = conn.execute(
                "SELECT * FROM validation_results ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


def format_result(r):
    """검증 결과 1개를 사람이 읽기 좋은 텍스트로"""
    st = r.get("stats") or {}
    lines = [
        f"『{r['cond_no']}번』 {r['txt'][:55]}",
        f"  등급: {'🏆' if r['grade']=='채택 후보' else ('✅' if r['grade']=='조건부' else ('⚠️' if r['grade']=='수익만' else '❌'))} {r['grade']}",
        f"  매매 {st.get('trades', 0)}건 (종목 {st.get('symbols', 0)}개) · 승률 {st.get('win_rate', 0)}% · "
        f"평균 {st.get('avg_ret', 0):+.2f}% · 손익비 {st.get('pf', 0)}",
        f"  지수 대비: 평균수익 {st.get('avg_ret', 0):+.2f}% vs 코스피 {st.get('bench_avg', 0) if st.get('bench_avg') is not None else '-'}% "
        f"(초과 {st.get('excess', 0):+.2f}%)",
        f"  무작위 대조군 {RANDOM_RUNS}회 평균 {st.get('random_avg', 0):+.2f}% → 백분위 {st.get('percentile', 0):.0f}% "
        f"(≥{PERCENTILE_MIN:.0f}%여야 무작위와 구별)",
        f"  자금 {st.get('filled', 0)}건 체결({st.get('skipped', 0)}건 스킵) · CAGR {st.get('cagr', 0)}% · "
        f"MDD {st.get('mdd', 0)}% · 총수익 {st.get('total_pct', 0):+.2f}%",
        f"  {r.get('note', '')}",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="엄밀 백테스트 검증")
    parser.add_argument("--condition", default=None, help="조건식 cond_no (예: 1)")
    parser.add_argument("--all", action="store_true", help="활성 조건식 전체")
    parser.add_argument("--symbol", default=None, help="특정 종목만 (테스트)")
    parser.add_argument("--max-symbols", type=int, default=300)
    args = parser.parse_args()
    db.init_db()
    logging.basicConfig(level=logging.INFO)
    if args.all:
        res = validate_active_conditions(max_symbols=args.max_symbols)
        print("=" * 60)
        print(f"🎯 엄밀 검증 결과 ({res['total']}개 조건식 · 등급순)")
        print("  " + " · ".join(f"{g} {n}" for g, n in res["summary"].items()))
        print("=" * 60)
        for r in res["results"]:
            print(format_result(r))
            print("-" * 60)
    elif args.condition:
        conds = db.get_conditions(status="active")
        c = next((c for c in conds if c["cond_no"] == args.condition), None)
        if not c:
            print(f"조건식 {args.condition}번 없음")
        else:
            slots = json.loads(c.get("slots_json") or "[]")
            r = validate_condition({"cond_key": str(c["id"]), "cond_txt": c["cond_txt"], "slots": slots},
                                   max_symbols=args.max_symbols)
            print(format_result(r))
            print("\n[매매 목록]")
            for t in r["trades"][:20]:
                print(f"  {t['entry_date']}→{t['exit_date']} {t['symbol']} "
                      f"{t['ret_pct']:+.2f}% ({t['exit_reason']})")
    else:
        parser.print_help()


# ── 등급 게이트 (검증 통과 조건식만 모의매매 사용 - 선택 기능) ──

def latest_grade(cond_key):
    """조건식의 최근 검증 등급 (없으면 None)"""
    try:
        with db.get_conn() as conn:
            row = conn.execute(
                "SELECT grade FROM validation_results WHERE cond_key=? "
                "ORDER BY id DESC LIMIT 1", (cond_key,)).fetchone()
        return row["grade"] if row else None
    except Exception:
        return None


def grade_gate_pass(cond_key):
    """등급 게이트: VALIDATE_GATE_ENABLED=true면 허용 등급만 통과
    ★ 기본 true (안전측) - '채택 후보/조건부'만 모의매매 진입
      (검증 기록이 아직 없는 조건식은 통과 - 데이터 쌓이기 전 차단 안 함)
      끄려면 .env에 VALIDATE_GATE_ENABLED=false 명시
    """
    if not os.getenv("VALIDATE_GATE_ENABLED", "true").lower() == "true":
        return True
    g = latest_grade(cond_key)
    if g is None:
        return True  # 아직 검증 안 됨 = 통과 (데이터 쌓이기 전)
    allowed = {x.strip() for x in
               os.getenv("VALIDATE_GATE_GRADES", "채택 후보,조건부").split(",")}
    return g in allowed


def get_validation_top(limit=10, grades=("채택 후보", "조건부")):
    """★ 검증 통과(엄밀 등급) 조건식 - 모의매매 상위에 우선 올리기
    validation_results에서 최근 등급이 '채택 후보'/'조건부'인 cond_key 목록 (등급순)
    반환: [{cond_key, grade, percentile, avg_ret, trades}]
    """
    try:
        with db.get_conn() as conn:
            rows = conn.execute(
                "SELECT cond_key, grade, percentile, avg_ret, trades FROM validation_results "
                "WHERE id IN (SELECT MAX(id) FROM validation_results GROUP BY cond_key) "
                "AND grade IN (%s) ORDER BY "
                "CASE grade WHEN '채택 후보' THEN 0 ELSE 1 END, percentile DESC LIMIT ?"
                % ",".join("?" * len(grades)),
                (*grades, limit)).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


def _slots_of(cond):
    """조건식 → 슬롯 목록 (slots_json → [(key, param), ...])"""
    import json as _json
    try:
        return _json.loads(cond.get("slots_json") or "[]")
    except Exception:
        return []


def compare_ai_vs_rule(conditions=None, symbols=None, start=None, end=None, max_symbols=300,
                       ai_threshold=70, tp=TP_PCT, sl=SL_PCT, trail=TRAIL_PCT, fee=FEE_PCT):
    """★ AI 판단 넣은 vs 안 넣은 비교 백테스트 (사용자: '검증시 AI 넣은 것과 안 넣은 것 비교')
    - 그룹 A (AI 넣음): 조건식 신호 종목 중 'AI 매수 신뢰도(일봉 규칙 점수 기반 근사)' 임계 통과만 매수
                        → 매도도 AI/트레일링 규칙 (기존 백테스트 청산 규칙)
    - 그룹 B (AI 안 넣음): 조건식 신호 전부 매수 → 동일 매도 규칙
    - 두 그룹의 성과를 비교해 'AI 게이트가 도움이 되는지' 판단
    반환: {"a": {...성과}, "b": {...성과}, "diff": {...}, "note": str, "trades_a": n, "trades_b": n}
    """
    from screener import build_features, SLOTS
    if conditions is None:
        conds = db.get_conditions(status="active")
        conditions = [{"cond_key": str(c["id"]), "slots": _slots_of(c),
                       "cond_txt": c.get("cond_txt", "")} for c in conds[:5]]
    if symbols is None:
        univ = db.get_universe(market="KOSPI") + db.get_universe(market="KOSDAQ")
        if not univ:
            univ = db.get_universe()
        symbols = [u["symbol"] for u in univ]
    symbols = symbols[:max_symbols]

    def _score_at(f, i):
        """일봉 기반 'AI 신뢰도 근사 점수' (0~100): 추세/모멘텀/거래량/RSI"""
        s = 0
        try:
            if f.get("mom5_up") and f["mom5_up"](f, i, 3):
                s += 25
            if f.get("mom10_up") and f["mom10_up"](f, i, 5):
                s += 20
            if f.get("ma_above") and f["ma_above"](f, i, (5, 20)):
                s += 20
            if f.get("vol_ratio") and f["vol_ratio"](f, i, 1.5):
                s += 15
            if f.get("rsi_above") and f["rsi_above"](f, i, 50):
                s += 10
            if f.get("price_above_ma") and f["price_above_ma"](f, i, (5,)):
                s += 10
        except Exception:
            pass
        return s

    t0 = time.time()
    trades_a, trades_b = [], []
    n_test = 0
    for sym in symbols:
        bars = _load_bars(sym, max_days=1000)
        if len(bars) < 60:
            continue
        if start:
            bars = [b for b in bars if b["date"] >= start]
        if end:
            bars = [b for b in bars if b["date"] <= end]
        if len(bars) < 60:
            continue
        n_test += 1
        f = build_features(bars)
        if not f:
            continue
        n = len(bars)
        # 조건식 신호 수집
        sig_idx = []
        for cond in conditions:
            slots = cond.get("slots") or []
            if not slots:
                continue
            fns = []
            prms = []
            ok_slots = True
            for k, p in slots:
                if k not in SLOTS:
                    ok_slots = False
                    break
                fns.append(SLOTS[k][3])
                prms.append(p)
            if not ok_slots:
                continue
            for i in range(60, n - 1):
                if bars[i]["close"] <= 0:
                    continue
                hit = True
                for fn, p in zip(fns, prms):
                    try:
                        if not fn(f, i, p):
                            hit = False
                            break
                    except Exception:
                        hit = False
                        break
                if hit:
                    sig_idx.append(i)
        if not sig_idx:
            continue
        # 매도 시뮬 (공통): 익절/손절/트레일링
        def _simulate(i0):
            entry_price = bars[i0]["close"]
            if entry_price <= 0:
                return None
            tp_price = entry_price * (1 + tp / 100.0)
            sl_price = entry_price * (1 - sl / 100.0)
            peak = entry_price
            for j in range(i0 + 1, min(i0 + 1 + MAX_HOLD, n)):
                b = bars[j]
                if b["high"] <= 0 or b["low"] <= 0:
                    continue
                if b["open"] >= tp_price:
                    return {"ret": (tp_price / entry_price - 1) * 100 - fee, "reason": "갭익절"}
                if b["open"] <= sl_price:
                    return {"ret": (sl_price / entry_price - 1) * 100 - fee, "reason": "갭손절"}
                if b["high"] >= tp_price:
                    return {"ret": (tp_price / entry_price - 1) * 100 - fee, "reason": "익절"}
                if b["low"] <= sl_price:
                    return {"ret": (sl_price / entry_price - 1) * 100 - fee, "reason": "손절"}
                peak = max(peak, b["close"])
                if trail > 0 and peak * (1 - trail / 100.0) > entry_price and \
                        b["close"] <= peak * (1 - trail / 100.0):
                    return {"ret": (b["close"] / entry_price - 1) * 100 - fee, "reason": "트레일링"}
            last = bars[min(i0 + MAX_HOLD, n - 1)]
            return {"ret": (last["close"] / entry_price - 1) * 100 - fee, "reason": "보유만료"}

        for i0 in sig_idx:
            # 그룹 B: 전부 매수
            r = _simulate(i0)
            if r:
                trades_b.append(r)
            # 그룹 A: AI 신뢰도 임계 통과만 매수
            score = _score_at(f, i0)
            if score >= ai_threshold:
                r = _simulate(i0)
                if r:
                    trades_a.append(r)

    def _stats(tr):
        if not tr:
            return {"trades": 0, "win_rate": 0, "avg_ret": 0, "pf": 0, "max_loss": 0}
        wins = [t["ret"] for t in tr if t["ret"] > 0]
        losses = [t["ret"] for t in tr if t["ret"] <= 0]
        gross_win = sum(wins)
        gross_loss = abs(sum(losses))
        return {
            "trades": len(tr),
            "win_rate": round(len(wins) / len(tr) * 100, 1),
            "avg_ret": round(sum(t["ret"] for t in tr) / len(tr), 2),
            "pf": round(gross_win / gross_loss, 2) if gross_loss > 0 else (99.0 if gross_win > 0 else 0),
            "max_loss": round(min(t["ret"] for t in tr), 2),
        }

    a = _stats(trades_a)
    b = _stats(trades_b)
    diff = {
        "avg_ret": round(a["avg_ret"] - b["avg_ret"], 2),
        "win_rate": round(a["win_rate"] - b["win_rate"], 1),
        "pf": round(a["pf"] - b["pf"], 2),
        "trades": a["trades"] - b["trades"],
    }
    note = ("AI 게이트가 수익률/승률을 높였다면 매수 시 AI 판단 ON 추천 / "
            "오히려 나쁘다면 OFF 유지 (조건식 신호만)") if a["trades"] > 0 and b["trades"] > 0 else "표본 부족"
    return {"a": a, "b": b, "diff": diff, "note": note,
            "trades_a": a["trades"], "trades_b": b["trades"],
            "symbols_tested": n_test, "elapsed": round(time.time() - t0, 1),
            "ai_threshold": ai_threshold}


def index_guideline(cond_key, min_down_sells=5):
    """★ 지수 가이드라인: 조건식이 '어떤 지수 국면에서 안 좋은지' (테스트/실전 대비용)
    - 하락장(코스피 ≤ -1%) 표본이 min_down_sells 이상이면 신뢰 있는 가이드
    - 하락장 승률 < 45% → "코스피 하락장(-1%↓)에서는 사용 자제"
    - 하락장 승률 < 40% → "코스피 급락(-2%↓)에서는 금지"
    반환: {"level": "ok"|"caution"|"avoid"|"insufficient", "guide": str, "data": {...}}
    """
    try:
        stats = db.index_condition_stats()
        cs = stats.get(str(cond_key)) or {}
        down = cs.get("down") or {}
        sells = down.get("sells", 0)
        wr = down.get("win_rate", 0)
        avg = down.get("avg_ret", 0)
        if sells < min_down_sells:
            return {"level": "insufficient", "guide": "하락장 표본 부족 - 가이드 대기 (데이터 쌓이는 중)",
                    "data": {"down_sells": sells, "down_win": wr, "down_avg": avg}}
        if wr < 40:
            return {"level": "avoid", "guide": f"⚠️ 코스피 하락장(-1%↓)에서 사용 금지 권장 (하락장 승률 {wr}%)",
                    "data": {"down_sells": sells, "down_win": wr, "down_avg": avg}}
        if wr < 50:
            return {"level": "caution", "guide": f"⚠️ 코스피 하락장(-1%↓)에서는 신중 (하락장 승률 {wr}% - 낮음)",
                    "data": {"down_sells": sells, "down_win": wr, "down_avg": avg}}
        return {"level": "ok", "guide": f"✅ 하락장에서도 양호 (하락장 승률 {wr}% · 평균 {avg:+.2f}%)",
                "data": {"down_sells": sells, "down_win": wr, "down_avg": avg}}
    except Exception as e:
        return {"level": "error", "guide": str(e)[:60], "data": {}}


def time_guideline(cond_key, min_sells=5):
    """★ 시간대 가이드: 조건식이 '어느 시간대에 안 좋은지' (지수 국면과 함께)
    - 해당 시간대 표본 ≥ min_sells + 승률 < 45% → "이 시간대 자제"
    - 가장 좋은/나쁜 시간대 1개씩 + 지수 국면 상호작용
    반환: {"best": {...}, "worst": {...}, "guide": str, "data": {...}}
    """
    try:
        stats = db.time_zone_stats()
        cs = stats.get(str(cond_key)) or {}
        if not cs:
            return {"guide": "아직 시간대별 표본 없음 (장중 진입이 쌓이면 분석)", "best": None, "worst": None, "data": {}}
        scored = []
        for bucket, s in cs.items():
            if s.get("sells", 0) >= min_sells:
                scored.append({**s, "bucket": bucket})
        if not scored:
            return {"guide": "시간대별 표본 부족(5건 미만) - 더 쌓이면 분석", "best": None, "worst": None, "data": cs}
        scored.sort(key=lambda x: -x["win_rate"])
        best, worst = scored[0], scored[-1]
        # 지수 국면 상호작용 (하락장에서 이 시간대는?)
        ix = db.index_condition_stats().get(str(cond_key), {})
        down = ix.get("down") or {}
        parts = [f"가장 좋은 시간대: {best['bucket']} (승률 {best['win_rate']}%·{best['avg_ret']:+.2f}%)",
                 f"가장 나쁜 시간대: {worst['bucket']} (승률 {worst['win_rate']}%·{worst['avg_ret']:+.2f}%)"]
        if down.get("sells", 0) >= 5:
            parts.append(f"하락장에서: 승률 {down['win_rate']}%·평균 {down['avg_ret']:+.2f}%")
        if worst["win_rate"] < 45:
            parts.insert(0, f"⚠️ {worst['bucket']} 시간대 자제 권장")
        return {"best": best, "worst": worst, "guide": " | ".join(parts), "data": cs}
    except Exception as e:
        return {"guide": f"오류 {str(e)[:50]}", "best": None, "worst": None, "data": {}}
