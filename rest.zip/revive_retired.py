# -*- coding: utf-8 -*-
"""
♻️ 퇴출 조건식 재심(부활) 도구 (revive_retired.py)
=====================================================
사용자 요청 (2026-09-01): "조건식 대량 퇴출 하였으면 그만큼 찾아서 편입을 시켜야"

하는 일:
  - retired_conditions(퇴출 보관함)의 조건식을 현재 검증 로직으로 다시 시험
  - '채택 후보/조건부' 등급 + 매매 20건 이상이면 → 대기(backlog)로 부활
    (바로 운영 아님 - lifecycle 승격 절차를 다시 밟음. 과적합 방지 규율 유지)
  - 재심 이력은 strategy/revive_state.json에 기록 (같은 걸 반복 재심 안 함 -
    기본 30일 지나야 재재심)

왜 필요한가:
  - 예전 grade_condition 버그(지수 비교 반전) 시절에 매겨진 등급으로
    퇴출된 조건식이 있을 수 있음 → 고친 검증으로 다시 보면 살릴 수 있음
  - 시장이 변하면 예전에 기각된 스타일이 다시 통할 수도 있음 (분기 재심 가치)

실행:
  python revive_retired.py --list              # 퇴출 보관함 목록
  python revive_retired.py --run               # 재심 5개 (오래된 것부터)
  python revive_retired.py --run --max 20      # 20개 재심
  python revive_retired.py --run --max-symbols 400   # 더 엄밀히 (느림)

자동: lifecycle이 충원모드(운영 조건식 < LC_MIN_ACTIVE)일 때 라운드마다 몇 개씩 재심
"""
import argparse
import json
import logging
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import sys

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

log = logging.getLogger("revive")

STATE_PATH = os.path.join("strategy", "revive_state.json")
REVIVE_GRADES = ("채택 후보", "조건부")          # 부활 허용 등급 (lifecycle 승격과 동일)
RECHECK_DAYS = _cfg_env_int("REVIVE_RECHECK_DAYS", 30)   # 같은 조건식 재재심 최소 간격


def _load_state():
    try:
        with open(STATE_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"checked": {}, "revived": []}


def _save_state(st):
    try:
        os.makedirs("strategy", exist_ok=True)
        with open(STATE_PATH, "w", encoding="utf-8") as f:
            json.dump(st, f, ensure_ascii=False, indent=1)
    except Exception:
        pass


def list_retired():
    """퇴출 보관함 전체 (오래된 순)"""
    try:
        with db.get_conn() as conn:
            rows = conn.execute(
                "SELECT * FROM retired_conditions ORDER BY retired_at").fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


def revive_batch(max_n=5, max_symbols=200, log_fn=None):
    """퇴출분 max_n개 재심 → 통과하면 backlog 부활. 반환 요약 dict"""
    def L(m):
        log.info(m)
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    from validation import validate_condition, save_validation_results
    from datetime import datetime, timedelta

    st = _load_state()
    checked = st.setdefault("checked", {})
    cut = (db.now_kst() - timedelta(days=RECHECK_DAYS)).isoformat()

    rows = list_retired()
    if not rows:
        return {"checked": 0, "revived": [], "note": "퇴출 보관함 비어있음"}

    # 최근 재심 안 한 것부터 (한 번도 안 한 것 최우선)
    todo = [r for r in rows if (checked.get(str(r["cond_key"])) or "") < cut]
    todo.sort(key=lambda r: checked.get(str(r["cond_key"]), ""))
    if not todo:
        return {"checked": 0, "revived": [],
                "note": f"전부 {RECHECK_DAYS}일 내 재심 완료 (대기)"}

    out = {"checked": 0, "revived": [], "results": []}
    val_results = []
    for r in todo[:max_n]:
        ck = str(r["cond_key"])
        try:
            slots = json.loads(r.get("slots_json") or "[]")
        except Exception:
            slots = []
        if not slots:
            checked[ck] = db.now_kst_iso()
            continue
        try:
            v = validate_condition({"cond_key": ck,
                                    "cond_txt": r.get("cond_txt", ""),
                                    "slots": [tuple(s) for s in slots]},
                                   max_symbols=max_symbols)
            val_results.append(v)
            grade = v.get("grade") or ""
            trades = (v.get("stats") or {}).get("trades") or v.get("trades") or 0
            out["checked"] += 1
            checked[ck] = db.now_kst_iso()
            out["results"].append({"cond_key": ck, "grade": grade, "trades": trades,
                                   "txt": (r.get("cond_txt") or "")[:40]})
            if grade in REVIVE_GRADES and trades >= 20:
                # ── 부활: conditions.status → backlog + 보관함에서 제거 ──
                with db.get_conn() as conn:
                    row = conn.execute("SELECT id, status FROM conditions WHERE id=?",
                                       (int(ck),)).fetchone() if ck.isdigit() else None
                    if row:
                        conn.execute("UPDATE conditions SET status='backlog' WHERE id=?",
                                     (row["id"],))
                    else:
                        # conditions 행이 없으면 재등록 (번호 새로 발급)
                        no = db.next_cond_no()
                        cid = db.create_condition(no, r.get("cond_txt", ""),
                                                  [tuple(s) for s in slots],
                                                  source="revive")
                        db.set_condition_status(cid, "backlog")
                    conn.execute("DELETE FROM retired_conditions WHERE cond_key=?", (ck,))
                out["revived"].append(ck)
                st.setdefault("revived", []).append(
                    {"cond_key": ck, "at": db.now_kst_iso(), "grade": grade,
                     "trades": trades, "txt": (r.get("cond_txt") or "")[:40]})
                L(f"♻️🌱 부활: [{(r.get('cond_txt') or '')[:36]}] {grade}·{trades}건 "
                  f"→ 대기(backlog) 복귀 (lifecycle 승격 절차 재개)")
            else:
                L(f"♻️ 재심 유지퇴출: [{(r.get('cond_txt') or '')[:36]}] "
                  f"{grade or '등급없음'}·{trades}건")
        except Exception as e:
            L(f"⚠️ 재심 실패 {ck}: {str(e)[:50]}")
            checked[ck] = db.now_kst_iso()

    if val_results:
        try:
            save_validation_results(val_results)
        except Exception:
            pass
    _save_state(st)
    if out["revived"]:
        L(f"♻️ 재심 {out['checked']}건 → 부활 {len(out['revived'])}건")
    return out


def main():
    ap = argparse.ArgumentParser(description="퇴출 조건식 재심/부활")
    ap.add_argument("--list", action="store_true", help="퇴출 보관함 목록")
    ap.add_argument("--run", action="store_true", help="재심 실행")
    ap.add_argument("--max", type=int, default=5, help="재심 개수 (기본 5)")
    ap.add_argument("--max-symbols", type=int, default=200, help="검증 종목 수 (기본 200)")
    args = ap.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(message)s")
    db.init_db()

    if args.list:
        rows = list_retired()
        if not rows:
            print("퇴출 보관함이 비어 있습니다.")
            return
        st = _load_state()
        print(f"🗑 퇴출 보관함 {len(rows)}개 (오래된 순):")
        for r in rows:
            ck = str(r["cond_key"])
            last = (st.get("checked", {}).get(ck) or "")[:10] or "재심 전"
            print(f"  {ck:>5} | {(r.get('retired_at') or '')[:10]} 퇴출 | "
                  f"재심 {last} | {r.get('reason', '')[:16]} | {(r.get('cond_txt') or '')[:44]}")
        return

    if args.run:
        r = revive_batch(max_n=args.max, max_symbols=args.max_symbols)
        print(f"\n재심 {r['checked']}건 · 부활 {len(r['revived'])}건")
        if r.get("note"):
            print(f"({r['note']})")
        return

    ap.print_help()


if __name__ == "__main__":
    main()
