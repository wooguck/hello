# -*- coding: utf-8 -*-
"""
🚦 데이터 품질 자동 게이트 (quality_gate.py) - 2026-08-27 추가
================================================================
문제: 데이터가 썩어 있으면(오래됨/이상 봉/구멍) 그 위의 검증·매매 판단이 전부 오염됨.
지금까지는 data_audit를 '수동으로' 돌려야 알 수 있었음.

해결: 라운드마다 자동으로 4가지를 빠르게 검사(수 초).
  [1] 신선도  : 최신 일봉이 마지막 거래일 대비 며칠 뒤졌는지 (3일+ = 🔴)
  [2] 이상 봉 : high < low, 종가 0/음수, 하루 ±40% 초과(상하한 불가능) 표본 검사
  [3] 커버리지: 최근 5거래일 봉이 있는 종목 비율 (50% 미만 = 🔴)
  [4] 중복 봉 : 같은 날짜 일봉 2개 이상 (INSERT OR REPLACE 실패 흔적)

결과: {"level": "ok"|"warn"|"bad", "issues": [...], "checked": n}
  - bad면 teams 라운드가 검증 단계를 건너뜀 (썩은 데이터로 등급 매기지 않음)
  - 매도/손절/가드는 데이터 품질과 무관하게 계속 (안전장치는 안 멈춤)

단독 실행: python quality_gate.py
"""
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import random
import sys

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

SAMPLE_N = _cfg_env_int("QGATE_SAMPLE", 80)       # 표본 종목 수 (전수는 느림)
STALE_BAD_DAYS = _cfg_env_int("QGATE_STALE_DAYS", 3)  # 최신봉 지연 허용 (거래일)


def _trading_days_back(n=10):
    """최근 거래일 n개 (달력 테이블 기반, 없으면 주말 제외 근사)"""
    try:
        from db import recent_trading_days
        return recent_trading_days(n)
    except Exception:
        pass
    from datetime import timedelta
    out, d = [], db.now_kst().date()
    while len(out) < n:
        if d.weekday() < 5:
            out.append(d.strftime("%Y-%m-%d"))
        d -= timedelta(days=1)
    return out


def run(sample_n=None, log_fn=None):
    """품질 게이트 1회 실행. 반환 {"level","issues","checked","fresh_ratio"}"""
    def _log(m):
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    sample_n = sample_n or SAMPLE_N
    issues = []
    # 종목 파일 목록
    try:
        from db import stock_db_dir
        base = stock_db_dir()
    except Exception:
        base = os.path.join("data", "stocks")
    files = []
    if os.path.isdir(base):
        files = [f for f in os.listdir(base) if f.endswith(".db")]
    if not files:
        return {"level": "bad", "issues": ["종목 데이터 파일 0개 - 수집부터 필요"],
                "checked": 0, "fresh_ratio": 0.0}

    rng = random.Random(20260827)  # 재현성 (같은 데이터면 같은 결과)
    sample = rng.sample(files, min(sample_n, len(files)))
    days = _trading_days_back(10)
    recent5 = set(days[:5])
    last_td = days[0] if days else None

    fresh = 0
    anom = []
    dup = []
    latest_seen = ""
    for fn in sample:
        sym = fn.replace(".db", "")
        try:
            bars = db.get_stock_daily(sym, max_days=30)
        except Exception:
            continue
        if not bars:
            continue
        # [1]/[3] 신선도·커버리지
        dts = [b["date"] for b in bars]
        latest_seen = max(latest_seen, dts[-1])
        if any(d in recent5 for d in dts):
            fresh += 1
        # [2] 이상 봉 (최근 30봉만 - 빠르게)
        for b in bars:
            c, h, lo = b.get("close") or 0, b.get("high") or 0, b.get("low") or 0
            if c <= 0:
                anom.append(f"{sym} {b['date']} 종가 {c}")
                break
            if h and lo and h < lo:
                anom.append(f"{sym} {b['date']} 고가<저가")
                break
        for i in range(1, len(bars)):
            p, c = bars[i - 1].get("close") or 0, bars[i].get("close") or 0
            if p > 0 and c > 0 and abs(c / p - 1) > 0.40:
                anom.append(f"{sym} {bars[i]['date']} 하루 {((c/p)-1)*100:+.0f}% (상하한 불가능)")
                break
        # [4] 중복 날짜
        if len(dts) != len(set(dts)):
            dup.append(sym)

    checked = len(sample)
    fresh_ratio = fresh / checked if checked else 0.0

    level = "ok"
    if last_td and latest_seen and latest_seen < last_td:
        # 전체 최신봉이 마지막 거래일보다 뒤졌는지 (표본 최대 기준)
        gap = sum(1 for d in days if latest_seen < d)
        if gap >= STALE_BAD_DAYS:
            issues.append(f"최신 일봉 {latest_seen} - 마지막 거래일 대비 {gap}거래일 뒤짐")
            level = "bad"
        elif gap >= 1:
            issues.append(f"최신 일봉 {latest_seen} ({gap}거래일 지연 - 수집 확인)")
            level = "warn"
    if fresh_ratio < 0.5:
        issues.append(f"최근 5거래일 봉 보유 종목 {fresh_ratio*100:.0f}% (<50%) - 수집 구멍")
        level = "bad"
    elif fresh_ratio < 0.8 and level == "ok":
        issues.append(f"최근 5거래일 커버리지 {fresh_ratio*100:.0f}% (80% 미만 주의)")
        level = "warn"
    if anom:
        issues.append(f"이상 봉 {len(anom)}건: " + " / ".join(anom[:3]))
        if len(anom) >= max(3, checked // 10):
            level = "bad"
        elif level == "ok":
            level = "warn"
    if dup:
        issues.append(f"중복 날짜 봉 {len(dup)}종목: {dup[:5]}")
        if level == "ok":
            level = "warn"

    icon = {"ok": "🟢", "warn": "🟡", "bad": "🔴"}[level]
    _log(f"🚦 [품질게이트] {icon} {level.upper()} · 표본 {checked}종목 · "
         f"커버리지 {fresh_ratio*100:.0f}%" + (f" · {issues[0]}" if issues else ""))
    return {"level": level, "issues": issues, "checked": checked,
            "fresh_ratio": round(fresh_ratio, 3)}


if __name__ == "__main__":
    r = run(log_fn=print)
    print()
    print(f"판정: {r['level']}")
    for i in r["issues"]:
        print(" -", i)
    if not r["issues"]:
        print(" 이상 없음")
