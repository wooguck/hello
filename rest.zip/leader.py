# -*- coding: utf-8 -*-
"""
👑 AI 대장주 공략 (leader.py)
==============================
검색식에 편입된 종목들 중에서 '오늘 가장 강한 종목(대장주)'만 골라 저점매수.

아이디어 (사용자):
  "내 검색식에 편입된 종목들 중에 가장 강력한 애들만 매수할 수 없냐.
   그 종목들의 테마와 거래대금 등을 분석해서 오늘 어떤 테마가 뜨는지,
   어느 종목이 대장주인지 파악해서 한두 종목 저점매수 공략"

핵심 (공개 API로 실현 — 키 불필요):
  1) 실시간 시세: fchart 최신 봉(당일 시/고/저/종/거래량) + m.stock 개별 basic(현재가/등락률)
  2) 대장주 스코어(0~100):
     - 저점 위치 (고가 대비 하락폭 - 저점매수 자리, 40점)
     - 등락률 강도 (0초과·상한가 직전 제외, 20점)
     - 거래량 급증 (최근 5일 평균 대비, 20점)
     - 거래대금 규모 (종가×거래량, 20점)
  3) AI(Gemini)가 후보 데이터를 보고 '오늘 대장주 1~2개' 최종 선택 (키 없으면 규칙 상위)
  4) 선택된 종목만 진입 (고가 추종 방지 - 가격필터·등락률 상한 포함)

사용: paper_test._paper_execute 에서 LEADER_ENABLED=true 면 자동 적용.
"""
import json
import logging
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import re
import time

import requests

log = logging.getLogger("leader")

# ── 설정 (.env) ──
LEADER_ENABLED = os.getenv("LEADER_ENABLED", "true").lower() == "true"
LEADER_MAX = _cfg_env_int("LEADER_MAX", 2)            # 선별할 대장주 수 (한두 종목)
LEADER_MIN_SCORE = _cfg_env_float("LEADER_MIN_SCORE", 40)  # 최소 스코어
LEADER_AI = os.getenv("LEADER_AI", "true").lower() == "true"   # AI 최종 선택 (키 없으면 규칙)
LEADER_CHG_MAX = _cfg_env_float("LEADER_CHG_MAX", 15.0)    # 등락률 상한 (과열 제외)
LEADER_DIP_MIN = _cfg_env_float("LEADER_DIP_MIN", 1.0)     # 고가 대비 최소 하락폭 % (저점매수)


def fetch_live_quote(symbol: str):
    """개별 종목 실시간 시세 - 키 불필요 (네이버 공개)
    반환: {"symbol", "name", "price"(현재가), "chg_pct"(등락률),
           "open", "high", "low", "volume", "amount"(≈거래대금), "date"} / None
    """
    try:
        # 1) fchart 최신 일봉 (당일 시/고/저/종/거래량 실시간 갱신)
        r = requests.get(
            f"https://fchart.stock.naver.com/sise.nhn?symbol={symbol}"
            f"&timeframe=day&count=6&requestType=0",
            headers={"User-Agent": "Mozilla/5.0"}, timeout=8)
        items = re.findall(r'<item data="([^"]+)"', r.text) if r.status_code == 200 else []
        if not items:
            return None
        last = items[-1].split("|")
        if len(last) < 6:
            return None
        d = last[0]
        o, h, l, c, v = (float(last[1]), float(last[2]), float(last[3]),
                         float(last[4]), float(last[5]))
        # 2) 현재가/등락률 (개별 basic)
        name = symbol
        chg = None
        try:
            r2 = requests.get(f"https://m.stock.naver.com/api/stock/{symbol}/basic",
                              headers={"User-Agent": "Mozilla/5.0"}, timeout=8)
            if r2.status_code == 200:
                d2 = r2.json()
                name = d2.get("stockName") or symbol
                try:
                    chg = float(str(d2.get("fluctuationsRatio", "0")).replace(",", ""))
                except Exception:
                    chg = None
        except Exception:
            pass
        return {"symbol": symbol, "name": name, "price": c,
                "chg_pct": chg, "open": o, "high": h, "low": l,
                "volume": v, "amount": round(c * v), "date": d}
    except Exception as e:
        log.warning(f"실시간 시세 실패 {symbol}: {e}")
        return None


def leader_score(q: dict, prev_vol_avg: float = None):
    """대장주 스코어 (0~100) - 높을수록 '오늘 강하고 저점인 대장주 후보'
    q: fetch_live_quote 결과
    prev_vol_avg: 최근 5일 평균 거래량 (없으면 거래량 점수 중립)
    """
    if not q:
        return 0.0
    score = 0.0
    detail = []
    price = q["price"]
    high, low, open_ = q["high"], q["low"], q["open"]
    # 1) 저점 위치 (40점): 고가 대비 현재가 하락폭이 1%~8% 사이 = 저점매수 자리
    rng = high - low if high > low else 0
    if rng > 0 and price > 0:
        dip = (high - price) / rng * 100   # 고가에서 얼마나 내려왔나 (%)
        if dip >= LEADER_DIP_MIN and dip <= 30:
            score += 40 * (1 - dip / 40)
            detail.append(f"저점({dip:.0f}%)")
        elif dip > 30:
            score += 8  # 너무 떨어진 건 약세일 수도
            detail.append("깊은하락")
        else:
            score += 10  # 고가 근처 = 추격 위험
            detail.append("고가근접")
    # 2) 등락률 강도 (20점): 0 초과 ~ 상한가 직전
    chg = q.get("chg_pct")
    if chg is not None:
        if 0 < chg <= LEADER_CHG_MAX:
            score += 20 * min(1.0, chg / 5.0)
            detail.append(f"등락+{chg:.1f}%")
        elif chg > LEADER_CHG_MAX:
            score += 3
            detail.append("과열제외")
        elif chg <= -1.0:
            score -= 10
            detail.append(f"하락{chg:.1f}%")
        else:
            score += 5
            detail.append(f"등락{chg:+.1f}%")
    # 3) 거래량 급증 (20점): 최근 5일 평균 대비
    if prev_vol_avg and prev_vol_avg > 0 and q["volume"] > 0:
        vratio = q["volume"] / prev_vol_avg
        if vratio >= 1.5:
            score += 20 * min(1.0, vratio / 3.0)
            detail.append(f"거래량{vratio:.1f}배")
        elif vratio >= 1.0:
            score += 10
            detail.append(f"거래량{vratio:.1f}배")
    # 4) 거래대금 규모 (20점): 3억 이상 유동성 + 클수록 + (절대 원)
    amt = q.get("amount") or 0
    if amt >= 300_000_000:
        score += 20 * min(1.0, amt / 1_000_000_000)
        detail.append(f"대금{amt/1e8:.1f}억")
    elif amt >= 50_000_000:
        score += 6
        detail.append(f"대금{amt/1e8:.1f}억")
    q["score"] = round(max(0.0, min(100.0, score)), 1)
    q["detail"] = ", ".join(detail)
    return q["score"]


def _prev_vol_avg(symbol, days=5):
    """최근 N일 평균 거래량 (fchart) - 없으면 None"""
    try:
        r = requests.get(f"https://fchart.stock.naver.com/sise.nhn?symbol={symbol}"
                         f"&timeframe=day&count={days + 1}&requestType=0",
                         headers={"User-Agent": "Mozilla/5.0"}, timeout=8)
        items = re.findall(r'<item data="([^"]+)"', r.text) if r.status_code == 200 else []
        vols = []
        for it in items[:-1]:  # 오늘 제외
            f = it.split("|")
            if len(f) >= 6:
                try:
                    vols.append(float(f[5]))
                except Exception:
                    continue
        return sum(vols) / len(vols) if vols else None
    except Exception:
        return None


def score_symbols(symbols, limit=50):
    """여러 종목 대장주 스코어 - 실시간 시세 기반
    반환: [{symbol, name, price, chg_pct, score, detail, ...}] 점수 내림차순
    """
    out = []
    for sym in symbols[:limit]:
        q = fetch_live_quote(sym)
        if not q:
            continue
        pv = _prev_vol_avg(sym)
        leader_score(q, pv)
        out.append(q)
        time.sleep(0.05)
    out.sort(key=lambda x: -(x.get("score") or 0))
    return out


def _pick_by_rule(scored, n):
    """규칙 선택: 스코어 상위 + 최소 점수 통과"""
    picks = []
    for s in scored:
        if len(picks) >= n:
            break
        if (s.get("score") or 0) >= LEADER_MIN_SCORE:
            picks.append(s)
    return picks


def _pick_by_ai(scored, n):
    """AI(Gemini) 최종 선택 - 후보 실시간 데이터를 보고 '오늘 대장주' 고름
    실패/키 없으면 규칙 폴백
    """
    if not scored:
        return []
    try:
        from ai_consult import _gemini_rest
    except Exception:
        return _pick_by_rule(scored, n)
    lines = []
    for i, s in enumerate(scored[:15], 1):
        chg = s.get("chg_pct")
        chg_txt = f"{chg:+.2f}%" if chg is not None else "?"
        lines.append(f"{i}. {s['symbol']} {s['name']} | 현재가 {s['price']:,.0f} | "
                     f"등락 {chg_txt} | 시 {s.get('open', 0):,.0f} 고 {s.get('high', 0):,.0f} "
                     f"저 {s.get('low', 0):,.0f} | 거래대금 {s.get('amount', 0) / 1e8:.1f}억 | "
                     f"스코어 {s.get('score', 0)} ({s.get('detail', '')})")
    system = ("당신은 한국 주식 '대장주 공략' 전문가입니다. 오늘 장에서 가장 강한 테마를 이끄는 "
              "종목을 고르세요. 종목코드만 JSON 배열로 출력하세요.")
    prompt = (
        "아래는 조건검색식에 편입된 종목들의 오늘(실시간) 데이터입니다.\n"
        f"{chr(10).join(lines)}\n\n"
        "이 중 '오늘 대장주' 후보를 최대 2개 골라주세요.\n"
        "대장주 기준: 등락률이 강하고(플러스), 거래대금이 크고(시장을 이끄는),\n"
        "고가 대비 적당히 빠져 저점매수 자리에 있는 종목.\n"
        f'응답 형식(JSON만): ["005930", "042700"]'
    )
    try:
        txt = _gemini_rest(prompt, system)
        m = re.search(r"\[.*\]", txt, re.S)
        if m:
            codes = json.loads(m.group(0))
            picked = [s for s in scored if s["symbol"] in codes]
            if picked:
                return picked
    except Exception:
        pass
    return _pick_by_rule(scored, n)


def pick_leaders(symbols, n=None):
    """★ 대장주 선별 파이프라인: 스코어링 → (AI or 규칙) 선택
    symbols: 신호 종목 코드 목록
    반환: {"picks": [선택된 종목 dict...], "scored": [전체 스코어...], "note": str}
    """
    if n is None:
        n = LEADER_MAX
    if not symbols:
        return {"picks": [], "scored": [], "note": "신호 종목 없음"}
    scored = score_symbols(symbols)
    if not scored:
        return {"picks": [], "scored": [], "note": "실시간 시세 수집 실패"}
    if LEADER_AI:
        picks = _pick_by_ai(scored, n)
        note = "AI 선택" if len(picks) > 0 and any(s.get("chg_pct") is not None for s in scored) else "규칙 선택"
        if not picks:
            picks = _pick_by_rule(scored, n)
            note = "AI 응답 없음 → 규칙 선택"
    else:
        picks = _pick_by_rule(scored, n)
        note = "규칙 선택"
    return {"picks": picks, "scored": scored,
            "note": f"{note} · 스코어 상위 {len(scored)}개 중 {len(picks)}개 선택"}
