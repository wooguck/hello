"""유전 알고리즘 - 선택(selection) / 교차(crossover) / 돌연변이(mutation)"""
import random
from strategy import PARAM_RANGES, PARAM_STEPS, random_params


def select_survivors(strategies_with_fitness: list, survivor_count: int) -> list:
    if not strategies_with_fitness:
        return []
    ranked = sorted(strategies_with_fitness, key=lambda s: s.get("fitness", -9999), reverse=True)
    return ranked[:survivor_count]


def crossover(params_a: dict, params_b: dict) -> dict:
    child = {}
    for key in PARAM_RANGES:
        val = random.choice([params_a.get(key), params_b.get(key)])
        if val is None:
            lo, hi = PARAM_RANGES[key]
            if isinstance(lo, int):
                val = random.randint(lo, hi)
            else:
                val = round(random.uniform(lo, hi), 2)
        child[key] = val
    return child


def mutate(params: dict, mutation_rate: float) -> dict:
    """
    각 파라미터가 mutation_rate 확률로 의미 있는 단위(step)로 변형.
    - 정수형(EMA/RSI기간/보유일) : 1 단위
    - % 파라미터(손절/익절/트레일링) : 0.5% 단위
    - 배수 파라미터(거래량/변동성) : 0.1 단위
    - 체결강도 기준 : 5 단위
    0.01 단위 마이크로 변이는 하지 않는다 (과적합/의미없는 수치 방지).
    """
    mutated = dict(params)
    for key, (lo, hi) in PARAM_RANGES.items():
        if random.random() < mutation_rate:
            step = PARAM_STEPS.get(key, 1)
            n_steps = random.randint(1, 3)  # 한 번에 1~3 스텝 이동
            direction = random.choice([-1, 1])
            current = mutated.get(key, (lo + hi) / 2)
            new_val = current + direction * step * n_steps
            new_val = max(lo, min(hi, new_val))
            if isinstance(lo, int) and isinstance(hi, int):
                mutated[key] = int(round(new_val))
            else:
                mutated[key] = round(new_val, 2)
    # 파라미터 간 논리 보정
    if mutated.get("ema_fast", 0) >= mutated.get("ema_slow", 100):
        mutated["ema_slow"] = min(PARAM_RANGES["ema_slow"][1], mutated["ema_fast"] + random.randint(1, 10))
        mutated["ema_fast"] = max(PARAM_RANGES["ema_fast"][0], mutated["ema_slow"] - 5)
    if mutated.get("rsi_buy", 30) >= mutated.get("rsi_sell", 70):
        mutated["rsi_buy"] = min(40, mutated["rsi_sell"] - 5)
    return mutated


def next_generation(survivors: list, population_size: int, mutation_rate: float) -> list:
    if not survivors:
        return [random_params() for _ in range(population_size)]
    next_gen_params = [s["params"] for s in survivors]
    while len(next_gen_params) < population_size:
        if len(survivors) >= 2:
            parent_a, parent_b = random.sample(survivors, 2)
        else:
            parent_a = parent_b = survivors[0]
        child = crossover(parent_a["params"], parent_b["params"])
        child = mutate(child, mutation_rate)
        next_gen_params.append(child)
    return next_gen_params
