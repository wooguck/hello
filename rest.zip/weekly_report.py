# -*- coding: utf-8 -*-
"""
📅 주간 리포트 (weekly_report.py)
=================================
매주 주말에 자동 생성 - "AI 판단 넣은 것 vs 안 넣은 것" 비교 결과와
주간 매매 성과를 정리해, 다음 주 프롬프트/설정 수정 방향을 제안합니다.

수정 반영은 **사용자 허락 후** (자동 적용 없음 - 앱에서 확인 후 반영)

실행:
  python weekly_report.py            # 이번 주 리포트 생성
  python weekly_report.py --week 2026-08-17   # 특정 주(월요일 날짜) 리포트
  python weekly_report.py --list     # 지난 리포트 목록
"""
import argparse
import json
import os
import sys
from datetime import datetime, timedelta

import db
from db import now_kst, now_kst_iso

REPORTS_DIR = os.path.join("reports", "weekly")
STATE_FILE = os.path.join("strategy", "weekly_report.json")

# ── 주(week) 시작(월요일) 계산 ──────────────────────
def week_start(d=None):
    d = d or now_kst()
    return (d - timedelta(days=d.weekday())).date()


def last_week_start(d=None):
    return week_start(d) - timedelta(days=7)


def weekly_trade_stats(start_iso, end_iso):
    """해당 주(월~금)에 청산된 거래 통계 + AI vs 규칙 그룹별 비교
    반환: {total: {...}, ai: {...}, rule: {...}, by_kind: {...}}
    """
    out = {"total": {"trades": 0, "win": 0, "loss": 0, "win_rate": 0,
                     "sum_ret": 0.0, "avg_ret": 0.0, "max_loss": 0.0},
           "ai": None, "rule": None}
    try:
        with db.get_conn() as c:
            rows = c.execute(
                "SELECT * FROM paper_positions WHERE status='closed' "
                "AND exit_time>=? AND exit_time<?", (start_iso, end_iso)).fetchall()
        rows = [dict(r) for r in rows]
    except Exception:
        return out

    def _grp(rs):
        if not rs:
            return None
        wins = [r for r in rs if (r.get("ret_pct") or 0) > 0]
        losses = [r for r in rs if (r.get("ret_pct") or 0) <= 0]
        rets = [r.get("ret_pct") or 0 for r in rs]
        return {"trades": len(rs), "win": len(wins), "loss": len(losses),
                "win_rate": round(len(wins) / len(rs) * 100, 1),
                "sum_ret": round(sum(rets), 2),
                "avg_ret": round(sum(rets) / len(rs), 2),
                "max_loss": round(min(rets), 2)}

    out["total"] = _grp(rows) or out["total"]
    # AI 판단 그룹: 청산 사유에 [AI매도] (또는 [AI]) 포함
    ai_rows = [r for r in rows if "[AI" in (r.get("exit_reason") or r.get("sell_plan") or "")
               or "[AI" in (r.get("cond_txt") or "")]
    rule_rows = [r for r in rows if r not in ai_rows]
    out["ai"] = _grp(ai_rows)
    out["rule"] = _grp(rule_rows)
    # 거래 유형별 (수동/검증/신호)
    kinds = {}
    for r in rows:
        k = db.paper_kind_label(r.get("cond_key", ""), r.get("cond_txt", ""))
        kinds.setdefault(k, []).append(r)
    out["by_kind"] = {k: _grp(v) for k, v in kinds.items()}
    return out


# ── ② AI vs 규칙 백테스트 비교 ──────────────────────
def ai_vs_rule_compare(start_iso, end_iso, max_symbols=200):
    try:
        from validation import compare_ai_vs_rule
        r = compare_ai_vs_rule(start=start_iso, end=end_iso, max_symbols=max_symbols)
        return r
    except Exception as e:
        return {"error": str(e)[:100]}


# ── ③ 권장 변경사항 (프롬프트/설정 - 사용자 허락 대기) ──
def build_recommendations(tstats, cmp):
    """비교 결과로 다음 주 수정 권장사항 생성 (자동 적용 안 함 - 허락 필요)"""
    recs = []
    # 매수 AI 게이트 권장
    if cmp and not cmp.get("error"):
        a, b = cmp.get("a", {}), cmp.get("b", {})
        if a.get("trades", 0) >= 5 and b.get("trades", 0) >= 5:
            if a.get("avg_ret", 0) > b.get("avg_ret", 0) + 0.3 and a.get("win_rate", 0) >= b.get("win_rate", 0):
                recs.append({"type": "매수 AI 게이트 ON",
                             "desc": f"AI 넣은 그룹 평균 {a.get('avg_ret')}% > 안 넣은 {b.get('avg_ret')}% "
                                     f"(승률 {a.get('win_rate')}% vs {b.get('win_rate')}%) - "
                                     f"매수 시 AI 판단을 켜보는 것을 권장"})
            elif b.get("avg_ret", 0) > a.get("avg_ret", 0) + 0.3:
                recs.append({"type": "매수 AI 게이트 OFF 유지",
                             "desc": f"AI 안 넣은 그룹 평균 {b.get('avg_ret')}% > AI 넣은 {a.get('avg_ret')}% - "
                                     f"조건식 신호만(현재 방향) 유지 권장"})
            else:
                recs.append({"type": "판단 유지",
                             "desc": f"AI 넣은/안 넣은 차이 미미 (평균 {a.get('avg_ret')}% vs {b.get('avg_ret')}%) - "
                                     f"현재 설정 유지"})
        else:
            recs.append({"type": "표본 부족",
                         "desc": "AI vs 규칙 비교 표본이 아직 부족 - 데이터가 쌓이면 다음 주에 판단"})
    # 매도 AI/규칙 성과
    if tstats.get("ai") and tstats.get("rule"):
        ai, ru = tstats["ai"], tstats["rule"]
        if ai.get("trades", 0) >= 3 and ru.get("trades", 0) >= 3:
            if ai["avg_ret"] > ru["avg_ret"] + 0.2:
                recs.append({"type": "매도 AI 판단 유지",
                             "desc": f"AI 매도 평균 {ai['avg_ret']}% > 규칙 매도 {ru['avg_ret']}% - "
                                     f"매도 AI 판단(현재 ON) 유지 권장"})
            elif ru["avg_ret"] > ai["avg_ret"] + 0.2:
                recs.append({"type": "매도 AI 검토",
                             "desc": f"규칙 매도 평균 {ru['avg_ret']}% > AI 매도 {ai['avg_ret']}% - "
                                     f"매도 프롬프트 수정 또는 AI OFF 검토 필요 (허락 후 반영)"})
    # 프롬프트 개선 후보 (매도 손실 사유에서)
    try:
        with db.get_conn() as c:
            bad = c.execute(
                "SELECT exit_reason, COUNT(*) n FROM paper_positions WHERE status='closed' "
                "AND (ret_pct < 0) GROUP BY exit_reason ORDER BY n DESC LIMIT 3").fetchall()
        for r in bad[:2]:
            recs.append({"type": "프롬프트 개선 후보",
                         "desc": f"손실 사유 빈도 {r[0] or '기타'} {r[1]}회 - 매도 프롬프트 해당 항목 점검 권장"})
    except Exception:
        pass
    return recs


# ── 리포트 생성 ─────────────────────────────────────
def generate_weekly_report(target=None):
    """주간 리포트 생성 (target: 주 시작 날짜 문자열 'YYYY-MM-DD' / None=이번 주)
    반환: {"path": str, "week": str, "summary": {...}}
    """
    ws = week_start(datetime.fromisoformat(target)) if target else week_start()
    we = ws + timedelta(days=7)
    start_iso = f"{ws} 00:00:00"
    end_iso = f"{we} 00:00:00"
    ws_prev = ws - timedelta(days=7)

    os.makedirs(REPORTS_DIR, exist_ok=True)
    tstats = weekly_trade_stats(start_iso, end_iso)
    cmp = ai_vs_rule_compare(f"{ws_prev} 00:00:00", end_iso, max_symbols=200)
    recs = build_recommendations(tstats, cmp)

    # ── 보유 현황 (매도 지침 포함) ──
    hold_lines = []
    try:
        for p in db.get_paper_open():
            plan = (p.get("sell_plan") or "")[:60]
            tgt = p.get("target_price") or 0
            stp = p.get("stop_price") or 0
            hold_lines.append(f"- {p.get('symbol')} {p.get('qty')}주 @{p.get('entry_price', 0):,.0f} "
                              f"· 목표 {tgt:,.0f} / 손절 {stp:,.0f}"
                              + (f" · 지침: {plan}" if plan else ""))
    except Exception:
        pass

    # ── 명예의 전당 상위 ──
    hof_lines = []
    try:
        for h in db.hof_list(limit=5):
            hof_lines.append(f"- {h.get('cond_txt', '')[:40]} "
                             f"승률 {h.get('win_rate', 0):.1f}% PF {h.get('pf', 0):.2f}")
    except Exception:
        pass

    lines = []
    lines.append(f"# 📅 주간 리포트 ({ws} ~ {ws + timedelta(days=4)})")
    lines.append(f"생성 시각: {now_kst():%Y-%m-%d %H:%M}")
    lines.append("")
    lines.append("## ① 이번 주 매매 성과")
    t = tstats["total"]
    lines.append(f"- 거래 {t['trades']}건 · 승률 {t['win_rate']}% · "
                 f"평균 수익률 {t['avg_ret']}% · 최대 손실 {t['max_loss']}%")
    if tstats.get("by_kind"):
        lines.append("- 거래 유형별:")
        for k, v in tstats["by_kind"].items():
            lines.append(f"  - {k}: {v['trades']}건 승률 {v['win_rate']}% 평균 {v['avg_ret']}%")
    lines.append("")
    lines.append("## ② AI 판단 넣은 vs 안 넣은 비교")
    if cmp and not cmp.get("error"):
        a, b = cmp.get("a", {}), cmp.get("b", {})
        lines.append(f"- AI 넣은 그룹 (신뢰도 {cmp.get('ai_threshold', 70)} 이상): "
                     f"{a.get('trades', 0)}건 승률 {a.get('win_rate', 0)}% 평균 {a.get('avg_ret', 0)}% PF {a.get('pf', 0)}")
        lines.append(f"- AI 안 넣은 그룹 (신호 전부): "
                     f"{b.get('trades', 0)}건 승률 {b.get('win_rate', 0)}% 평균 {b.get('avg_ret', 0)}% PF {b.get('pf', 0)}")
        d = cmp.get("diff", {})
        lines.append(f"- 차이: 평균 {d.get('avg_ret', 0):+.2f}% · 승률 {d.get('win_rate', 0):+.1f}% · "
                     f"거래 {d.get('trades', 0):+d}건")
        lines.append(f"- 해석: {cmp.get('note', '')}")
    else:
        lines.append(f"- 비교 실패/표본 부족: {cmp.get('error', '데이터 없음') if cmp else '백테스트 미실행'}")
    if tstats.get("ai") and tstats.get("rule"):
        lines.append(f"- 실매매 기준: AI 매도 {tstats['ai']['trades']}건 승률 {tstats['ai']['win_rate']}% "
                     f"평균 {tstats['ai']['avg_ret']}% · 규칙 매도 {tstats['rule']['trades']}건 "
                     f"승률 {tstats['rule']['win_rate']}% 평균 {tstats['rule']['avg_ret']}%")
    lines.append("")
    lines.append("## ③ 보유 현황 (매도 지침 포함)")
    lines.extend(hold_lines if hold_lines else ["- 보유 없음"])
    lines.append("")
    lines.append("## ④ 명예의 전당 상위")
    lines.extend(hof_lines if hof_lines else ["- 아직 없음"])
    lines.append("")
    lines.append("## ⑤ 권장 변경사항 (⛔ 수정은 사용자 허락 후 반영)")
    if recs:
        for i, r in enumerate(recs, 1):
            lines.append(f"{i}. [{r['type']}] {r['desc']}")
    else:
        lines.append("- 이번 주 권장 변경 없음")
    lines.append("")
    lines.append("---")
    lines.append("*이 리포트는 매주 주말 자동 생성됩니다. 변경사항은 앱에서 직접 확인 후 허락 버튼으로 반영합니다.*")

    fname = f"weekly_{ws}.md"
    fpath = os.path.join(REPORTS_DIR, fname)
    with open(fpath, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    # 상태 저장 (웹 대시보드 표시용)
    summary = {"week": str(ws), "generated_at": now_kst_iso(),
               "trades": t["trades"], "win_rate": t["win_rate"], "avg_ret": t["avg_ret"],
               "ai_vs_rule": cmp, "recommendations": recs,
               "ai_sell": tstats.get("ai"), "rule_sell": tstats.get("rule"),
               "path": fpath}
    try:
        os.makedirs("strategy", exist_ok=True)
        with open(STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2, default=str)
    except Exception:
        pass
    return {"path": fpath, "week": str(ws), "summary": summary}


def list_reports():
    try:
        fs = sorted(f for f in os.listdir(REPORTS_DIR) if f.startswith("weekly_"))
        return [{"file": f, "path": os.path.join(REPORTS_DIR, f)} for f in fs]
    except Exception:
        return []


def get_latest():
    """최근 리포트 요약 (웹/앱 표시용)"""
    try:
        with open(STATE_FILE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="주간 리포트")
    parser.add_argument("--week", default=None, help="주 시작 날짜(월요일) YYYY-MM-DD")
    parser.add_argument("--list", action="store_true", help="지난 리포트 목록")
    args = parser.parse_args()
    db.init_db()
    if args.list:
        for r in list_reports():
            print(f"  {r['file']}")
    else:
        res = generate_weekly_report(target=args.week)
        print(f"📅 주간 리포트 생성: {res['path']}")
        s = res["summary"]
        print(f"   거래 {s['trades']}건 · 승률 {s['win_rate']}% · 평균 {s['avg_ret']}%")
        print(f"   권장사항: {len(s['recommendations'])}건 (허락 후 반영)")
