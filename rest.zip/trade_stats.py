# -*- coding: utf-8 -*-
"""
📈 매매 통계 / 성과 분석 (trade_stats.py)
==========================================
청산 완료된 포지션 기준으로 스크린샷 스타일의 성과 리포트를 출력합니다.

지표:
  - 청산 거래 수 (승/패/본전) · 승률 · 최대 연속 승/패
  - 총 실현손익(원, 수수료·세금 차감 추정) · 거래당 평균
  - 투입금액 대비 수익률 · 평균 수익 / 평균 손실 · 손익비(Profit Factor)
  - 최대 낙폭(MDD, 누적 실현손익 고점 대비) · 최대 수익 / 최대 손실 거래
  - 전략(조건식)별 · 종목별 · 청산사유별 분석

실행:
  python trade_stats.py                # 최근 30일
  python trade_stats.py --days 90      # 최근 90일
  python trade_stats.py --days 0       # 전체 기간
  python trade_stats.py --html         # trade_stats.html 저장 (웹 스타일)
"""
import argparse

_INCLUDE_VIRTUAL = False   # ★ 2026-08-28: 기본 실제모의(real)만 집계. --all이면 가상 포함
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import sys
from datetime import datetime, timedelta

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db
from config import CFG

# 수수료+세금 추정 (왕복): 모의/실전 공통 기본값 - 매도세 0.15% + 수수료 왕복 ~0.03%
FEE_PCT = _cfg_env_float("STATS_FEE_PCT", 0.18)


def load_trades(days=30):
    """청산 완료 포지션 로드 → 거래 리스트"""
    with db.get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM paper_positions WHERE status='closed' "
            + ("" if _INCLUDE_VIRTUAL else "AND order_kind='real' ")
            + "ORDER BY exit_time").fetchall()
    out = []
    cut = (db.now_kst() - timedelta(days=days)).isoformat() if days else ""
    for r in rows:
        r = dict(r)
        if days and (r.get("exit_time") or "") < cut:
            continue
        ep = r.get("entry_price") or 0
        xp = r.get("exit_price") or 0
        qty = r.get("qty") or 0
        if ep <= 0 or xp <= 0 or qty <= 0:
            continue
        gross = (xp - ep) * qty
        fee = (ep + xp) * qty * (FEE_PCT / 200)  # 왕복 절반씩
        pnl = gross - fee
        invested = ep * qty
        out.append({
            "symbol": r.get("symbol", ""),
            "cond": (r.get("cond_txt") or r.get("cond_key") or "")[:30],
            "cond_key": r.get("cond_key") or "",
            "entry_time": r.get("entry_time") or "",
            "exit_time": r.get("exit_time") or "",
            "ret_pct": r.get("ret_pct") or ((xp / ep - 1) * 100),
            "pnl": pnl,
            "invested": invested,
            "reason": (r.get("exit_reason") or "")[:20],
        })
    return out


def _streaks(trades):
    """최대 연속 승 / 연속 패"""
    max_w = max_l = cur_w = cur_l = 0
    for t in trades:
        if t["pnl"] > 0:
            cur_w += 1; cur_l = 0
        elif t["pnl"] < 0:
            cur_l += 1; cur_w = 0
        else:
            cur_w = cur_l = 0
        max_w = max(max_w, cur_w)
        max_l = max(max_l, cur_l)
    return max_w, max_l


def _mdd(trades):
    """누적 실현손익 곡선의 최대 낙폭(원)"""
    cum = peak = mdd = 0.0
    for t in trades:
        cum += t["pnl"]
        peak = max(peak, cum)
        mdd = max(mdd, peak - cum)
    return mdd


def _fmt_w(v):
    return f"{v:+,.0f}원"


def summarize(trades):
    n = len(trades)
    if n == 0:
        return None
    wins = [t for t in trades if t["pnl"] > 0]
    losses = [t for t in trades if t["pnl"] < 0]
    flats = n - len(wins) - len(losses)
    win_rate = len(wins) / (len(wins) + len(losses)) * 100 if (wins or losses) else 0
    total_pnl = sum(t["pnl"] for t in trades)
    total_invested = sum(t["invested"] for t in trades)
    avg_win = sum(t["pnl"] for t in wins) / len(wins) if wins else 0
    avg_loss = sum(t["pnl"] for t in losses) / len(losses) if losses else 0
    gross_win = sum(t["pnl"] for t in wins)
    gross_loss = abs(sum(t["pnl"] for t in losses))
    pf = gross_win / gross_loss if gross_loss > 0 else float("inf")
    max_w, max_l = _streaks(trades)
    best = max(trades, key=lambda t: t["pnl"])
    worst = min(trades, key=lambda t: t["pnl"])
    return {
        "n": n, "wins": len(wins), "losses": len(losses), "flats": flats,
        "win_rate": win_rate, "max_w": max_w, "max_l": max_l,
        "total_pnl": total_pnl, "avg_pnl": total_pnl / n,
        "invested": total_invested,
        "roi": total_pnl / total_invested * 100 if total_invested else 0,
        "avg_win": avg_win, "avg_loss": avg_loss, "pf": pf,
        "mdd": _mdd(trades), "best": best, "worst": worst,
    }


def group_stats(trades, key):
    groups = {}
    for t in trades:
        groups.setdefault(t[key] or "(없음)", []).append(t)
    rows = []
    for g, ts in groups.items():
        s = summarize(ts)
        rows.append((g, s))
    rows.sort(key=lambda x: -x[1]["total_pnl"])
    return rows


def main():
    global _INCLUDE_VIRTUAL
    ap = argparse.ArgumentParser()
    ap.add_argument("--all", action="store_true", help="가상기록 포함 (기본: 실제모의만)")
    ap.add_argument("--days", type=int, default=30, help="최근 N일 (0=전체)")
    ap.add_argument("--html", action="store_true", help="trade_stats.html 저장")
    args = ap.parse_args()
    _INCLUDE_VIRTUAL = getattr(args, "all", False)
    if not _INCLUDE_VIRTUAL:
        print("※ 실제모의(real) 체결분만 집계 - 가상기록 포함하려면 --all")

    trades = load_trades(days=args.days)
    period = f"최근 {args.days}일" if args.days else "전체 기간"
    print("=" * 66)
    print(f"📈 매매 통계 / 성과 분석  (청산 완료된 포지션 기준 · {period})")
    print("=" * 66)
    s = summarize(trades)
    if not s:
        print("청산 완료된 거래가 없습니다 (모의매매가 청산을 만들면 여기 집계됩니다)")
        return

    print(f"""
  청산 거래     : {s['n']}건  ({s['wins']}승 {s['losses']}패 {s['flats']}본전)
  승률          : {s['win_rate']:.1f}%   (최대 연속 {s['max_w']}승 / {s['max_l']}패)
  총 실현손익   : {_fmt_w(s['total_pnl'])}  (거래당 평균 {_fmt_w(s['avg_pnl'])})
  투입 대비     : {s['roi']:+.2f}%  (총 투입 {s['invested']:,.0f}원)
  평균 수익/손실: {_fmt_w(s['avg_win'])} / {_fmt_w(s['avg_loss'])}
  손익비 (PF)   : {s['pf']:.2f}
  최대 낙폭(MDD): {s['mdd']:,.0f}원 (누적 실현손익 고점 대비)
  최대 수익/손실: {_fmt_w(s['best']['pnl'])} ({s['best']['symbol']}) / {_fmt_w(s['worst']['pnl'])} ({s['worst']['symbol']})
  ※ 수수료·세금 {FEE_PCT}% 차감 추정치""")

    for title, key in (("전략(조건식)별", "cond"), ("종목별", "symbol"), ("청산 사유별", "reason")):
        rows = group_stats(trades, key)
        print(f"\n  ── {title} " + "─" * (50 - len(title)))
        print(f"  {'구분':30} {'거래':>4} {'승률':>6} {'총손익':>12} {'평균수익률':>8}")
        for g, gs in rows[:12]:
            avg_ret = sum(t['ret_pct'] for t in trades if (t[key] or '(없음)') == g) / gs['n']
            print(f"  {g[:28]:30} {gs['n']:>4} {gs['win_rate']:>5.1f}% {gs['total_pnl']:>+11,.0f} {avg_ret:>+7.2f}%")

    if args.html:
        rows_html = ""
        for g, gs in group_stats(trades, "cond")[:15]:
            color = "#e74c3c" if gs["total_pnl"] > 0 else "#3498db"
            rows_html += (f"<tr><td>{g}</td><td>{gs['n']}</td><td>{gs['win_rate']:.1f}%</td>"
                          f"<td style='color:{color}'>{gs['total_pnl']:+,.0f}</td>"
                          f"<td>{gs['pf']:.2f}</td></tr>")
        html = f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>매매 통계</title>
<style>body{{background:#0d1117;color:#c9d1d9;font-family:'Malgun Gothic',sans-serif;padding:24px}}
.cards{{display:flex;gap:12px;flex-wrap:wrap;margin:16px 0}}
.card{{background:#161b22;border:1px solid #30363d;border-radius:8px;padding:14px 18px;min-width:150px}}
.card .k{{font-size:12px;color:#8b949e}}.card .v{{font-size:20px;font-weight:bold;margin-top:4px}}
.red{{color:#e74c3c}}.blue{{color:#58a6ff}}
table{{border-collapse:collapse;width:100%;margin-top:12px}}
th,td{{border-bottom:1px solid #30363d;padding:8px 10px;text-align:left;font-size:13px}}
th{{color:#8b949e}}</style></head><body>
<h2>📈 매매 통계 / 성과 분석 <small style="color:#8b949e">({period} · 청산 완료 기준)</small></h2>
<div class="cards">
<div class="card"><div class="k">청산 거래</div><div class="v">{s['n']}건</div><div class="k">{s['wins']}승 {s['losses']}패 {s['flats']}본전</div></div>
<div class="card"><div class="k">승률</div><div class="v">{s['win_rate']:.1f}%</div><div class="k">최대 연속 {s['max_w']}승/{s['max_l']}패</div></div>
<div class="card"><div class="k">총 실현손익 (추정)</div><div class="v {'red' if s['total_pnl']>0 else 'blue'}">{s['total_pnl']:+,.0f}원</div><div class="k">거래당 {s['avg_pnl']:+,.0f}원</div></div>
<div class="card"><div class="k">투입 대비 수익률</div><div class="v {'red' if s['roi']>0 else 'blue'}">{s['roi']:+.2f}%</div><div class="k">총 투입 {s['invested']:,.0f}원</div></div>
<div class="card"><div class="k">평균 수익/손실</div><div class="v"><span class="red">{s['avg_win']:+,.0f}</span> / <span class="blue">{s['avg_loss']:+,.0f}</span></div><div class="k">원 단위</div></div>
<div class="card"><div class="k">손익비 (PF)</div><div class="v">{s['pf']:.2f}</div><div class="k">총이익 ÷ 총손실</div></div>
<div class="card"><div class="k">최대 낙폭 (MDD)</div><div class="v blue">{s['mdd']:,.0f}원</div><div class="k">누적 고점 대비</div></div>
</div>
<table><tr><th>전략(조건식)</th><th>거래수</th><th>승률</th><th>총손익(원)</th><th>PF</th></tr>{rows_html}</table>
<p style="color:#8b949e;font-size:12px">※ 실현손익은 수수료·세금 {FEE_PCT}% 차감 추정치. 진행 중(보유) 포지션은 제외.</p>
</body></html>"""
        with open("trade_stats.html", "w", encoding="utf-8") as f:
            f.write(html)
        print("\n📄 저장: trade_stats.html (브라우저로 열면 대시보드 스타일)")


if __name__ == "__main__":
    main()
