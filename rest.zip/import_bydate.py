# -*- coding: utf-8 -*-
"""
📦 구버전 OpenAPI+ 수집분(ByDate CSV) → stock-bot DB 변환 (import_bydate.py) v2
==============================================================================
예전 collector.py(키움 OpenAPI+ OCX)가 저장한 E:/StockData/ByDate/*.csv 를
data/stocks/{symbol}.db 로 변환합니다.

★ v2: 종목별로 모아서 한 번에 저장 (봉마다 DB 열지 않음) - 397개 파일도 몇 분 내
★ 파일마다 진행 표시 (몇 개째인지 실시간 확인 가능)
★ 수정주가 어긋남(액면분할 의심) 자동 감지 → mismatch_symbols.json

구버전 파일 형식:
  {YYYYMMDD}_daily.csv  : code,open,high,low,close,volume,value  (하루치 전 종목)
  {YYYYMMDD}_minute.csv : code,time,open,high,low,close,volume   (분봉)

실행:
  python import_bydate.py --dir E:/StockData/ByDate            # 일봉 전체
  python import_bydate.py --dir E:/StockData/ByDate --minutes  # 분봉도 함께
  python import_bydate.py --dir E:/StockData/ByDate --limit 5  # 테스트: 5개 파일만
"""
import argparse
import csv
import glob
import logging
import os
import sqlite3
import sys
import time
from datetime import datetime

logging.basicConfig(level=logging.WARNING)
try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db


def _log(msg):
    print(msg, flush=True)


def _norm_code(code):
    """종목코드 정규화: 5930 → 005930 (CSV 로드시 앞 0 소실 대비)"""
    s = str(code).strip().replace("A", "")
    if not s or not s.replace(".", "").isdigit():
        return None
    s = s.split(".")[0]
    if len(s) > 6:
        return None
    return s.zfill(6)


def _read_all_daily(files):
    """CSV 전부 읽어 종목별로 모음: {symbol: [(date_iso,o,h,l,c,v,amt), ...]}
    메모리: 3300종목 × 400일 × 7필드 ≈ 수백 MB 이내 - OK
    """
    by_sym = {}
    n_rows = 0
    t0 = time.time()
    for i, path in enumerate(files):
        base = os.path.basename(path)
        d = base.split("_")[0]
        if len(d) != 8 or not d.isdigit():
            continue
        date_iso = f"{d[:4]}-{d[4:6]}-{d[6:8]}"
        try:
            with open(path, encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    code = _norm_code(row.get("code"))
                    if not code:
                        continue
                    try:
                        o = int(float(row.get("open") or 0))
                        h = int(float(row.get("high") or 0))
                        l = int(float(row.get("low") or 0))
                        c = int(float(row.get("close") or 0))
                        v = int(float(row.get("volume") or 0))
                        amt = int(float(row.get("value") or 0)) or c * v
                    except Exception:
                        continue
                    if c <= 0:
                        continue
                    by_sym.setdefault(code, []).append(
                        (date_iso, o or c, h or c, l or c, c, v, amt))
                    n_rows += 1
        except Exception as e:
            _log(f"  ⚠️ {base} 읽기 실패: {str(e)[:60]}")
        # ★ 파일마다 진행 표시 (한 줄 갱신)
        el = time.time() - t0
        sys.stdout.write(f"\r  📖 CSV 읽는 중 {i+1}/{len(files)} · {n_rows:,}봉 · {el:.0f}초   ")
        sys.stdout.flush()
    print()
    return by_sym


def _save_by_symbol(by_sym):
    """종목별 DB에 일괄 저장 (executemany - 종목당 커넥션 1번)
    반환: (저장봉수, mismatch dict)
    """
    stocks_dir = os.path.join(db.DATA_DIR, "stocks")
    os.makedirs(stocks_dir, exist_ok=True)
    mismatch = {}
    total = 0
    now = db.now_kst_iso()
    syms = list(by_sym.keys())
    t0 = time.time()
    for i, sym in enumerate(syms):
        rows = by_sym[sym]
        path = os.path.join(stocks_dir, f"{sym}.db")
        try:
            conn = sqlite3.connect(path, timeout=10)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS daily_bars (
                    bar_date TEXT PRIMARY KEY,
                    open_price REAL, high_price REAL, low_price REAL, close_price REAL,
                    volume REAL, amount REAL, source TEXT, updated_at TEXT
                )""")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS minute_bars (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    bar_time TEXT NOT NULL, price REAL NOT NULL,
                    volume REAL, cum_volume REAL, UNIQUE(bar_time)
                )""")
            # ★ 수정주가 어긋남 검사: 겹치는 날짜 종가 비교 (첫 어긋남만 기록)
            try:
                have = dict(conn.execute(
                    "SELECT bar_date, close_price FROM daily_bars").fetchall())
                for (d, o, h, l, c, v, a) in rows:
                    old = have.get(d)
                    if old and c > 0:
                        diff = abs(old - c) / max(old, c)
                        if diff > 0.02:
                            mismatch[sym] = {"date": d, "old": old, "csv": c}
                            break
            except Exception:
                pass
            conn.executemany(
                "INSERT OR REPLACE INTO daily_bars (bar_date, open_price, high_price, "
                "low_price, close_price, volume, amount, source, updated_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, 'openapi_plus', ?)",
                [(d, o, h, l, c, v, a, now) for (d, o, h, l, c, v, a) in rows])
            conn.commit()
            conn.close()
            total += len(rows)
        except Exception as e:
            _log(f"\n  ⚠️ {sym} 저장 실패: {str(e)[:60]}")
        if (i + 1) % 50 == 0 or i == len(syms) - 1:
            el = time.time() - t0
            sys.stdout.write(f"\r  💾 저장 중 {i+1}/{len(syms)}종목 · {total:,}봉 · {el:.0f}초   ")
            sys.stdout.flush()
    print()
    return total, mismatch


def _flush_minutes(by_sym, conns_dir):
    """모인 분봉을 종목별 DB에 저장하고 메모리 비움. 반환: 저장 봉 수"""
    total = 0
    for sym, rows in by_sym.items():
        path = os.path.join(conns_dir, f"{sym}.db")
        try:
            conn = sqlite3.connect(path, timeout=10)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS minute_bars (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    bar_time TEXT NOT NULL, price REAL NOT NULL,
                    volume REAL, cum_volume REAL, UNIQUE(bar_time)
                )""")
            conn.executemany(
                "INSERT OR IGNORE INTO minute_bars (bar_time, price, volume, cum_volume) "
                "VALUES (?, ?, ?, 0)", rows)
            conn.commit()
            conn.close()
            total += len(rows)
        except Exception as e:
            _log(f"\n  ⚠️ {sym} 분봉 저장 실패: {str(e)[:60]}")
    by_sym.clear()   # ★ 메모리 해제 (7GB CSV MemoryError 방지의 핵심)
    return total


def import_minutes(files, flush_every=10):
    """분봉 CSV → 종목별 DB
    ★ v3: 파일 10개마다 저장+메모리 비움 (기존: 397개 전부 메모리에 쌓다 MemoryError)
    """
    stocks_dir = os.path.join(db.DATA_DIR, "stocks")
    os.makedirs(stocks_dir, exist_ok=True)
    by_sym = {}
    grand_total = 0
    pending_rows = 0
    t0 = time.time()
    for i, path in enumerate(files):
        base = os.path.basename(path)
        d = base.split("_")[0]
        if len(d) != 8 or not d.isdigit():
            continue
        try:
            with open(path, encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    code = _norm_code(row.get("code"))
                    if not code:
                        continue
                    t = str(row.get("time") or "").strip()
                    # ★ 소수점 제거 (pandas가 90100.0 으로 저장한 경우)
                    if t.endswith(".0"):
                        t = t[:-2]
                    # ★ 앞자리 0 소실 복원: 오전 시간대가 CSV에서 90100(5자리)/13(13자리)로
                    #   저장됨 → 6/14자리로 패딩 (이거 때문에 오전 9시대 분봉이 전부 스킵되던 버그)
                    if len(t) in (5, 13):
                        t = "0" + t
                    if len(t) >= 12:
                        bar_time = t[:12]
                    elif len(t) == 6:
                        bar_time = d + t[:4]
                    elif len(t) == 4:
                        bar_time = d + t
                    elif len(t) == 3:          # 901 = 0:09:01? 아님 - 9:01 (HMM)
                        bar_time = d + "0" + t[:1] + t[1:3].zfill(2)
                    else:
                        continue
                    try:
                        c = int(float(row.get("close") or 0))
                        v = int(float(row.get("volume") or 0))
                        bt = datetime.strptime(bar_time, "%Y%m%d%H%M")
                    except Exception:
                        continue
                    if c <= 0:
                        continue
                    by_sym.setdefault(code, []).append((bt.isoformat(), c, v))
                    pending_rows += 1
        except MemoryError:
            _log(f"\n  ⚠️ {base}: 메모리 부족 - 지금까지 모인 것 저장 후 계속")
            grand_total += _flush_minutes(by_sym, stocks_dir)
            pending_rows = 0
        except Exception as e:
            _log(f"\n  ⚠️ {base} 읽기 실패: {type(e).__name__} {str(e)[:60]}")
        # ★ 파일 N개마다(또는 300만 봉 넘으면) 저장 + 메모리 비움
        if (i + 1) % flush_every == 0 or pending_rows > 3_000_000 or i == len(files) - 1:
            saved = _flush_minutes(by_sym, stocks_dir)
            grand_total += saved
            pending_rows = 0
        el = time.time() - t0
        sys.stdout.write(f"\r  📖 분봉 CSV {i+1}/{len(files)} · 저장 {grand_total:,}봉 · {el:.0f}초   ")
        sys.stdout.flush()
    print()
    return grand_total


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True, help="ByDate 폴더 경로 (예: E:/StockData/ByDate)")
    ap.add_argument("--minutes", action="store_true", help="분봉 CSV도 변환")
    ap.add_argument("--only-minutes", action="store_true",
                    help="일봉은 건너뛰고 분봉만 변환 (일봉을 이미 흡수한 경우)")
    ap.add_argument("--limit", type=int, default=0, help="테스트: 파일 N개만")
    args = ap.parse_args()

    mismatch = {}
    by_sym = {}
    if not args.only_minutes:
        daily_files = sorted(glob.glob(os.path.join(args.dir, "*_daily.csv")))
        if args.limit:
            daily_files = daily_files[:args.limit]
        _log(f"📦 일봉 CSV {len(daily_files)}개 발견 - 변환 시작")

        by_sym = _read_all_daily(daily_files)
        _log(f"  → {len(by_sym)}종목 분량 읽음 - 저장 시작")
        total, mismatch = _save_by_symbol(by_sym)
        _log(f"✅ 일봉 변환 완료: {len(by_sym)}종목 {total:,}봉")

    if args.minutes or args.only_minutes:
        minute_files = sorted(glob.glob(os.path.join(args.dir, "*_minute.csv")))
        if args.limit:
            minute_files = minute_files[:args.limit]
        _log(f"📈 분봉 CSV {len(minute_files)}개 - 변환 시작")
        m = import_minutes(minute_files)
        _log(f"✅ 분봉 변환 완료: {m:,}봉")

    # ★ 수정주가 어긋남(액면분할 의심) 보고
    if mismatch:
        _log(f"\n⚠️ 수정주가 어긋남 의심 {len(mismatch)}종목 (CSV 수집 후 액면분할/감자 가능):")
        for sym in list(sorted(mismatch))[:30]:
            mm = mismatch[sym]
            _log(f"   {sym}: {mm['date']} 기존 {mm['old']:,.0f} vs CSV {mm['csv']:,.0f}")
        if len(mismatch) > 30:
            _log(f"   ... 외 {len(mismatch)-30}종목")
        _log("   → 이 종목들은 data/stocks/{종목}.db 를 지우고 collect_data.py로 새로 받기 권장")
        try:
            import json
            with open("mismatch_symbols.json", "w", encoding="utf-8") as f:
                json.dump(mismatch, f, ensure_ascii=False, indent=2)
            _log("   목록 저장: mismatch_symbols.json")
        except Exception:
            pass
    else:
        _log("✅ 수정주가 어긋남 없음 (기존 데이터와 일관)")

    st = db.data_collection_stats()
    _log(f"📊 현재 데이터: 종목 {st['stock_files']}개 · 일봉 {st['daily_bars']:,}봉 · "
         f"분봉 {st['minute_bars']:,}봉 · {st['total_mb']}MB")


if __name__ == "__main__":
    main()
