# -*- coding: utf-8 -*-
"""
📊 감사 보고서 요약 (audit_summary.py)
========================================
data_audit_report.json 을 읽어 "문제 2899종목"의 정체를 분류해 보여줍니다.
(전체 재검사 없이 저장된 보고서만 분석 - 1초)

실행: python audit_summary.py
출력 전체를 복사해서 공유해 주세요.
"""
import json
import os
import sys
from collections import Counter

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def main():
    if not os.path.exists("data_audit_report.json"):
        print("❌ data_audit_report.json 없음 - 먼저 python data_audit.py 실행")
        return
    with open("data_audit_report.json", encoding="utf-8") as f:
        r = json.load(f)

    t = r.get("totals", {})
    print("=" * 60)
    print("📊 감사 보고서 요약")
    print("=" * 60)
    print(f"검사 시각: {r.get('checked_at', '')[:19]}")
    print(f"파일 {t.get('files', 0):,}개 · 일봉 {t.get('daily_bars', 0):,}봉 · "
          f"분봉 {t.get('minute_bars', 0):,}봉 · {t.get('size_mb', 0)}MB")
    print(f"거래일 달력 {t.get('calendar_days', 0)}일 · 유니버스 {t.get('universe', 0)} · "
          f"폐지 {t.get('dead', 0)}")
    print()

    missing = r.get("missing_files", [])
    few = r.get("few_bars", {})
    stale = r.get("stale", {})
    gaps = r.get("gaps", {})
    bad = r.get("bad_values", [])
    broken = r.get("broken_files", [])

    print(f"① 파일 없음      : {len(missing)}")
    print(f"② 봉 부족(<30)   : {len(few)}")
    print(f"③ 오래됨(7일+)   : {len(stale)}")
    print(f"④ 중간 갭(3일+)  : {len(gaps)}")
    print(f"⑤ 값 오류/중복   : {len(bad)}")
    print(f"⑦ 파일 손상      : {len(broken)}")
    print()

    # ③ 오래됨 분포: 마지막 날짜별로 몇 종목인지 (패턴 파악의 핵심)
    if stale:
        dist = Counter(v for v in stale.values())
        print("③ '오래됨' 마지막 날짜 분포 (상위 10):")
        for d, n in dist.most_common(10):
            print(f"    {d}: {n}종목")
        print()

    # ④ 갭 분포: 갭 날짜들이 특정 날짜에 몰려있는지
    if gaps:
        gap_dates = Counter()
        for g in gaps.values():
            for d in g:
                gap_dates[d] += 1
        print("④ '중간 갭' 많이 빠진 날짜 (상위 10):")
        for d, n in gap_dates.most_common(10):
            print(f"    {d}: {n}종목에서 빠짐")
        gap_sizes = Counter(len(g) for g in gaps.values())
        print("   갭 크기 분포:", dict(sorted(gap_sizes.items())[:8]))
        print()

    # 중복 분류 (한 종목이 여러 문제에 겹치는지)
    s_missing, s_few, s_stale, s_gap = set(missing), set(few), set(stale), set(gaps)
    only_gap = s_gap - s_missing - s_few - s_stale
    only_stale = s_stale - s_missing - s_few
    print("🔎 겹침 분석:")
    print(f"   문제 종목 합집합: {len(s_missing | s_few | s_stale | s_gap)}종목")
    print(f"   '갭만' 있는 종목: {len(only_gap)} · '오래됨만': {len(only_stale)}")
    print()
    print("→ 이 출력 전체를 복사해서 공유해 주세요")


if __name__ == "__main__":
    main()
