# -*- coding: utf-8 -*-
"""
📊 시스템 라이브 상태 대시보드 (web_status.py)
=============================================
자동매매 시스템의 현재 상태를 브라우저로 보여주는 미니 웹 서버 (표준 라이브러리만 사용).
Tkinter 데스크톱 앱은 브라우저에서 직접 못 띄우므로, 실시간 상태 확인용으로 제공.

실행:
  python web_status.py            # 0.0.0.0:8000 에서 서빙 (프리뷰 자동 연결)
"""
import json
import logging
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import sqlite3
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

logging.basicConfig(level=logging.WARNING)

PORT = _cfg_env_int("WEB_STATUS_PORT", 8000)

# ★ 실제 계좌 연동 정보 캐시 (60초 - 웹 새로고침마다 키움 API 호출 방지)
_ACCOUNT_CACHE = {"t": 0, "data": None}

# ── 시스템 정보 수집 (실패해도 안전) ─────────────────────
def sys_info():
    info = {}
    try:
        import db
        db.init_db()
        info["universe"] = db.count_universe()
        try:
            st = db.data_collection_stats()
            info["stock_files"] = st.get("stock_files", 0)
            info["daily_bars"] = st.get("daily_bars", 0)
            info["minute_bars"] = st.get("minute_bars", 0)
            info["total_mb"] = st.get("total_mb", 0)
            info["universe"] = st.get("universe", 0)
        except Exception:
            pass
        info["hof"] = len(db.hof_list(ranked_only=True))
        info["hof_total"] = len(db.hof_list(limit=100000, ranked_only=False))
        # 조건식 봉 기준 분포 (사진 조건식 [일]/[주]/[월]/[분])
        try:
            with db.get_conn() as c:
                rows = c.execute("SELECT tf, COUNT(*) n FROM conditions "
                                 "WHERE status='active' GROUP BY tf").fetchall()
            info["tf"] = {r["tf"] or "day": r["n"] for r in rows}
        except Exception:
            info["tf"] = {}
        # 다음날 모의투자 예약 수
        try:
            info["sched"] = len(db.get_scheduled_paper())
        except Exception:
            info["sched"] = 0
        # 지수×시간대 분석 요약
        try:
            it = db.index_time_stats(min_sells=3)
            info["time_analysis"] = it.get("rows", [])
            info["time_best"] = it.get("best", [])
        except Exception:
            info["time_analysis"], info["time_best"] = [], []
        # 저평가 추적 요약
        try:
            info["value_watch"] = db.value_watch_stats()
        except Exception:
            info["value_watch"] = {"watching": 0, "up": 0, "avg_peak_return": 0}
        # 급등 유전자 결과
        try:
            import json as _json, os as _os
            gp = _os.path.join("strategy", "surge_genes.json")
            if _os.path.exists(gp):
                gd = _json.load(open(gp, encoding="utf-8"))
                info["surge_genes"] = {"surge": gd.get("surge_count", 0),
                                       "symbols": gd.get("symbols", 0),
                                       "genes": gd.get("genes", [])[:4],
                                       "cands": gd.get("candidates", [])[:3]}
            else:
                info["surge_genes"] = None
            # 등록된 급등유전자 조건식 수
            _gn = 0
            for _c in db.get_conditions(status="active"):
                if _c.get("cond_no", "").startswith("S") and "급등유전자" in (_c.get("cond_txt") or ""):
                    _gn += 1
            info["surge_registered"] = _gn
        except Exception:
            info["surge_genes"], info["surge_registered"] = None, 0
        # 펀더멘털 (관심 종목 - 네이버 폴백, 가벼움)
        try:
            import fundamentals as _f
            fund_rows = []
            for _sym in ("005930", "000660", "042700"):
                fd = _f.naver_fundamentals(_sym)
                if fd and (fd.get("PER") or fd.get("PBR")):
                    fund_rows.append(f"{_sym} PER {fd.get('PER') or '-'} PBR {fd.get('PBR') or '-'} ROE {fd.get('ROE') or '-'}")
            info["fund"] = fund_rows[:4]
        except Exception:
            info["fund"] = []
        # 엄밀 검증 등급 분포 (validation_results 최근)
        try:
            with db.get_conn() as c:
                rows = c.execute("SELECT grade, COUNT(*) n FROM validation_results "
                                 "WHERE id IN (SELECT MAX(id) FROM validation_results GROUP BY cond_key) "
                                 "GROUP BY grade").fetchall()
            info["grades"] = {r["grade"]: r["n"] for r in rows}
            info["val_total"] = sum(info["grades"].values())
        except Exception:
            info["grades"], info["val_total"] = {}, 0
        # 자동파일럿 상태
        try:
            import os as _os, json as _json
            p = _os.path.join("strategy", "control_state.json")
            if _os.path.exists(p):
                st = _json.load(open(p, encoding="utf-8"))
                info["pilot_last"] = (st.get("last_run_at") or "")[:16].replace("T", " ")
        except Exception:
            info["pilot_last"] = "-"
        with db.get_conn() as c:
            info["paper_open"] = c.execute(
                "SELECT COUNT(*) FROM paper_positions WHERE status='open'").fetchone()[0]
            info["paper_closed"] = c.execute(
                "SELECT COUNT(*) FROM paper_positions WHERE status='closed'").fetchone()[0]
        # ★ 거래 유형별 건수 (실제 매매 vs 검증 구분)
        try:
            with db.get_conn() as c:
                rows = c.execute("SELECT cond_key, cond_txt, COUNT(*) n FROM paper_positions "
                                 "GROUP BY cond_key, cond_txt").fetchall()
            kinds = {"수동매수": 0, "검증통과": 0, "검증예약": 0, "신호": 0}
            for r in rows:
                k = db.paper_kind_label(r["cond_key"], r["cond_txt"])
                kinds[k] = kinds.get(k, 0) + r["n"]
            info["paper_kinds"] = kinds
        except Exception:
            info["paper_kinds"] = {}
        # ★ 실제 계좌 연동 상태 (60초 캐시 - 키움 레이트리밋 방어)
        try:
            import time as _t
            _now = _t.time()
            if _now - _ACCOUNT_CACHE["t"] > 60:
                try:
                    _ACCOUNT_CACHE["data"] = db.get_account_summary()
                except Exception:
                    _ACCOUNT_CACHE["data"] = None
                _ACCOUNT_CACHE["t"] = _now
            ov = _ACCOUNT_CACHE.get("data")
            if isinstance(ov, dict) and ov.get("mock"):
                info["account_linked"] = "모의 기본값(키 없음/DRY_RUN)"
                info["account_pos"] = 0
                info["account_err"] = "APP_KEY/ACCOUNT_NO 미설정 또는 DRY_RUN=true - 실제 보유 조회 불가"
            elif isinstance(ov, dict):
                info["account_linked"] = "✅ 연동됨"
                info["account_pos"] = len(ov.get("positions") or [])
                errs = ov.get("errors") or []
                info["account_err"] = " · ".join(str(e) for e in errs[:3]) if errs else ""
            else:
                info["account_linked"] = "미연동"
                info["account_pos"] = 0
                info["account_err"] = ""
        except Exception:
            info["account_linked"] = "미연동"
            info["account_pos"] = 0
            info["account_err"] = ""
        # ★ 주간 리포트 요약 (AI 넣은 vs 안 넣은 비교)
        try:
            import weekly_report as _wr
            info["weekly"] = _wr.get_latest()
        except Exception:
            info["weekly"] = None
        #   60초 캐시 (AI 호출·가격 조회 과부하 방지 - Gemini 1회/종목)
        try:
            import time as _t
            _now = _t.time()
            if _now - globals().get("_EVAL_CACHE_T", 0) > 60:
                evs = []
                ov = _ACCOUNT_CACHE.get("data")
                if isinstance(ov, dict) and ov.get("positions") and not ov.get("mock"):
                    from ai_consult import evaluate_holding_adv
                    for p in ov["positions"][:20]:
                        try:
                            e = evaluate_holding_adv(p.get("symbol", ""), {
                                "entry_price": p.get("avg_price", 0) or 0,
                                "qty": p.get("qty", 0) or 0,
                                "name": p.get("name", "")})
                            if e:
                                evs.append(e)
                        except Exception:
                            continue
                globals()["_HOLDINGS_EVAL_CACHE"] = evs
                globals()["_HOLDINGS_EVAL_T"] = db.now_kst().strftime("%H:%M:%S")
                globals()["_EVAL_CACHE_T"] = _now
            info["holdings_eval"] = globals().get("_HOLDINGS_EVAL_CACHE", [])
            info["holdings_eval_t"] = globals().get("_HOLDINGS_EVAL_T", "")
        except Exception:
            info["holdings_eval"] = globals().get("_HOLDINGS_EVAL_CACHE", [])
            info["holdings_eval_t"] = globals().get("_HOLDINGS_EVAL_T", "")
    except Exception as e:
        info["error"] = str(e)[:100]
    return info


def cfg_summary():
    try:
        from config import CFG
        return {
            "server": "모의투자" if CFG.USE_MOCK else "실전",
            "base_url": CFG.base_url,
            "dry_run": CFG.DRY_RUN,
            "ai_provider": CFG.AI_PROVIDER,
            "ai_confidence": CFG.AI_BUY_CONFIDENCE_THRESHOLD,
            "ai_buy_gate": getattr(CFG, "AI_BUY_GATE", False),
            "ai_sell_gate": getattr(CFG, "AI_SELL_GATE", True),
            "hard_sl": CFG.HARD_STOP_LOSS_PCT,
            "min_tp": CFG.MIN_TAKE_PROFIT_PCT,
            "fee": CFG.FEE_ROUND_TRIP_PCT,
            "index_warn": CFG.INDEX_WARN_PCT,
            "index_crash": CFG.INDEX_CRASH_PCT,
            "leader_enabled": getattr(CFG, "LEADER_ENABLED", True),
            "scalp_enabled": getattr(CFG, "SCALP_ENABLED", True),
            "weekly_report": getattr(CFG, "WEEKLY_REPORT_ENABLED", True),
            "app_key": "설정됨" if CFG.APP_KEY else "미설정",
            "account": (CFG.ACCOUNT_NO or "-")[:4] + "***" if CFG.ACCOUNT_NO else "-",
        }
    except Exception as e:
        return {"error": str(e)[:100]}


def files_summary():
    pys = [f for f in os.listdir(".") if f.endswith(".py")]
    return {"py_count": len(pys),
            "key": [f for f in ("desktop_app.py", "collect_data.py", "live_trader.py",
                                "scalp.py", "validation.py", "leader.py", "db.py")
                    if os.path.exists(f)]}


def module_health():
    """핵심 모듈 import 상태"""
    import importlib
    mods = ["config", "db", "kiwoom_client", "engine", "paper_test", "screener",
            "ai_judge", "ai_consult", "teams", "backfill_history", "charting",
            "validation", "leader", "scalp", "live_trader", "collect_data"]
    ok, bad = [], []
    for m in mods:
        try:
            importlib.import_module(m)
            ok.append(m)
        except Exception as e:
            bad.append(f"{m}({str(e)[:40]})")
    return {"ok": ok, "bad": bad}


# ── HTML (인라인 CSS - 프리뷰에서도 정상) ────────────────
PAGE = """<!DOCTYPE html>
<html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>📊 자동매매 시스템 상태</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, 'Malgun Gothic', 'Segoe UI', sans-serif;
         background: #0d1117; color: #e6edf3; padding: 24px; }
  h1 { font-size: 22px; margin-bottom: 4px; }
  .sub { color: #8b949e; font-size: 13px; margin-bottom: 20px; }
  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: 14px; }
  .card { background: #161b22; border: 1px solid #21262d; border-radius: 10px;
          padding: 16px 18px; }
  .card h2 { font-size: 14px; color: #58a6ff; margin-bottom: 12px; }
  .row { display: flex; justify-content: space-between; padding: 5px 0;
         border-bottom: 1px dashed #21262d; font-size: 13px; }
  .row:last-child { border-bottom: none; }
  .row .k { color: #8b949e; }
  .row .v { font-weight: 600; }
  .ok { color: #3fb950; } .warn { color: #d29922; } .bad { color: #f85149; }
  .big { font-size: 26px; font-weight: 700; }
  .tag { display: inline-block; padding: 2px 8px; border-radius: 20px;
         font-size: 12px; margin: 2px 4px 2px 0; }
  .tag.ok { background: #1f3327; } .tag.bad { background: #3d1d1d; }
  .badge { display:inline-block; padding:3px 10px; border-radius:20px; font-size:12px;
           font-weight:700; }
  .badge.on { background:#1f3327; color:#3fb950; }
  .badge.off { background:#3d1d1d; color:#f85149; }
  .footer { margin-top: 22px; color: #8b949e; font-size: 12px; text-align: center; }
</style></head><body>
<h1>📊 한국 주식 자동매매 시스템</h1>
<div class="sub">라이브 상태 대시보드 · 새로고침하면 갱신 · {ts}</div>
<div class="grid">
  <div class="card"><h2>🖥 접속 설정</h2>{cfg_rows}</div>
  <div class="card"><h2>📦 데이터 수집</h2>{data_rows}</div>
  <div class="card"><h2>🔍 검증 결과 (명예의 전당)</h2>{hof_rows}</div>
  <div class="card"><h2>💼 실제 매매 (계좌·모의실전)</h2>{paper_rows}</div>
  <div class="card"><h2>🔎 보유 종목 AI 평가 · 적정가</h2>{hold_eval_rows}</div>
  <div class="card"><h2>🧩 모듈 상태</h2>{mod_rows}</div>
  <div class="card"><h2>🎯 엄밀 검증 등급</h2>{grade_rows}</div>
  <div class="card"><h2>📐 조건식 봉 기준</h2>{tf_rows}</div>
  <div class="card"><h2>⏰ 지수×시간대 분석</h2>{time_rows}</div>
  <div class="card"><h2>📊 펀더멘털 (영웅문/네이버)</h2>{fund_rows_html}</div>
  <div class="card"><h2>💎 저평가 추적</h2>{value_rows}</div>
  <div class="card"><h2>🧬 급등 유전자</h2>{surge_rows}</div>
  <div class="card"><h2>⚙️ 주요 설정값</h2>{risk_rows}</div>
  <div class="card"><h2>📅 주간 리포트 (AI vs 규칙)</h2>{weekly_rows}</div>
  <div class="card"><h2>🚀 자동 파일럿</h2>{pilot_rows}</div>
  <div class="card"><h2>📄 파일</h2>{file_rows}</div>
</div>
<div class="footer">자동매매 데스크톱 앱은 Tkinter라 브라우저 미리보기 불가 ·
  이 대시보드는 상태 확인용 · 상세 운영은 python desktop_app.py</div>
</body></html>
"""


def _rows(d):
    out = []
    for k, v in d.items():
        cls = "v"
        if isinstance(v, str) and v.startswith("❌"):
            cls = "bad"
        out.append(f'<div class="row"><span class="k">{k}</span>'
                   f'<span class="v {cls}">{v}</span></div>')
    return "".join(out)


def build_page():
    info = sys_info()
    cfg = cfg_summary()
    files = files_summary()
    health = module_health()

    cfg_rows = _rows({
        "서버": f"{cfg.get('server')} ({cfg.get('base_url', '')})",
        "DRY_RUN(주문생략)": "ON(안전)" if cfg.get("dry_run") else "OFF(실주문)",
        "AI 엔진": cfg.get("ai_provider", "-"),
        "매수 신뢰도": f"{cfg.get('ai_confidence')}%",
        "앱키": cfg.get("app_key", "-"),
        "계좌": cfg.get("account", "-"),
    })

    data_rows = _rows({
        "전 종목 목록": f"{info.get('universe', 0):,}개",
        "수집 종목": f"{info.get('stock_files', 0):,}개",
        "일봉": f"{info.get('daily_bars', 0):,}봉",
        "분봉": f"{info.get('minute_bars', 0):,}봉",
        "용량": f"{info.get('total_mb', 0)}MB",
    })

    # ★ 검증(명예의 전당)과 실제 매매(계좌·모의실전)를 카드로 분리 (공통 분모 제거)
    hof_rows = _rows({
        "명예의 전당(활성)": f"{info.get('hof', 0)}건",
        "명예의 전당(이력)": f"{info.get('hof_total', 0)}건",
    })
    # 거래 유형별 건수 (수동매수/검증통과/검증예약/신호 - 섞여 보이지 않게)
    kinds = info.get("paper_kinds") or {}
    kind_tags = "".join(
        f'<span class="tag ok">{k} {v}건</span>' for k, v in kinds.items() if v)
    if not kind_tags:
        kind_tags = '<span class="tag">거래 기록 없음</span>'
    paper_rows = (_rows({
        "계좌 연동": info.get("account_linked", "미연동"),
        "계좌 실제 보유": f"{info.get('account_pos', 0)}종목",
        "모의실전 보유": f"{info.get('paper_open', 0)}건",
        "모의실전 청산": f"{info.get('paper_closed', 0)}건",
    })
        + '<div style="margin:6px 0">' + kind_tags + "</div>")
    if info.get("account_err"):
        paper_rows += (f'<div style="font-size:11px;color:#f85149">⚠️ {info["account_err"]}</div>')

    # ★ 보유 종목 AI 평가 카드 (적정가/매수 위치/매도 제안)
    evs = info.get("holdings_eval") or []
    if evs:
        rows_html = []
        for e in evs:
            nm = e.get("name") or e.get("symbol")
            qty = e.get("qty", 0)
            entry = e.get("entry_price", 0) or 0
            price = e.get("price", 0) or 0
            ret = e.get("ret", 0)
            verdict = e.get("verdict", "-")
            vcol = {"보유": "#58a6ff", "수익청산": "#3fb950", "손절": "#f85149",
                    "평가불가": "#d29922"}.get(verdict, "#8b949e")
            fair = (e.get("tech") or {}).get("fair", "-")
            fair_note = (e.get("tech") or {}).get("fair_note", "")
            epos = (e.get("tech") or {}).get("entry_pos", "?")
            enote = (e.get("tech") or {}).get("entry_note", "")
            tgt = (e.get("tech") or {}).get("target", 0)
            stop = (e.get("tech") or {}).get("stop", 0)
            ret_col = "#3fb950" if ret >= 0 else "#f85149"
            rows_html.append(
                f'<div style="border:1px solid #21262d;border-radius:8px;padding:8px 10px;'
                f'margin-bottom:8px">'
                f'<div style="display:flex;justify-content:space-between;align-items:center">'
                f'<span style="font-weight:700">{nm}</span>'
                f'<span class="tag" style="color:{vcol};border:1px solid {vcol}">{verdict}</span></div>'
                f'<div style="font-size:12px;color:#8b949e;margin-top:2px">'
                f'{e.get("symbol")} · {qty}주</div>'
                f'<div class="row"><span class="k">평단가(매수 위치)</span>'
                f'<span class="v">{entry:,.0f}원</span></div>'
                f'<div class="row"><span class="k">현재가 / 수익률</span>'
                f'<span class="v">{price:,.0f}원 · <span style="color:{ret_col}">{ret:+.2f}%</span></span></div>'
                f'<div class="row"><span class="k">적정가 판단</span>'
                f'<span class="v">{fair}</span></div>'
                f'<div style="font-size:11px;color:#8b949e">{fair_note}</div>'
                f'<div class="row"><span class="k">매수 위치 평가</span>'
                f'<span class="v">{epos}</span></div>'
                f'<div style="font-size:11px;color:#8b949e">{enote}</div>'
                f'<div class="row"><span class="k">매도 제안 (목표/손절)</span>'
                f'<span class="v">{tgt:,.0f} / {stop:,.0f}원</span></div>'
                f'<div style="font-size:11px;color:#8b949e;margin-top:2px">'
                f'{e.get("reason", "")[:100]}</div>'
                + (f'<div style="font-size:11px;color:#d29922;margin-top:2px">'
                   f'📌 매수 시 지침[{e.get("plan_provider", "rule")}]: '
                   f'{e.get("sell_plan", "")[:110]}</div>'
                   if e.get("sell_plan") else "")
                + '</div>')
        hold_eval_rows = "".join(rows_html)
        if info.get("holdings_eval_t"):
            hold_eval_rows += (f'<div style="font-size:11px;color:#8b949e;text-align:right">'
                               f'평가 시각 {info["holdings_eval_t"]}</div>')
    else:
        hold_eval_rows = ('<div class="tag">계좌 연동 시 보유 종목별로 적정가/매수 위치/AI 판단을 표시합니다 '
                          '(현재 보유 조회 안 됨)</div>')

    ok_tags = "".join(f'<span class="tag ok">✅ {m}</span>' for m in health["ok"])
    bad_tags = "".join(f'<span class="tag bad">❌ {m}</span>' for m in health["bad"])
    mod_rows = f'<div style="margin-bottom:8px">{ok_tags}{bad_tags}</div>' + _rows({
        "정상": f'{len(health["ok"])}개', "문제": f'{len(health["bad"])}개'})

    risk_rows = _rows({
        "하드손절": f"-{cfg.get('hard_sl')}%",
        "최소익절": f"+{cfg.get('min_tp')}%",
        "왕복수수료": f"{cfg.get('fee')}%",
        "지수 주의/위험": f"{cfg.get('index_warn')}% / {cfg.get('index_crash')}%",
        "대장주 공략": "ON" if cfg.get("leader_enabled") else "OFF",
        "장초반 스캘핑": "ON" if cfg.get("scalp_enabled") else "OFF",
        "매수 AI 판단": "ON" if cfg.get("ai_buy_gate") else "OFF(조건식 신호만)",
        "매도 AI 판단": "ON" if cfg.get("ai_sell_gate") else "OFF(규칙만)",
        "주간 리포트": "자동" if cfg.get("weekly_report", True) else "OFF",
    })

    key_files = "".join(f'<span class="tag ok">{f}</span>' for f in files["key"])
    file_rows = f'<div style="margin-bottom:8px">{key_files}</div>' + _rows({
        "Python 파일": f"{files['py_count']}개"})

    html = (PAGE
            .replace("{ts}", time.strftime("%Y-%m-%d %H:%M:%S"))
            .replace("{cfg_rows}", cfg_rows)
            .replace("{data_rows}", data_rows)
            .replace("{paper_rows}", paper_rows)
            .replace("{hof_rows}", hof_rows)
            .replace("{hold_eval_rows}", hold_eval_rows)
            .replace("{mod_rows}", mod_rows)
            .replace("{risk_rows}", risk_rows)
            .replace("{file_rows}", file_rows))
    grades = info.get("grades") or {}
    if grades:
        g_txt = " ".join(f'<span class="tag ok">{g} {n}</span>' for g, n in grades.items())
    else:
        g_txt = '<span class="tag">아직 검증 기록 없음 (🎯 엄밀 검증 실행)</span>'
    grade_rows = f'<div style="margin-bottom:8px">{g_txt}</div>' + _rows({
        "검증된 조건식": f"{info.get('val_total', 0)}개"})
    pilot_rows = _rows({
        "자동파일럿": "앱 켜면 자동 시작",
        "마지막 라운드": info.get("pilot_last", "-"),
        "모의실전 보유/청산": f"{info.get('paper_open', 0)} / {info.get('paper_closed', 0)}",
        "📅 다음날 예약": f"{info.get('sched', 0)}개 (검증 통과분)",
    })

    # ★ 주간 리포트 카드 (AI 넣은 vs 안 넣은 비교)
    wk = info.get("weekly")
    if wk:
        cmp = wk.get("ai_vs_rule") or {}
        a, b = cmp.get("a") or {}, cmp.get("b") or {}
        a_txt = (f"{a.get('trades', 0)}건 승률 {a.get('win_rate', 0)}% "
                 f"평균 {a.get('avg_ret', 0)}%") if a else "-"
        b_txt = (f"{b.get('trades', 0)}건 승률 {b.get('win_rate', 0)}% "
                 f"평균 {b.get('avg_ret', 0)}%") if b else "-"
        recs = wk.get("recommendations") or []
        rec_txt = "<br>".join(f"{i}. [{r.get('type','')}] {r.get('desc','')[:60]}"
                              for i, r in enumerate(recs[:4], 1))
        weekly_rows = _rows({
            "리포트 주차": wk.get("week", "-"),
            "생성 시각": (wk.get("generated_at") or "-")[:16].replace("T", " "),
            "주간 거래": f"{wk.get('trades', 0)}건 승률 {wk.get('win_rate', 0)}% "
                        f"평균 {wk.get('avg_ret', 0)}%",
            "AI 넣은 그룹": a_txt,
            "AI 안 넣은 그룹": b_txt,
        })
        if rec_txt:
            weekly_rows += (f'<div style="margin-top:6px;font-size:11px;color:#d29922">'
                            f'⛔ 권장(허락 후 반영):<br>{rec_txt}</div>')
    else:
        weekly_rows = _rows({"상태": "아직 주간 리포트 없음 - 앱 리포트 탭에서 생성 (매주 토요일 자동)"})
    tf = info.get("tf") or {}
    if tf:
        tf_txt = " ".join(
            f'<span class="tag ok">{"[일]" if k=="day" else "[주]" if k=="week" else "[월]" if k=="month" else "["+k.replace("min","")+"분]" if k.startswith("min") else k} {v}</span>'
            for k, v in tf.items())
    else:
        tf_txt = '<span class="tag">조건식 없음</span>'
    tf_rows = f'<div style="margin-bottom:8px">{tf_txt}</div>' + _rows({
        "총 조건식": sum(tf.values())})
    ta = info.get("time_analysis") or []
    if ta:
        best_t = info.get("time_best") or []
        time_rows = _rows({
            "표본 있는 조합": f"{len(ta)}개",
            "최고 조합": (f"{best_t[0]['regime']}·{best_t[0]['bucket']} "
                         f"승률{best_t[0]['win_rate']}%" if best_t else "-"),
        })
        time_rows += '<div style="margin-top:6px;font-size:11px;color:#8b949e">' + "<br>".join(
            f"{r['regime']}·{r['bucket']} {r['sells']}건 승률{r['win_rate']}%" for r in ta[:6]) + "</div>"
    else:
        time_rows = _rows({"상태": "표본 부족 - 장중 진입 쌓이면 분석"})
    fund = info.get("fund") or []
    if fund:
        fund_rows_html = '<div style="font-size:11px;color:#8b949e">' + "<br>".join(fund) + "</div>"
    else:
        fund_rows_html = _rows({"상태": "펀더멘털 수집 대기"})
    vw = info.get("value_watch") or {}
    value_rows = _rows({
        "관찰 중": f"{vw.get('watching', 0)}개",
        "✅ +15% 회복": f"{vw.get('up', 0)}개",
        "회복 평균 최고수익": f"{vw.get('avg_peak_return', 0)}%",
    })
    sg = info.get("surge_genes")
    if sg:
        gtxt = "<br>".join(f"{g['slot']} +{g['diff']:.0f}%" for g in sg.get("genes", []))
        surge_rows = _rows({
            "급등 사례": f"{sg.get('surge', 0)}건",
            "분석 종목": f"{sg.get('symbols', 0)}개",
            "등록 검색식": f"{info.get('surge_registered', 0)}개",
        })
        surge_rows += f'<div style="margin-top:6px;font-size:11px;color:#8b949e">{gtxt}</div>'
    else:
        surge_rows = _rows({"상태": "python surge_mining.py --run 실행"})
    html = (html.replace("{grade_rows}", grade_rows)
                .replace("{tf_rows}", tf_rows)
                .replace("{time_rows}", time_rows)
                .replace("{fund_rows_html}", fund_rows_html)
                .replace("{value_rows}", value_rows)
                .replace("{surge_rows}", surge_rows)
                .replace("{pilot_rows}", pilot_rows)
                .replace("{weekly_rows}", weekly_rows))
    return html


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path not in ("/", "/index.html"):
            self.send_response(404)
            self.end_headers()
            return
        body = build_page().encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        pass  # 조용히


# ── 자동 기동 (데스크톱 앱에서 호출 - 서버를 백그라운드 스레드로) ──
_server = None
_server_thread = None


def start_server(port=None, host="0.0.0.0"):
    """대시보드 서버를 백그라운드 스레드로 시작 (이미 켜져 있으면 스킵 - 포트 충돌 방지)
    반환: (port, started) — started=True면 이번에 새로 시작됨
    ★ 포트가 사용 중이면 8001~8005로 자동 폴백 (다른 프로그램이 8000을 쓰는 PC 대응)
    """
    global _server, _server_thread
    if _server is not None:
        return PORT, False
    p = port or PORT
    srv = None
    used_port = p
    for cand in [p] + [p + k for k in range(1, 6)]:
        try:
            srv = ThreadingHTTPServer((host, cand), Handler)
            used_port = cand
            break
        except OSError as e:
            print(f"⚠️ 대시보드 포트 {cand} 사용 중({e}) - 다음 포트 시도")
            continue
    if srv is None:
        print("❌ 대시보드 시작 실패: 8000~8005 모두 사용 중")
        return p, False
    _server = srv
    _server_thread = threading.Thread(target=srv.serve_forever, daemon=True)
    _server_thread.start()
    print(f"📊 시스템 상태 대시보드: http://localhost:{used_port}")
    return used_port, True


def stop_server():
    """대시보드 서버 정지 (데스크톱 앱 종료 시 호출)"""
    global _server, _server_thread
    if _server is not None:
        try:
            _server.shutdown()
            _server.server_close()
        except Exception:
            pass
        _server = None
        _server_thread = None


if __name__ == "__main__":
    start_server()
    print("Ctrl+C 로 종료")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        stop_server()
