# -*- coding: utf-8 -*-
"""
📊 펀더멘털 보충 (fundamentals.py) — 영웅문(OpenAPI+) 우선, 네이버 폴백
========================================================================
설계 (사용자: "빠른 건 네이버, 보충은 영웅문에서 필요한 자료들"):
  - 빠른 데이터(일봉/분봉/실시간/지수)  → 네이버 (기존)
  - 펀더멘털(PER/PBR/EPS/ROE/배당)      → 영웅문 opt10001 우선, 없으면 네이버 종목 페이지
  - 투자자별 수급(개인/외국인/기관)      → 영웅문 opt10059 우선, 없으면 규칙(미지원 안내)
  - 공매도/대차                       → 영웅문 opt10054 (있으면)

사용: 조건식 스캔/엄밀검증에서 '버핏 관점 필터'(저PER/고ROE 등)로 확장 가능.
"""
import logging
import os
import re

import requests

log = logging.getLogger("fund")

_HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

# ── 1) 네이버 펀더멘털 (종목 페이지 - 영웅문 없을 때 폴백) ──
def naver_fundamentals(symbol: str):
    """네이버 종목 페이지에서 PER/PBR/EPS/ROE/배당수익률 추출
    반환: {"PER": float, "PBR": float, "EPS": float, "ROE": float,
           "div_yield": float, "source": "naver"} / None
    """
    try:
        r = requests.get(f"https://finance.naver.com/item/main.naver?code={symbol}",
                         headers=_HEADERS, timeout=10)
        if r.status_code != 200:
            return None
        t = r.text
        def _val(label):
            # <th ...>PER(배)</strong></th> ... <td class="">36.84</td>
            m = re.search(
                rf'<strong>\s*{re.escape(label)}\s*</strong>.*?</th>\s*<td[^>]*>\s*([0-9.,\-]+)\s*</td>',
                t, re.S)
            if not m:
                return None
            s = m.group(1).replace(",", "").strip()
            try:
                return float(s)
            except Exception:
                return None
        out = {
            "PER": _val("PER(배)"),
            "PBR": _val("PBR(배)"),
            "EPS": _val("EPS(원)"),
            "ROE": _val("ROE(지배주주)") or _val("ROE"),
            "div_yield": _val("배당수익률"),
        }
        # ★ 이상값 가드: PER이 1000 초과면 EPS 등 다른 셀이 잡힌 것 → None 처리
        if out["PER"] is not None and out["PER"] > 1000:
            out["PER"] = None
        if out["EPS"] is not None and out["EPS"] > 100000:
            out["EPS"] = None
        if out["PBR"] is not None and (out["PBR"] > 100 or out["PBR"] < 0):
            out["PBR"] = None
        if out["ROE"] is not None and (out["ROE"] > 1000 or out["ROE"] < -1000):
            out["ROE"] = None
        if out["PER"] is None and out["PBR"] is None and out["ROE"] is None:
            return None
        out["source"] = "naver"
        return out
    except Exception as e:
        log.warning(f"네이버 펀더멘털 실패 {symbol}: {e}")
        return None


# ── 2) 영웅문(OpenAPI+) 보충 조회 ──
def openapi_fundamentals(symbol: str, kiwoom=None):
    """영웅문 opt10001 주식기본정보: PER/PBR/EPS/ROE/배당수익률
    kiwoom: live_trader의 연결된 Kiwoom 객체 (없으면 None → 네이버 폴백)
    """
    if kiwoom is None:
        return None
    try:
        kiwoom.SetInputValue("종목코드", symbol)
        kiwoom.CommRqData("fund", "opt10001", 0, "0101")
        import time
        time.sleep(0.4)
        def _gd(key):
            try:
                v = kiwoom.GetCommData("opt10001", 0, 0, key).strip()
                return float(str(v).replace(",", "").replace("N/A", "0") or 0) if v else 0
            except Exception:
                return 0
        out = {"PER": _gd("PER"), "PBR": _gd("PBR"), "EPS": _gd("EPS"),
               "ROE": _gd("ROE"), "div_yield": _gd("배당수익률"), "source": "openapi"}
        return out
    except Exception as e:
        log.warning(f"영웅문 펀더멘털 실패 {symbol}: {e}")
        return None


def openapi_investor_flow(symbol: str, kiwoom=None):
    """영웅문 opt10059 투자자별 매매상위/수급 - 없으면 None (네이버도 수급은 종목별 어려움)
    반환: {"foreign_net": int, "individual_net": int, "institution_net": int, "source": "openapi"}
    """
    if kiwoom is None:
        return None
    try:
        kiwoom.SetInputValue("종목코드", symbol)
        kiwoom.CommRqData("investor", "opt10059", 0, "0101")
        import time
        time.sleep(0.4)
        # opt10059는 화면 구성이 다양 - 대표 필드만 시도
        return None  # 필요시 구현 (화면별 응답 구조 확인 후)
    except Exception:
        return None


# ── 3) 통합: 영웅문 우선 → 네이버 폴백 ──
def get_fundamentals(symbol: str, kiwoom=None):
    """★ 펀더멘털 통합 조회: 영웅문(opt10001) 우선 → 네이버 폴백"""
    r = openapi_fundamentals(symbol, kiwoom)
    if r and (r.get("PER") or r.get("PBR")):
        return r
    return naver_fundamentals(symbol)


def is_value_stock(fund, max_per=15.0, min_roe=8.0):
    """★ 버핏 관점 가치주 판정 (저PER + 고ROE + PBR 합리적)
    fund: get_fundamentals 결과
    반환: (bool, reason)
    """
    if not fund:
        return False, "펀더멘털 없음"
    per = fund.get("PER") or 0
    pbr = fund.get("PBR") or 0
    roe = fund.get("ROE") or 0
    parts = []
    ok = True
    if per > 0:
        if per <= max_per:
            parts.append(f"PER {per:.1f}≤{max_per}")
        else:
            ok = False
            parts.append(f"PER {per:.1f}>{max_per}")
    if roe > 0:
        if roe >= min_roe:
            parts.append(f"ROE {roe:.1f}≥{min_roe}")
        else:
            ok = False
            parts.append(f"ROE {roe:.1f}<{min_roe}")
    if not parts:
        return False, "펀더멘털 값 부족"
    return ok, (" ✅ ".join(parts) if ok else " ❌ ".join(parts))
