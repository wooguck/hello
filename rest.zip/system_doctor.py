# -*- coding: utf-8 -*-
"""
🩺 시스템 닥터 (system_doctor.py) - "제대로 돌아가는지" 전 구간 자가 진단
==========================================================================
"의심을 백번천번" 요청 반영: 말이 아니라 증거로 확인합니다.
파이프라인의 각 관문이 실제로 작동하는지 + 돈이 새는 구멍이 없는지 검사.

검사 항목 (10가지):
  [1] 데이터 신선도    : 일봉이 최근 거래일까지 있는가
  [2] 검증 실행 여부   : validation_results에 최근 기록이 있는가
  [3] 검증 논리 건전성 : "채택 후보"가 정말 대조군 95%+·지수 초과인가 (재검산)
  [4] 등급 게이트     : 기각 조건식이 매수에 쓰이고 있지 않은가 ★돈 새는 구멍
  [5] 매수-검증 연결   : 실제 매수가 검증 통과 조건식에서 나왔는가
  [6] 손절 규율      : 청산 기록에서 손절이 -3%(+슬리피지) 근처에서 끊겼는가
                       -5% 이상 뚫린 손절 = 매도 지연 증거 ★
  [7] 매도 가드      : sell_guard가 살아있는가 (round_progress와 별개)
  [8] 하드손절 설정   : HARD_STOP_LOSS_PCT > 0 인가
  [9] 과최적화 냄새   : 승률 90%+ 조건식 = 의심 (표본/편향 확인)
  [10] 미래 데이터 누출: 백테스트 진입가가 신호 다음날 시가인가 (코드 검사)

실행:
  python system_doctor.py         # 전체 진단
결과: 콘솔 + system_doctor_report.md
"""
import json
import os
import sqlite3
import sys
from datetime import datetime, timedelta

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db
from config import CFG

PASS, WARN, FAIL = "✅", "🟡", "🔴"
results = []


def check(name, status, detail, fix=""):
    results.append((status, name, detail, fix))
    print(f"  {status} {name}: {detail}")
    if fix and status != PASS:
        print(f"       → 조치: {fix}")


def main():
    results.clear()   # ★ 앱 안에서 반복 호출돼도 결과 누적 안 되게
    print("=" * 66)
    print("🩺 시스템 닥터 - 전 구간 자가 진단")
    print("=" * 66)

    # [1] 데이터 신선도
    try:
        import glob
        latest = ""
        for f in glob.glob(os.path.join(db.DATA_DIR, "stocks", "*.db"))[:200]:
            try:
                c = sqlite3.connect(f)
                r = c.execute("SELECT MAX(bar_date) FROM daily_bars").fetchone()
                c.close()
                if r and r[0] and r[0] > latest:
                    latest = r[0]
            except Exception:
                continue
        days_old = (datetime.now() - datetime.strptime(latest, "%Y-%m-%d")).days if latest else 999
        if days_old <= 4:
            check("데이터 신선도", PASS, f"최신 일봉 {latest} ({days_old}일 전)")
        elif days_old <= 10:
            check("데이터 신선도", WARN, f"최신 일봉 {latest} - {days_old}일 늦음",
                  "자동 파일럿 자료수집이 도는지 확인")
        else:
            check("데이터 신선도", FAIL, f"최신 일봉 {latest} - {days_old}일 늦음!",
                  "collect_data.py --once 실행")
    except Exception as e:
        check("데이터 신선도", FAIL, str(e)[:60])

    # [2] 검증 실행 여부
    vrows = []
    try:
        from validation import load_validation_history
        vrows = load_validation_history(limit=50)
        if vrows:
            newest = max((v.get("created_at") or "") for v in vrows)
            age_h = (db.now_kst() - datetime.fromisoformat(newest)).total_seconds() / 3600
            if age_h <= 48:
                check("검증 실행", PASS, f"최근 검증 {len(vrows)}건 · 마지막 {age_h:.0f}시간 전")
            else:
                check("검증 실행", WARN, f"마지막 검증이 {age_h/24:.1f}일 전",
                      "파일럿 5라운드마다 자동 - 라운드가 도는지 확인")
        else:
            check("검증 실행", WARN, "검증 기록 0건 (아직 5라운드 미도달?)",
                  "앱 테스트 탭 🎯 엄밀 검증 수동 1회 실행")
    except Exception as e:
        check("검증 실행", FAIL, str(e)[:60])

    # [3] 검증 논리 건전성: 채택 후보 재검산
    try:
        adopted = [v for v in vrows if v.get("grade") == "채택 후보"]
        bad = []
        for v in adopted:
            pctl = v.get("percentile") or 0
            excess = v.get("excess")
            if pctl < 95 or (excess is not None and excess <= 0):
                bad.append(f"{v.get('cond_no')}(백분위{pctl}/초과{excess})")
        if not adopted:
            check("검증 논리", WARN, "'채택 후보' 아직 0건 (정상 - 시간 필요)")
        elif not bad:
            check("검증 논리", PASS,
                  f"채택 후보 {len(adopted)}건 전부 기준 충족 (대조군 95%+ · 지수 초과 > 0)")
        else:
            check("검증 논리", FAIL, f"기준 미달인데 채택된 것: {bad[:3]}",
                  "validation.py grade 로직 점검 필요 - 알려주세요")
    except Exception as e:
        check("검증 논리", FAIL, str(e)[:60])

    # [4] 등급 게이트 (돈 새는 구멍 1순위!)
    gate_on = os.getenv("VALIDATE_GATE_ENABLED", "true").lower() == "true"
    if gate_on:
        check("등급 게이트", PASS, "VALIDATE_GATE_ENABLED=true (통과 등급만 매수)")
    else:
        check("등급 게이트", FAIL,
              "게이트 꺼짐! 기각 등급 조건식도 매수에 쓰일 수 있음",
              ".env에 VALIDATE_GATE_ENABLED=true 추가 (강력 권장)")

    # [5] 매수-검증 연결: 최근 매수의 조건식이 검증 이력에 있는가
    try:
        with db.get_conn() as conn:
            buys = conn.execute(
                "SELECT DISTINCT cond_key, cond_txt FROM paper_positions "
                "WHERE entry_time > datetime('now', '-3 days')").fetchall()
        vkeys = {str(v.get("cond_key")) for v in vrows}
        # ★ 2026-09-02: 채널 매수는 조건식이 아님 - 검증 대상에서 제외 (오탐 제거)
        #   (BASELINE=일부러 무작위 대조군, MOMENTUM/THEME 등=별도 채널 실험 - trade_stats로 비교)
        _channels = ("MANUAL", "AI_PICK", "BASELINE", "MOMENTUM", "THEME",
                     "FORCE_LINE", "RADAR", "VALUE")
        unknown = [b["cond_txt"][:24] for b in buys
                   if str(b["cond_key"]) not in vkeys
                   and b["cond_key"] not in _channels
                   and not str(b["cond_key"]).startswith("SCALP")]
        if not buys:
            check("매수-검증 연결", WARN, "최근 3일 매수 0건 (장/조건식 상황에 따라 정상)")
        elif not unknown:
            check("매수-검증 연결", PASS, f"최근 매수 {len(buys)}개 조건식 전부 검증 이력 있음")
        else:
            check("매수-검증 연결", WARN, f"검증 안 된 조건식으로 매수: {unknown[:3]}",
                  "게이트 켜면 차단됨 ([4] 참고)")
    except Exception as e:
        check("매수-검증 연결", WARN, str(e)[:60])

    # [6] 손절 규율: 뚫린 손절 찾기
    #   ★ 2026-09-02 개선: '밤사이 갭하락 → 개장 직후 청산'은 시스템 잘못이 아님
    #   (전날 -3% 걸 새벽에 팔 방법이 없음) → 개장 30분 내 청산은 갭으로 분류,
    #   장중(09:30 이후) 뚫림만 '매도 지연 증거'로 FAIL
    try:
        hard = float(getattr(CFG, "HARD_STOP_LOSS_PCT", 3.0))
        with db.get_conn() as conn:
            closed = conn.execute(
                "SELECT symbol, ret_pct, exit_reason, exit_time FROM paper_positions "
                "WHERE status='closed' AND ret_pct < ? ORDER BY exit_time DESC LIMIT 30",
                (-(hard + 2.0),)).fetchall()
        gap, delayed = [], []
        for r in closed:
            t = str(r["exit_time"] or "")[11:16]
            (gap if ("09:00" <= t <= "09:30" or not t) else delayed).append(r)
        if not closed:
            check("손절 규율", PASS, f"-{hard+2:.0f}% 이상 뚫린 손절 없음 (규율 지켜짐)")
        elif not delayed:
            check("손절 규율", PASS,
                  f"뚫림 {len(gap)}건 전부 개장 갭하락 (전날 종가→다음날 시가 급락 - "
                  f"시스템 지연 아님. 밤새 하락은 어떤 시스템도 못 팜)")
        else:
            worst = [f"{r['symbol']}({r['ret_pct']:+.1f}% {str(r['exit_time'])[11:16]})"
                     for r in delayed[:5]]
            check("손절 규율", FAIL,
                  f"장중 매도 지연 {len(delayed)}건 (갭 {len(gap)}건 별도): {worst}",
                  "sell_guard 45초 가드가 도는지 + 시세 수신 확인 필요")
    except Exception as e:
        check("손절 규율", WARN, str(e)[:60])

    # [6-2] ★ 아침(08:30~09:40) 오류 패턴 (2026-09-02 사용자: "아침시간마다 오류")
    try:
        import glob as _g
        import re as _re
        morn_errs = {}
        for lf in _g.glob(os.path.join("logs", "*.log"))[:8]:
            try:
                for ln in open(lf, encoding="utf-8", errors="replace").readlines()[-4000:]:
                    m = _re.search(r"[T ](0[89]):([0-5]\d)", ln[:40])
                    if not m:
                        continue
                    hm = f"{m.group(1)}:{m.group(2)}"
                    if not ("08:30" <= hm <= "09:40"):
                        continue
                    if any(k in ln for k in ("❌", "ERROR", "Traceback", "오류", "실패")):
                        # 시각/숫자 제거 후 그룹핑 (같은 오류는 한 줄로 묶임)
                        key = _re.sub(r"^[\d\-T:. ]+", "", ln.strip())
                        key = _re.sub(r"\d{4,}", "N", key)[:60]
                        morn_errs[key] = morn_errs.get(key, 0) + 1
            except Exception:
                continue
        if not morn_errs:
            check("아침 오류 패턴", PASS, "최근 로그에서 08:30~09:40 오류 없음")
        else:
            top = sorted(morn_errs.items(), key=lambda x: -x[1])[:3]
            check("아침 오류 패턴", WARN,
                  f"아침 시간대 오류 {sum(morn_errs.values())}건: "
                  + " / ".join(f"[{n}회] {k[:45]}" for k, n in top),
                  "이 줄을 그대로 공유해주면 원인 수리 가능")
    except Exception:
        check("아침 오류 패턴", WARN, "판단 불가")

    # [7] 매도 가드 존재
    if os.path.exists("sell_guard.py"):
        check("매도 가드", PASS, "sell_guard.py 있음 (앱 시작 시 자동 기동 - v26)")
    else:
        check("매도 가드", FAIL, "sell_guard.py 없음!", "안전판_v26.zip 반영 필요")

    # [8] 하드손절 설정
    hard = float(getattr(CFG, "HARD_STOP_LOSS_PCT", 3.0))
    if hard > 0:
        check("하드손절", PASS, f"-{hard}% (0이 아님 - 절대 규칙 활성)")
    else:
        check("하드손절", FAIL, "HARD_STOP_LOSS_PCT=0 - 하드손절 꺼짐!",
              ".env에서 3.0 등으로 설정")

    # [9] 과최적화 냄새
    try:
        sus = [v for v in vrows if (v.get("win_rate") or 0) >= 90 and (v.get("trades") or 0) < 100]
        if sus:
            check("과최적화 냄새", WARN,
                  f"승률 90%+ & 표본<100 조건식 {len(sus)}건 - 우연일 가능성",
                  "표본이 쌓일 때까지 실전 투입 보류 권장")
        else:
            check("과최적화 냄새", PASS, "승률 90%+ 소표본 조건식 없음")
    except Exception:
        check("과최적화 냄새", WARN, "판단 불가")

    # [10] 미래 데이터 누출 (코드 검사)
    try:
        src = open("validation.py", encoding="utf-8").read()
        # 실제 구현: 진입 = 신호일 종가(bars[i0]["close"]), 청산은 다음날(i0+1)부터
        # → 신호는 i까지의 데이터로만 판정 + 청산은 미래 봉 → 누출 없음
        #   (신호일 종가 진입은 '종가 확인 후 매수' 가정 - 실전과 일치)
        ok = ('entry_price = bars[i0]["close"]' in src and "range(i0 + 1" in src)
        if ok:
            check("미래 누출 방지", PASS,
                  "진입=신호일 종가 · 청산=다음날부터 (신호가 미래 데이터를 안 봄 - 코드 확인)")
        else:
            check("미래 누출 방지", WARN, "진입/청산 시점 코드 패턴이 예상과 다름 - 수동 확인 필요")
    except Exception:
        check("미래 누출 방지", WARN, "판단 불가")

    # [11] ★ 2026-09-01 유기적 연동 점검 (사용자: "실제 기능들이 다 되고 있는지")
    #   판단 기록(judgments) / 검증 저장 스키마 / 편입 파이프라인 / 오늘 매매 흔적
    try:
        with db.get_conn() as conn:
            # 11-1) AI/규칙 판단 기록이 쌓이는가 (최근 3일)
            jn = conn.execute(
                "SELECT COUNT(*) n FROM judgments "
                "WHERE judged_at > datetime('now','-3 days')").fetchone()["n"]
            if jn > 0:
                by = conn.execute(
                    "SELECT kind, COUNT(*) n FROM judgments "
                    "WHERE judged_at > datetime('now','-3 days') GROUP BY kind").fetchall()
                _bt = " · ".join(f"{r['kind']} {r['n']}건" for r in by)
                check("AI/규칙 판단 기록", PASS, f"최근 3일 {jn}건 ({_bt})")
            else:
                check("AI/규칙 판단 기록", WARN,
                      "최근 3일 판단 기록 0건 - 매수/매도 판단이 안 돌았거나 기록 누락",
                      "장중에 앱을 켜두고 다시 진단. 그래도 0이면 재빌드 확인")
    except Exception as e:
        check("AI/규칙 판단 기록", WARN, f"판단 불가: {str(e)[:40]}")
    try:
        # 11-2) validation_results 스키마 (excess 컬럼 유무 = 편입 먹통 버그 체크)
        with db.get_conn() as conn:
            _vc = {r["name"] for r in conn.execute(
                "PRAGMA table_info(validation_results)").fetchall()}
        if not _vc:
            check("검증 저장 스키마", WARN, "validation_results 테이블 아직 없음 (첫 검증 전)")
        elif "excess" in _vc:
            check("검증 저장 스키마", PASS, "최신 스키마 (excess 등 컬럼 있음)")
        else:
            check("검증 저장 스키마", FAIL,
                  "구버전 스키마! 검증 결과 저장이 조용히 실패 중 → 승격/편입 먹통",
                  "새 zip 반영+재빌드 후 아무 검증 1회 돌면 자동 마이그레이션")
    except Exception:
        check("검증 저장 스키마", WARN, "판단 불가")
    try:
        # 11-3) 편입 파이프라인: 30일 내 새 조건식 생성 + 검증 기록 최신성
        with db.get_conn() as conn:
            newc = conn.execute(
                "SELECT COUNT(*) n FROM conditions "
                "WHERE created_at > datetime('now','-30 days')").fetchone()["n"]
            lastv = conn.execute(
                "SELECT MAX(created_at) m FROM validation_results").fetchone()["m"]
        active_n = len(db.get_conditions(status="active"))
        backlog_n = len(db.get_conditions(status="backlog"))
        detail = (f"운영 {active_n}·대기 {backlog_n} · 30일 새 조건식 {newc}개 · "
                  f"마지막 검증 {str(lastv or '없음')[:16]}")
        if newc == 0 and backlog_n == 0:
            check("편입 파이프라인", WARN, detail + " - 새 편입이 전혀 없음",
                  "밤 라운드가 도는지 확인 (팜리그/빌더 하트비트) + 충원모드 로그 확인")
        else:
            check("편입 파이프라인", PASS, detail)
    except Exception:
        check("편입 파이프라인", WARN, "판단 불가")
    try:
        # 11-4) 최근 거래일 매수 흔적 (아침 매수 안 됨 진단)
        with db.get_conn() as conn:
            b3 = conn.execute(
                "SELECT COUNT(*) n FROM paper_positions "
                "WHERE entry_time > datetime('now','-3 days')").fetchone()["n"]
            morn = conn.execute(
                "SELECT COUNT(*) n FROM paper_positions "
                "WHERE entry_time > datetime('now','-3 days') "
                "AND time(entry_time) < '10:00'").fetchone()["n"]
        if b3 > 0:
            check("최근 매수 흔적", PASS, f"3일 내 매수 {b3}건 (오전 9~10시 {morn}건)")
        else:
            check("최근 매수 흔적", WARN, "3일 내 매수 0건",
                  "현황판 매수깔때기(신호→관문별 스킵)를 보고 병목 관문 확인")
    except Exception:
        check("최근 매수 흔적", WARN, "판단 불가")

    # ── 종합 ──
    n_fail = sum(1 for s, *_ in results if s == FAIL)
    n_warn = sum(1 for s, *_ in results if s == WARN)
    print("\n" + "=" * 66)
    if n_fail == 0 and n_warn <= 2:
        print(f"🟢 종합: 건강 (실패 0 · 주의 {n_warn}) - 시스템이 설계대로 돌고 있습니다")
    elif n_fail == 0:
        print(f"🟡 종합: 대체로 정상 (주의 {n_warn}건) - 위 조치 참고")
    else:
        print(f"🔴 종합: 실패 {n_fail}건! - 위 🔴 항목부터 조치하세요")
    print("   ※ '수익 보장'은 어떤 시스템도 불가능합니다. 이 진단은")
    print("     '검증 규율이 지켜지고 있는가'를 확인하는 것이며, 그것이")
    print("     장기적으로 수익 확률을 높이는 유일한 방법입니다.")

    # 보고서 저장
    md = ["# 🩺 시스템 닥터 보고서", f"검사: {db.now_kst().isoformat()[:19]}", "",
          "| 상태 | 항목 | 내용 |", "|---|---|---|"]
    for s, n, d, _f in results:
        md.append(f"| {s} | {n} | {d} |")
    with open("system_doctor_report.md", "w", encoding="utf-8") as f:
        f.write("\n".join(md))
    print("📄 저장: system_doctor_report.md")

    # ★ 2026-09-01: 기계가 읽는 JSON도 저장 (현황판이 자동 표시 - 사용자 명령 불필요)
    try:
        os.makedirs("strategy", exist_ok=True)
        json.dump({"at": db.now_kst().isoformat()[:19],
                   "fail": n_fail, "warn": n_warn,
                   "ok": sum(1 for s, *_ in results if s == PASS),
                   "items": [{"status": s, "name": n, "detail": d, "fix": f2}
                             for s, n, d, f2 in results]},
                  open(os.path.join("strategy", "doctor_report.json"), "w",
                       encoding="utf-8"), ensure_ascii=False, indent=1)
    except Exception:
        pass
    return {"fail": n_fail, "warn": n_warn}


def auto_run_daily(log_fn=None):
    """★ 하루 1회 자동 진단 (teams 라운드에서 호출 - 사용자는 현황판에서 보기만)
    이미 오늘 진단했으면 스킵. 반환: 요약 dict 또는 None(스킵)"""
    try:
        rp = json.load(open(os.path.join("strategy", "doctor_report.json"),
                            encoding="utf-8"))
        if str(rp.get("at", ""))[:10] == db.now_kst().strftime("%Y-%m-%d"):
            return None   # 오늘 이미 진단함
    except Exception:
        pass
    try:
        # exe 창모드는 stdout이 없어 print가 죽을 수 있음 → 파일로 우회
        import io
        import contextlib
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            r = main()
        if log_fn:
            try:
                log_fn(f"🩺 자동 자가진단 완료: 실패 {r['fail']}·주의 {r['warn']} "
                       f"(현황판 시스템 탭에서 확인)")
            except Exception:
                pass
        return r
    except Exception:
        return None


if __name__ == "__main__":
    main()
