"""
자동 파일럿 (auto_pilot.py) — 4팀 총괄 운영 (간결)
====================================================
가상 매매 제거. 4팀 구조 (teams.py):
  📥 자료수집 → 🔍 검증 → 🖥 모의매매 → 🧠 총괄(AI·명예의 전당)

실행:
    python auto_pilot.py --rounds 3        # 3라운드 자동
    python auto_pilot.py --status          # 상태 조회
"""
import json
import logging

import db
from config import CFG

log = logging.getLogger("auto_pilot")

from teams import CONTROL, ControlTeam, DataTeam, ValidateTeam, PaperTeam  # noqa: E402


def status():
    """총괄 상태 (UI)"""
    return CONTROL.status()


def run_rounds(rounds=3, per_run=None, paper_n=10, interval=8):
    """여러 라운드 반복 (간결)"""
    import time
    out = []
    for r in range(1, rounds + 1):
        res = CONTROL.round(per_run=per_run, paper_n=paper_n)
        res["round"] = r
        out.append(res)
        if r < rounds:
            time.sleep(interval)
    return {"rounds": out, "note": f"4팀 운영 {rounds}라운드 완료"}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="자동 파일럿 (4팀)")
    parser.add_argument("--rounds", type=int, default=3)
    parser.add_argument("--status", action="store_true")
    args = parser.parse_args()
    db.init_db()
    logging.basicConfig(level=logging.INFO)
    if args.status:
        st = status()
        print("데이터:", st["data"])
        print("모의매매:", st["paper"])
        print("명예의 전당:", st["hof_count"], "건 | 마지막:", st.get("last_run_at"))
    else:
        res = run_rounds(rounds=args.rounds)
        for r in res["rounds"]:
            print(f"[라운드 {r['round']} · {r.get('elapsed')}초]")
            for l in CONTROL.last_log[-5:]:
                print("  " + l)
            print()
