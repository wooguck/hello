# -*- coding: utf-8 -*-
"""
🔬 자리 연구소 (spot_research.py) - 2026-08-28 추가
================================================================
사용자 질문: "어느 시점에서 오르는가? 매물대 통과? 신고가? 주도주?"

유명한 '자리 가설' 8개를 같은 잣대로 실측 비교:
  ① 매물대 상단 돌파 (vp_break - 위에 팔 사람 없어진 자리)
  ② 20일 신고가 돌파 (박스 상단 돌파)
  ③ 60일 신고가 돌파 (중기 박스 돌파)
  ④ 250일 고점 근접 (전고점 도전 자리)
  ⑤ 볼린저 상단 돌파 (변동성 확장)
  ⑥ 골든크로스 직후 (추세 전환 자리)
  ⑦ 낙폭 과대 반등 (60일 고점 -30% + 저점 반등)
  ⑧ 거래량 폭발 (20일 평균 3배)

각 자리의 "그 후 5일" 성적을 기준선(아무 날)과 비교:
  평균 / ★중앙값(복권형 판별) / 승률 / 표본수
  → 기준선보다 중앙값·승률 둘 다 높은 자리 = 진짜 기울어진 자리

실행: python spot_research.py                (5일 보유)
      python spot_research.py --days 10      (10일 보유)
      python spot_research.py --max-symbols 4000   (전 종목 - PC에서)
"""
import argparse
import sys

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

SPOTS = [
    ("① 매물대 상단 돌파",   [("vp_break", {})]),
    ("② 20일 신고가 돌파",   [("high20_break", {})]),
    ("③ 60일 신고가 돌파",   [("high60_break", {})]),
    ("④ 250일 전고점 근접",  [("high250_near", {})]),
    ("⑤ 볼린저 상단 돌파",   [("boll_break_up", {})]),
    ("⑥ 골든크로스 (3일내)", [("golden_cross", {"n": 3})]),
    ("⑦ 낙폭과대+저점반등",  [("fall_from_high60", {"x": 30}), ("low_rebound", {})]),
    ("⑧ 거래량 3배 폭발",    [("vol_ratio20", {"x": 3})]),
]


def _log(m=""):
    print(m, flush=True)


def run(hold=5, max_symbols=300, log_fn=None):
    def L(m):
        _log(m)
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    from screener import load_features, SLOTS
    from config import CFG
    import os as _os
    try:
        cov = db.backfill_coverage(min_days=60)
        symbols = [s for s, c in cov["symbols"].items() if c >= 60][:max_symbols]
    except Exception:
        symbols = []
    feats = load_features(symbols, max_symbols=max_symbols)
    if not feats:
        L("데이터 부족")
        return
    amin = float(_os.getenv("VALIDATE_MIN_AMOUNT", "300000000"))

    def collect(slots):
        """해당 자리 신호일의 이후 hold일 수익률 목록 (실전일치 필터 적용)"""
        rets = []
        fns = [SLOTS[k][3] for k, _p in slots]
        prms = [p for _k, p in slots]
        for sym, f in feats.items():
            if not f:
                continue
            n = len(f["close"])
            vol = f.get("volume") or []
            for i in range(60, n - hold):
                c0 = f["close"][i]
                if c0 <= 0 or c0 < CFG.MOCK_PRICE_MIN or c0 > CFG.MOCK_PRICE_MAX:
                    continue
                if vol and i >= 5:
                    amt5 = sum((f["close"][k] or 0) * (vol[k] or 0)
                               for k in range(i - 4, i + 1)) / 5
                    if amt5 < amin:
                        continue
                if slots:   # 기준선은 slots=[]
                    hit = True
                    for fn, p in zip(fns, prms):
                        try:
                            if not fn(f, i, p):
                                hit = False
                                break
                        except Exception:
                            hit = False
                            break
                    if not hit:
                        continue
                r = (f["close"][i + hold] / c0 - 1) * 100
                if abs(r) <= hold * 31:      # 물리한계 캡 (환상수익 차단)
                    rets.append(r)
        return rets

    base = collect([])
    b_avg = sum(base) / len(base) if base else 0
    b_med = sorted(base)[len(base) // 2] if base else 0
    b_win = len([x for x in base if x > 0]) / len(base) * 100 if base else 0
    L("=" * 74)
    L(f"🔬 자리 연구소: 각 '자리'의 {hold}일 후 성적 (종목 {len(feats)} · 실전일치 필터)")
    L("=" * 74)
    L(f"  {'기준선 (아무 날)':22s} 표본 {len(base):7,d} · 평균 {b_avg:+.2f}% · "
      f"중앙값 {b_med:+.2f}% · 승률 {b_win:.1f}%")
    L("  " + "-" * 70)
    results = []
    for name, slots in SPOTS:
        rs = collect(slots)
        if len(rs) < 20:
            L(f"  {name:22s} 표본 {len(rs):7,d} (부족 - 판단 불가)")
            continue
        avg = sum(rs) / len(rs)
        med = sorted(rs)[len(rs) // 2]
        win = len([x for x in rs if x > 0]) / len(rs) * 100
        edge_m = med - b_med
        edge_w = win - b_win
        mark = "🟢" if (edge_m > 0.15 and edge_w > 1) else "🔴" if (edge_m < -0.15 and edge_w < -1) else "🟡"
        L(f"  {name:22s} 표본 {len(rs):7,d} · 평균 {avg:+.2f}% · 중앙값 {med:+.2f}% "
          f"({edge_m:+.2f}) · 승률 {win:.1f}% ({edge_w:+.1f}) {mark}")
        results.append({"name": name, "n": len(rs), "avg": round(avg, 3),
                        "med": round(med, 3), "win": round(win, 1),
                        "edge_med": round(edge_m, 3), "edge_win": round(edge_w, 1)})
    L("  " + "-" * 70)
    L("  🟢 = 중앙값·승률 둘 다 기준선 초과 (진짜 기울어진 자리)")
    L("  판단: 🟢 자리는 검색식/채널 우선순위에 반영 가치 - 소원함이나 요청으로 조합 가능")
    import json, os
    os.makedirs("strategy", exist_ok=True)
    json.dump({"hold": hold, "symbols": len(feats),
               "baseline": {"n": len(base), "avg": round(b_avg, 3),
                            "med": round(b_med, 3), "win": round(b_win, 1)},
               "spots": results},
              open(os.path.join("strategy", "spot_research.json"), "w",
                   encoding="utf-8"), ensure_ascii=False, indent=1)
    L("📄 저장: strategy/spot_research.json")
    return results


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=5)
    ap.add_argument("--max-symbols", type=int, default=300)
    args = ap.parse_args()
    db.init_db()
    run(hold=args.days, max_symbols=args.max_symbols)
