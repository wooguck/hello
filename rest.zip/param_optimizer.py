# -*- coding: utf-8 -*-
"""
🎛 매도 파라미터 자동 최적화 (param_optimizer.py)
==================================================
"2% 익절이 좋은지 5%가 좋은지, 3일 보유가 좋은지 5일이 좋은지"를
조건식별로 **자동으로 전부 시험**해서 최적 조합을 찾습니다.

★ 과적합 방지 내장 (지난번 구버전 교훈 반영):
  1) 시간 분리: 앞 70% 기간(학습)에서 최적 조합 선정 →
     뒤 30% 기간(검증, OOS)에서도 플러스인지 확인. OOS 실패 = 탈락
  2) 고원(plateau) 검사: 1등 조합의 이웃 조합(±1칸)도 평균 플러스여야 채택
     ("TP 4.5%만 되고 4%/5%는 안 되는" 노이즈 적합 차단)
  3) 결과에 1등만이 아니라 상위 5개 + 이웃 성적 함께 표시 (사람이 판단 가능)

★ 캐시 (재검색 고속화):
  - 신호(진입 후보) 계산이 가장 무거움 → 조건식+종목+기간 해시로 캐시 저장
  - 같은 조건식 다시 돌리면 신호 재계산 없이 파라미터 조합만 재평가 (수십 배 빠름)
  - 캐시 위치: strategy/opt_cache/ (데이터 갱신일 바뀌면 자동 무효화)

실행:
  python param_optimizer.py --list          # 조건식 목록
  python param_optimizer.py --cond 2        # 2번 조건식 최적화
  python param_optimizer.py --cond 2 --apply  # 최적 조합을 .env에 자동 적용
"""
import argparse
import hashlib
import itertools
import json
import os
import pickle
import sys
import time
from datetime import datetime

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db
import validation as V

CACHE_DIR = os.path.join("strategy", "opt_cache")

# 시험할 조합 (요청: 익절 2~5% / 보유 3~5일 포함, 주변까지)
# ★ 2026-08-28 확장: 단타(1~3일)~스윙(20일=1달) 전 구간 (사용자: "1일/3일/5일/1달 스윙")
TP_GRID = [2.0, 3.0, 4.0, 5.0, 7.0, 10.0, 15.0, 20.0]
SL_GRID = [1.5, 2.0, 3.0, 4.0, 5.0]
TRAIL_GRID = [0.0, 1.5, 2.0, 3.0]
HOLD_GRID = [1, 2, 3, 5, 7, 10, 15, 20]

def style_of(hold):
    """보유일 → 스타일 라벨 (초단타는 분봉 축적 후 별도)"""
    return "단타" if hold <= 3 else "스윙단기" if hold <= 10 else "스윙(1달)"
FEE = V.FEE_PCT


def _log(msg=""):
    print(msg, flush=True)


def list_conds():
    out = []
    try:
        for c in db.get_conditions(status="active"):
            try:
                slots = json.loads(c.get("slots_json") or "[]")
            except Exception:
                slots = []
            if slots:
                out.append({"id": str(c["id"]), "txt": (c.get("cond_txt") or "")[:70],
                            "slots": slots})
    except Exception:
        pass
    if not out:
        try:
            from photo_conditions import PHOTO_TEMPLATES, template_slots
            for t in PHOTO_TEMPLATES:
                out.append({"id": f"photo{t['photo']}",
                            "txt": f"[사진{t['photo']}] {t['name']}",
                            "slots": [[k, p] for k, p in template_slots(t)]})
        except Exception:
            pass
    return out


# ── 신호 수집 (무거움 → 캐시) ────────────────────────────
def collect_signals(slots, max_symbols=400):
    """조건식 신호 발생 지점 수집: [(sym, bars, [signal_idx...])]
    캐시: 조건식+종목집합+데이터최신일 해시 → 재실행 시 즉시 로드
    """
    os.makedirs(CACHE_DIR, exist_ok=True)
    try:
        cov = db.backfill_coverage(min_days=120)
        symbols = sorted([s for s, n in cov["symbols"].items() if n >= 120])[:max_symbols]
    except Exception:
        symbols = []
    if not symbols:
        return [], "일봉 120봉+ 종목 없음"
    # 데이터 최신일 (캐시 무효화 기준)
    latest = ""
    try:
        import sqlite3
        p = os.path.join(db.DATA_DIR, "stocks", f"{symbols[0]}.db")
        c = sqlite3.connect(p)
        latest = (c.execute("SELECT MAX(bar_date) FROM daily_bars").fetchone() or [""])[0] or ""
        c.close()
    except Exception:
        pass
    key = hashlib.md5(json.dumps([slots, symbols[:50], len(symbols), latest],
                                 sort_keys=True, default=str).encode()).hexdigest()[:16]
    cpath = os.path.join(CACHE_DIR, f"sig_{key}.pkl")
    if os.path.exists(cpath):
        try:
            with open(cpath, "rb") as f:
                data = pickle.load(f)
            return data, f"캐시 히트 ({len(data)}종목 - 신호 재계산 생략)"
        except Exception:
            pass
    # 신호 계산 (validation과 동일 방식)
    from screener import build_features, SLOTS
    fns = []
    prms = []
    for it in slots:
        k, p = it[0], (it[1] if len(it) > 1 else {})
        if k in SLOTS:
            fns.append(SLOTS[k][3])
            prms.append(p or {})
    out = []
    t0 = time.time()
    for si, sym in enumerate(symbols):
        bars = V._load_bars(sym, max_days=1000)
        if len(bars) < 120:
            continue
        f = build_features(bars)
        if not f:
            continue
        idxs = []
        for i in range(60, len(bars) - 1):
            if bars[i]["close"] <= 0:
                continue
            ok = True
            for fn, p in zip(fns, prms):
                try:
                    if not fn(f, i, p):
                        ok = False
                        break
                except Exception:
                    ok = False
                    break
            if ok:
                idxs.append(i)
        if idxs:
            out.append((sym, bars, idxs))
        if (si + 1) % 50 == 0:
            sys.stdout.write(f"\r  신호 수집 {si+1}/{len(symbols)} · {time.time()-t0:.0f}초   ")
            sys.stdout.flush()
    print()
    try:
        with open(cpath, "wb") as f:
            pickle.dump(out, f)
    except Exception:
        pass
    return out, f"신호 계산 완료 ({len(out)}종목 · {time.time()-t0:.0f}초 → 캐시 저장, 다음엔 즉시)"


# ── 파라미터 조합 평가 (신호 재사용 - 빠름) ──────────────
def eval_params(signals, tp, sl, trail, hold, date_from=None, date_to=None):
    """주어진 TP/SL/트레일/보유일로 모든 신호를 청산 시뮬 (보수적: SL 먼저)"""
    rets = []
    for sym, bars, idxs in signals:
        n = len(bars)
        for i in idxs:
            d = bars[i]["date"]
            if date_from and d < date_from:
                continue
            if date_to and d > date_to:
                continue
            if i + 1 >= n:
                continue
            entry = bars[i + 1]["open"] or bars[i + 1]["close"]
            if entry <= 0:
                continue
            tp_p = entry * (1 + tp / 100)
            sl_p = entry * (1 - sl / 100)
            highest = entry
            ret = None
            for j in range(i + 1, min(i + 1 + hold, n)):
                b = bars[j]
                lo, hi, cl = b["low"] or b["close"], b["high"] or b["close"], b["close"]
                # 보수적: 같은 날 둘 다 스치면 손절 먼저
                if lo <= sl_p:
                    ret = -sl
                    break
                if hi >= tp_p:
                    ret = tp
                    break
                highest = max(highest, hi)
                if trail > 0 and highest > entry:
                    tr_p = highest * (1 - trail / 100)
                    if lo <= tr_p and tr_p > entry:
                        ret = (tr_p / entry - 1) * 100
                        break
            if ret is None:
                # 보유 만기 종가 청산
                j_end = min(i + hold, n - 1)
                cl = bars[j_end]["close"]
                if cl > 0:
                    ret = (cl / entry - 1) * 100
                else:
                    continue
            rets.append(ret - FEE)
    if len(rets) < 20:
        return None
    wins = [r for r in rets if r > 0]
    gross_l = abs(sum(r for r in rets if r <= 0)) or 0.001
    return {"trades": len(rets), "avg": sum(rets) / len(rets),
            "win_rate": len(wins) / len(rets) * 100,
            "pf": sum(wins) / gross_l}


def neighbors(combo):
    """조합의 이웃 (각 축 ±1칸)"""
    tp, sl, tr, hd = combo
    out = []
    for grid, val, pos in ((TP_GRID, tp, 0), (SL_GRID, sl, 1), (TRAIL_GRID, tr, 2), (HOLD_GRID, hd, 3)):
        i = grid.index(val)
        for k in (i - 1, i + 1):
            if 0 <= k < len(grid):
                c = list(combo)
                c[pos] = grid[k]
                out.append(tuple(c))
    return out


def optimize_one(c, max_symbols=400, apply=False, quiet=False):
    """조건식 1개 최적화 (자동 파이프라인에서도 호출). 반환: 채택 조합 dict 또는 None"""
    global _log
    if quiet:
        _orig_log = _log
        _log = lambda m="": None
    try:
        return _optimize_body(c, max_symbols, apply)
    finally:
        if quiet:
            _log = _orig_log


def auto_optimize(max_per_call=1, max_symbols=300, log_fn=None):
    """★ 자동 순환 최적화 (2026-08-28 사용자: '자동으로 최적 찾는 거 아니야?')
    라운드에서 호출 - 오래 안 본 조건식부터 1개씩 최적화, 결과 저장.
    적용(.env)은 전 조건식 결과의 '중앙값 조합'으로만 (한 조건식이 전역을 흔들지 않게)"""
    import json as _json
    os.makedirs("strategy", exist_ok=True)
    store_p = os.path.join("strategy", "opt_results.json")
    store = {}
    try:
        store = _json.load(open(store_p, encoding="utf-8"))
    except Exception:
        pass
    conds = list_conds()
    if not conds:
        return {}
    # 오래 안 본 순
    conds.sort(key=lambda c: store.get(c["id"], {}).get("at", ""))
    done = []
    for c in conds[:max_per_call]:
        r = optimize_one(c, max_symbols=max_symbols, apply=False, quiet=True)
        entry = {"at": db.now_kst_iso(), "txt": c["txt"][:50]}
        if r:
            entry.update(r)
            done.append((c["txt"][:30], r))
        else:
            entry["verdict"] = "통과 조합 없음"
        store[c["id"]] = entry
        if log_fn and r:
            try:
                log_fn(f"🎛 [자동최적화] {c['txt'][:28]} → TP{r['tp']}/SL{r['sl']}"
                       f"/트{r['trail']}/{r['hold']}일 (OOS {r['oos_avg']:+.2f}%)")
            except Exception:
                pass
    # ★ 전 조건식 중앙값 조합 → .env 적용 (5개 이상 결과 모였을 때만)
    oks = [v for v in store.values() if v.get("tp")]
    if len(oks) >= 5 and os.getenv("AUTO_OPT_APPLY", "true").lower() == "true":
        med = lambda k: sorted(v[k] for v in oks)[len(oks) // 2]
        combo = {"tp": med("tp"), "sl": med("sl"), "trail": med("trail"), "hold": int(med("hold"))}
        prev = store.get("_applied") or {}
        if prev != combo:
            try:
                from visual_lab import apply_env
                apply_env(combo)
                store["_applied"] = combo
                if log_fn:
                    log_fn(f"🎛 [자동최적화] 전체 중앙값 적용: TP{combo['tp']}/SL{combo['sl']}"
                           f"/트{combo['trail']}/{combo['hold']}일 ({len(oks)}개 조건식 합의)")
            except Exception:
                pass
    _json.dump(store, open(store_p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return {"optimized": len(done), "stored": len(oks)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cond", type=int, default=0)
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--apply", action="store_true", help="최적 조합 .env 자동 적용")
    ap.add_argument("--auto", action="store_true", help="자동 순환 (라운드가 하는 것 수동 실행)")
    ap.add_argument("--max-symbols", type=int, default=400)
    args = ap.parse_args()

    conds = list_conds()
    if args.auto:
        r = auto_optimize(max_per_call=3, log_fn=print)
        print("자동 최적화:", r)
        return
    if args.list or not args.cond:
        _log(f"조건식 {len(conds)}개: (--cond 번호로 선택 / --auto 자동순환)")
        for i, c in enumerate(conds):
            _log(f"  {i+1}. [{c['id']}] {c['txt']}")
        return
    c = conds[min(args.cond - 1, len(conds) - 1)]
    _optimize_body(c, args.max_symbols, args.apply)


def _optimize_body(c, max_symbols=400, apply=False):

    _log("=" * 70)
    _log(f"🎛 매도 파라미터 자동 최적화  |  {c['txt']}")
    _log("=" * 70)
    _log(f"조합: TP{TP_GRID} × SL{SL_GRID} × 트레일{TRAIL_GRID} × 보유{HOLD_GRID}"
         f" = {len(TP_GRID)*len(SL_GRID)*len(TRAIL_GRID)*len(HOLD_GRID)}개")

    signals, note = collect_signals(c["slots"], max_symbols=max_symbols)
    _log(f"[1] 신호 수집: {note}")
    if not signals:
        return
    all_dates = sorted({bars[i]["date"] for _s, bars, idxs in signals for i in idxs})
    if len(all_dates) < 30:
        _log("⛔ 신호 날짜가 30일 미만 - 표본 부족")
        return
    split = all_dates[int(len(all_dates) * 0.7)]
    _log(f"[2] 시간 분리: 학습 ~{split} (70%) / 검증 {split}~ (30%)")

    # 학습 구간 전 조합 평가
    t0 = time.time()
    results = []
    combos = list(itertools.product(TP_GRID, SL_GRID, TRAIL_GRID, HOLD_GRID))
    for i, (tp, sl, tr, hd) in enumerate(combos):
        r = eval_params(signals, tp, sl, tr, hd, date_to=split)
        if r:
            results.append(((tp, sl, tr, hd), r))
        if (i + 1) % 60 == 0:
            sys.stdout.write(f"\r  조합 평가 {i+1}/{len(combos)} · {time.time()-t0:.0f}초   ")
            sys.stdout.flush()
    print()
    if not results:
        _log("⛔ 유효 조합 없음 (매매 20건 미만)")
        return
    results.sort(key=lambda x: -(x[1]["avg"] * min(x[1]["pf"], 3)))

    _log(f"\n[3] 학습 구간 상위 5개 → OOS(검증)·고원 검사:")
    _log(f"  {'조합(TP/SL/트레일/보유)':26} {'학습:평균/승률/PF':>22} {'OOS:평균/승률':>16} {'이웃평균':>8} 판정")
    _log("  " + "-" * 86)
    chosen = None
    for combo, tr_r in results[:5]:
        tp, sl, trl, hd = combo
        oos = eval_params(signals, tp, sl, trl, hd, date_from=split)
        nb_avgs = []
        for nb in neighbors(combo):
            nr = eval_params(signals, *nb, date_to=split)
            if nr:
                nb_avgs.append(nr["avg"])
        nb_avg = sum(nb_avgs) / len(nb_avgs) if nb_avgs else 0
        oos_ok = oos and oos["avg"] > 0
        plateau_ok = nb_avg > 0
        verdict = "✅ 채택 가능" if (oos_ok and plateau_ok) else \
                  ("⚠️ OOS 실패" if not oos_ok else "⚠️ 고원 실패(노이즈 적합 의심)")
        _log(f"  [{style_of(hd)}] TP{tp}/SL{sl}/트{trl}/{hd}일 "
             f"{tr_r['avg']:+.2f}%/{tr_r['win_rate']:.0f}%/{tr_r['pf']:.2f}{'':6} "
             f"{(oos['avg'] if oos else 0):+.2f}%/{(oos['win_rate'] if oos else 0):.0f}%{'':4} "
             f"{nb_avg:+.2f}%  {verdict}")
        if chosen is None and oos_ok and plateau_ok:
            chosen = (combo, tr_r, oos)

    if not chosen:
        _log("\n🔴 결론: OOS+고원을 모두 통과한 조합 없음 - 이 조건식은 파라미터로")
        _log("   구제가 안 되는 것일 수 있습니다 (조건식 자체를 바꾸는 게 맞음)")
        return None
    (tp, sl, trl, hd), tr_r, oos = chosen
    _log(f"\n🏆 최적 조합: 익절 {tp}% · 손절 {sl}% · 트레일링 {trl}% · 보유 {hd}일")
    _log(f"   학습 {tr_r['trades']}건 평균 {tr_r['avg']:+.2f}% · 검증(OOS) {oos['trades']}건 평균 {oos['avg']:+.2f}%")
    _log(f"   → \"2%냐 5%냐\"의 답: 이 조건식은 위 조합이 통계적으로 가장 안정적입니다")

    if apply:
        try:
            from visual_lab import apply_env
            r = apply_env({"tp": tp, "sl": sl, "trail": trl, "hold": hd})
            _log(f"\n💾 .env 적용 완료: {r['applied']} (백업 .env.bak)")
            _log("   ⚠️ 실행 중인 앱은 재시작해야 반영됩니다")
        except Exception as e:
            _log(f"\n⚠️ 적용 실패: {e} - visual_lab.py가 같은 폴더에 있어야 합니다")
    else:
        _log(f"\n적용하려면: python param_optimizer.py --cond N --apply")
    return {"tp": tp, "sl": sl, "trail": trl, "hold": hd,
            "oos_avg": round(oos["avg"], 3), "oos_win": round(oos["win_rate"], 1),
            "trades": tr_r["trades"], "verdict": "채택"}


if __name__ == "__main__":
    main()
