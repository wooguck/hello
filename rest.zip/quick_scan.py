# -*- coding: utf-8 -*-
"""
⚡ 장중 빠른 스캔 (quick_scan.py) - 지수 게이트 + 최소기준 필터 + 당일 분봉 확인
==============================================================================
사용자 요청:
  "당일 분봉 검증이 안 되나 · 장시작 지수 반영해서 찾고 · 최소 기준으로 걸러서 빠르게"

동작 (3단계 깔때기 - 빠른 것부터):
  [1] 지수 게이트 (1초)   : 코스피/코스닥 실시간 등락률 → 기준 미달이면 진입 보류 안내
  [2] 최소기준 필터 (수 초): 로컬 일봉으로 전 종목 → 가격/거래대금/봉수/최신성 컷
                            + 정배열·눌림 점수 상위만 통과 (기본 상위 40종목)
  [3] 당일 분봉 확인 (종목당 ~0.3초): 네이버 분봉으로 오늘 장중 흐름 검사
       · 시가 대비 현재 위치 · VWAP 위/아래 · 오전 거래대금 · 급등 추격 여부
  → 최종 후보 랭킹 출력 (조건식 신호 여부도 함께 표시)

실행:
  python quick_scan.py              # 기본 (2단계 상위 40종목 → 분봉 확인)
  python quick_scan.py --top 20     # 분봉 확인 종목 수 조절 (적을수록 빠름)
  python quick_scan.py --no-minute  # 분봉 생략 (수 초 만에 1·2단계만)
"""
import argparse
import os
import sys
import time
from datetime import datetime

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db
from config import CFG


def _log(msg=""):
    print(msg, flush=True)


# ── [1] 지수 게이트 ──────────────────────────────────────
def index_gate():
    from backfill_history import fetch_index
    warn = float(getattr(CFG, "INDEX_WARN_PCT", -1.0))
    crash = float(getattr(CFG, "INDEX_CRASH_PCT", -2.0))
    out = []
    worst = 0.0
    for nm in ("KOSPI", "KOSDAQ"):
        try:
            ix = fetch_index(nm)
            if ix:
                out.append(f"{ix['name']} {ix['value']:,.2f} ({ix['change_pct']:+.2f}%)")
                worst = min(worst, ix["change_pct"])
        except Exception:
            continue
    level = "정상"
    if crash and worst <= crash:
        level = "위험(진입금지+청산권고)"
    elif warn and worst <= warn:
        level = "주의(진입보류)"
    return {"level": level, "worst": worst, "txt": " · ".join(out) or "지수 조회 실패"}


# ── [2] 최소기준 필터 (로컬 일봉 - 초고속) ────────────────
def base_filter(min_price=1000, max_price=200000, min_amount=300_000_000,
                min_bars=30, top=40):
    from validation import _load_bars
    stocks_dir = os.path.join(db.DATA_DIR, "stocks")
    names = {}
    try:
        for u in db.get_universe():
            names[u.get("symbol")] = u.get("name") or ""
    except Exception:
        pass
    today = db.now_kst().strftime("%Y-%m-%d")
    fresh_cut = today[:8] + "01"  # 이번 달 봉이 있으면 최신으로 간주 (단순·빠름)
    cands = []
    files = [f[:-3] for f in os.listdir(stocks_dir) if f.endswith(".db")] if os.path.isdir(stocks_dir) else []
    for sym in files:
        bars = _load_bars(sym, max_days=40)
        if len(bars) < min_bars:
            continue
        if bars[-1]["date"] < fresh_cut:
            continue                      # 최신 아님 (폐지 등)
        c = [b["close"] for b in bars]
        v = [b["volume"] for b in bars]
        px = c[-1]
        if not (min_price <= px <= max_price):
            continue                      # 최소/최대 가격 기준
        amt5 = px * (sum(v[-5:]) / 5)
        if amt5 < min_amount:
            continue                      # 최소 거래대금 기준
        ma5 = sum(c[-5:]) / 5
        ma20 = sum(c[-20:]) / 20
        chg5 = (c[-1] / c[-6] - 1) * 100 if len(c) > 5 and c[-6] else 0
        chg1 = (c[-1] / c[-2] - 1) * 100 if c[-2] else 0
        score = 0.0
        if ma5 > ma20:
            score += 2
        if px > ma20:
            score += 2
        if -3 <= chg5 <= 2:
            score += 2       # 눌림 (추격 방지)
        if chg1 > 8:
            score -= 3       # 당일 급등 추격 감점
        vr = (sum(v[-3:]) / 3) / (sum(v[-20:]) / 20 + 1)
        if vr > 1.2:
            score += 1
        if score >= 4:
            cands.append({"symbol": sym, "name": names.get(sym, "")[:8], "price": px,
                          "score": score, "chg5": chg5, "amt5": amt5})
    cands.sort(key=lambda x: -x["score"])
    return cands[:top]


# ── [3] 당일 분봉 확인 (네이버 실시간 - 종목당 1콜) ────────
def check_today_minutes(symbol):
    """오늘 분봉으로 장중 흐름 판정
    반환: {ok, open_pos(시가대비%), vwap_above, am_amount(오전 거래대금 추정), note} / None
    """
    from backfill_history import fetch_minutes
    try:
        bars = fetch_minutes(symbol, max_bars=500)
    except Exception:
        return None
    today = db.now_kst().strftime("%Y%m%d")
    tb = [b for b in bars if b["bar_time"].strftime("%Y%m%d") == today]
    if len(tb) < 5:
        return None                       # 오늘 분봉 없음 (장전/데이터 지연)
    o = tb[0]["price"]
    cur = tb[-1]["price"]
    open_pos = (cur / o - 1) * 100 if o else 0
    # VWAP (분봉 가격×거래량 가중)
    tot_v = sum(b["volume"] for b in tb) or 1
    vwap = sum(b["price"] * b["volume"] for b in tb) / tot_v
    amount = sum(b["price"] * b["volume"] for b in tb)
    note = []
    ok = True
    if cur < vwap:
        note.append("VWAP 아래(약세)")
        ok = False
    if open_pos < -2:
        note.append("시가 대비 -2%↓")
        ok = False
    if open_pos > 7:
        note.append("당일 +7%↑ 추격주의")
        ok = False
    if not note:
        note.append("장중 흐름 양호")
    return {"ok": ok, "open_pos": open_pos, "vwap_above": cur >= vwap,
            "amount": amount, "note": " · ".join(note)}


def cond_signal(symbol, price):
    """활성 조건식 중 신호 잡히는 게 있는지 (있으면 조건식명)"""
    try:
        import json as _j
        import paper_test
        for c in db.get_conditions(status="active")[:10]:
            try:
                slots = _j.loads(c.get("slots_json") or "[]")
            except Exception:
                continue
            if not slots:
                continue
            hit, _r = paper_test._check_signal(slots, symbol, price)
            if hit:
                return (c.get("cond_txt") or "")[:24]
    except Exception:
        pass
    return ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--top", type=int, default=40, help="분봉 확인 종목 수")
    ap.add_argument("--no-minute", action="store_true", help="분봉 생략 (1·2단계만)")
    args = ap.parse_args()

    t0 = time.time()
    _log("=" * 66)
    _log(f"⚡ 장중 빠른 스캔  ({db.now_kst().strftime('%m-%d %H:%M')})")
    _log("=" * 66)

    # [1] 지수
    g = index_gate()
    icon = "🟢" if g["level"] == "정상" else ("🟡" if "주의" in g["level"] else "🔴")
    _log(f"\n[1] 지수 게이트: {icon} {g['level']}  |  {g['txt']}")
    if "위험" in g["level"]:
        _log("    ⛔ 지수 급락 - 오늘은 신규 진입 비권장 (스캔은 계속)")

    # [2] 최소기준
    cands = base_filter(top=args.top)
    _log(f"\n[2] 최소기준 필터: {len(cands)}종목 통과 "
         f"(가격 1천~20만 · 거래대금 3억+ · 최신 일봉 · 추세점수 4+) · {time.time()-t0:.1f}초")
    if not cands:
        _log("    후보 없음 - 데이터/기준 확인")
        return

    # [3] 당일 분봉
    if args.no_minute:
        _log("\n[3] 당일 분봉 확인: 생략 (--no-minute)")
        final = [{**c, "m": None} for c in cands]
    else:
        _log(f"\n[3] 당일 분봉 확인 중 ({len(cands)}종목 × ~0.3초)...")
        final = []
        for i, c in enumerate(cands):
            m = check_today_minutes(c["symbol"])
            final.append({**c, "m": m})
            sys.stdout.write(f"\r    {i+1}/{len(cands)}   ")
            sys.stdout.flush()
            time.sleep(0.25)
        print()

    # 랭킹 출력 (분봉 양호 우선)
    def _rank(x):
        m = x["m"]
        return (0 if (m and m["ok"]) else (2 if m is None else 1), -x["score"])
    final.sort(key=_rank)

    _log(f"\n{'':2}{'종목':8} {'이름':10} {'현재가':>9} {'점수':>4} {'당일':>7} {'장중 판정'}")
    _log("  " + "-" * 66)
    shown = 0
    for x in final:
        m = x["m"]
        if m is None and not args.no_minute:
            mark, pos, note = "⚪", "-", "오늘 분봉 없음(장전?)"
        elif m is None:
            mark, pos, note = "  ", "-", ""
        else:
            mark = "🟢" if m["ok"] else "🔻"
            pos = f"{m['open_pos']:+.1f}%"
            note = m["note"]
        sig = cond_signal(x["symbol"], x["price"])
        sigtxt = f"  📡{sig}" if sig else ""
        _log(f"{mark} {x['symbol']:8} {x['name']:10} {x['price']:>9,.0f} {x['score']:>4.0f} "
             f"{pos:>7} {note}{sigtxt}")
        shown += 1
        if shown >= 25:
            _log(f"  ... 외 {len(final)-25}종목")
            break

    _log(f"\n⏱ 총 {time.time()-t0:.1f}초 · 🟢=장중 흐름 양호 · 📡=활성 조건식 신호 겹침")
    _log("   (진입은 모의매매 루프/AI픽이 담당 - 이 스캔은 빠른 눈 확인용)")


if __name__ == "__main__":
    main()
