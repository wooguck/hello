@echo off
setlocal
cd /d "%~dp0"

echo [1] Python version:
python --version
echo.
echo [2] Running app directly (errors will show below)...
echo ------------------------------------------------------------
python desktop_app.py
echo ------------------------------------------------------------
echo.
echo If you see Traceback/Error above, copy and send it.
echo If the app window opened OK = code is fine, exe build issue.
pause
