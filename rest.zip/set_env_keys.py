# -*- coding: utf-8 -*-
"""
🔑 .env 키 입력 헬퍼 (set_env_keys.py)
======================================
cmd에서 키를 입력받아 .env에 자동 기록 (수동 편집 대신)

실행:
  python set_env_keys.py

입력 순서:
  1) KIWOOM_APP_KEY     (모의용 앱키)
  2) KIWOOM_APP_SECRET  (모의용 시크릿)
  3) KIWOOM_ACCOUNT_NO  (모의계좌번호 숫자만)
  4) GEMINI_API_KEY     (Gemini 키 - AI 판단용, 없으면 Enter)
"""
import os
import sys

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ENV_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")


def load_env():
    data = {}
    if os.path.exists(ENV_PATH):
        for line in open(ENV_PATH, encoding="utf-8"):
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                data[k.strip()] = v.strip()
    return data


def save_env(data):
    # 기존 주석/순서 유지하며 키만 교체
    lines = []
    if os.path.exists(ENV_PATH):
        lines = open(ENV_PATH, encoding="utf-8").read().split("\n")
    keys = list(data.keys())
    for i, ln in enumerate(lines):
        s = ln.strip()
        if s and not s.startswith("#") and "=" in s:
            k = s.split("=", 1)[0].strip()
            if k in data:
                lines[i] = f"{k}={data[k]}"
                keys.remove(k)
    # 새 키 추가
    for k in keys:
        lines.append(f"{k}={data[k]}")
    with open(ENV_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"✅ .env 저장 완료: {ENV_PATH}")


def ask(label, current=""):
    v = input(f"  {label} [{current if current else '비어있음'}]: ").strip()
    return v or current


if __name__ == "__main__":
    print("=" * 56)
    print("🔑 키움/Gemini 키 입력 - .env 자동 설정")
    print("  (모의용 키! 실전 키를 넣지 마세요)")
    print("=" * 56)
    data = load_env()
    data["KIWOOM_APP_KEY"] = ask("KIWOOM_APP_KEY", data.get("KIWOOM_APP_KEY", ""))
    data["KIWOOM_APP_SECRET"] = ask("KIWOOM_APP_SECRET", data.get("KIWOOM_APP_SECRET", ""))
    data["KIWOOM_ACCOUNT_NO"] = ask("KIWOOM_ACCOUNT_NO(계좌번호)", data.get("KIWOOM_ACCOUNT_NO", ""))
    data["GEMINI_API_KEY"] = ask("GEMINI_API_KEY(선택, Enter 스킵)", data.get("GEMINI_API_KEY", ""))
    save_env(data)
    print()
    print("  다음 실행:")
    print("    python verify_final.py      # 확인")
    print("    python collect_data.py --once")
    print("    python desktop_app.py")
