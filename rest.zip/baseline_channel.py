# -*- coding: utf-8 -*-
"""
🎲 기준선(대조군) 채널 (baseline_channel.py) - "선별 없이 그냥 사는" 실험군
==========================================================================
사용자: "AI가 선별해서 사는 거랑, 선별 없이 그냥 사는 거랑 비교되고 있는지?"

목적: 진짜 대조군. 아무 선별 없이 무작위로 사서, 매도 규칙만 동일하게 적용.
  → trade_stats에서 BASELINE vs 조건식/AI_PICK/MOMENTUM/FORCE_LINE 직접 비교
  → 어떤 채널이든 BASELINE을 못 이기면 "선별이 의미 없다"는 증거

규칙:
  - 유동성 필터만 (거래대금 5일평균 3억+ - 체결 가능성만 보장, 선별 아님)
  - 그 안에서 완전 무작위 N종목 (기본 2)
  - 매수 금액/매도 규칙(트레일링·하드손절·가드)은 다른 채널과 동일
  - 하루 1회 제한

실행:
  python baseline_channel.py          # 오늘의 무작위 매수 (장중)
  python baseline_channel.py --dry    # 뽑기만
매일 자동: 장중 라운드 or 작업 스케줄러 09:10
"""
import argparse
import json
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import random
import sys

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

STATE = os.path.join("strategy", "baseline_state.json")


def _today():
    return db.now_kst().strftime("%Y-%m-%d")


def picked_today():
    try:
        with open(STATE, encoding="utf-8") as f:
            st = json.load(f)
        return st.get("picked", []) if st.get("date") == _today() else []
    except Exception:
        return []


def liquid_pool(min_amount=300_000_000):
    """유동성만 통과한 전체 풀 (선별 없음)"""
    import sqlite3
    sd = os.path.join(db.DATA_DIR, "stocks")
    pool = []
    if not os.path.isdir(sd):
        return pool
    for f in os.listdir(sd):
        if not f.endswith(".db"):
            continue
        try:
            c = sqlite3.connect(os.path.join(sd, f))
            r = c.execute("SELECT AVG(amount), MAX(bar_date) FROM (SELECT amount, bar_date "
                          "FROM daily_bars ORDER BY bar_date DESC LIMIT 5)").fetchone()
            c.close()
            if r and r[0] and r[0] >= min_amount:
                pool.append(f[:-3])
        except Exception:
            continue
    return pool


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=2)
    ap.add_argument("--dry", action="store_true")
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    print("🎲 기준선(무작위) 채널 - 선별 없이 그냥 사는 대조군")
    if picked_today() and not args.force and not args.dry:
        print(f"오늘 이미 매수함: {picked_today()} (--force로 재실행)")
        return
    pool = liquid_pool()
    print(f"유동성 풀 {len(pool)}종목 (거래대금 3억+ - 이것만 걸러짐, 선별 없음)")
    if len(pool) < args.n:
        print("풀 부족")
        return
    held = {p["symbol"] for p in db.get_paper_open()}
    cands = [s for s in pool if s not in held]
    picks = random.sample(cands, min(args.n, len(cands)))
    names = {}
    try:
        for u in db.get_universe():
            names[u.get("symbol")] = u.get("name") or ""
    except Exception:
        pass

    import paper_test
    from config import CFG
    budget = _cfg_env_float("BASELINE_BUDGET", 0) or paper_test.buy_budget()  # ★ 공용 예산 (비율/금액)
    bought = []
    in_market = paper_test._in_market_hours()
    for sym in picks:
        price = paper_test._get_price(sym) or 0
        if price <= 0:
            continue
        qty = int(budget / price)
        if qty < 1:
            continue   # 가격 > 종목당 예산 - 스킵
        if args.dry:
            print(f"  🔍 [뽑기] {sym} {names.get(sym,'')} {qty}주 @{price:,.0f}")
            continue
        order = None
        if paper_test.REAL_PAPER_ORDER and in_market and not CFG.DRY_RUN:
            order = paper_test._place_real_order(sym, "buy", qty, price)
            if order and order.get("status") == "error":
                continue
        # ★ 진입 슬리피지 (대조군도 동일 조건 - 비교 공정성, 2026-08-27)
        entry_p = price if (order and not CFG.DRY_RUN) else paper_test.entry_slip(price)
        db.open_paper_position("BASELINE", "[기준선] 무작위 매수 (선별 없음 - 대조군)",
                               sym, entry_p, qty, order_kind=("real" if order else "virtual"))
        bought.append(sym)
        print(f"  ✅ 매수 {sym} {names.get(sym,'')} {qty}주 @{price:,.0f} (무작위)")
    if bought and not args.dry:
        os.makedirs("strategy", exist_ok=True)
        with open(STATE, "w", encoding="utf-8") as f:
            json.dump({"date": _today(), "picked": bought}, f, ensure_ascii=False)
        print(f"\n→ 매도는 다른 채널과 동일 규칙 (트레일링/하드손절/가드)")
        print("→ 비교: python trade_stats.py 에서 'BASELINE' 행이 기준선입니다")
        print("  다른 채널이 BASELINE보다 못하면 = 그 선별은 무의미하다는 증거")


if __name__ == "__main__":
    main()
