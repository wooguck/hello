# -*- coding: utf-8 -*-
"""
🚀 급등주 모멘텀 채널 (momentum_channel.py)
=============================================
사용자: "조건식이 다 높은 지점에서 사고, 인기 없는 종목만 있고,
        실제 급등하는 종목이 필요함"

접근: 당일 상승률 상위(네이버 실시간)에서 '지금 막 달리기 시작한' 종목만 선별.
  ⚠️ 급등주는 추격이 아니라 '초입'이 생명 - 필터가 핵심:
  ① 상승률 +3~+15% (이미 +20% 상한가 근처는 제외 - 추격 금지)
  ② 거래대금 50억+ (인기/유동성 - '그저 그런 종목' 배제)
  ③ 첫 급등 (최근 20일 내 +15% 급등 이력 없음 = 신선한 재료)
  ④ 세력 동반 확인 (기관+외인 순매수면 가점) - force_line 연동
  ⑤ VWAP 위 (당일 분봉 - 장중 흐름 살아있음)

매수: cond_key='MOMENTUM' 채널 (trade_stats에서 조건식/AI픽/세력선과 성적 비교)
매도: 기존 안전벨트 그대로 (동적 트레일링 + 하드손절 + 가드)
  + 급등주 전용: 타이트한 손절 권장 (지침 손절가 = 당일 VWAP 근처)

실행:
  python momentum_channel.py            # 스캔만 (눈 확인)
  python momentum_channel.py --buy 2    # 상위 2종목 모의 매수
자동화: 장중 라운드에서 호출 가능 (MOMENTUM_ENABLED=true)
"""
import argparse
import json
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import sys
import time

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import requests
import db

H = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}


def _n(s):
    try:
        return float(str(s).replace(",", "").replace("+", "").replace("%", ""))
    except Exception:
        return 0.0


def fetch_up_ranks(max_n=60):
    """당일 상승률 상위 (KOSPI+KOSDAQ)"""
    out = []
    for mk in ("KOSPI", "KOSDAQ"):
        try:
            r = requests.get(f"https://m.stock.naver.com/api/stocks/up/{mk}",
                             params={"page": 1, "pageSize": max_n // 2}, headers=H, timeout=10)
            for s in (r.json().get("stocks") or []):
                if s.get("stockEndType") != "stock":
                    continue
                out.append({"symbol": s["itemCode"], "name": s.get("stockName", "")[:8],
                            "price": _n(s.get("closePrice")),
                            "chg": _n(s.get("fluctuationsRatio")),
                            # accumulatedTradingValue 단위: 백만원
                            "amount_억": _n(s.get("accumulatedTradingValue")) / 100})
        except Exception:
            continue
    return out


def first_surge(symbol, lookback=20, thresh=15.0):
    """최근 N일 내 +15% 급등 이력이 없으면 True (첫 급등 = 신선)"""
    try:
        from validation import _load_bars
        bars = _load_bars(symbol, max_days=lookback + 2)
        for i in range(1, len(bars)):
            p0 = bars[i - 1]["close"]
            if p0 and (bars[i]["high"] / p0 - 1) * 100 >= thresh:
                return False
        return True
    except Exception:
        return True   # 데이터 없으면 통과 (신규상장 등)


def force_backing(symbol):
    """기관+외인 최근 5일 순매수면 True (세력 동반)"""
    try:
        from force_line import fetch_trend
        rows = fetch_trend(symbol, days=6)
        if len(rows) < 3:
            return None
        return sum(r["organ"] + r["frgn"] for r in rows[-5:]) > 0
    except Exception:
        return None


def vwap_above(symbol):
    """당일 분봉 VWAP 위인지 (장중 흐름)"""
    try:
        from backfill_history import fetch_minutes
        bars = fetch_minutes(symbol, max_bars=500)
        today = db.now_kst().strftime("%Y%m%d")
        tb = [b for b in bars if b["bar_time"].strftime("%Y%m%d") == today]
        if len(tb) < 5:
            return None
        tot_v = sum(b["volume"] for b in tb) or 1
        vwap = sum(b["price"] * b["volume"] for b in tb) / tot_v
        return tb[-1]["price"] >= vwap
    except Exception:
        return None


def scan(min_chg=3.0, max_chg=15.0, min_amount=50):
    """급등 초입 후보 스캔 → 점수순"""
    ranks = fetch_up_ranks()
    held = set()
    try:
        held = {p["symbol"] for p in db.get_paper_open()}
    except Exception:
        pass
    cands = []
    for s in ranks:
        if not (min_chg <= s["chg"] <= max_chg):
            continue                        # 추격 방지 (상한가 근처 제외)
        if s["amount_억"] < min_amount:
            continue                        # 인기/유동성
        if s["symbol"] in held:
            continue
        score = 50.0
        fresh = first_surge(s["symbol"])
        if fresh:
            score += 25                     # 첫 급등 (신선한 재료)
        fb = force_backing(s["symbol"])
        if fb:
            score += 15                     # 세력 동반
        va = vwap_above(s["symbol"])
        if va:
            score += 10                     # 장중 흐름 유지
        elif va is False:
            score -= 20                     # VWAP 아래 = 꺾임
        cands.append({**s, "fresh": fresh, "force": fb, "vwap": va,
                      "score": round(score)})
        time.sleep(0.3)
    cands.sort(key=lambda x: -x["score"])
    return cands


def buy(cands, n=2, budget=None):
    import paper_test
    budget = budget or _cfg_env_float("MOMENTUM_BUDGET", 0) or paper_test.buy_budget()  # ★ 공용 예산 (비율/금액)
    bought = 0
    in_market = paper_test._in_market_hours()
    for c in cands:
        if bought >= n:
            break
        if c["score"] < 75:
            continue                        # 고득점만 (첫급등+세력 or VWAP)
        price = paper_test._get_price(c["symbol"]) or c["price"]
        if price <= 0:
            continue
        qty = int(budget / price)
        if qty < 1:
            continue   # 가격 > 종목당 예산 - 스킵 (비율 매수 취지 유지)
        order = None
        from config import CFG
        if paper_test.REAL_PAPER_ORDER and in_market and not CFG.DRY_RUN:
            order = paper_test._place_real_order(c["symbol"], "buy", qty, price)
            if order and order.get("status") == "error":
                continue
        # 급등주 전용 지침: 손절 타이트 (-2%), 목표는 트레일링에 맡김
        # ★ 진입 슬리피지 (조건식 경로와 동일 - 채널 비교 공정성, 2026-08-27)
        entry_p = price if (order and not CFG.DRY_RUN) else paper_test.entry_slip(price)
        stop = entry_p * 0.98
        db.open_paper_position(
            "MOMENTUM", f"[급등초입] +{c['chg']:.1f}% {c['amount_억']:.0f}억 "
            + ("신선" if c["fresh"] else "") + ("·세력" if c["force"] else ""),
            c["symbol"], entry_p, qty, stop_price=stop,
            order_kind=("real" if order else "virtual"),
            sell_plan=f"급등주 - 손절 {stop:,.0f}(-2%) 타이트, 익절은 동적 트레일링")
        print(f"  ✅ 매수 {c['symbol']} {c['name']} {qty}주 @{price:,.0f} (점수 {c['score']})"
              + (" 실제모의주문" if order else " 가상기록"))
        bought += 1
    return bought


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--buy", type=int, default=0)
    args = ap.parse_args()
    print("=" * 70)
    print("🚀 급등주 모멘텀 스캔 (초입만 - 추격 금지 필터)")
    print("=" * 70)
    cands = scan()
    if not cands:
        print("후보 없음 (장외거나 +3~15% & 50억+ 구간에 종목 없음)")
        return
    print(f"\n{'':2}{'종목':8} {'이름':10} {'등락':>6} {'대금':>6} {'첫급등':>4} {'세력':>4} {'VWAP':>4} {'점수':>4}")
    print("  " + "-" * 60)
    for c in cands[:15]:
        print(f"  {c['symbol']:8} {c['name']:10} {c['chg']:>+5.1f}% {c['amount_억']:>5.0f}억 "
              f"{'✅' if c['fresh'] else '－':>4} {'✅' if c['force'] else ('－' if c['force'] is None else '❌'):>4} "
              f"{'✅' if c['vwap'] else ('?' if c['vwap'] is None else '❌'):>4} {c['score']:>4}")
    if args.buy:
        print()
        n = buy(cands, n=args.buy)
        print(f"→ {n}종목 매수 (채널 MOMENTUM - trade_stats에서 성적 비교)")


if __name__ == "__main__":
    main()
