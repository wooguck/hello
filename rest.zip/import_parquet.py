# -*- coding: utf-8 -*-
"""
📦 parquet → 우리 DB 변환 (import_parquet.py)
==============================================
종목별 일봉 parquet(2800종목·4~5GB)을 data/stocks/{symbol}.db 로 변환합니다.
- 네이버 백필(1~3시간) 대신 몇 분 안에 전 종목 일봉 로드
- 이미 있는 데이터는 bar_date 기준 REPLACE (중복 안전)
- 4~5GB 큰 파일도 청크(chunk)로 나눠 메모리 부담 없이 처리

컬럼명 자동 감지: date/일자/날짜 · symbol/종목코드 · open/시가 · high/고가
                  low/저가 · close/종가 · volume/거래량 (다른 이름이면 --map으로 지정)

실행:
  python import_parquet.py --file data.parquet              # 단일 파일
  python import_parquet.py --dir C:/parquet                 # 폴더(종목별 파일들)
  python import_parquet.py --file a.parquet --map date=일자,symbol=종목코드
  python import_parquet.py --file a.parquet --limit 100     # 테스트: 100종목만
"""
import argparse
import logging
import os
import sys
import time

logging.basicConfig(level=logging.WARNING)
try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

# ── 컬럼명 후보 (자동 감지) ──
DATE_KEYS = ["date", "Date", "일자", "날짜", "trd_dt", "기준일"]
TIME_KEYS = ["time", "Time", "체결시간", "시간"]   # ★ 분봉: time 컬럼이 있으면 분봉
SYM_KEYS = ["symbol", "Symbol", "종목코드", "code", "Code", "stk_cd", "티커"]
OPEN_KEYS = ["open", "Open", "시가", "open_price"]
HIGH_KEYS = ["high", "High", "고가", "high_price"]
LOW_KEYS = ["low", "Low", "저가", "low_price"]
CLOSE_KEYS = ["close", "Close", "종가", "close_price", "adj_close"]
VOL_KEYS = ["volume", "Volume", "거래량", "vol"]


def _pick(cols, keys):
    for k in keys:
        if k in cols:
            return k
    return None


def _norm_date(v):
    """날짜 정규화 → YYYY-MM-DD"""
    s = str(v).strip()
    if "-" in s:
        return s[:10]
    if len(s) == 8 and s.isdigit():
        return f"{s[:4]}-{s[4:6]}-{s[6:]}"
    return s[:10]


def _clean_symbol(sym):
    """A005930→005930 등 정규화. 유효 6자리면 반환, 아니면 None"""
    sym = str(sym).strip()
    if sym.startswith("A") and len(sym) == 7:
        sym = sym[1:]
    if sym.isdigit() and len(sym) == 6:
        return sym
    return None


def import_parquet_file(path, limit=None, cmap=None, batch=200000, symbol_hint=None):
    """parquet 1개 파일 → 종목별 DB 저장. 반환: {"symbols": n, "bars": n}
    - symbol_hint: 파일명에서 추출한 종목코드 (심볼 컬럼 없는 종목별 파일용)
    - pyarrow 있으면 배치(메모리 안전) / 없으면 fastparquet·pandas 전체 읽기
    """
    import pandas as pd
    total_bars = 0
    symbols = set()
    # pyarrow 사용 가능 여부
    try:
        import pyarrow.parquet as pq
        pf = pq.ParquetFile(path)
        frames = (b.to_pandas() for b in pf.iter_batches(batch_size=batch))
    except ImportError:
        # fastparquet/pandas 전체 읽기 (종목별 파일은 작아서 OK)
        try:
            df_all = pd.read_parquet(path)
            frames = [df_all]
        except Exception:
            return {"symbols": 0, "bars": 0}
    for df in frames:
        cols = set(df.columns)
        # 컬럼 매핑 (자동 감지 + 사용자 지정 우선)
        def _col(keys):
            if cmap:
                for k in keys:
                    if k in cmap and cmap[k] in cols:
                        return cmap[k]
            return _pick(cols, keys)

        c_date = _col(DATE_KEYS)
        c_time = _col(TIME_KEYS)   # ★ 분봉이면 time 컬럼
        c_sym = _col(SYM_KEYS)
        c_open = _col(OPEN_KEYS)
        c_high = _col(HIGH_KEYS)
        c_low = _col(LOW_KEYS)
        c_close = _col(CLOSE_KEYS)
        c_vol = _col(VOL_KEYS)
        if not (c_time or c_date) or not c_close:
            print(f"  ❌ 컬럼 인식 실패. 파일 컬럼: {sorted(cols)}")
            print("     --map으로 지정: --map date=일자,symbol=종목코드,...")
            return {"symbols": 0, "bars": 0}
        is_minute = bool(c_time)   # ★ time 컬럼 있으면 분봉
        # 종목별 그룹 처리
        if c_sym:
            groups = df.groupby(c_sym)
        elif symbol_hint and _clean_symbol(symbol_hint):
            groups = [(symbol_hint, df)]
        else:
            groups = [("?", df)]
        for sym, g in groups:
            sym = _clean_symbol(sym)
            if not sym:
                continue
            if is_minute:
                # ★ 분봉 저장
                total_bars += _save_minute_bars(sym, g, c_time, c_open, c_high, c_low, c_close, c_vol)
                symbols.add(sym)
                continue
            for _, r in g.iterrows():
                try:
                    d = _norm_date(r[c_date])
                    o = float(r[c_open]) if c_open else float(r[c_close])
                    h = float(r[c_high]) if c_high else float(r[c_close])
                    l = float(r[c_low]) if c_low else float(r[c_close])
                    cl = float(r[c_close])
                    v = float(r[c_vol]) if c_vol else 0
                except Exception:
                    continue
                if cl <= 0 or not d:
                    continue
                db.record_stock_daily(sym, d, o, h, l, cl, v, round(cl * v),
                                      source="parquet")
                total_bars += 1
                symbols.add(sym)
        if limit and len(symbols) >= limit:
            break
    return {"symbols": len(symbols), "bars": total_bars}


def import_parquet_dir(directory, limit=None, cmap=None):
    """폴더 안의 모든 parquet (종목별 파일 가정: 005930.parquet 등)"""
    total_s = total_b = 0
    files = [f for f in sorted(os.listdir(directory)) if f.endswith((".parquet", ".pq"))]
    print(f"parquet 파일 {len(files)}개 발견")
    for i, f in enumerate(files, 1):
        # 파일명이 종목코드면 그대로, 아니면 자동 감지
        sym_hint = os.path.splitext(f)[0]
        path = os.path.join(directory, f)
        try:
            r = import_parquet_file(path, limit=limit, cmap=cmap, symbol_hint=sym_hint)
            total_s += r["symbols"]
            total_b += r["bars"]
            print(f"  [{i}/{len(files)}] {f}: {r['bars']}봉 · {r['symbols']}종목")
        except Exception as e:
            print(f"  [{i}/{len(files)}] {f}: 실패 {str(e)[:50]}")
        if limit and total_s >= limit:
            break
    return {"symbols": total_s, "bars": total_b}


def _save_minute_bars(sym, df, c_time, c_open, c_high, c_low, c_close, c_vol):
    """분봉(time 컬럼) 저장 → minute_bars
    time 형식: 'YYYYMMDDHHMM' | 'YYYY-MM-DD HH:MM:SS' | 'HHMMSS'(당일) 유연 처리
    """
    from datetime import datetime as _dt
    saved = 0
    for _, r in df.iterrows():
        try:
            t_raw = str(r[c_time]).strip()
            # 형식 정규화 → ISO
            if len(t_raw) >= 12 and t_raw.isdigit():
                dt = _dt.strptime(t_raw[:12], "%Y%m%d%H%M")
            elif "-" in t_raw and ":" in t_raw:
                dt = _dt.fromisoformat(t_raw.replace("T", " ")[:19])
            elif len(t_raw) == 6 and t_raw.isdigit():
                # 시간만 있으면 오늘 날짜 추정 (당일 분봉)
                from datetime import date as _dd
                dt = _dt.combine(_dd.today(), _dt.strptime(t_raw, "%H%M%S").time())
            else:
                continue
            price = float(r[c_close])
            vol = float(r[c_vol]) if c_vol else 0
            if price <= 0:
                continue
            db.record_stock_minute(sym, dt.isoformat(), price, vol, None)
            saved += 1
        except Exception:
            continue
    return saved


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="parquet → 종목별 DB 변환")
    parser.add_argument("--file", default=None, help="parquet 파일 경로")
    parser.add_argument("--dir", default=None, help="parquet 폴더 (종목별 파일)")
    parser.add_argument("--map", default="", help="컬럼 매핑: date=일자,symbol=종목코드,...")
    parser.add_argument("--limit", type=int, default=None, help="처리 종목 수 제한(테스트)")
    args = parser.parse_args()

    db.init_db()
    cmap = {}
    if args.map:
        for pair in args.map.split(","):
            if "=" in pair:
                k, v = pair.split("=", 1)
                cmap[k.strip()] = v.strip()
    t0 = time.time()
    if args.file:
        r = import_parquet_file(args.file, limit=args.limit, cmap=cmap)
        print(f"\n✅ {r['symbols']}종목 {r['bars']}봉 변환 ({time.time()-t0:.0f}초)")
    elif args.dir:
        r = import_parquet_dir(args.dir, limit=args.limit, cmap=cmap)
        print(f"\n✅ 총 {r['symbols']}종목 {r['bars']}봉 변환 ({time.time()-t0:.0f}초)")
    else:
        parser.print_help()
        print("\n💡 parquet 컬럼 확인: python -c \"import pandas as pd; print(pd.read_parquet('파일.parquet').columns)\"")
