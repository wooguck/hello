# -*- coding: utf-8 -*-
"""
🧑‍🏫 AI 코치 (ai_coach.py) - 조건식 평가·개선 제안 기록 + 승인 시 자동 적용
==============================================================================
사용자 요청: "조건식에 대한 AI의 평가와 어떻게 변형/운용하면 수익날지
기록을 남기고, 추후에는 그 방식대로 운용까지 되도록"

동작 (3단계 - HANDOVER 원칙 '자동 적용 금지, 허락 후 반영' 준수):
  [1] 진단(자동): 라운드에서 주기 실행 - 조건식별 실전 성적 분석
      · AI(Gemini): 성적표를 보고 평가 + 구체적 개선 제안 생성
      · 키 없으면 규칙 진단: 청산 사유 분포로 문제 지점 자동 탐지
        (예: "트레일링 청산이 70%인데 평균 +0.4% = 익절이 너무 빠름 → TP 상향 제안")
  [2] 기록(자동): strategy/coach_log.json 에 누적 (조건식별 이력 - 언제 뭘 제안했나)
  [3] 적용(승인제): python ai_coach.py --apply <제안ID> 로 사용자가 승인하면
      · 파라미터 제안 → .env 반영 / 변형 제안 → 새 조건식 등록 (원본 유지)
      · 적용 후 성적 추적: 적용 시점 기록 → 이후 성적과 '적용 전' 비교 리포트

실행:
  python ai_coach.py              # 진단 실행 + 제안 목록
  python ai_coach.py --list       # 제안 이력 보기
  python ai_coach.py --apply 3    # 3번 제안 승인·적용
"""
import argparse
import json
import os
import sys
from datetime import datetime, timedelta

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db
from config import CFG

LOG_PATH = os.path.join("strategy", "coach_log.json")


def _load_log():
    try:
        with open(LOG_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"next_id": 1, "proposals": []}


def _save_log(log):
    os.makedirs("strategy", exist_ok=True)
    with open(LOG_PATH, "w", encoding="utf-8") as f:
        json.dump(log, f, ensure_ascii=False, indent=1)


def cond_report(cond_key, days=30):
    """조건식 1개의 실전 성적 + 청산 사유 분포"""
    cut = (db.now_kst() - timedelta(days=days)).isoformat()
    with db.get_conn() as conn:
        rows = conn.execute(
            "SELECT ret_pct, exit_reason, entry_time, exit_time FROM paper_positions "
            "WHERE status='closed' AND cond_key=? AND exit_time>?", (str(cond_key), cut)).fetchall()
    if not rows:
        return None
    rets = [r["ret_pct"] or 0 for r in rows]
    wins = [x for x in rets if x > 0]
    reasons = {}
    for r in rows:
        why = (r["exit_reason"] or "기타")
        key = ("트레일링" if "트레일링" in why else
               "하드손절" if "하드손절" in why else
               "지침손절" if "지침" in why else
               "시간청산" if ("1시간" in why or "보유" in why and "경과" in why) else
               "AI수익청산" if "수익청산" in why else
               "AI손절" if "손절" in why else "기타")
        g = reasons.setdefault(key, {"n": 0, "sum": 0.0})
        g["n"] += 1
        g["sum"] += (r["ret_pct"] or 0)
    return {"n": len(rets), "win_rate": round(len(wins) / len(rets) * 100, 1),
            "avg": round(sum(rets) / len(rets), 2),
            "reasons": {k: {"n": v["n"], "avg": round(v["sum"] / v["n"], 2)}
                        for k, v in reasons.items()}}


def rule_diagnose(cond, rep):
    """규칙 기반 진단: 청산 사유 분포에서 문제 지점 → 제안 생성"""
    props = []
    r = rep["reasons"]
    total = rep["n"]
    # 1) 트레일링 비중 높은데 평균 수익 낮음 → 익절 너무 빠름
    tr = r.get("트레일링") or r.get("AI수익청산")
    if tr and tr["n"] >= max(3, total * 0.4) and 0 < tr["avg"] < 0.8:
        props.append({"type": "param", "field": "VALIDATE_TP_PCT",
                      "diagnosis": f"수익청산 {tr['n']}건 평균 +{tr['avg']}%로 너무 얕음 (수수료 감안 시 남는 게 적음)",
                      "suggest": "익절 목표를 높이거나 param_optimizer로 이 조건식 전용 TP 재탐색",
                      "action": "python param_optimizer.py --cond <번호> --apply"})
    # 2) 하드손절 비중 높음 → 진입 타이밍 문제
    hs = r.get("하드손절")
    if hs and hs["n"] >= max(3, total * 0.3):
        props.append({"type": "variation", "field": "진입조건",
                      "diagnosis": f"하드손절 {hs['n']}건({hs['n']/total*100:.0f}%) - 진입 직후 하락 = 추격매수 경향",
                      "suggest": "진입 조건에 '눌림(below_ma_prev)' 또는 '등락률 상한(chg_under)' 추가 변형",
                      "action": "변형 조건식 자동 생성 (--apply 시)"})
    # 3) 시간청산 다수 + 평균 마이너스 → 신호가 방향성 없음
    tc = r.get("시간청산")
    if tc and tc["n"] >= max(3, total * 0.4) and tc["avg"] < 0:
        props.append({"type": "review", "field": "조건식",
                      "diagnosis": f"시간청산 {tc['n']}건 평균 {tc['avg']}% - 산 뒤 방향 없이 흘러내림",
                      "suggest": "이 조건식은 '언제'만 있고 '왜 오르는지'가 없음 - 거래량/모멘텀 슬롯 추가 검토",
                      "action": "대기(backlog) 이동 후 변형 재검증 권장"})
    # 4) 승률 낮은데 손익비도 낮음 → 폐기 후보
    if rep["win_rate"] < 40 and rep["avg"] < 0 and total >= 10:
        props.append({"type": "retire", "field": "status",
                      "diagnosis": f"승률 {rep['win_rate']}% · 평균 {rep['avg']}% ({total}건) - 구조적 손실",
                      "suggest": "대기로 이동 (lifecycle이 자동 강등하지만 즉시 이동 권장)",
                      "action": "backlog 이동 (--apply 시)"})
    return props


def ai_diagnose(cond, rep):
    """Gemini 진단 (키 있으면). 실패 시 []"""
    try:
        from ai_judge import call_llm, AI_ENABLED, GEMINI_API_KEY, OPENAI_API_KEY
        if not (AI_ENABLED and (GEMINI_API_KEY or OPENAI_API_KEY)):
            return []
        rtxt = " · ".join(f"{k} {v['n']}건(평균{v['avg']:+}%)" for k, v in rep["reasons"].items())
        prompt = (f"조건식: {cond.get('cond_txt','')[:80]}\n"
                  f"최근 30일 실전: {rep['n']}건 승률 {rep['win_rate']}% 평균 {rep['avg']:+}%\n"
                  f"청산 사유 분포: {rtxt}\n\n"
                  "이 조건식의 문제를 진단하고 수익 개선 제안 1~2개를 쓰세요.\n"
                  "형식(꼭 지켜, 한 줄에 하나): 진단|제안\n"
                  "예: 익절이 너무 빨라 평균수익 낮음|TP를 3%에서 5%로 상향 테스트")
        res = call_llm("당신은 퀀트 트레이딩 코치입니다. 데이터에 근거해 구체적으로 제안하세요.", prompt)
        props = []
        if res:
            for ln in res.splitlines():
                if "|" not in ln:
                    continue
                d, s = ln.split("|", 1)
                props.append({"type": "ai", "field": "AI제안",
                              "diagnosis": d.strip()[:100], "suggest": s.strip()[:120],
                              "action": "내용 검토 후 수동 반영 or param_optimizer/변형 활용"})
        return props[:2]
    except Exception:
        return []


def run_coach(log_fn=None, min_trades=8):
    """전 조건식 진단 → 새 제안을 coach_log에 기록. 반환: 새 제안 수"""
    def _log(m):
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass
        else:
            print(m)

    log = _load_log()
    existing = {(p["cond_key"], p["diagnosis"]) for p in log["proposals"]}
    new_cnt = 0
    conds = db.get_conditions(status="active")
    for c in conds:
        rep = cond_report(c["id"])
        if not rep or rep["n"] < min_trades:
            continue
        props = ai_diagnose(c, rep) or rule_diagnose(c, rep)
        for p in props:
            key = (str(c["id"]), p["diagnosis"])
            if key in existing:
                continue
            p.update({"id": log["next_id"], "cond_key": str(c["id"]),
                      "cond_no": c.get("cond_no"), "cond_txt": (c.get("cond_txt") or "")[:60],
                      "stats_at": rep, "created_at": db.now_kst_iso(),
                      "status": "제안됨"})
            log["proposals"].append(p)
            log["next_id"] += 1
            new_cnt += 1
            _log(f"🧑‍🏫 [코치] #{p['id']} {p['cond_txt'][:24]}: {p['diagnosis'][:50]}")
    if new_cnt:
        _save_log(log)
    return new_cnt


def apply_proposal(pid):
    """제안 승인·적용 (사용자 허락 = 이 명령 실행)"""
    log = _load_log()
    p = next((x for x in log["proposals"] if x["id"] == pid), None)
    if not p:
        print(f"❌ 제안 #{pid} 없음 (--list로 확인)")
        return
    if p.get("status") == "적용됨":
        print(f"이미 적용된 제안입니다 (#{pid})")
        return
    t = p["type"]
    if t == "variation":
        # 눌림/추격방지 슬롯 추가한 변형 조건식 생성 (원본 유지)
        try:
            with db.get_conn() as conn:
                c = conn.execute("SELECT * FROM conditions WHERE id=?",
                                 (int(p["cond_key"]),)).fetchone()
            slots = json.loads(c["slots_json"] or "[]")
            slots.append(["chg_under", {"x": 5}])   # 추격 방지
            no = db.next_cond_no()
            with db.get_conn() as conn:
                conn.execute("INSERT INTO conditions (cond_no, parent_no, cond_txt, slots_json, "
                             "source, status, created_at) VALUES (?,?,?,?,?,?,?)",
                             (no, c["cond_no"], f"[코치변형] {c['cond_txt'][:50]} +추격방지",
                              json.dumps(slots), "coach", "active", db.now_kst_iso()))
            print(f"✅ 변형 조건식 {no}번 등록 (원본 {c['cond_no']}번 유지) - 검증/작명은 라운드가 자동")
        except Exception as e:
            print(f"❌ 변형 생성 실패: {e}")
            return
    elif t == "retire":
        db.set_condition_status(int(p["cond_key"]), "backlog")
        print(f"✅ {p['cond_no']}번 대기(backlog) 이동")
    elif t == "param":
        print(f"👉 이 제안은 파라미터 재탐색입니다. 실행:")
        print(f"   python param_optimizer.py --cond {p['cond_no']} --apply")
    else:
        print(f"👉 AI 제안 - 내용: {p['suggest']}")
        print("   구체 행동: param_optimizer(파라미터) / visual_lab(눈 확인) / 변형은 다음 라운드")
    p["status"] = "적용됨"
    p["applied_at"] = db.now_kst_iso()
    _save_log(log)
    print(f"📄 기록됨: 적용 이후 성적은 coach_log의 stats_at(적용 전)과 비교 추적됩니다")


def list_proposals():
    log = _load_log()
    if not log["proposals"]:
        print("제안 없음 - python ai_coach.py 로 진단 실행")
        return
    print(f"{'ID':>3} {'상태':6} {'조건식':26} 진단 → 제안")
    print("-" * 90)
    for p in log["proposals"][-30:]:
        print(f"{p['id']:>3} {p.get('status','')[:5]:6} {p['cond_txt'][:24]:26} "
              f"{p['diagnosis'][:36]} → {p['suggest'][:36]}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--apply", type=int, default=0)
    args = ap.parse_args()
    if args.list:
        list_proposals()
    elif args.apply:
        apply_proposal(args.apply)
    else:
        print("🧑‍🏫 AI 코치 진단 시작 (실전 8건+ 조건식 대상)...")
        n = run_coach()
        print(f"\n새 제안 {n}건" + (" → python ai_coach.py --list 로 확인, --apply <ID>로 승인" if n else " (문제 발견 안 됨 또는 표본 부족)"))


if __name__ == "__main__":
    main()
