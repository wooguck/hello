# -*- coding: utf-8 -*-
"""
🔧 .env 분리 복구 (fix_env_split.py) - 2026-08-28
================================================================
문제: split_env.py가 키움 앱키/시크릿을 settings.env로 보내버림
      (키 이름 변형/인코딩 차이로 KEEP 목록 매칭 실패)

이 도구:
  .env + settings.env + .env.split_bak 3곳을 모두 읽고
  '연결 정보로 보이는 것'을 전부 .env로 모으고, 나머지는 settings.env로.
  판별은 이름 패턴 (대소문자 무관):
    KEY / SECRET / ACCOUNT / TOKEN / MOCK / DRY_RUN / AI_PROVIDER / AI_MODEL / PASSWORD
  백업: .env.fix_bak / settings.env.fix_bak

실행: python fix_env_split.py
"""
import os
import re
import shutil
import sys

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

CRED_PAT = re.compile(
    r"(KEY|SECRET|ACCOUNT|ACCT|TOKEN|MOCK|DRY_RUN|AI_PROVIDER|AI_MODEL|PASSWORD|PASSWD)",
    re.IGNORECASE)


def read_lines(path):
    """utf-8 → cp949 순서로 시도 (한글 주석 인코딩 대응)"""
    if not os.path.exists(path):
        return []
    for enc in ("utf-8", "cp949", "euc-kr"):
        try:
            return open(path, encoding=enc).read().splitlines()
        except Exception:
            continue
    return open(path, encoding="utf-8", errors="replace").read().splitlines()


def main():
    creds, settings = {}, {}
    # 우선순위: 현재 .env > settings.env > 백업들 (나중에 읽는 게 덮지 않게 setdefault)
    sources = [".env", "settings.env", ".env.split_bak", ".env.bak"]
    found_src = []
    for src in sources:
        lines = read_lines(src)
        if lines:
            found_src.append(src)
        for ln in lines:
            s = ln.strip()
            if not s or s.startswith("#") or "=" not in s:
                continue
            key = s.split("=", 1)[0].strip()
            if CRED_PAT.search(key):
                creds.setdefault(key, ln.rstrip())
            else:
                settings.setdefault(key, ln.rstrip())
    if not creds and not settings:
        print("❌ 읽을 파일이 없습니다 (.env / settings.env / 백업)")
        return

    # 백업
    for f in (".env", "settings.env"):
        if os.path.exists(f):
            shutil.copy(f, f + ".fix_bak")

    with open(".env", "w", encoding="utf-8") as f:
        f.write("# .env - 연결 정보 전용 (키움/AI/안전스위치)\n")
        for k in sorted(creds):
            f.write(creds[k] + "\n")
    with open("settings.env", "w", encoding="utf-8") as f:
        f.write("# settings.env - 일반 설정 (우선순위: .env > 이 파일 > 기본값)\n")
        for k in sorted(settings):
            f.write(settings[k] + "\n")

    print("=" * 58)
    print("🔧 복구 완료")
    print("=" * 58)
    print(f"  읽은 파일: {', '.join(found_src)}")
    print(f"  .env         ← 연결 정보 {len(creds)}개:")
    for k in sorted(creds):
        v = creds[k].split("=", 1)[1] if "=" in creds[k] else ""
        masked = (v[:4] + "****") if len(v) > 4 else "****"
        print(f"      {k} = {masked}")
    print(f"  settings.env ← 일반 설정 {len(settings)}개")
    print("\n  확인: KIWOOM_APP_KEY / KIWOOM_APP_SECRET / 계좌가 위 목록에 있는지 보세요")
    print("  ⚠️ 앱 재시작 필요")


if __name__ == "__main__":
    main()
