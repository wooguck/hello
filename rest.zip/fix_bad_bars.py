# -*- coding: utf-8 -*-
"""
🩹 불량 봉 즉석 보정 (fix_bad_bars.py) - 2026-08-28 추가
================================================================
문제 (사용자): 값 오류 7종목이 audit_fix로 재수신해도 계속 남음.
원인: 소스(네이버/다음)가 주는 데이터 자체에 오류가 있어서
      "비우고 → 다시 받기 → 같은 불량 저장" 무한 반복.

해결: 재수신 대신 기존 봉을 제자리에서 보정:
  - 고가 < max(시,종): 고가 = max(시,고,저,종)
  - 저가 > min(시,종): 저가 = min(시,고,저,종)
  - 종가 <= 0: 그 봉 삭제 (쓸 수 없는 봉)
  - 중복 날짜: 최신 updated_at만 남김
+ db.record_stock_daily에 같은 보정이 저장 시점에 들어갔으므로 재발 안 함.

실행: python fix_bad_bars.py          # 전 종목 스캔 + 보정
"""
import os
import sqlite3
import sys

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db


def _log(m=""):
    print(m, flush=True)


def fix_symbol(path):
    """한 종목 파일 보정. 반환 (고침 수, 삭제 수)"""
    fixed = removed = 0
    try:
        conn = sqlite3.connect(path, timeout=10)
        rows = conn.execute(
            "SELECT bar_date, open_price, high_price, low_price, close_price "
            "FROM daily_bars").fetchall()
        for (d, o, h, l, c) in rows:
            try:
                o, h, l, c = float(o or 0), float(h or 0), float(l or 0), float(c or 0)
            except Exception:
                continue
            if c <= 0:
                conn.execute("DELETE FROM daily_bars WHERE bar_date=?", (d,))
                removed += 1
                continue
            vals = [v for v in (o, h, l, c) if v > 0]
            nh, nl = max(vals), min(vals)
            if abs(nh - h) > 1e-9 or abs(nl - l) > 1e-9:
                conn.execute("UPDATE daily_bars SET high_price=?, low_price=? "
                             "WHERE bar_date=?", (nh, nl, d))
                fixed += 1
        # 중복 날짜 제거 (rowid 큰 것만 유지)
        conn.execute("DELETE FROM daily_bars WHERE rowid NOT IN "
                     "(SELECT MAX(rowid) FROM daily_bars GROUP BY bar_date)")
        conn.commit()
        conn.close()
    except Exception:
        pass
    return fixed, removed


def main():
    base = os.path.join(db.DATA_DIR, "stocks")
    if not os.path.isdir(base):
        _log("데이터 폴더 없음")
        return
    files = [f for f in os.listdir(base) if f.endswith(".db")]
    _log(f"🩹 불량 봉 보정: {len(files)}종목 스캔...")
    tot_f = tot_r = touched = 0
    for i, fn in enumerate(files):
        f, r = fix_symbol(os.path.join(base, fn))
        if f or r:
            touched += 1
            _log(f"  {fn[:-3]}: 보정 {f}봉 · 삭제 {r}봉")
        tot_f += f
        tot_r += r
        if (i + 1) % 500 == 0:
            _log(f"  ... {i+1}/{len(files)}")
    _log(f"\n✅ 완료: {touched}종목에서 보정 {tot_f}봉 · 삭제 {tot_r}봉")
    _log("   (저장 로직에도 자동보정이 들어가서 앞으로 재발하지 않습니다)")
    _log("   재검사: python data_audit.py")


if __name__ == "__main__":
    main()
