# -*- coding: utf-8 -*-
"""
🐋 세력선 스캐너 (force_line.py) - 기관+외인 누적 순매수 기반 매집 검출
========================================================================
차트의 '세력선'(사모펀드/기관 누적 매수선)을 데이터로 재현:
  세력선 = 기관 순매수 + 외국인 순매수 누적 (네이버 투자자별 매매동향, 무료 60일)

매집 점수 (0~100):
  ① 20일 세력 순매수가 양수 + 꾸준함 (매집 강도)
  ② 주가가 아직 덜 오름 (매집 중 - 분출 전이 최고 타점)
  ③ 최근 5일 세력 가속 (분출 임박 신호)
  → 코스맥스 사례: 매집(6~7월 주가 잠잠+순매수) 후 분출(8월 +56%)

실행:
  python force_line.py                  # 유동성 상위 종목 스캔 → 순위 저장
  python force_line.py --top 100        # 스캔 종목 수
  python force_line.py --buy 3          # 상위 3종목 모의 매수 (FORCE_LINE 채널)
                                        # 매도는 기존 AI/하드손절/가드가 자동 관리
저장: strategy/force_picks.json (현황판/다음날 매수용)
"""
import argparse
import json
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import sys
import time

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import requests
import db

H = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}


def _n(s):
    try:
        return int(str(s).replace(",", "").replace("+", ""))
    except Exception:
        return 0


def fetch_trend(symbol, days=60):
    """네이버 투자자별 매매동향 (기관/외인/개인 순매수 + 종가, 최근 60일)"""
    try:
        r = requests.get(f"https://m.stock.naver.com/api/stock/{symbol}/trend",
                         params={"pageSize": days}, headers=H, timeout=10)
        if r.status_code != 200:
            return []
        rows = sorted(r.json(), key=lambda x: x.get("bizdate", ""))
        return [{"date": x["bizdate"],
                 "organ": _n(x.get("organPureBuyQuant")),
                 "frgn": _n(x.get("foreignerPureBuyQuant")),
                 "close": _n(x.get("closePrice"))} for x in rows]
    except Exception:
        return []


def force_score(rows):
    """매집 점수 계산. 반환 dict / None(데이터 부족)"""
    if len(rows) < 25:
        return None
    force = [r["organ"] + r["frgn"] for r in rows]
    closes = [r["close"] for r in rows if r["close"] > 0]
    if len(closes) < 25:
        return None
    cum20 = sum(force[-20:])
    cum5 = sum(force[-5:])
    pos_days = sum(1 for f in force[-20:] if f > 0)   # 20일 중 순매수일
    chg20 = (closes[-1] / closes[-21] - 1) * 100 if len(closes) >= 21 and closes[-21] else 0
    # 유통 물량 대비 규모 (거래량 정보 없어 절대치 근사 - 종가 곱해 금액화)
    amt20 = cum20 * closes[-1]
    score = 0.0
    if cum20 > 0:
        score += 30                          # 20일 순매집
        score += min(20, pos_days * 2)       # 꾸준함 (10일+ 순매수면 만점)
    if cum5 > 0 and cum20 > 0 and cum5 > cum20 / 4:
        score += 20                          # 최근 가속
    if -5 <= chg20 <= 10:
        score += 20                          # ★ 주가 아직 잠잠 = 분출 전 (최고 타점)
    elif chg20 > 25:
        score -= 15                          # 이미 분출 - 추격 위험
    if amt20 >= 5_000_000_000:
        score += 10                          # 매집 규모 50억+
    return {"score": round(max(0, score), 1), "cum20": cum20, "cum5": cum5,
            "pos_days": pos_days, "chg20": round(chg20, 1),
            "amt20_억": round(amt20 / 1e8), "price": closes[-1]}


def liquid_symbols(top=150):
    """로컬 일봉에서 유동성(거래대금) 상위 종목"""
    import sqlite3
    sd = os.path.join(db.DATA_DIR, "stocks")
    out = []
    if not os.path.isdir(sd):
        return []
    for f in os.listdir(sd):
        if not f.endswith(".db"):
            continue
        try:
            c = sqlite3.connect(os.path.join(sd, f))
            r = c.execute("SELECT AVG(amount) FROM (SELECT amount FROM daily_bars "
                          "ORDER BY bar_date DESC LIMIT 5)").fetchone()
            c.close()
            if r and r[0]:
                out.append((f[:-3], r[0]))
        except Exception:
            continue
    out.sort(key=lambda x: -x[1])
    return [s for s, _a in out[:top]]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--top", type=int, default=150, help="스캔 종목 수 (유동성 상위)")
    ap.add_argument("--buy", type=int, default=0, help="상위 N종목 모의 매수")
    args = ap.parse_args()

    names = {}
    try:
        for u in db.get_universe():
            names[u.get("symbol")] = u.get("name") or ""
    except Exception:
        pass

    syms = liquid_symbols(top=args.top)
    print(f"🐋 세력선 스캔: 유동성 상위 {len(syms)}종목 (종목당 ~0.4초)")
    ranked = []
    t0 = time.time()
    for i, sym in enumerate(syms):
        rows = fetch_trend(sym)
        sc = force_score(rows)
        if sc and sc["score"] >= 50:
            ranked.append({"symbol": sym, "name": names.get(sym, "")[:8], **sc})
        sys.stdout.write(f"\r  {i+1}/{len(syms)} · 후보 {len(ranked)} · {time.time()-t0:.0f}초   ")
        sys.stdout.flush()
        time.sleep(0.35)
    print()
    ranked.sort(key=lambda x: -x["score"])

    print(f"\n{'':2}{'종목':8} {'이름':10} {'점수':>4} {'20일세력':>10} {'꾸준':>4} "
          f"{'주가20일':>7} {'매집액':>6}")
    print("  " + "-" * 60)
    for r in ranked[:20]:
        tag = "👀매집중" if -5 <= r["chg20"] <= 10 else ("🚀분출" if r["chg20"] > 10 else "")
        print(f"  {r['symbol']:8} {r['name']:10} {r['score']:>4} {r['cum20']:>+10,} "
              f"{r['pos_days']:>3}일 {r['chg20']:>+6.1f}% {r['amt20_억']:>4}억 {tag}")

    os.makedirs("strategy", exist_ok=True)
    with open(os.path.join("strategy", "force_picks.json"), "w", encoding="utf-8") as f:
        json.dump({"date": db.now_kst().strftime("%Y-%m-%d"), "picks": ranked[:20]},
                  f, ensure_ascii=False, indent=1)
    print(f"\n📄 저장: strategy/force_picks.json ({len(ranked)}종목)")

    if args.buy and ranked:
        import paper_test
        from ai_consult import build_sell_plan
        budget = _cfg_env_float("AI_PICKS_BUDGET", 0) or paper_test.buy_budget()  # ★ 공용 예산 (비율/금액)
        n = 0
        held = {p["symbol"] for p in db.get_paper_open()}
        for r in ranked:
            if n >= args.buy:
                break
            if r["symbol"] in held or r["chg20"] > 15:   # 이미 분출한 건 추격 안 함
                continue
            price = paper_test._get_price(r["symbol"]) or r["price"]
            qty = int(budget / price)
            if qty < 1:
                continue   # 가격 > 종목당 예산 - 스킵
            # ★ 진입 슬리피지 (조건식 경로와 동일 - 채널 비교 공정성, 2026-08-27)
            entry_p = paper_test.entry_slip(price)
            plan = None
            try:
                plan = build_sell_plan(r["symbol"], entry_p, qty)
            except Exception:
                pass
            db.open_paper_position(
                "FORCE_LINE", f"[세력선] 점수{r['score']} 20일 {r['cum20']:+,}주 매집", 
                r["symbol"], entry_p, qty, order_kind="virtual",
                target_price=(plan or {}).get("target_price"),
                stop_price=(plan or {}).get("stop_price"),
                sell_plan=(plan or {}).get("plan"))
            print(f"  ✅ 매수 {r['symbol']} {r['name']} {qty}주 @{price:,.0f} (세력선 채널)")
            n += 1
        if n:
            print(f"→ {n}종목 매수 - 매도는 기존 AI/하드손절/가드가 관리 · "
                  f"성적은 trade_stats에서 'FORCE_LINE'으로 비교")


if __name__ == "__main__":
    main()
