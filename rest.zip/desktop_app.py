"""키움 AI 자동매매 - 완전판 데스크톱 GUI (Tkinter, 서버 없음, 외부 GUI 라이브러리 0개)

실행:  python desktop_app.py
EXE:   pip install pyinstaller
       pyinstaller --onefile --noconsole --name KiwoomAIAuto desktop_app.py

탭 구성 (9개):
  📊 대시보드     - 통계 카드 + 세대 진행률 + 매매/정산/세대교체/리셋 버튼
  🧬 전략         - 전체 전략 테이블 (세대/상태/파라미터/거래수/fitness)
  📌 포지션·거래  - 오픈 포지션 + 최근 거래
  💰 손익분석     - 기간별 손익 요약 + 전략별/일별/종목별 손익
  📈 시세 아카이브- 1주일 쌓인 스냅샷 요약 + 주간 리포트
  📝 프롬프트     - 매수/매도 프롬프트 편집 + 저장 + AI 기준 검토
  🤖 AI 컨설턴트  - Gemini/GPT/규칙 상담 (프롬프트 검토/전략 분석/추천/리스크)
  ⚙️ 설정         - .env 편집 (키/모드/AI 설정) + 저장 즉시 반영
  🧪 테스트·백테스트 - 자체 테스트 / 모의 백테스트 / 스냅샷 재현 백테스트
"""
import json
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import sys
import sqlite3
import threading
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
from datetime import datetime, date, timedelta
from db import now_kst

import db
from config import CFG

DB_PATH = db.DB_PATH
BUY_PROMPT_PATH = "prompts/buy_prompt.txt"
SELL_PROMPT_PATH = "prompts/sell_prompt.txt"

# ── 다크 테마 ──
BG = "#0d1117"
CARD = "#161b22"
BORDER = "#30363d"
TEXT = "#e6edf3"
MUTED = "#8b949e"
ACCENT = "#58a6ff"
GREEN = "#3fb950"
RED = "#f85149"
YELLOW = "#d29922"
PURPLE = "#bc8cff"

LAST_ACTION = {"result": "아직 실행된 작업이 없습니다", "time": ""}

# 설정 탭에 표시할 환경변수 목록
ENV_FIELDS = [
    # (env 키, 라벨, 타입)
    ("KIWOOM_APP_KEY", "앱 키", "str"),
    ("KIWOOM_APP_SECRET", "시크릿 키", "str"),
    ("KIWOOM_ACCOUNT_NO", "계좌번호(10자리)", "str"),
    ("KIWOOM_USE_MOCK", "모의투자 서버", "bool"),
    ("DRY_RUN", "DRY_RUN (주문차단)", "bool"),
    ("ENGINE_MODE", "엔진 모드 (auto/params/ai_prompt)", "str"),
    ("CONDITION_SEQ", "조건검색 SEQ (비면 샘플종목)", "str"),
    ("AI_JUDGE_ENABLED", "AI 판단 활성화", "bool"),
    ("AI_BUY_CONFIDENCE", "매수 신뢰도 필터", "bool"),
    # ★ AI 판단 게이트 (클릭 토글 - 매수/매도 각각 넣고 뺄 수 있음)
    ("AI_BUY_GATE", "매수 시 AI 판단 (끔=조건식 신호만)", "bool"),
    ("AI_SELL_GATE", "매도 시 AI 판단 (기본 켬)", "bool"),
    ("WEEKLY_REPORT_ENABLED", "주간 리포트 자동 생성", "bool"),
    ("AI_BUY_CONFIDENCE_THRESHOLD", "매수 신뢰도 임계값 %", "int"),
    ("AI_PROVIDER", "AI 공급자 (rule/openai/gemini)", "str"),
    ("AI_MODEL", "AI 모델", "str"),
    ("OPENAI_API_KEY", "OpenAI API 키", "str"),
    ("GEMINI_API_KEY", "Gemini API 키", "str"),
    ("RISK_PER_TRADE_PCT", "거래 리스크 %", "float"),
    ("MAX_POSITIONS_PER_STRATEGY", "전략당 최대 포지션", "int"),
    ("DEFAULT_ORDER_QTY", "기본 주문 수량", "int"),
    ("TRADING_CYCLE_SECONDS", "사이클 주기(초)", "int"),
    ("SCAN_ALL_MODE", "전체 종목 스캔 (true=전종목)", "bool"),
    ("SCAN_BATCH_SIZE", "한 사이클 스캔 종목 수", "int"),
    ("MOCK_PRICE_MIN", "모의 매수 최저가(원)", "int"),
    ("MOCK_PRICE_MAX", "모의 매수 최고가(원)", "int"),
    ("MIN_TAKE_PROFIT_PCT", "최소 익절 %", "float"),
    ("HARD_STOP_LOSS_PCT", "강제 손절 %", "float"),
    ("ALLOW_AVERAGING", "보유 중 추가매수 허용", "bool"),
    ("TEST_FORCE_MOCK_INDICATORS", "테스트용 지표 강제(mock)", "bool"),
    ("AUTO_STRATEGY_GEN", "자동 전략 생성 (데이터 기반)", "bool"),
    ("STRATEGY_MIN_DAYS", "전략 생성 최소 일봉 수(일)", "int"),
    ("STRATEGY_MIN_SYMBOLS", "전략 생성 최소 종목 수", "int"),
    ("STRATEGY_COOLDOWN_DAYS", "전략 재분석 간격(일)", "int"),
    ("AUTO_BACKFILL_MINUTES", "분봉 자동 백필", "bool"),
    ("MINUTE_ALL", "분봉 전 종목 수신 (true=전종목)", "bool"),
    ("MINUTE_SYMBOLS", "분봉 대상 직접 지정 (콤마)", "str"),
    ("MINUTE_MAX_SYMBOLS", "분봉 최대 종목 수 (전종목 off시)", "int"),
    ("RANK_CANDIDATE_COUNT", "매수 감시 후보 수 (순위 점수 상위 N)", "int"),
    ("WATCH_PERIOD_MINUTES", "매수 감시 주기(분, 09:00 정각 정렬)", "int"),
    ("WATCH_CHG_MIN", "1차 조건식: 등락률 하한 %", "float"),
    ("WATCH_CHG_MAX", "1차 조건식: 등락률 상한 %", "float"),
    ("WATCH_MIN_AMOUNT", "1차 조건식: 최소 거래대금(원)", "int"),
    ("WATCH_CATEGORIES", "감시 카테고리 (급등,반등,저평가)", "str"),
    ("CATEGORY_SIZE", "카테고리당 후보 수 (기본 50)", "int"),
]

ENV_ATTR_MAP = {
    "KIWOOM_APP_KEY": "APP_KEY", "KIWOOM_APP_SECRET": "APP_SECRET",
    "KIWOOM_ACCOUNT_NO": "ACCOUNT_NO", "KIWOOM_USE_MOCK": "USE_MOCK",
    "DRY_RUN": "DRY_RUN", "AI_JUDGE_ENABLED": "AI_JUDGE_ENABLED",
    "AI_PROVIDER": "AI_PROVIDER", "AI_MODEL": "AI_MODEL",
    "OPENAI_API_KEY": "OPENAI_API_KEY", "GEMINI_API_KEY": "GEMINI_API_KEY",
    "CONDITION_SEQ": "CONDITION_SEQ", "RISK_PER_TRADE_PCT": "RISK_PER_TRADE_PCT",
    "MAX_POSITIONS_PER_STRATEGY": "MAX_POSITIONS_PER_STRATEGY",
    "DEFAULT_ORDER_QTY": "DEFAULT_ORDER_QTY",
    "TRADING_CYCLE_SECONDS": "TRADING_CYCLE_SECONDS",
    "SCAN_ALL_MODE": "SCAN_ALL_MODE",
    "SCAN_BATCH_SIZE": "SCAN_BATCH_SIZE",
    "MOCK_PRICE_MIN": "MOCK_PRICE_MIN",
    "MOCK_PRICE_MAX": "MOCK_PRICE_MAX",
    "TEST_FORCE_MOCK_INDICATORS": "TEST_FORCE_MOCK_INDICATORS",
    "MIN_TAKE_PROFIT_PCT": "MIN_TAKE_PROFIT_PCT",
    "HARD_STOP_LOSS_PCT": "HARD_STOP_LOSS_PCT",
    "ALLOW_AVERAGING": "ALLOW_AVERAGING",
    "AUTO_STRATEGY_GEN": "AUTO_STRATEGY_GEN",
    "STRATEGY_MIN_DAYS": "STRATEGY_MIN_DAYS",
    "STRATEGY_MIN_SYMBOLS": "STRATEGY_MIN_SYMBOLS",
    "STRATEGY_COOLDOWN_DAYS": "STRATEGY_COOLDOWN_DAYS",
    "AUTO_BACKFILL_MINUTES": "AUTO_BACKFILL_MINUTES",
    "MINUTE_ALL": "MINUTE_ALL",
    "MINUTE_SYMBOLS": "MINUTE_SYMBOLS",
    "MINUTE_MAX_SYMBOLS": "MINUTE_MAX_SYMBOLS",
    "RANK_CANDIDATE_COUNT": "RANK_CANDIDATE_COUNT",
    "WATCH_PERIOD_MINUTES": "WATCH_PERIOD_MINUTES",
    "WATCH_CHG_MIN": "WATCH_CHG_MIN",
    "WATCH_CHG_MAX": "WATCH_CHG_MAX",
    "WATCH_MIN_AMOUNT": "WATCH_MIN_AMOUNT",
    "WATCH_CATEGORIES": "WATCH_CATEGORIES",
    "CATEGORY_SIZE": "CATEGORY_SIZE",
    "AI_BUY_GATE": "AI_BUY_GATE",
    "AI_SELL_GATE": "AI_SELL_GATE",
    "WEEKLY_REPORT_ENABLED": "WEEKLY_REPORT_ENABLED",
}


# ── 유틸 ──

def _q(sql, params=()):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute(sql, params)
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _read_prompt(path, fallback):
    try:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
            return content if content.strip() else fallback
    except Exception:
        return fallback


def _write_prompt(path, content):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return True
    except Exception as e:
        print(f"[UI] 프롬프트 저장 실패: {e}")
        return False


def _read_env_map() -> dict:
    """.env 파일을 dict로 읽기"""
    out = {}
    if not os.path.exists(".env"):
        return out
    try:
        with open(".env", "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, _, v = line.partition("=")
                out[k.strip()] = v.strip()
    except Exception:
        pass
    return out


# ★ 2026-09-02 .env/settings.env 분리 저장 (사용자: ".env엔 지워지지 않는 것만,
#   나머지는 다른 파일에" - 설정 저장 버튼이 전부 .env에 몰아쓰던 것 수정)
#   .env = 연결/인증/실행모드만 (아래 목록) / 그 외 전부 settings.env
ENV_CRED_KEYS = {
    "KIWOOM_APP_KEY", "KIWOOM_APP_SECRET", "KIWOOM_ACCOUNT_NO",
    "KIWOOM_BASE_URL_MOCK", "KIWOOM_BASE_URL_REAL", "KIWOOM_USE_MOCK",
    "DRY_RUN", "AI_PROVIDER", "AI_MODEL", "AI_BASE_URL",
    "OPENAI_API_KEY", "GEMINI_API_KEY",
}


def _write_one_env(path: str, values: dict) -> bool:
    """한 env 파일에 값 반영 (주석/순서 보존, 신규 키 추가)"""
    try:
        lines = []
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                lines = f.readlines()
        out, written = [], set()
        for line in lines:
            stripped = line.strip()
            if "=" in line and not stripped.startswith("#"):
                k = line.split("=", 1)[0].strip()
                if k in values:
                    out.append(f"{k}={values[k]}\n")
                    written.add(k)
                    continue
            out.append(line)
        for k, v in values.items():
            if k not in written:
                out.append(f"{k}={v}\n")
        with open(path, "w", encoding="utf-8") as f:
            f.writelines(out)
        return True
    except Exception as e:
        print(f"[UI] {path} 저장 실패: {e}")
        return False


def _write_env_map(values: dict) -> bool:
    """설정 저장: 연결/인증 키만 .env, 나머지는 전부 settings.env
    (+ 일반 키가 .env에 이미 있으면 제거해서 중복/우선순위 꼬임 방지)"""
    cred = {k: v for k, v in values.items() if k in ENV_CRED_KEYS}
    general = {k: v for k, v in values.items() if k not in ENV_CRED_KEYS}
    ok = True
    if cred:
        ok = _write_one_env(".env", cred) and ok
    if general:
        ok = _write_one_env("settings.env", general) and ok
        # .env에 남아있는 일반 키 청소 (예전에 몰아 저장된 것 - 우선순위 꼬임 방지)
        try:
            if os.path.exists(".env"):
                with open(".env", "r", encoding="utf-8") as f:
                    lines = f.readlines()
                cleaned = [ln for ln in lines
                           if not ("=" in ln and not ln.strip().startswith("#")
                                   and ln.split("=", 1)[0].strip() in general)]
                if len(cleaned) != len(lines):
                    with open(".env", "w", encoding="utf-8") as f:
                        f.writelines(cleaned)
        except Exception:
            pass
    return ok


def _apply_to_cfg(values: dict):
    """환경변수 값을 CFG 객체 + os.environ에 즉시 반영 (재시작 불필요)"""
    types = {k: t for k, _l, t in ENV_FIELDS}
    for key, val in values.items():
        t = types.get(key, "str")
        try:
            if t == "bool":
                v = str(val).lower() in ("true", "1", "yes", "on")
            elif t == "int":
                v = int(val)
            elif t == "float":
                v = float(val)
            else:
                v = str(val)
        except Exception:
            v = str(val)
        os.environ[key] = str(v)
        attr = ENV_ATTR_MAP.get(key)
        if attr and hasattr(CFG, attr):
            setattr(CFG, attr, v)
    # engine 모드/프로바이더 재반영
    try:
        CFG.ENGINE_MODE = os.getenv("ENGINE_MODE", "auto")
        CFG.AI_PROVIDER = os.getenv("AI_PROVIDER", "rule")
        CFG.AI_JUDGE_ENABLED = os.getenv("AI_JUDGE_ENABLED", "true").lower() in ("true", "1")
    except Exception:
        pass


def _fmt_pnl(v):
    try:
        return f"{v:,.0f}원"
    except Exception:
        return str(v)


class RO_Text(scrolledtext.ScrolledText):
    """읽기 전용이지만 선택/복사가 완벽하게 되는 텍스트 위젯
    - 우클릭 메뉴: 복사 / 전체 선택
    - Ctrl+A, Ctrl+C 지원
    - 편집 키 입력만 차단
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.bind("<Key>", self._block_key)
        self.bind("<Control-a>", lambda e: self._select_all())
        self.bind("<Control-A>", lambda e: self._select_all())
        self.bind("<Button-3>", self._show_menu)

    def _block_key(self, event):
        # Ctrl 조합(복사 등)은 허용
        if event.state & 0x4:
            return None
        return "break"

    def _select_all(self):
        self.tag_add("sel", "1.0", "end")
        return "break"

    def _show_menu(self, event):
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="복사 (Ctrl+C)", command=lambda: self.event_generate("<<Copy>>"))
        menu.add_command(label="전체 선택 (Ctrl+A)", command=self._select_all)
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def append(self, text):
        """텍스트 끝에 추가 + 자동 스크롤"""
        self.insert("end", text)
        self.see("end")

    def replace(self, text):
        """전체 내용 교체"""
        self.delete("1.0", "end")
        self.insert("1.0", text)
        self.see("1.0")


# ── 사용자 가이드 (설명 버튼용) ─────────────────────────
GUIDE_TEXT = {
    "overview": """🤖 키움 AI 자동매매 - 사용 가이드
========================================

이 프로그램은 3단계 안전장치로 동작합니다:
  DRY_RUN=true  → 실제 주문 차단 (로그만)
  둘 다 false   → 실전 주문 (주의!)

📊 대시보드
  - 시스템 상태: 지금 어떤 모드/몇 세대/시세 수신 중인지
  - 버튼:
    ▶ 자동매매 시작  : 장중 정각 정렬 주기(기본 3분)로 순위→점수 상위 감시 → 실제 주문 사이클 (모의/실전 서버는 설정에서)
    ⏹ 정지           : 실행 중인 작업 중지
    📊 장마감 정산    : 오늘 성과를 daily_performance에 기록
    🧬 세대교체       : 유전알고리즘 다음 세대로 진화 (강제)
    📡 시세 조회      : 기본 검사 종목 즉시 조회
    🌐 전체종목       : 전 종목(코스피+코스닥 약 3300개) 목록 가져오기
    ⏱ 자동수집       : 60초마다 시세 스냅샷 저장 (1달치 데이터 쌓기)
  - 🔍 전체종목 스캔: 전 종목을 배치로 순환 (예: 20개/사이클, 진행률 표시)
  - 📦 자료 수집 기간: 언제부터 언제까지 쌓였는지 표시 (KST)
  - 📈 지수: 코스피/코스닥 지수도 같이 저장 (유전변형용 종합 데이터)
  - ★ 앱 켜지면 자동으로 자료 수집 시작 (모의/실시간 매매와 별개)
  - 🧠 전략 자동생성: 네이버 일봉(90일)이 충분한 종목 수가 쌓이면
    자동으로 시장 분석 + 후보 전략 백테스트를 돌려, 통과한 최고 전략만
    매수/매도 프롬프트에 [📊 자동 전략 분석] 블록으로 반영합니다.
    (승률/손익비 미달이면 절대 강제 적용 안 함 · 하드손절·최소익절·신뢰도는 불변)

🧬 전략
  - 10개 전략이 각자 다른 DNA(파라미터)로 매매 판단
  - survivor = 실제 모의투자 주문 대상
  - candidate = 신규 후보, retired = 폐기됨

📌 포지션·거래
  - 가상(실제 주문 없음) vs 모의(실제 모의 주문) 구분
  - 수익률%로 지금 몇 프로 익절/손절인지 확인

💰 손익분석
  - 기간별 청산 실적 (승률/평균수익/총손익)

📈 시세 아카이브
  - 받은 시세를 DB에 쌓아두고 재사용 (다시 안 받아도 됨)
  - 1주/1달/3달/전체 기간별 리포트

📝 프롬프트
  - 매수/매도 판단 기준 텍스트. 수정 → 저장 → 즉시 반영
  - 저장 전 자동 백업됨 (prompts/backup/)

🤖 AI 컨설턴트
  - 분석/상담용. ★자동 적용되지 않음★ (참고만)
  - 적용하려면 그 내용을 프롬프트 탭에 직접 붙여넣고 저장

⚙️ 설정
  - .env 설정 GUI (키/모드/AI 등) - 저장 즉시 반영

🧪 테스트·백테스트
  - 자체 테스트: 시스템 전체 점검
  - 모의 백테스트: 랜덤 전략으로 성능 재현
  - 스냅샷 재현: 실제 쌓인 데이터로 신호 재현
""",
    "dashboard": "📊 대시보드\n\n4팀이 자동 운영됩니다.\n- 📥 자료수집: 전 종목 일봉(4년)+분봉(한 달) 자동 수집\n- 🔍 검증: 조건식이 신호를 잘 잡는지 확인\n- 🖥 모의매매: 조건식 신호 → 모의 주문 확인\n- 🧠 총괄(AI): 3팀 순서대로 실행 + 명예의 전당\n- 🚀 자동 파일럿: 위 4팀을 자동으로 계속 운영\n- 🧪 조건식 성적표: 조건식별 매수/매도/순손익/승률 (더블클릭 → 종목 → 차트)\n- 🔄 새로고침: 상태 즉시 갱신",
    "strategy": "🧬 전략\n\n유전알고리즘이 10개 전략을 진화시킵니다.\n- survivor: 실제 모의투자 주문 대상 (상위)\n- candidate: 신규 후보\n- retired: 폐기 (백테스트 점수 낮음)\n- fitness: 실적 점수 (-999 = 거래 20건 미만, 아직 평가 안 됨)",
    "positions": "💼 계좌\n\n- 계좌 보유 종목 표시 (로그인 서버가 모의든 실전이든 동일 화면)\n- 전체 청산: 보유 전부 매도 (확인창)\n- 종목 더블클릭: 그 종목만 매도 (확인창)\n- 수익률%: 현재가 대비 익절/손절 상태",
    "pnl": "💰 손익분석\n\n청산된 포지션 기준으로 기간별 실적을 보여줍니다.\n승률/평균수익률/총손익을 전략별·일별·종목별로 집계합니다.",
    "archive": "📈 시세 아카이브\n\n받은 시세를 DB(market_snapshots)에 쌓아둡니다.\n- 같은 종목은 최근 데이터를 재사용 (API 재호출 최소화)\n- 기간별 리포트로 가격/체결강도/RSI 추이 확인\n- 📊 분봉 요약: 관심/보유 종목의 최근 분봉(네이버, 최근 1주일)\n  · 분당 종가+누적거래량만 제공되며 봉별 고/저가는 없습니다\n  · 자동 전략 생성의 장중 분석(오전 강세 지속성)에 사용됩니다",
    "prompts": "📝 프롬프트\n\n매수/매도 판단 기준 텍스트입니다.\n- 수정 → 💾 저장 → 다음 사이클부터 반영\n- 저장 전 자동 백업 (prompts/backup/)\n- 🤖 AI 기준 검토: AI가 개선안 제안 (참고용, 자동 적용 안 됨)",
    "consult": "🤖 AI 컨설턴트\n\n분석/상담 전용입니다.\n- ⚠️ AI가 제안한 내용은 자동 적용되지 않습니다\n- 적용하려면 프롬프트 탭에서 직접 수정 후 저장하세요\n- 키 없으면 규칙 기반으로 답변합니다",
    "settings": "⚙️ 설정\n\n.env 파일을 GUI로 편집합니다.\n- DRY_RUN=true, USE_MOCK=true 가 안전 기본값\n- 저장 즉시 반영 (재시작 불필요)",
    "test": "🧪 테스트·백테스트\n\n- 자체 테스트: 시스템 구성요소 전체 점검\n- 모의 백테스트: 랜덤 전략 성능 재현\n- 스냅샷 재현: 실제 쌓인 데이터로 신호 재현\n- 📅 날짜 검산: 특정 날짜(YYYY-MM-DD)의 수집 데이터로 신호 재현\n  · 주말/공휴일은 자동 제외 (이전 거래일로 보정)\n  · 거래일 여부를 즉시 표시 (✅/⚠️)\n  · 스냅샷 기반이라 빠름 (API 호출 없음)\n- 결과는 DB에 저장되어 다시 조회 가능\n- 전략 자동생성(지금 실행): 쌓인 일봉 데이터로 시장 분석 + 후보 전략 백테스트\n  -> 통과한 최고 전략만 프롬프트에 반영 (미달 시 강제 적용 안 함)",
}


class GuideWindow:
    """설명(?) 버튼 → 가이드 팝업 창"""
    def __init__(self, parent, title, text):
        win = tk.Toplevel(parent)
        win.title(f"❓ {title}")
        win.geometry("640x520")
        win.configure(bg=BG)
        win.transient(parent)
        txt = RO_Text(win, wrap="word", bg=BG, fg=TEXT,
                      insertbackground=TEXT, font=("Segoe UI", 11))
        txt.pack(fill="both", expand=True, padx=14, pady=14)
        txt.insert("1.0", text)
        btn = ttk.Button(win, text="닫기", command=win.destroy)
        btn.pack(pady=(0, 12))


def show_guide(parent, key):
    GuideWindow(parent, {"overview": "전체 가이드"}.get(key, key), GUIDE_TEXT.get(key, ""))


class AutoTraderApp:
    def __init__(self, root):
        self.root = root
        root.title("🤖 키움 AI 자동매매 - 완전판")
        root.geometry("1240x860")
        root.configure(bg=BG)
        root.minsize(960, 600)  # 리사이즈 자유 (스크롤로 아래 내용 확인 가능)

        self._setup_style()
        self._build_header()
        self._build_notebook()
        self._build_statusbar()

        self._build_dashboard_tab()
        # ★ UI 단순화: 가상 시뮬레이션 탭 제거 (실제/모의 중심)
        self._build_real_tab()      # 💼 실제 매매 (계좌+모의/실전만)
        self._build_pnl_tab()
        self._build_data_tab()      # 📈 시세 데이터 (수집+연구시트)
        self._build_prompt_tab()
        self._build_consult_tab()
        self._build_settings_tab()
        self._build_report_tab()     # 📋 일일 복기 리포트 (뷰어 + AI 토의)
        self._build_test_tab()

        # 작업 중지 플래그 (⏹ 중지 버튼)
        self.stop_flag = False
        self._paper_active = False   # ★ 모의매매 실행 중 표시용
        # 자동 시세 수집 상태 (앱 켜져있는 동안 60초마다 스냅샷+지수 저장)
        self.collecting = False
        self._refresh_live()
        self.root.after(30000, self._auto_refresh)  # ★ 30초 간격 (2026-09-02 무거움 개편)

        # ★ 데이터 수집은 수동/자동파일럿: '📥 데이터 수집' 버튼 + 장마감 자동 (별도)

        # ★ 앱 켜지면 자동 파일럿 자동 시작 (사용자 개입 없음 - 4팀 운영)
        # ★ 사진 원형 조건식 자동 등록 (조건식 없을 때 - 모의매매가 안 도는 것 방지)
        try:
            import condition_manager as _cm
            n = _cm.init_conditions()
            if n:
                self._alog(f"[{now_kst():%H:%M:%S}] 📷 사진 검색식 원형 {n}개 등록 (최초 실행)\n")
        except Exception:
            pass
        if getattr(CFG, "AUTO_PILOT", True):
            self._alog(f"[{now_kst():%H:%M:%S}] 🚀 자동 파일럿 자동 시작 (데이터 우선 → AI 지시 → 명예의 전당)\n")
            self._toggle_pilot()

    # ── 스타일 ──
    def _setup_style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("TFrame", background=BG)
        style.configure("Card.TFrame", background=CARD)
        style.configure("Treeview", background=CARD, fieldbackground=CARD,
                        foreground=TEXT, borderwidth=0, rowheight=25, font=("Segoe UI", 10))
        style.configure("Treeview.Heading", background="#11161d", foreground=MUTED,
                        borderwidth=0, font=("Segoe UI", 10, "bold"))
        style.map("Treeview", background=[("selected", "#1f6feb")])
        style.configure("TButton", background=CARD, foreground=TEXT, borderwidth=1,
                        padding=(13, 6), font=("Segoe UI", 10, "bold"))
        style.map("TButton", background=[("active", "#21262d"), ("pressed", "#30363d")])
        style.configure("Run.TButton", background="#1f6feb", foreground="white")
        style.map("Run.TButton", background=[("active", "#388bfd")])
        # ★ 실행 중 버튼 (눌렸으면 노란색 - 확실한 피드백)
        style.configure("Running.TButton", background="#d29922", foreground="black", font=("Segoe UI", 10, "bold"))
        style.map("Running.TButton", background=[("active", "#e3b341")])
        # ★ 완료 버튼 (성공하면 초록 - 잠깐 보였다가 원복)
        style.configure("Done.TButton", background="#238636", foreground="white")
        style.map("Done.TButton", background=[("active", "#2ea043")])
        style.configure("Danger.TButton", foreground=RED)
        style.configure("TLabel", background=BG, foreground=TEXT, font=("Segoe UI", 10))
        style.configure("Card.TLabel", background=CARD, foreground=TEXT)
        style.configure("Muted.TLabel", background=CARD, foreground=MUTED, font=("Segoe UI", 9))
        style.configure("Header.TLabel", background=BG, foreground=TEXT, font=("Segoe UI", 16, "bold"))
        style.configure("CardVal.TLabel", background=CARD, foreground=TEXT, font=("Segoe UI", 18, "bold"))
        style.configure("CardLabel.TLabel", background=CARD, foreground=MUTED, font=("Segoe UI", 9))
        style.configure("Title.TLabel", background=CARD, foreground=ACCENT, font=("Segoe UI", 11, "bold"))
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", background="#21262d", foreground=TEXT, padding=(15, 7))
        style.map("TNotebook.Tab", background=[("selected", CARD)], foreground=[("selected", ACCENT)])
        style.configure("Horizontal.TProgressbar", background=ACCENT, troughcolor="#21262d")
        style.configure("TCheckbutton", background=CARD, foreground=TEXT)
        style.configure("TEntry", fieldbackground="#0d1117", foreground=TEXT,
                        insertcolor=TEXT, borderwidth=1)
        style.configure("TCombobox", fieldbackground="#0d1117", foreground=TEXT)
        style.map("TCombobox", fieldbackground=[("readonly", "#0d1117")])

    # ── 헤더 ──
    def _build_header(self):
        hdr = ttk.Frame(self.root, padding=(16, 12, 16, 4))
        hdr.pack(fill="x")
        ttk.Label(hdr, text="🤖 키움 AI 자동매매", style="Header.TLabel").pack(side="left")
        ttk.Button(hdr, text="❓ 사용 가이드",
                   command=lambda: show_guide(self.root, "overview")).pack(side="left", padx=(14, 0))
        self.badge_frame = ttk.Frame(hdr)
        self.badge_frame.pack(side="right")
        self.badge_mock = ttk.Label(self.badge_frame, text="", padding=(8, 3))
        self.badge_dry = ttk.Label(self.badge_frame, text="", padding=(8, 3))
        self.badge_ai = ttk.Label(self.badge_frame, text="", padding=(8, 3))
        self.badge_mock.pack(side="left", padx=3)
        self.badge_dry.pack(side="left", padx=3)
        self.badge_ai.pack(side="left", padx=3)

    def _badge(self, lbl, text, color, bg):
        lbl.config(text=text, background=bg, foreground=color, font=("Segoe UI", 10, "bold"))

    # ── 노트북 ──
    def _build_notebook(self):
        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill="both", expand=True, padx=12, pady=6)

    # ── 상태바 ──
    def _build_statusbar(self):
        self.status = ttk.Label(self.root, text="", style="Muted.TLabel", padding=(16, 6))
        self.status.pack(fill="x", side="bottom")

    # ==========================================================
    # 1) 대시보드
    # ==========================================================
    def _build_dashboard_tab(self):
        tab = ttk.Frame(self.nb, style="Card.TFrame", padding=10)
        self.nb.add(tab, text="📊 대시보드")

        # ── 스크롤 래퍼: 창이 작아도 아래 패널을 볼 수 있게 ──
        canvas = tk.Canvas(tab, bg=CARD, highlightthickness=0)
        vsb = ttk.Scrollbar(tab, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas, style="Card.TFrame", padding=(2, 2))
        win_id = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(win_id, width=e.width))
        canvas.configure(yscrollcommand=vsb.set)
        canvas.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        def _on_wheel(ev):
            canvas.yview_scroll(int(-ev.delta / 120), "units")
        def _on_enter(_e):
            canvas.bind_all("<MouseWheel>", _on_wheel)
            canvas.bind_all("<Button-4>", lambda ev: canvas.yview_scroll(-1, "units"))
            canvas.bind_all("<Button-5>", lambda ev: canvas.yview_scroll(1, "units"))
        def _on_leave(_e):
            canvas.unbind_all("<MouseWheel>")
            canvas.unbind_all("<Button-4>")
            canvas.unbind_all("<Button-5>")
        canvas.bind("<Enter>", _on_enter)
        canvas.bind("<Leave>", _on_leave)
        inner.bind("<Enter>", _on_enter)
        inner.bind("<Leave>", _on_leave)

        # 이후 위젯들은 inner 안에 배치 (tab 변수 = inner)
        tab = inner

        # ── ① 상태 줄: 시스템 / 시세 / 데이터 ──
        self.sys_status = ttk.Label(tab, text="🖥 시스템 상태: 확인 중...", style="Card.TLabel")
        self.sys_status.pack(fill="x", padx=(12, 12), pady=(2, 0))
        self.market_status = ttk.Label(tab, text="📡 시세 수신 상태: 확인 중...",
                                       style="Muted.TLabel")
        self.market_status.pack(fill="x", padx=(12, 12), pady=(2, 0))
        self.collect_period = ttk.Label(tab, text="📦 데이터 수집 현황: 확인 중...",
                                        style="Card.TLabel")
        self.collect_period.pack(fill="x", padx=(12, 12), pady=(2, 0))

        # ── ② 실행 바: 자동 파일럿 / 새로고침 / 신뢰도 ──
        bar = ttk.Frame(tab, style="Card.TFrame", padding=(12, 10))
        bar.pack(fill="x", padx=(12, 12), pady=(6, 0))
        self.pilot_btn = ttk.Button(bar, text="🚀 자동 파일럿 시작", style="Run.TButton",
                                    command=self._toggle_pilot, width=20)
        self.pilot_btn.pack(side="left")
        self.pilot_state = ttk.Label(bar, text="⏹ 중지됨", style="Card.TLabel")
        self.pilot_state.pack(side="left", padx=8)
        # ⚡ 실시간 모드 (OpenAPI+ 영웅문 연동 - 실시간 매수/매도)
        self.live_btn = ttk.Button(bar, text="⚡ 실시간 모드", style="Danger.TButton",
                                   command=self._toggle_live_mode)
        self.live_btn.pack(side="left", padx=(6, 0))
        self.live_state = ttk.Label(bar, text="", style="Card.TLabel")
        self.live_state.pack(side="left", padx=4)
        ttk.Button(bar, text="🔄 새로고침", command=self._refresh_live).pack(side="right", padx=3)
        ttk.Label(bar, text="🎯 신뢰도:", style="Card.TLabel").pack(side="right", padx=(10, 2))
        self.conf_combo = ttk.Combobox(bar, values=["50%", "60%", "70%", "80%", "90%"],
                                       width=6, state="readonly")
        self.conf_combo.set(f"{CFG.AI_BUY_CONFIDENCE_THRESHOLD}%")
        self.conf_combo.pack(side="right", padx=2)
        self.conf_combo.bind("<<ComboboxSelected>>", self._on_conf_change)
        ttk.Label(bar, text="이상일 때만 매수", style="Muted.TLabel").pack(side="right", padx=(0, 10))

        # ── ③ 4팀 카드 (2x2) - 처음 보는 사람도 어떤 팀이 뭘 하는지 바로 이해 ──
        teams_frame = ttk.Frame(tab, style="Card.TFrame")
        teams_frame.pack(fill="x", padx=(12, 12), pady=(6, 0))
        for c in range(2):
            teams_frame.columnconfigure(c, weight=1)

        def _team_card(row, col, emoji, title, desc, state_key):
            card = ttk.Frame(teams_frame, style="Card.TFrame", padding=(12, 10))
            card.grid(row=row, column=col, sticky="nsew", padx=4, pady=4)
            ttk.Label(card, text=f"{emoji} {title}", style="Title.TLabel").pack(anchor="w")
            ttk.Label(card, text=desc, style="Muted.TLabel", wraplength=420).pack(anchor="w", pady=(2, 0))
            state = ttk.Label(card, text="확인 중...", style="Card.TLabel", wraplength=420)
            state.pack(anchor="w", pady=(6, 0))
            setattr(self, f"team_{state_key}", state)
            btn_row = ttk.Frame(card, style="Card.TFrame")
            btn_row.pack(anchor="w", pady=(6, 0))
            return btn_row, card

        # 📥 자료수집 팀
        b, _ = _team_card(0, 0, "📥", "자료수집 팀",
                          "전 종목 일봉(최대 4년)+분봉(한 달치)을 모아둡니다. 자동으로 계속 쌓입니다.",
                          "data")
        self.backfill_btn = ttk.Button(b, text="📥 데이터 수집", style="Run.TButton",
                                       command=self._toggle_backfill)
        self.backfill_btn.pack(side="left")
        ttk.Label(b, text="자동 수집: 매일 장마감 후", style="Muted.TLabel").pack(side="left", padx=8)

        # 🔍 검증 팀
        b, _ = _team_card(0, 1, "🔍", "검증 팀",
                          "모은 자료로 조건식들이 신호를 잘 잡는지, 싹수없는 건 뒤로 빼고 변형을 만듭니다.",
                          "validate")
        _b = ttk.Button(b, text="🔍 검증 실행", style="Run.TButton",
                   command=lambda: self._run_test("team_validate", _b)); _b.pack(side="left")

        # 🖥 모의매매 팀
        b, _ = _team_card(1, 0, "🖥", "모의매매 팀",
                          "조건식 신호가 나면 모의 주문을 내고, 익절/손절/보유를 실제로 확인합니다.",
                          "paper")
        _b = ttk.Button(b, text="🖥 모의매매 실행", style="Run.TButton",
                   command=lambda: self._run_test("team_paper", _b)); _b.pack(side="left")

        # 🧠 총괄 팀 (AI)
        b, _ = _team_card(1, 1, "🧠", "총괄 팀 (AI)",
                          "위 3개 팀을 순서대로 돌리고, 명예의 전당을 관리합니다. 자동으로 운영됩니다.",
                          "control")
        _b = ttk.Button(b, text="🧠 총괄 라운드", style="Run.TButton",
                   command=lambda: self._run_test("control_round", _b)); _b.pack(side="left")

        # ── ④ 조건식 모의 매매 성적표 (핵심 - 전체 폭) ──
        cond_panel = ttk.Frame(tab, style="Card.TFrame", padding=(10, 8))
        cond_panel.pack(fill="x", padx=(12, 12), pady=(6, 0))
        cond_head = ttk.Frame(cond_panel, style="Card.TFrame")
        cond_head.pack(fill="x")
        ttk.Label(cond_head, text="🧪 조건식 성적표 (더블클릭 → 매수 종목 → 차트)",
                  style="Title.TLabel").pack(side="left")
        self.cond_summary = ttk.Label(cond_head, text="", style="Muted.TLabel")
        self.cond_summary.pack(side="right")
        ccols = ("no", "txt", "buys", "sells", "profit", "loss", "net", "win", "st")
        self.tree_cond = ttk.Treeview(cond_panel, columns=ccols, show="headings", height=9)
        for c, h, w in [("no", "번", 42), ("txt", "조건식", 320), ("buys", "매수", 46),
                        ("sells", "매도", 46), ("profit", "수익", 74), ("loss", "손실", 74),
                        ("net", "순손익", 84), ("win", "승률", 54), ("st", "상태", 52)]:
            self.tree_cond.heading(c, text=h)
            self.tree_cond.column(c, width=w, anchor="center" if c not in ("txt",) else "w")
        self.tree_cond.pack(fill="both", expand=True, pady=(6, 0))
        self.tree_cond.bind("<Double-1>", lambda e: self._on_cond_click())
        self.tree_cond.bind("<Return>", lambda e: self._on_cond_click())
        self.cond_hint = ttk.Label(cond_panel,
                                   text="※ 더블클릭 → 그 조건식이 매수한 종목 → 종목 더블클릭 → 차트 · 수익/손실/순손익=원",
                                   style="Muted.TLabel")
        self.cond_hint.pack(anchor="w", pady=(4, 0))

        # ── ⑤ 작업 로그 ──
        self.action_box = RO_Text(tab, height=7, bg="#0d1117", fg=MUTED,
                                  font=("Consolas", 9), wrap="word", relief="flat")
        self.action_box.pack(fill="x", padx=(12, 12), pady=(6, 0))
        self._alog("📋 작업 로그 (4팀이 여기에 기록합니다)\n"
                                      "────────────────────────────────────\n")

    # ==========================================================
    # 2) 전략
    # ==========================================================
    # 💼 실제 매매 탭 (계좌 + 모의/실전만 - 가상 완전 분리)
    # ==========================================================
    def _build_real_tab(self):
        tab = ttk.Frame(self.nb, style="Card.TFrame", padding=8)
        self.nb.add(tab, text="💼 계좌")
        tab.columnconfigure(0, weight=1)
        tab.columnconfigure(1, weight=1)
        tab.rowconfigure(1, weight=1)

        # ── 데이터 저장 위치 / 수집 현황 (직관적으로) ──
        data_bar = ttk.Frame(tab, style="Card.TFrame", padding=(10, 6))
        data_bar.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 8))
        self.data_status = ttk.Label(data_bar, text="📂 데이터 저장 위치/수집 현황: 확인 중...",
                                     style="Card.TLabel")
        self.data_status.pack(side="left")
        # ★ 봉 구분 안내 (사용자: '일봉/주봉/분봉 표현이 없다')
        self.candle_info = ttk.Label(
            data_bar,
            text=" 📈 판단 기준: 일봉(최신 봉 종가) · 주문가: 실시간 현재가 · 분봉: 스캘핑/청산 판정용",
            style="Muted.TLabel")
        self.candle_info.pack(side="right")

        left = ttk.Frame(tab, style="Card.TFrame")
        left.grid(row=1, column=0, sticky="nsew", padx=(0, 8))
        top = ttk.Frame(left, style="Card.TFrame")
        top.pack(fill="x", pady=(0, 4))
        ttk.Label(top, text="💼 보유 종목 (실제 키움 계좌만)", style="Title.TLabel").pack(side="left")
        ttk.Button(top, text="❓", width=3, command=lambda: show_guide(self.root, "positions")).pack(side="left", padx=8)
        ttk.Button(top, text="🤖 AI 평가", style="Run.TButton",
                   command=self._show_holdings_eval).pack(side="left", padx=8)
        ttk.Button(top, text="🗑 전체 청산", style="Danger.TButton",
                   command=self._liquidate_all).pack(side="left", padx=8)
        self.pos_status = ttk.Label(top, text="0건", style="Muted.TLabel")
        self.pos_status.pack(side="right")
        cols = ("sym", "name", "qty", "avg", "cur", "eval", "pnl", "ret")
        self.tree_pos = ttk.Treeview(left, columns=cols, show="headings")
        for c, h, w in [("sym", "코드", 58), ("name", "종목명", 95),
                        ("qty", "수량", 48), ("avg", "평균가", 90), ("cur", "현재가", 90),
                        ("eval", "매수금액", 95), ("pnl", "손익", 90), ("ret", "수익률", 70)]:
            self.tree_pos.heading(c, text=h)
            self.tree_pos.column(c, width=w, anchor="center" if c not in ("name",) else "w")
        self.tree_pos.pack(fill="both", expand=True)
        self.tree_pos.bind("<Double-1>", lambda e: self._on_pos_double_click(e))

        right = ttk.Frame(tab, style="Card.TFrame")
        right.grid(row=1, column=1, sticky="nsew")
        top2 = ttk.Frame(right, style="Card.TFrame")
        top2.pack(fill="x", pady=(0, 4))
        ttk.Label(top2, text="최근 거래", style="Title.TLabel").pack(side="left")
        self.trade_status = ttk.Label(top2, text="0건", style="Muted.TLabel")
        self.trade_status.pack(side="right")
        cols = ("id", "sym", "name", "side", "price", "kind", "time")
        self.tree_trades = ttk.Treeview(right, columns=cols, show="headings")
        for c, h, w in [("id", "#", 40), ("sym", "코드", 58), ("name", "종목명", 90),
                        ("side", "방향", 50), ("price", "가격", 88),
                        ("kind", "유형", 70), ("time", "시각", 130)]:
            self.tree_trades.heading(c, text=h)
            self.tree_trades.column(c, width=w, anchor="center" if c not in ("name", "time") else "w")
        self.tree_trades.pack(fill="both", expand=True)

    # ==========================================================
    # 🧪 시뮬레이션 탭 (가상만 - 실제 주문 없음)
    # ==========================================================

    def _build_pnl_tab(self):
        tab = ttk.Frame(self.nb, style="Card.TFrame", padding=8)
        self.nb.add(tab, text="💰 손익분석")
        tab.columnconfigure(0, weight=1)
        tab.rowconfigure(2, weight=1)
        tab.rowconfigure(4, weight=2)

        ctrl = ttk.Frame(tab, style="Card.TFrame")
        ctrl.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        ttk.Label(ctrl, text="기간:", style="Card.TLabel").pack(side="left", padx=4)
        self.pnl_period = ttk.Combobox(ctrl, values=["1일", "7일", "30일", "전체"], width=8, state="readonly")
        self.pnl_period.set("7일")
        self.pnl_period.pack(side="left", padx=4)
        ttk.Button(ctrl, text="📊 손익 조회", command=self._load_pnl).pack(side="left", padx=8)
        ttk.Button(ctrl, text="❓", width=3, command=lambda: show_guide(self.root, "pnl")).pack(side="left", padx=4)

        # 요약 (손익비 포함 - 돈 버는 시스템의 핵심 지표)
        self.pnl_summary = ttk.Label(tab, text="손익 요약: -", style="Card.TLabel")
        self.pnl_summary.grid(row=1, column=0, sticky="w", pady=(0, 6))

        cols_frame = ttk.Frame(tab, style="Card.TFrame")
        cols_frame.grid(row=2, column=0, sticky="nsew")
        for i in range(3):
            cols_frame.columnconfigure(i, weight=1)
        cols_frame.rowconfigure(0, weight=1)

        self.pnl_trees = {}
        for i, (name, key) in enumerate([("전략별", "per_strategy"), ("일별", "per_day"), ("종목별", "per_symbol")]):
            f = ttk.Frame(cols_frame, style="Card.TFrame")
            f.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 4, 4 if i == 2 else 0))
            ttk.Label(f, text=name, style="Title.TLabel").pack(anchor="w", pady=(0, 4))
            cols = ("key", "trades", "win", "avg%", "pnl")
            tr = ttk.Treeview(f, columns=cols, show="headings", height=12)
            for c, h, w in [("key", "구분", 70), ("trades", "거래", 50), ("win", "승률%", 60),
                            ("avg%", "평균%", 60), ("pnl", "손익", 90)]:
                tr.heading(c, text=h)
                tr.column(c, width=w, anchor="center")
            # 일별 탭: 날짜 클릭/더블클릭 → 그날 상세 표시
            if key == "per_day":
                tr.bind("<Double-1>", lambda e, k=key: self._on_pnl_day_click(e, k))
                tr.bind("<Return>", lambda e, k=key: self._on_pnl_day_click(e, k))
            tr.pack(fill="both", expand=True)
            self.pnl_trees[key] = tr

        # ── 선택한 날짜의 상세 (그날 매수/매도/수익률/손익) ──
        detail_head = ttk.Frame(tab, style="Card.TFrame")
        detail_head.grid(row=3, column=0, sticky="ew", pady=(8, 4))
        self.pnl_detail_title = ttk.Label(detail_head, text="📅 날짜 선택 시 상세 (일별 탭에서 날짜 더블클릭)",
                                          style="Title.TLabel")
        self.pnl_detail_title.pack(side="left")
        self.pnl_detail_summary = ttk.Label(detail_head, text="", style="Card.TLabel")
        self.pnl_detail_summary.pack(side="right")

        detail_frame = ttk.Frame(tab, style="Card.TFrame")
        detail_frame.grid(row=4, column=0, sticky="nsew")
        # 거래 내역 테이블
        ttk.Label(detail_frame, text="거래 내역", style="CardLabel.TLabel").grid(row=0, column=0, sticky="w")
        cols = ("time", "sym", "name", "side", "price", "qty", "kind", "amount")
        self.pnl_detail_trades = ttk.Treeview(detail_frame, columns=cols, show="headings", height=6)
        for c, h, w in [("time", "시각", 60), ("sym", "코드", 55), ("name", "종목명", 90),
                        ("side", "방향", 45), ("price", "가격", 80), ("qty", "수량", 40),
                        ("kind", "유형", 60), ("amount", "금액", 90)]:
            self.pnl_detail_trades.heading(c, text=h)
            self.pnl_detail_trades.column(c, width=w, anchor="center" if c not in ("name",) else "w")
        self.pnl_detail_trades.grid(row=1, column=0, sticky="nsew", pady=(2, 4))
        # 청산 결과 테이블 (수익률/손익)
        ttk.Label(detail_frame, text="청산 결과 (수익률/손익)", style="CardLabel.TLabel").grid(row=2, column=0, sticky="w")
        cols = ("sym", "name", "entry", "exit", "qty", "ret", "pnl", "kind")
        self.pnl_detail_closed = ttk.Treeview(detail_frame, columns=cols, show="headings", height=5)
        for c, h, w in [("sym", "코드", 55), ("name", "종목명", 90), ("entry", "진입가", 80),
                        ("exit", "청산가", 80), ("qty", "수량", 40), ("ret", "수익률", 70),
                        ("pnl", "손익", 90), ("kind", "유형", 55)]:
            self.pnl_detail_closed.heading(c, text=h)
            self.pnl_detail_closed.column(c, width=w, anchor="center" if c not in ("name",) else "w")
        self.pnl_detail_closed.grid(row=3, column=0, sticky="nsew", pady=(2, 0))
        detail_frame.columnconfigure(0, weight=1)
        detail_frame.rowconfigure(1, weight=1)
        detail_frame.rowconfigure(3, weight=1)

    # ==========================================================
    # 5) 시세 아카이브 (1주일 자료)
    # ==========================================================
    def _build_data_tab(self):
        tab = ttk.Frame(self.nb, style="Card.TFrame", padding=8)
        self.nb.add(tab, text="📈 시세 데이터")
        tab.columnconfigure(0, weight=1)
        tab.rowconfigure(1, weight=2)
        tab.rowconfigure(3, weight=3)

        ctrl = ttk.Frame(tab, style="Card.TFrame")
        ctrl.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        ttk.Button(ctrl, text="↻ 리포트 새로고침", command=self._load_archive).pack(side="left", padx=4)
        ttk.Label(ctrl, text="기간:", style="Card.TLabel").pack(side="left", padx=(12, 2))
        self.archive_period = ttk.Combobox(ctrl, values=["1주", "1달", "3달", "전체"], width=6, state="readonly")
        self.archive_period.set("1달")
        self.archive_period.pack(side="left", padx=4)
        ttk.Button(ctrl, text="조회", command=self._load_archive).pack(side="left", padx=4)
        ttk.Button(ctrl, text="📊 분봉 요약", command=self._load_minute_summary).pack(side="left", padx=4)
        ttk.Button(ctrl, text="❓", width=3, command=lambda: show_guide(self.root, "archive")).pack(side="left", padx=4)
        self.archive_summary = ttk.Label(ctrl, text="", style="Card.TLabel")
        self.archive_summary.pack(side="left", padx=12)

        # 종목별 요약 테이블
        cols = ("sym", "samples", "range", "change", "high", "low", "cheg_avg", "cheg_last", "rsi")
        self.tree_archive = ttk.Treeview(tab, columns=cols, show="headings", height=8)
        for c, h, w in [("sym", "종목", 70), ("samples", "샘플", 60), ("range", "가격범위", 170),
                        ("change", "변화%", 70), ("high", "고가", 90), ("low", "저가", 90),
                        ("cheg_avg", "체결평균", 85), ("cheg_last", "체결최신", 85), ("rsi", "RSI", 55)]:
            self.tree_archive.heading(c, text=h)
            self.tree_archive.column(c, width=w, anchor="center" if c not in ("range",) else "w")
        self.tree_archive.grid(row=1, column=0, sticky="nsew", pady=(0, 8))

        # 주간 리포트 텍스트
        ttk.Label(tab, text="주간 리포트", style="Title.TLabel").grid(row=2, column=0, sticky="nw")
        self.report_text = RO_Text(tab, wrap="word", bg="#0d1117", fg=TEXT,
                                   insertbackground=TEXT, font=("Consolas", 10))
        self.report_text.grid(row=3, column=0, sticky="nsew", pady=(4, 0))
        self.report_text.insert("1.0", "아직 리포트가 없습니다.\n")

    # ==========================================================
    # 6) 프롬프트
    # ==========================================================
    def _build_prompt_tab(self):
        tab = ttk.Frame(self.nb, style="Card.TFrame", padding=8)
        self.nb.add(tab, text="📝 프롬프트")
        tab.columnconfigure(0, weight=1)
        tab.columnconfigure(1, weight=1)
        tab.rowconfigure(1, weight=1)

        ttk.Label(tab, text="매수 프롬프트 (수정 후 저장 - 즉시 반영)",
                  style="Title.TLabel").grid(row=0, column=0, sticky="w", padx=4, pady=(0, 6))
        ttk.Label(tab, text="매도 프롬프트 (수정 후 저장 - 즉시 반영)",
                  style="Title.TLabel").grid(row=0, column=1, sticky="w", padx=4, pady=(0, 6))
        self.prompt_txt_buy = scrolledtext.ScrolledText(tab, wrap="word", bg="#0d1117",
                                                        fg=TEXT, insertbackground=TEXT,
                                                        font=("Consolas", 10))
        self.prompt_txt_buy.grid(row=1, column=0, sticky="nsew", padx=4)
        self.prompt_txt_sell = scrolledtext.ScrolledText(tab, wrap="word", bg="#0d1117",
                                                         fg=TEXT, insertbackground=TEXT,
                                                         font=("Consolas", 10))
        self.prompt_txt_sell.grid(row=1, column=1, sticky="nsew", padx=4)
        self.prompt_txt_buy.insert("1.0", _read_prompt(BUY_PROMPT_PATH, "[매수 조건]..."))
        self.prompt_txt_sell.insert("1.0", _read_prompt(SELL_PROMPT_PATH, "[매도 조건]..."))

        btns = ttk.Frame(tab, style="Card.TFrame")
        btns.grid(row=2, column=0, columnspan=2, sticky="w", padx=4, pady=8)
        ttk.Button(btns, text="💾 프롬프트 저장", style="Run.TButton", command=self._save_prompts).pack(side="left", padx=4)
        ttk.Button(btns, text="❓", width=3, command=lambda: show_guide(self.root, "prompts")).pack(side="left", padx=4)
        ttk.Button(btns, text="🤖 AI 기준 검토", command=self._ai_review_prompts).pack(side="left", padx=4)
        ttk.Button(btns, text="↻ 파일에서 다시 불러오기", command=self._reload_prompt_files).pack(side="left", padx=4)

    # ==========================================================
    # 7) AI 컨설턴트
    # ==========================================================
    def _build_consult_tab(self):
        tab = ttk.Frame(self.nb, style="Card.TFrame", padding=8)
        self.nb.add(tab, text="🤖 AI 컨설턴트")
        self.consult_tab_index = self.nb.index("end") - 1

        top = ttk.Frame(tab, style="Card.TFrame")
        top.pack(fill="x", pady=(0, 6))
        self.consult_status = ttk.Label(top, text="", style="Card.TLabel")
        self.consult_status.pack(side="left")
        ttk.Button(top, text="❓", width=3, command=lambda: show_guide(self.root, "consult")).pack(side="left", padx=8)
        self._update_consult_status()

        presets = ttk.Frame(tab, style="Card.TFrame")
        presets.pack(fill="x", pady=(0, 8))
        for txt, fn in [("📝 프롬프트 검토", lambda: self._consult_preset("prompts")),
                        ("📊 전략 분석", lambda: self._consult_preset("analyze")),
                        ("🧬 세대교체 추천", lambda: self._consult_preset("evolve")),
                        ("⚠️ 리스크 점검", lambda: self._consult_preset("risk")),
                        ("⏰ 지수×시간대", lambda: self._consult_preset("index_time")),
                        ("📈 주간 리포트", lambda: self._consult_preset("report")),
                        ("🔁 매수결과 리뷰", lambda: self._consult_preset("buy_review"))]:
            ttk.Button(presets, text=txt, command=fn).pack(side="left", padx=3)

        self.consult_out = RO_Text(tab, wrap="word", bg="#0d1117", fg=TEXT,
                                   insertbackground=TEXT, font=("Consolas", 10))
        self.consult_out.pack(fill="both", expand=True, pady=(0, 8))
        self._append_consult("🤖 AI 컨설턴트 준비됨. 질문을 입력하거나 위 버튼을 누르세요.\n"
                             f"현재 공급자: {CFG.AI_PROVIDER}\n")

        bottom = ttk.Frame(tab, style="Card.TFrame")
        bottom.pack(fill="x")
        self.consult_input = ttk.Entry(bottom)
        self.consult_input.pack(side="left", fill="x", expand=True, padx=(0, 6))
        self.consult_input.bind("<Return>", lambda e: self._send_consult())
        ttk.Button(bottom, text="보내기", style="Run.TButton", command=self._send_consult).pack(side="right")

        # ── 검증마스터 유사: 종목 분석 (편입 데이터 + AI) ──
        sym_bar = ttk.Frame(tab, style="Card.TFrame")
        sym_bar.pack(fill="x", pady=(6, 0))
        ttk.Label(sym_bar, text="🔍 종목 분석 (검증마스터):", style="Card.TLabel").pack(side="left", padx=2)
        self.sym_input = ttk.Entry(sym_bar, width=10)
        self.sym_input.pack(side="left", padx=2)
        ttk.Button(sym_bar, text="📊 분석", style="Run.TButton",
                   command=self._analyze_symbol_btn).pack(side="left", padx=4)
        ttk.Label(sym_bar, text="예: 005930 (편입가/고저/체결강도/거래량 → AI가 뉴스·추세·테마 분석)",
                  style="Muted.TLabel").pack(side="left", padx=6)

    # ==========================================================
    # 8) 설정
    # ==========================================================
    def _build_settings_tab(self):
        tab = ttk.Frame(self.nb, style="Card.TFrame", padding=8)
        self.nb.add(tab, text="⚙️ 설정")

        head = ttk.Frame(tab, style="Card.TFrame")
        head.pack(fill="x", pady=(0, 8))
        ttk.Label(head, text="환경설정 (.env) - 수정 후 저장하면 즉시 반영됩니다",
                  style="Title.TLabel").pack(side="left")
        ttk.Button(head, text="❓", width=3, command=lambda: show_guide(self.root, "settings")).pack(side="left", padx=8)
        ttk.Button(head, text="💾 설정 저장", style="Run.TButton", command=self._save_settings).pack(side="right")

        canvas = tk.Canvas(tab, bg=CARD, highlightthickness=0)
        scroll = ttk.Scrollbar(tab, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas, style="Card.TFrame")
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        self.env_vars = {}
        env_map = _read_env_map()
        for row, (key, label, typ) in enumerate(ENV_FIELDS):
            f = ttk.Frame(inner, style="Card.TFrame", padding=(6, 4))
            f.grid(row=row, column=0, sticky="ew", padx=4)
            inner.columnconfigure(0, weight=1)
            ttk.Label(f, text=f"{label} ({key})", style="Card.TLabel", width=38).pack(side="left", padx=4)
            if typ == "bool":
                var = tk.BooleanVar(value=str(env_map.get(key, "true" if key in ("KIWOOM_USE_MOCK", "DRY_RUN") else "")).lower() in ("true", "1", "yes", "on"))
                chk = ttk.Checkbutton(f, variable=var, style="TCheckbutton")
                chk.pack(side="left")
                self.env_vars[key] = var
            else:
                cur = env_map.get(key, "")
                if not cur:
                    cur = str(getattr(CFG, ENV_ATTR_MAP.get(key, ""), "")) if ENV_ATTR_MAP.get(key) else ""
                var = tk.StringVar(value=cur)
                ent = ttk.Entry(f, textvariable=var)
                ent.pack(side="left", fill="x", expand=True, padx=4)
                self.env_vars[key] = var

        hint = ttk.Label(inner, text="\n⚠️ 주의: DRY_RUN=true, USE_MOCK=true 상태에서 시작하세요.\n"
                                     "두 값을 모두 false로 바꿔야 실전 주문이 나갑니다.",
                         style="Muted.TLabel")
        hint.grid(row=len(ENV_FIELDS) + 1, column=0, sticky="w", padx=8, pady=10)

    # ==========================================================
    # 9) 테스트 · 백테스트
    # ==========================================================
    def _build_report_tab(self):
        """📋 일일 복기 리포트: 날짜 선택 → 내용+차트 → AI 토의"""
        tab = ttk.Frame(self.nb, style="Card.TFrame", padding=8)
        self.nb.add(tab, text="📋 리포트")
        tab.columnconfigure(0, weight=1)
        tab.rowconfigure(2, weight=1)

        ctrl = ttk.Frame(tab, style="Card.TFrame")
        ctrl.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        ttk.Label(ctrl, text="일일 복기 리포트:", style="Title.TLabel").pack(side="left", padx=(0, 8))
        ttk.Button(ctrl, text="🔄 날짜 목록", command=self._report_list).pack(side="left", padx=3)
        ttk.Label(ctrl, text="날짜:", style="Card.TLabel").pack(side="left", padx=(10, 2))
        self.report_date = ttk.Combobox(ctrl, width=12, state="readonly")
        self.report_date.pack(side="left", padx=2)
        ttk.Button(ctrl, text="📄 리포트 보기", style="Run.TButton", command=self._report_show).pack(side="left", padx=3)
        ttk.Button(ctrl, text="➕ 오늘 리포트 생성", command=self._report_gen).pack(side="left", padx=3)
        ttk.Button(ctrl, text="🤖 AI 토의", style="Run.TButton", command=self._report_discuss).pack(side="left", padx=3)
        ttk.Label(ctrl, text="매수/매도 타점 차트 + 복기 · AI와 개선 논의",
                  style="Muted.TLabel").pack(side="left", padx=8)

        # 토의 입력 (AI 토의 시 질문)
        ask = ttk.Frame(tab, style="Card.TFrame")
        ask.grid(row=2, column=0, sticky="ew", pady=(0, 8))
        ttk.Label(ask, text="🤖 토의 의견:", style="Card.TLabel").pack(side="left", padx=2)
        self.report_question = ttk.Entry(ask)
        self.report_question.pack(side="left", fill="x", expand=True, padx=4)
        self.report_question.insert(0, "예: 손절이 늦었는데 어떻게 개선할까?")
        ttk.Button(ask, text="보내기", style="Run.TButton", command=self._report_discuss).pack(side="right")

        # 주간 리포트 행 (AI 넣은 vs 안 넣은 비교 + 허락 반영)
        wk = ttk.Frame(tab, style="Card.TFrame")
        wk.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        ttk.Label(wk, text="📅 주간 리포트:", style="Title.TLabel").pack(side="left", padx=(0, 8))
        ttk.Button(wk, text="🔄 주간 보기", style="Run.TButton",
                   command=self._weekly_show).pack(side="left", padx=3)
        ttk.Button(wk, text="➕ 지금 생성", command=self._weekly_gen).pack(side="left", padx=3)
        ttk.Button(wk, text="✅ 권장사항 반영 (허락)", style="Danger.TButton",
                   command=self._weekly_apply).pack(side="left", padx=3)
        ttk.Label(wk, text="AI 판단 넣은 vs 안 넣은 비교 · 수정은 허락 후 반영",
                  style="Muted.TLabel").pack(side="left", padx=8)

        # 리포트 텍스트
        self.report_text = RO_Text(tab, wrap="word", bg="#0d1117", fg=TEXT,
                                   insertbackground=TEXT, font=("Consolas", 10))
        self.report_text.grid(row=3, column=0, sticky="nsew", pady=(0, 8))
        self.report_text.insert("1.0", "날짜를 선택하고 '📄 리포트 보기'를 누르세요.\n"
                                      "'➕ 오늘 리포트 생성'으로 오늘 매매 복기 리포트를 만들 수 있습니다.")
        # 차트 표시 영역 (하단, 그림 여러 장)
        ttk.Label(tab, text="매수 타점 차트 (더블클릭 시 확대)", style="Title.TLabel").grid(row=4, column=0, sticky="w")
        chart_row = ttk.Frame(tab, style="Card.TFrame")
        chart_row.grid(row=5, column=0, sticky="ew")
        self.report_charts = chart_row

    def _weekly_gen(self):
        """📅 주간 리포트 즉시 생성"""
        def worker():
            try:
                import weekly_report
                w = weekly_report.generate_weekly_report()
                txt = open(w["path"], encoding="utf-8").read()
                self.root.after(0, lambda: self.report_text.delete("1.0", "end"))
                self.root.after(0, lambda: self.report_text.insert("1.0", txt))
            except Exception as e:
                self.root.after(0, lambda: self._set_status(f"⚠️ 주간 리포트 생성 실패: {e}"))
        threading.Thread(target=worker, daemon=True).start()

    def _weekly_show(self):
        """📅 최근 주간 리포트 보기"""
        try:
            import weekly_report
            latest = weekly_report.get_latest()
            if not latest or not os.path.exists(latest.get("path", "")):
                self.report_text.delete("1.0", "end")
                self.report_text.insert("1.0", "아직 주간 리포트가 없습니다.\n"
                                               "'➕ 지금 생성' 버튼으로 생성하세요 (AI 넣은 vs 안 넣은 비교 포함).")
                return
            txt = open(latest["path"], encoding="utf-8").read()
            self.report_text.delete("1.0", "end")
            self.report_text.insert("1.0", txt)
        except Exception as e:
            self._set_status(f"⚠️ 주간 리포트 보기 실패: {e}")

    def _weekly_apply(self):
        """✅ 주간 리포트 권장사항 반영 (사용자 허락 확인 후 - 자동 적용 없음)
        현재는 권장사항 확인용이며, 실제 프롬프트/설정 수정은 확인창을 거쳐 적용합니다.
        """
        try:
            import weekly_report
            latest = weekly_report.get_latest()
            if not latest:
                messagebox.showinfo("주간 리포트", "아직 주간 리포트가 없습니다. 먼저 생성해주세요.")
                return
            recs = latest.get("recommendations") or []
            if not recs:
                messagebox.showinfo("주간 리포트", "권장 변경사항이 없습니다.")
                return
            lines = "\n".join(f"{i}. [{r['type']}] {r['desc']}" for i, r in enumerate(recs, 1))
            if messagebox.askyesno("권장사항 반영",
                                   f"다음 권장사항을 확인했습니다.\n\n{lines}\n\n"
                                   f"⚠️ 반영할 항목이 있으면 번호를 메모한 뒤 알려주세요.\n"
                                   f"AI가 자동으로 설정/프롬프트를 바꾸지 않습니다.\n"
                                   f"(현재는 리포트 확인 단계 - 설정 변경은 ⚙️ 설정 탭에서 직접) "):
                self._set_status("✅ 권장사항 확인 완료 (설정 변경은 ⚙️ 설정 탭에서 직접)")
        except Exception as e:
            self._set_status(f"⚠️ 권장사항 확인 실패: {e}")

    def _report_list(self):
        """날짜 목록 갱신"""
        import daily_report
        dates = daily_report.list_reports()
        self.report_date["values"] = dates
        if dates:
            self.report_date.set(dates[0])
            self._set_status(f"리포트 {len(dates)}개 (최신 {dates[0]})")

    def _report_gen(self):
        """오늘 리포트 생성"""
        def worker():
            import daily_report
            r = daily_report.generate_daily_report()
            self.root.after(0, lambda: self._report_show_date(r["date"] if r else None))
            if r:
                self.root.after(0, lambda: self._set_status(f"📋 {r['date']} 리포트 생성 완료"))
        self._set_status("📋 오늘 리포트 생성 중...")
        threading.Thread(target=worker, daemon=True).start()

    def _report_show(self):
        d = self.report_date.get()
        if d:
            self._report_show_date(d)

    def _report_show_date(self, d):
        if not d:
            return
        import daily_report
        txt = daily_report.get_report(d)
        charts = daily_report.get_report_charts(d)
        if txt:
            self.report_text.replace(txt)
        else:
            self.report_text.replace(f"{d}: 리포트 없음 — '➕ 오늘 리포트 생성'으로 만드세요.")
        # 차트 이미지 표시
        for w in self.report_charts.winfo_children():
            w.destroy()
        try:
            from PIL import ImageTk, Image
            for p in charts[:6]:
                img = Image.open(p)
                ratio = min(260 / img.width, 180 / img.height) if img.width > 260 else 1
                if ratio < 1:
                    img = img.resize((int(img.width * ratio), int(img.height * ratio)), Image.LANCZOS)
                photo = ImageTk.PhotoImage(img)
                lbl = ttk.Label(self.report_charts, image=photo)
                lbl.image = photo
                lbl.pack(side="left", padx=3)
                lbl.bind("<Double-1>", lambda e, pp=p: self._display_chart(pp, os.path.basename(pp)))
        except Exception:
            pass
        self._report_list()

    def _report_discuss(self):
        """🤖 AI 토의: 선택 날짜 리포트 + 질문"""
        d = self.report_date.get()
        q = self.report_question.get().strip()
        def worker():
            import ai_consult
            txt = ai_consult.discuss_daily_report(d, question=q)
            self.root.after(0, lambda: self.report_text.replace(txt))
            self.root.after(0, lambda: self._set_status("🤖 토의 완료"))
        self._set_status("🤖 AI 토의 중...")
        threading.Thread(target=worker, daemon=True).start()

    def _build_test_tab(self):
        tab = ttk.Frame(self.nb, style="Card.TFrame", padding=8)
        self.nb.add(tab, text="🧪 테스트·백테스트")

        btns = ttk.Frame(tab, style="Card.TFrame")
        btns.pack(fill="x", pady=(0, 8))
        # ── ★ 4팀 운영 (간결) ──
        ttk.Label(btns, text="4팀 운영:", style="Title.TLabel").pack(side="left", padx=(0, 6))
        _b = ttk.Button(btns, text="🧠 총괄 라운드 (자료수집→검증→모의매매)", style="Run.TButton",
                   command=lambda: self._run_test("control_round", _b)); _b.pack(side="left", padx=3)
        _b = ttk.Button(btns, text="📥 자료수집", command=lambda: self._run_test("team_data", _b)); _b.pack(side="left", padx=3)
        _b = ttk.Button(btns, text="🔍 검증", command=lambda: self._run_test("team_validate", _b)); _b.pack(side="left", padx=3)
        _b = ttk.Button(btns, text="🖥 모의매매", command=lambda: self._run_test("team_paper", _b)); _b.pack(side="left", padx=3)
        _b = ttk.Button(btns, text="🏆 명예의 전당", command=lambda: self._run_test("hof", _b)); _b.pack(side="left", padx=3)
        _b = ttk.Button(btns, text="🎯 엄밀 검증", style="Run.TButton",
                   command=lambda: self._run_test("validation", _b)); _b.pack(side="left", padx=3)
        _b = ttk.Button(btns, text="📷 사진 검색식 검증", style="Run.TButton",
                   command=lambda: self._run_test("photo_validate", _b)); _b.pack(side="left", padx=3)
        _b = ttk.Button(btns, text="🧪 자체 점검", command=lambda: self._run_test("self", _b)); _b.pack(side="left", padx=3)
        ttk.Button(btns, text="❓", width=3, command=lambda: show_guide(self.root, "test")).pack(side="left", padx=3)

        # ── 🎯 엄밀 검증 옵션 (일자별 검증 - 빠르게) ──
        vopt = ttk.Frame(tab, style="Card.TFrame", padding=(10, 6))
        vopt.pack(fill="x", pady=(0, 8))
        ttk.Label(vopt, text="🎯 검증 기간(빈칸=전체):", style="Title.TLabel").pack(side="left", padx=(0, 6))
        ttk.Label(vopt, text="시작", style="Muted.TLabel").pack(side="left")
        self.v_start = ttk.Entry(vopt, width=11)
        self.v_start.pack(side="left", padx=2)
        ttk.Label(vopt, text="종료", style="Muted.TLabel").pack(side="left", padx=(8, 0))
        self.v_end = ttk.Entry(vopt, width=11)
        self.v_end.pack(side="left", padx=2)
        ttk.Label(vopt, text="종목수", style="Muted.TLabel").pack(side="left", padx=(8, 0))
        self.v_syms = ttk.Entry(vopt, width=6)
        self.v_syms.insert(0, "100")
        self.v_syms.pack(side="left", padx=2)
        ttk.Label(vopt, text="(YYYY-MM-DD · 종목 적을수록 빠름)", style="Muted.TLabel").pack(side="left", padx=6)

        # ── 매수타점 차트 (시각화 - 검증/타점 확인) ──
        chart_bar = ttk.Frame(tab, style="Card.TFrame")
        chart_bar.pack(fill="x", pady=(0, 8))
        ttk.Label(chart_bar, text="📈 매수타점 차트:", style="Title.TLabel").pack(side="left", padx=(0, 6))
        self.chart_sym = ttk.Entry(chart_bar, width=10)
        self.chart_sym.insert(0, "005930")
        self.chart_sym.pack(side="left", padx=2)
        ttk.Button(chart_bar, text="📊 차트 보기", style="Run.TButton", command=self._show_chart).pack(side="left", padx=3)
        ttk.Button(chart_bar, text="🤖 AI 설명", command=self._chart_ai).pack(side="left", padx=3)
        ttk.Button(chart_bar, text="🔍 최근 신호", command=self._chart_signals).pack(side="left", padx=3)
        ttk.Label(chart_bar, text="종목코드 · 캔들+MA+거래량+매수▲/매도▼ 타점 · 차트를 채팅에 올리면 AI가 설명",
                  style="Muted.TLabel").pack(side="left", padx=8)

        # ── 4팀 안내줄 ──
        hint_bar = ttk.Frame(tab, style="Card.TFrame")
        hint_bar.pack(fill="x", pady=(0, 8))
        ttk.Label(hint_bar, text="💡 대시보드에서 🚀 자동 파일럿을 켜면 4팀(자료수집→검증→모의매매→총괄)이 자동 운영됩니다",
                  style="Muted.TLabel").pack(side="left")

        self.test_out = RO_Text(tab, wrap="word", bg="#0d1117", fg=TEXT,
                                insertbackground=TEXT, font=("Consolas", 10))
        self.test_out.pack(fill="both", expand=True)
        self.test_out.insert("1.0", "테스트 결과가 여기에 표시됩니다.\n")

    # ==========================================================
    # 데이터 로드 (라이브)
    # ==========================================================
    def _refresh_live(self):
        self._load_stats()
        self._load_data_status()     # 📂 데이터 저장 위치/수집 현황
        self._load_positions()       # 💼 계좌 실제 보유
        self._load_trades()
        self._load_real_panel()
        self._load_conditions()      # 🧪 조건식 모의 매매 성적표
        try:
            self._load_pnl()  # 손익분석 자동 갱신 (검색 불필요)
        except Exception:
            pass

    def _auto_refresh(self):
        """★ 2026-09-02 가벼움 개편 (사용자: "무거워서 설정 바꿀 때마다 멈춤")
        - 기존: 10초마다 UI 스레드에서 전체 갱신 (손익분석 SQL 포함)
          → 라운드/수집이 DB를 쓰는 중이면 UI가 그 잠금을 기다리며 '응답 없음'
        - 수정: 30초 간격 + 가벼운 것만 매번, 무거운 것(손익분석/조건식표)은 3회에 1번
          + 라운드가 도는 중이면 무거운 갱신 스킵 (DB 경합 자체를 회피)
        """
        try:
            self._refresh_tick = getattr(self, "_refresh_tick", 0) + 1
            self._load_stats()
            self._load_data_status()
            self._load_positions()
            self._load_trades()
            if self._refresh_tick % 3 == 0:      # 90초에 1번만 무거운 것
                busy = False
                try:
                    import json as _j
                    import time as _t2
                    rp = _j.load(open(os.path.join("strategy", "round_progress.json"),
                                      encoding="utf-8"))
                    busy = (_t2.time() - rp.get("now", 0)) < 120 and \
                           rp.get("step", 9) < rp.get("steps_total", 4)
                except Exception:
                    pass
                if not busy:                     # 라운드 진행 중엔 DB 경합 피함
                    self._load_real_panel()
                    self._load_conditions()
                    try:
                        self._load_pnl()
                    except Exception:
                        pass
        except Exception:
            pass
        self.root.after(30000, self._auto_refresh)  # 30초 간격

    def _load_data_status(self):
        """📂 데이터 저장 위치 + 수집 현황 표시 (계좌 탭 상단) - 종목별 저장 구조"""
        try:
            cp = db.get_data_collection_period()
            fi = db.get_data_files_info()
            mst = db.get_market_status()
            n_stock = db.stock_files_count()
            mode_txt = f"종목별 {n_stock}파일" if db.STOCK_DIR_SAVE else f"날짜별 {fi['count']}파일"
            txt = (f"📂 저장: {db.DATA_DIR}/ (일봉·분봉 {mode_txt} · 시세 {cp['snapshot_count']:,}건) "
                   f"+ trading.db(전략/거래) | 수집기간: "
                   f"{cp['start'] or '시작 전'} ~ {cp['end'] or '-'} | 최근수신: {mst['last_fetch'][:19] if mst['last_fetch'] else '-'}")
            self.data_status.config(text=txt)
        except Exception:
            pass

    def _alog(self, msg):
        """★ 2026-09-02 스레드 안전 작업로그 (사용자: "무거워서 멈춤" 수리 핵심)
        - 기존: 백그라운드 스레드(파일럿/수집/라운드)가 Tk 위젯을 직접 조작
          → Tkinter는 스레드 안전이 아님 → 간헐 멈춤/응답없음/충돌의 주원인
        - 수정: 모든 로그를 root.after(0)으로 UI 스레드에 위임 + 300줄 상한
          (밤새 켜두면 수만 줄 쌓여 렌더가 느려지는 문제도 함께 해결)
        """
        def _do():
            try:
                self.action_box.insert("1.0", msg)
                # 300줄 넘으면 오래된 것 잘라냄 (메모리/렌더 보호)
                try:
                    if float(self.action_box.index("end-1c").split(".")[0]) > 300:
                        self.action_box.delete("300.0", "end")
                except Exception:
                    pass
            except Exception:
                pass
        try:
            import threading as _th
            if _th.current_thread() is _th.main_thread():
                _do()
            else:
                self.root.after(0, _do)
        except Exception:
            pass

    def _load_stats(self):
        """대시보드 상태 갱신: 4팀 카드 + 상태 라벨 (간결)"""
        self._badge(self.badge_mock, f"서버: {'모의' if CFG.USE_MOCK else '실전'}",
                    "#79c0ff", "#16263a")
        self._badge(self.badge_dry, f"DRY_RUN: {'ON' if CFG.DRY_RUN else 'OFF'}",
                    GREEN if CFG.DRY_RUN else RED,
                    "#16301f" if CFG.DRY_RUN else "#3a1a1a")
        self._badge(self.badge_ai, f"AI: {CFG.AI_PROVIDER}", PURPLE, "#2b2240")

        # 시스템 상태 (서버/계좌/파일럿) - ★ 모의매매 실행 중이면 빨간 ● 표시
        try:
            pilot_running = getattr(self, "pilot_running", False)
            paper_active = pilot_running and getattr(self, "_paper_active", False)
            if pilot_running:
                if paper_active:
                    pilot_txt = "🔴 모의매매 실행 중"  # 빨간 ● = 지금 매매가 돌고 있음
                else:
                    pilot_txt = "🟢 자동 파일럿 운영 중"
            else:
                pilot_txt = "⚫ 자동 파일럿 중지"
            self.sys_status.config(
                text=f"🖥 시스템: {CFG.base_url} · 계좌 {CFG.ACCOUNT_NO or '-'} · {pilot_txt}")
        except Exception:
            pass

        # 데이터 수집 현황 (자료수집 팀 카드 + 상단 라벨)
        try:
            st = db.data_collection_stats()
            univ = st["universe"]
            pct = round(st["stock_files"] / univ * 100, 1) if univ else 0
            last_txt = f" · 마지막 {st['last_backfill']}" if st["last_backfill"] else ""
            txt = (f"종목 {st['stock_files']}/{univ}개 ({pct}%) · 일봉 {st['daily_bars']:,}봉 · "
                   f"분봉 {st['minute_bars']:,}봉 · {st['total_mb']}MB{last_txt}")
            if hasattr(self, "team_data"):
                self.team_data.config(text=txt)
            self.collect_period.config(text=f"📦 데이터 수집 현황: {txt}")
        except Exception:
            pass

        # 검증 팀 카드 (조건식 요약)
        try:
            import condition_manager as cm
            conds = cm.list_conditions_with_stats()
            active = [c for c in conds if c["status"] == "active"]
            buys = sum(c["stats"].get("buys", 0) for c in active)
            sells = sum(c["stats"].get("sells", 0) for c in active)
            if hasattr(self, "team_validate"):
                self.team_validate.config(
                    text=f"조건식 {len(active)}개 운영 · 매수 {buys} · 매도 {sells} · "
                         f"원형 {sum(1 for c in conds if '-' not in c['cond_no'])}개 · "
                         f"변형 {sum(1 for c in conds if '-' in c['cond_no'])}개")
        except Exception:
            pass

        # 모의매매 팀 카드 (성적 요약)
        try:
            import paper_test
            s = paper_test.paper_summary()
            if hasattr(self, "team_paper"):
                self.team_paper.config(
                    text=f"청산 {s['trades']}건 · 승률 {s['win_rate']}% · 손익비 {s['pf']} · "
                         f"보유 {s['open']} · 미실현 {s['unrealized_pnl']:+,}원 · 잔고 {s['cash']:,.0f}원")
        except Exception:
            pass

        # 총괄 팀 카드 (명예의 전당/마지막 라운드)
        try:
            hof = len(db.hof_list())                       # 상위 랭킹
            hof_total = len(db.hof_list(limit=100000, ranked_only=False))  # 전체 누적 이력
            last = ""
            try:
                import json as _json, os as _os
                st = _json.load(open(_os.path.join("strategy", "control_state.json"), encoding="utf-8"))
                last = f" · 마지막 {st.get('last_run_at','')[:16].replace('T',' ')}"
            except Exception:
                pass
            if hasattr(self, "team_control"):
                self.team_control.config(
                    text=f"명예의 전당 상위 {hof}건 · 이력 {hof_total}건 · "
                         f"퇴출 {len(db.retired_list(limit=100))}건{last}")
        except Exception:
            pass

        # 시세 수신 상태 + ★ 시장(지수) 상태
        try:
            mst = db.get_market_status()
            last = mst["last_fetch"]
            idx_txt = ""
            try:
                idx = db.get_index_summary()
                if idx:
                    parts = [f"{r['index_name']} {r['change_pct']:+.2f}%"
                             for r in idx if r.get("change_pct") is not None]
                    if parts:
                        idx_txt = " · 📊 " + " ".join(parts)
            except Exception:
                pass
            if last:
                self.market_status.config(
                    text=f"📡 시세: ✅ 최근 수신 {last[:19].replace('T',' ')} · "
                         f"스냅샷 {mst['snapshot_count']}건{idx_txt}")
            else:
                self.market_status.config(text=f"📡 시세: {mst['source']}{idx_txt}")
        except Exception:
            pass

        # ⚡ 브리지/스캘핑 상태 (하이브리드)
        _bridge_txt = ""
        try:
            import realtime_bridge as _rb
            _rb.connect()
            _bridge_txt = f" | {_rb.status_text()}"
        except Exception:
            pass
        self.status.config(text=f"모드: {CFG.base_url} | 계좌: {CFG.ACCOUNT_NO or '-'} | "
                                f"AI: {CFG.AI_PROVIDER}{_bridge_txt} | {now_kst():%Y-%m-%d %H:%M:%S}")

    def _load_engine_status(self):
        if not hasattr(self, 'eng_state'):
            return  # 엔진 상태 위젯 없음 - 스킵
        """매수/매도 판단 엔진 상태 표시 (전략 탭에서)"""
        try:
            import ai_judge
            st = ai_judge.engine_status()
            color = GREEN if st["use_llm"] else YELLOW
            b, s = st["buy"], st["sell"]
            self.eng_state.config(text=f"🧠 판단 엔진: {st['engine_label']}", foreground=color)
            self.buy_engine.config(text=f"매수={b['engine']}")
            self.sell_engine.config(text=f"매도={s['engine']}")
        except Exception as e:
            self.eng_state.config(text=f"판단 엔진 오류: {e}")

    def _load_real_panel(self):
        """💼 계좌 탭 현황 로드 - 새 위젯(tree_pos/tree_trades)에 위임
        (구버전 real_summary/tree_real 참조 제거 - 버전 불일치 방지)
        """
        try:
            self._load_positions()
        except Exception:
            pass
        try:
            self._load_trades()
        except Exception:
            pass
        # 계좌 잔고 요약 (예수금/평가) - pos_status에 함께 표시
        try:
            acc = db.get_account_summary()
            if isinstance(acc, dict) and acc.get("entr", 0) > 0:
                parts = [f"예수금 {acc['entr']:,.0f}원"]
                if acc.get("total_asset", 0) > 0:
                    parts.append(f"평가 {acc['total_asset']:,.0f}원")
                if acc.get("pnl") is not None:
                    parts.append(f"손익 {acc['pnl']:+,.0f}원")
                self.pos_status.config(text=" · ".join(parts))
        except Exception:
            pass

    def _on_conf_change(self, event=None):
        if not hasattr(self, 'conf_state'):
            return  # 신뢰도 상태 위젯 없음 - 스킵
        """신뢰도 기준 변경 → .env 저장 + 즉시 반영"""
        try:
            sel = self.conf_combo.get()
            pct = int(sel.replace("%", "").split(" ")[0])
            from config import CFG as _C
            _C.AI_BUY_CONFIDENCE_THRESHOLD = pct
            # .env에도 저장 (재시작 후 유지)
            try:
                env = _read_env_map()
                env["AI_BUY_CONFIDENCE_THRESHOLD"] = str(pct)
                _write_env_map(env)
                os.environ["AI_BUY_CONFIDENCE_THRESHOLD"] = str(pct)
            except Exception:
                pass
            self.conf_state.config(text=f"적용됨: {pct}% 이상만 매수", foreground=GREEN)
            self._set_status(f"🎯 매수 신뢰도 기준 {pct}% 적용")
        except Exception:
            pass

    def _show_holdings_eval(self):
        """🤖 보유 종목 AI 평가 창 (적정가/매수 위치/매도 제안)"""
        def worker():
            rows = []
            try:
                if CFG.DRY_RUN:
                    rows.append(("", "DRY_RUN 모드 - 실제 계좌 조회 안 됨 (.env에서 DRY_RUN=false 필요)", ""))
                else:
                    acc = db.get_account_summary()
                    if not isinstance(acc, dict) or acc.get("mock") or not acc.get("positions"):
                        rows.append(("", "계좌 연동 안 됨 - 키/계좌번호 확인 (모의/실전 키 일치 필요)", ""))
                    else:
                        from ai_consult import evaluate_holding_adv
                        for p in acc["positions"][:20]:
                            try:
                                e = evaluate_holding_adv(p.get("symbol", ""), {
                                    "entry_price": p.get("avg_price", 0) or 0,
                                    "qty": p.get("qty", 0) or 0,
                                    "name": p.get("name", "")})
                                if e:
                                    rows.append((e, "", ""))
                            except Exception:
                                continue
                        if not rows:
                            rows.append(("", "보유 종목 없음 (계좌에 종목이 없습니다)", ""))
            except Exception as ex:
                rows.append(("", f"평가 오류: {ex}", ""))
            self.root.after(0, lambda: self._show_holdings_eval_ui(rows))

        threading.Thread(target=worker, daemon=True).start()

    def _show_holdings_eval_ui(self, rows):
        """평가 결과 창 표시"""
        try:
            win = tk.Toplevel(self.root)
            win.title("🤖 보유 종목 AI 평가")
            win.configure(bg=BG)
            win.geometry("860x620")
            box = ttk.Frame(win, style="Card.TFrame", padding=10)
            box.pack(fill="both", expand=True)
            cap = ttk.Label(box, text="적정가 · 매수 위치 · 매도 제안 (로컬 일봉 + AI 판단)",
                            style="Muted.TLabel")
            cap.pack(anchor="w", pady=(0, 6))
            txt = RO_Text(box, height=30, bg="#0d1117", fg=MUTED,
                          font=("Consolas", 10), wrap="word", relief="flat")
            txt.pack(fill="both", expand=True)
            buf = []
            for e, _m, _x in rows:
                if e and isinstance(e, dict):
                    tech = e.get("tech") or {}
                    buf.append(f"■ {e.get('name')} ({e.get('symbol')}) · {e.get('qty', 0)}주")
                    buf.append(f"  평단가(매수 위치): {e.get('entry_price', 0):,.0f}원 · "
                               f"현재가 {e.get('price', 0):,.0f}원 · 수익률 {e.get('ret', 0):+.2f}%")
                    buf.append(f"  AI 판단: {e.get('verdict')} [{e.get('provider')}] - {e.get('reason', '')[:80]}")
                    buf.append(f"  적정가 판단: {tech.get('fair', '-')}  ({tech.get('fair_note', '')})")
                    buf.append(f"  매수 위치: {tech.get('entry_pos', '?')}  ({tech.get('entry_note', '')})")
                    buf.append(f"  매도 제안: 목표(저항) {tech.get('target', 0):,.0f}원 · "
                               f"손절(지지) {tech.get('stop', 0):,.0f}원")
                    if e.get("sell_plan"):
                        buf.append(f"  📌 매수 시 매도 지침[{e.get('plan_provider', 'rule')}]: "
                                   f"{e.get('sell_plan', '')[:100]}")
                    buf.append(f"  MA5/20/60: {tech.get('ma5') or '-':,.0f} / {tech.get('ma20') or '-':,.0f}"
                               f" / {tech.get('ma60') or '-':,.0f} · RSI {tech.get('rsi') or '-'}")
                    buf.append("")
                else:
                    buf.append(_m or _x or "")
                    buf.append("")
            txt.insert("1.0", "\n".join(buf) if buf else "평가 결과 없음")
        except Exception:
            pass

    def _on_pos_double_click(self, event):
        """종목 더블클릭 → 매도 확인창 → 개별 청산"""
        try:
            sel = self.tree_pos.selection()
            if not sel:
                return
            vals = self.tree_pos.item(sel[0], "values")
            symbol = vals[0]
            name = vals[1]
            qty = vals[2]
            if not messagebox.askyesno("종목 매도", f"{symbol} {name} {qty}주를 매도할까요?"):
                return

            def worker():
                try:
                    from engine import liquidate_symbol
                    ok = liquidate_symbol(symbol)
                    msg = f"✅ {symbol} {name} 매도 완료" if ok else f"⚠️ {symbol} 포지션 없음"
                except Exception as e:
                    msg = f"❌ 매도 실패: {e}"
                self.root.after(0, lambda: self._set_status(msg))
                self.root.after(0, self._refresh_live)

            threading.Thread(target=worker, daemon=True).start()
        except Exception:
            pass

    def _liquidate_all(self):
        """전체 포지션 청산 (확인창 후)"""
        n = len(_q("SELECT * FROM virtual_positions WHERE status='open'"))
        if n == 0:
            messagebox.showinfo("청산", "청산할 포지션이 없습니다")
            return
        if not messagebox.askyesno("전체 청산", f"보유 {n}개 포지션을 전부 매도할까요?\n(모의/실전이면 실제 매도 주문 나감)"):
            return

        def worker():
            try:
                from engine import liquidate_all
                closed = liquidate_all()
                msg = f"✅ 전체 청산 완료: {closed}개"
            except Exception as e:
                msg = f"❌ 전체 청산 실패: {e}"
            self.root.after(0, lambda: self._set_status(msg))
            self.root.after(0, self._refresh_live)

        threading.Thread(target=worker, daemon=True).start()


    def _load_positions(self):
        """💼 계좌 탭: 키움 계좌 실제 보유 종목만 표시 (자동매매 가상 기록 제외)
        - ★ 계좌 조회 결과를 60초 캐시 (화면 무거움 방지 - 10초 새로고침마다 API 호출 금지)
        - ★ 조회 실패/미연동 시: 가상 기록으로 대체하지 않고 "연동 실패" 명확 표시
          (실제 계좌와 무관한 내부 기록이 '보유 중'으로 보이는 오해 방지)
        """
        import time as _t
        now = _t.time()
        acc = None
        # 60초 캐시
        if getattr(self, "_acc_cache_t", 0) + 60 < now:
            try:
                if not CFG.DRY_RUN:
                    acc = db.get_account_summary()
                self._acc_cache = acc
                self._acc_cache_t = now
            except Exception:
                self._acc_cache = None
                self._acc_cache_t = now
        else:
            acc = getattr(self, "_acc_cache", None)

        account_positions = None
        linked = False
        if isinstance(acc, dict) and acc.get("positions"):
            account_positions = acc["positions"]
            linked = True
        elif isinstance(acc, dict) and acc.get("mock"):
            # 모의 기본값 응답 (키 없음/DRY_RUN) - 실제 계좌 아님
            linked = False
        # ★ 계좌 연동 실패 원인 (왜 보유 종목이 안 보이는지 명확히)
        acc_err = ""
        if isinstance(acc, dict) and acc.get("errors"):
            acc_err = " · ".join(str(e) for e in acc["errors"][:3])

        prices = {}
        if account_positions:
            # ★ 현재가는 키움 계좌 응답(cur_price)을 최우선 사용 (실시간·정확)
            #   기존: 내부 스냅샷(db.get_latest_price)만 사용 → 낡은/오염된 값으로
            #   수익률 +246%/-86% 같은 엉터리 표시 (사용자 보고 버그)
            for ap in account_positions:
                sym = ap.get("symbol", "")
                if not sym:
                    continue
                cur = ap.get("cur_price", 0) or 0
                if cur > 0:
                    prices[sym] = cur
                else:
                    p = db.get_latest_price(sym)
                    if p:
                        prices[sym] = p
        # ★ 계좌 미연동(실패/키없음) 시: 가상 기록으로 대체하지 않음 (오해 방지)
        #   account_positions=None 이면 아래에서 "연동 안 됨" 표시만

        agg = db.get_positions_aggregated(kind_filter=None, symbol_prices=prices,
                                          account_positions=account_positions,
                                          account_only=True)  # 💼 계좌: 실제 보유만

        self.tree_pos.delete(*self.tree_pos.get_children())
        # ★ 계좌 연동 상태 표시 (실제 주문 확인용) - 실패 시 원인까지
        if not CFG.DRY_RUN and account_positions is not None and not linked:
            if acc_err:
                self.pos_status.config(
                    text=f"⚠️ 계좌 연동 실패: {acc_err} (키/계좌번호/서버 확인)", foreground=RED)
            else:
                self.pos_status.config(
                    text="⚠️ 계좌 연동 실패/빈 응답 - 키/계좌번호 확인 (실제 보유 조회 불가)", foreground=RED)
        elif CFG.DRY_RUN:
            self.pos_status.config(
                text="DRY_RUN 모드 - 실제 주문/계좌 연동 안 됨 (손매수 종목도 안 보임) .env에서 DRY_RUN=false 필요",
                foreground=YELLOW)
        total_eval = 0
        n_real = 0
        for a in agg:
            nm = a["name"]
            ret = a["pnl_pct"]
            ret_txt = f"{ret:+.2f}%" if ret is not None else "-"
            cur_txt = f"{a['cur_price']:,.0f}" if a["cur_price"] else "-"
            self.tree_pos.insert("", "end", values=(
                a["symbol"], nm, a["qty"],
                f"{a['avg_price']:,.0f}", cur_txt,
                f"{a['eval_amt']:,.0f}", f"{a['pnl']:+,.0f}", ret_txt))
            if ret is not None:
                iid = self.tree_pos.get_children()[-1]
                self.tree_pos.tag_configure(f"pr_{'p' if ret >= 0 else 'n'}",
                                            foreground=GREEN if ret >= 0 else RED)
                self.tree_pos.item(iid, tags=(f"pr_{'p' if ret >= 0 else 'n'}",))
            total_eval += a["eval_amt"]
            if a["kind"] in ("모의", "실전", "혼합"):
                n_real += 1
        # 건수 + 총 매수금액 표시 (계좌 실제 보유 기준)
        try:
            self.pos_status.config(
                text=f"계좌 보유 {len(agg)}종목 · 매수금액 {total_eval:,.0f}원 · {now_kst():%H:%M:%S}")
        except Exception:
            self.pos_status.config(text=f"계좌 보유 {len(agg)}종목")

    def _load_trades(self):
        # 💼 실제 매매 탭: 모의실전 주문(paper_positions) 표시
        #   - 실제 주문(DRY_RUN=false)이 나가면 여기 기록으로 확인 가능
        #   - 열: id/코드/종목명/방향/가격/유형/시각
        try:
            rows = _q("SELECT * FROM paper_positions ORDER BY id DESC LIMIT 30")
        except Exception:
            rows = []
        self.tree_trades.delete(*self.tree_trades.get_children())
        for r in rows:
            t = (r.get("entry_time") or r.get("exit_time") or "")[:19]
            if r.get("status") == "open":
                side, price = "매수", r.get("entry_price") or 0
            else:
                side, price = "청산", r.get("exit_price") or r.get("entry_price") or 0
            nm = db.get_symbol_name(r.get("symbol", ""))
            # ★ 유형 구분: 수동매수/검증통과/검증예약/신호 (검증과 실제 매매가 섞여 보이지 않게)
            kind = db.paper_kind_label(r.get("cond_key", ""), r.get("cond_txt", ""))
            self.tree_trades.insert("", "end", values=(
                r["id"], r.get("symbol", ""), nm, side, f"{price:,.0f}", kind, t))
        # 실제 주문 확인 요약
        if CFG.DRY_RUN:
            note = f"{len(rows)}건 (DRY_RUN - 주문 생략)"
        else:
            open_n = _q("SELECT COUNT(*) c FROM paper_positions WHERE status='open'")[0]["c"] if rows else 0
            note = f"{len(rows)}건 (실제 모의주문 진행 중 · 보유 {open_n})"
        try:
            self.trade_status.config(text=note)
        except Exception:
            self.trade_status.config(text=f"{len(rows)}건")

    # ==========================================================
    # 손익분석
    # ==========================================================
    def _load_pnl(self):
        period_map = {"1일": 1, "7일": 7, "30일": 30, "전체": None}
        days = period_map.get(self.pnl_period.get(), 7)
        try:
            pnl = db.analyze_pnl(days=days)
        except Exception as e:
            self.pnl_summary.config(text=f"손익 분석 오류: {e}")
            return
        s = pnl["summary"]
        pf = s.get("profit_factor", 0)
        pf_txt = f"손익비(PF) {pf}" + (" ✅" if pf >= 1 else " ⚠️")
        self.pnl_summary.config(
            text=f"손익 요약 [{s['period_days']}일]: 거래 {s['trades']}건 · 승률 {s['win_rate']}% · "
                 f"평균 {s['avg_return']}% · 총손익 {_fmt_pnl(s['total_pnl'])} · "
                 f"{pf_txt} · 평균익절 {_fmt_pnl(s.get('avg_win', 0))} / 평균손절 {_fmt_pnl(s.get('avg_loss', 0))}")

        for key, title in [("per_strategy", "전략"), ("per_day", "일"), ("per_symbol", "종목")]:
            tr = self.pnl_trees[key]
            tr.delete(*tr.get_children())
            bucket = pnl[key]
            if key == "per_day":
                items = sorted(bucket.items(), key=lambda x: x[0], reverse=True)
            else:
                items = sorted(bucket.items(), key=lambda x: -x[1]["pnl"])
            for k, b in items[:15]:
                # 종목별은 "코드 종목명" 형태로 이미 변환됨
                key_txt = k
                tr.insert("", "end", values=(key_txt, b["trades"], f"{b['win_rate']:.0f}",
                                             f"{b['avg_return']:.2f}", _fmt_pnl(b["pnl"])))

    def _on_pnl_day_click(self, event, key):
        """일별 탭에서 날짜 선택 → 그날 상세 표시"""
        try:
            sel = self.pnl_trees[key].selection()
            if not sel:
                return
            date_str = self.pnl_trees[key].item(sel[0], "values")[0]
            self._load_daily_detail(date_str)
        except Exception:
            pass

    def _load_daily_detail(self, target_date):
        """특정 날짜의 매수/매도/수익률/손익 상세"""
        try:
            det = db.get_daily_pnl_detail(target_date)
            self.pnl_detail_title.config(text=f"📅 {det['date']} 상세")
            sm = det["summary"]
            self.pnl_detail_summary.config(
                text=f"거래 {sm['trades']}건 · 청산 {sm['closed']}건 · "
                     f"승률 {sm['win_rate']}% · 손익 {_fmt_pnl(sm['total_pnl'])}")
            # 거래 내역
            self.pnl_detail_trades.delete(*self.pnl_detail_trades.get_children())
            for t in det["trades"][:50]:
                side = "매수" if t["side"] == "buy" else "매도"
                kind = {"virtual": "가상", "mock_real": "모의", "live_real": "실전"}.get(t["kind"], t["kind"])
                self.pnl_detail_trades.insert("", "end", values=(
                    t["time"], t["symbol"], t["name"], side,
                    f"{t['price']:,.0f}", t["qty"], kind, f"{t['amount']:,.0f}"))
            # 청산 결과
            self.pnl_detail_closed.delete(*self.pnl_detail_closed.get_children())
            for c in det["closed"]:
                ret = c["ret_pct"]
                ret_txt = f"{ret:+.2f}%"
                kind = {"virtual": "가상", "mock_real": "모의", "live_real": "실전"}.get(c["kind"], c["kind"])
                self.pnl_detail_closed.insert("", "end", values=(
                    c["symbol"], c["name"], f"{c['entry']:,.0f}", f"{c['exit']:,.0f}",
                    c["qty"], ret_txt, _fmt_pnl(c["pnl"]), kind))
                if ret is not None:
                    iid = self.pnl_detail_closed.get_children()[-1]
                    self.pnl_detail_closed.tag_configure(f"dc_{'p' if ret >= 0 else 'n'}",
                                                         foreground=GREEN if ret >= 0 else RED)
                    self.pnl_detail_closed.item(iid, tags=(f"dc_{'p' if ret >= 0 else 'n'}",))
        except Exception as e:
            self.pnl_detail_title.config(text=f"상세 오류: {e}")

    # ==========================================================
    # 시세 아카이브
    # ==========================================================
    def _load_archive(self):
        period_map = {"1주": 168, "1달": 720, "3달": 2160, "전체": None}
        try:
            hours = period_map.get(self.archive_period.get(), 720)
        except Exception:
            hours = 720
        try:
            rep = db.build_weekly_report(hours=hours)
        except Exception as e:
            self.archive_summary.config(text=f"오류: {e}")
            return
        label = f"최근 {hours//24}일" if hours else "전체 기간"
        self.archive_summary.config(text=f"{label}: 스냅샷 {rep['summary']['samples']}건 · "
                                         f"종목 {rep['summary']['symbol_count']}개")
        self.tree_archive.delete(*self.tree_archive.get_children())
        for s in rep["symbols"]:
            self.tree_archive.insert("", "end", values=(
                s["symbol"], s["samples"], f"{s['first']:,.0f} → {s['last']:,.0f}",
                f"{s['change_pct']:+.2f}", f"{s['high']:,.0f}", f"{s['low']:,.0f}",
                f"{s['chegyul_avg']:.0f}", f"{s['chegyul_last']:.0f}",
                s["rsi_last"] if s["rsi_last"] is not None else "-"))
        self._set_text(self.report_text, rep["text"])

    def _load_minute_summary(self):
        """📊 분봉 요약: 관심/보유 종목의 최근 분봉 (네이버 백필 데이터)"""
        try:
            rows = db.get_minute_summary(days=7)
            if not rows:
                self.archive_summary.config(text="분봉 데이터 없음 (백필 시 자동 수집)")
                self._set_text(self.report_text, "분봉 데이터가 없습니다.\n"
                                                "프로그램을 켜두면 관심/보유 종목 분봉이 자동 백필됩니다.\n")
                return
            lines = ["📈 분봉 요약 (최근 7거래일 · 관심/보유 종목)",
                     "=" * 52, ""]
            for s in rows[:20]:
                chg = (s["last_price"] - s["low"]) / s["low"] * 100 if s["low"] else 0
                lines.append(f"[{s['symbol']} {s['name']}] 분봉 {s['bars']}개 "
                             f"({s['start']} ~ {s['end']})")
                lines.append(f"   고가 {s['high']:,.0f} / 저가 {s['low']:,.0f} / "
                             f"최근 {s['last_price']:,.0f} · 거래량 {s['volume_sum']:,.0f}")
            self.archive_summary.config(text=f"분봉 {len(rows)}종목")
            self._set_text(self.report_text, "\n".join(lines))
        except Exception as e:
            self.archive_summary.config(text=f"분봉 요약 오류: {e}")

    # ==========================================================
    # 프롬프트
    # ==========================================================
    def _save_prompts(self):
        """저장 전 자동 백업 (prompts/backup/) → 덮어쓰기 → 즉시 반영"""
        import shutil
        backup_dir = "prompts/backup"
        try:
            os.makedirs(backup_dir, exist_ok=True)
            ts = now_kst().strftime("%Y%m%d_%H%M%S")
            for src in (BUY_PROMPT_PATH, SELL_PROMPT_PATH):
                if os.path.exists(src):
                    shutil.copy2(src, os.path.join(backup_dir, f"{os.path.basename(src)}.{ts}"))
        except Exception:
            pass
        ok1 = _write_prompt(BUY_PROMPT_PATH, self.prompt_txt_buy.get("1.0", "end").strip())
        ok2 = _write_prompt(SELL_PROMPT_PATH, self.prompt_txt_sell.get("1.0", "end").strip())
        messagebox.showinfo("저장", "✅ 프롬프트 저장 완료 (백업: prompts/backup/)"
                            if ok1 and ok2 else "❌ 저장 실패")

    def _reload_prompt_files(self):
        self.prompt_txt_buy.delete("1.0", "end")
        self.prompt_txt_buy.insert("1.0", _read_prompt(BUY_PROMPT_PATH, "[매수 조건]..."))
        self.prompt_txt_sell.delete("1.0", "end")
        self.prompt_txt_sell.insert("1.0", _read_prompt(SELL_PROMPT_PATH, "[매도 조건]..."))
        self.status.config(text="프롬프트 파일에서 다시 불러왔습니다")

    def _ai_review_prompts(self):
        buy = self.prompt_txt_buy.get("1.0", "end").strip()
        sell = self.prompt_txt_sell.get("1.0", "end").strip()

        def worker():
            self._set_status("🤖 AI가 매수/매도 프롬프트를 검토 중... (수십 초 걸릴 수 있음)")
            try:
                import ai_consult
                result = ai_consult.review_prompts(buy, sell)
            except Exception as e:
                result = f"검토 실패: {e}"
            self.root.after(0, lambda: self._show_review_result(result))

        threading.Thread(target=worker, daemon=True).start()

    def _show_review_result(self, result):
        # 컨설턴트 탭으로 이동해 결과 표시
        self.nb.select(self.consult_tab_index)
        self._append_consult("\n" + "=" * 50 + "\n📝 AI 프롬프트 기준 검토 결과\n" + "=" * 50 + "\n" + result + "\n")

    # ==========================================================
    # AI 컨설턴트
    # ==========================================================
    def _update_consult_status(self):
        try:
            from ai_consult import _provider
            p = _provider()
            if p == "gemini":
                txt = "✅ Gemini 연결됨 (무료 티어)"
                color = GREEN
            elif p == "openai":
                txt = "✅ GPT 연결됨"
                color = GREEN
            else:
                txt = "⚠️ 규칙 기반 모드 - Gemini/GPT 키 미설정 (설정 탭에서 추가)"
                color = YELLOW
        except Exception:
            txt, color = "규칙 기반", MUTED
        self.consult_status.config(text=txt, foreground=color)

    def _append_consult(self, text):
        self.consult_out.append(text + "\n")

    def _consult_preset(self, kind):
        if kind == "index_time":
            try:
                import ai_consult
                res = ai_consult.analyze_index_time()
                self._append_consult(f"[⏰ 지수×시간대 분석 ({res['provider']})]\n{res['text']}\n")
                self._set_status("⏰ 지수×시간대 분석 완료")
            except Exception as e:
                self._append_consult(f"[⏰ 지수×시간대 분석 오류] {e}\n")
            return

        def worker():
            self.stop_flag = False
            self._set_status(f"AI 처리 중: {kind} ...")
            try:
                import ai_consult
                # AI 키 없으면 바로 안내 (무한 대기 방지)
                avail = ai_consult.is_ai_available()
                if not avail["available"]:
                    result = ("⚠️ " + avail["msg"] +
                              "\n\n지금은 [규칙 기반]으로 결과를 제공합니다. "
                              "설정 탭에서 GEMINI_API_KEY 를 넣으면 진짜 Gemini가 답합니다.")
                elif kind == "prompts":
                    buy = _read_prompt(BUY_PROMPT_PATH, "")
                    sell = _read_prompt(SELL_PROMPT_PATH, "")
                    result = ai_consult.review_prompts(buy, sell)
                elif kind == "analyze":
                    result = ai_consult.analyze_strategies()
                elif kind == "evolve":
                    result = ai_consult.recommendation()
                elif kind == "risk":
                    result = ai_consult.risk_check()
                elif kind == "report":
                    rep = db.build_weekly_report(hours=720)
                    result = rep["text"]
                elif kind == "buy_review":
                    result = ai_consult.review_buy_results()
                else:
                    result = ""
            except Exception as e:
                import traceback
                result = f"처리 실패:\n{traceback.format_exc()}"
            self.root.after(0, lambda r=result, k=kind: self._show_consult_result(k, r))

        threading.Thread(target=worker, daemon=True).start()

    def _show_consult_result(self, kind, result):
        label = {"prompts": "📝 프롬프트 검토", "analyze": "📊 전략 분석",
                 "evolve": "🧬 세대교체 추천", "risk": "⚠️ 리스크 점검",
                 "report": "📈 주간 리포트",
                 "buy_review": "🔁 매수결과 리뷰"}.get(kind, kind)
        advisory = ("\n\n────────────────────────\n"
                    "⚠️ [참고용] 이 내용은 자동 적용되지 않습니다.\n"
                    "실제 반영하려면 📝 프롬프트 탭에서 직접 수정 후 저장하세요.\n"
                    "(저장 시 자동 백업되므로 되돌릴 수 있습니다)")
        self._append_consult(f"\n{'='*50}\n{label}\n{'='*50}\n{result}{advisory}")
        self._set_status("AI 처리 완료 (참고용 - 자동 적용 안 됨)")

    def _analyze_symbol_btn(self):
        """종목 분석 (검증마스터 유사) - 편입 데이터 + AI 분석"""
        sym = self.sym_input.get().strip()
        if not sym:
            return
        self._append_consult(f"\n🔍 종목 분석 요청: {sym}")
        self._set_status(f"🔍 {sym} 분석 중...")

        def worker():
            try:
                import ai_consult
                result = ai_consult.analyze_symbol(sym)
            except Exception as e:
                import traceback
                result = f"분석 오류:\n{traceback.format_exc()}"
            self.root.after(0, lambda: self._append_consult(result))
            self.root.after(0, lambda: self._set_status("종목 분석 완료"))

        threading.Thread(target=worker, daemon=True).start()

    def _send_consult(self):
        q = self.consult_input.get().strip()
        if not q:
            return
        self.consult_input.delete(0, "end")
        self._append_consult(f"\n[나] {q}")

        def worker():
            self.stop_flag = False
            self._set_status("🤖 AI 응답 중... (⏹ 중지 버튼으로 취소 가능)")
            try:
                import ai_consult
                avail = ai_consult.is_ai_available()
                if not avail["available"]:
                    result = ("⚠️ " + avail["msg"] +
                              "\n[규칙 기반]으로 답합니다. Gemini를 쓰려면 설정 탭에서 "
                              "GEMINI_API_KEY 를 입력 후 저장하세요.")
                else:
                    result = ai_consult.ask(q)
            except Exception as e:
                import traceback
                result = f"오류:\n{traceback.format_exc()}"
            if self.stop_flag:
                result = "⏹ 사용자에 의해 중지됨"
            advisory = ("\n\n────────────────────────\n"
                        "⚠️ [참고용] AI 답변은 자동 적용되지 않습니다.\n"
                        "적용하려면 📝 프롬프트 탭에서 직접 수정 후 저장하세요.")
            self.root.after(0, lambda: self._append_consult(f"[AI] {result}{advisory}"))
            self.root.after(0, lambda: self._set_status("AI 응답 완료 (참고용)"))

        threading.Thread(target=worker, daemon=True).start()

    # ==========================================================
    # 설정
    # ==========================================================
    def _save_settings(self):
        values = {}
        types = {k: t for k, _l, t in ENV_FIELDS}
        bad = []
        for key, var in self.env_vars.items():
            if isinstance(var, tk.BooleanVar):
                values[key] = "true" if var.get() else "false"
            else:
                v = var.get().strip()
                # ★ 2026-09-02 빈/불량 숫자 저장 금지 (사고: 'KEY=' 빈 값 저장
                #   → int('') → 앱이 시작조차 못 함). 숫자 칸이 비면 저장에서 제외.
                t = types.get(key, "str")
                if t in ("int", "float"):
                    if v == "":
                        bad.append(f"{key} (빈 칸)")
                        continue
                    try:
                        int(v) if t == "int" else float(v)
                    except Exception:
                        bad.append(f"{key} (숫자 아님: {v[:10]})")
                        continue
                values[key] = v
        if bad:
            messagebox.showwarning(
                "설정 저장", "⚠️ 아래 항목은 숫자가 아니라서 저장하지 않았습니다\n"
                "(기존 값 유지):\n\n" + "\n".join(bad[:8]))
        if _write_env_map(values):
            _apply_to_cfg(values)
            self._update_consult_status()
            messagebox.showinfo("설정 저장", "✅ .env 저장 + 즉시 반영 완료")
            # ★ 2026-09-02: 저장 직후 전체 갱신(무거움) 대신 가벼운 배지만 갱신
            #   (전체 갱신은 30초 자동 주기가 처리 - "설정 바꿀 때마다 멈춤" 수리)
            try:
                self._load_stats()
            except Exception:
                pass
        else:
            messagebox.showerror("설정 저장", "❌ .env 저장 실패")

    # ==========================================================
    # 테스트 · 백테스트
    # ==========================================================
    def _run_test(self, kind, btn=None):
        # ★ 버튼 눌림 피드백: 실행 중 = 비활성 + 노란색
        self._pending_btn = btn
        if btn is not None:
            try:
                btn.config(state="disabled", style="Running.TButton")
            except Exception:
                pass
        def worker():
            self.stop_flag = False
            self._set_status(f"▶ {kind} 실행 중 ...")
            try:
                import traceback as tb
                import backtest
                if kind == "self":
                    result = _capture(backtest.self_test)
                    ok = bool(result)
                elif kind == "hof":
                    # ★ 명예의 전당 랭킹 뷰어 (상위 50 + 누적 이력)
                    try:
                        rk = db.hof_rank(limit=50)
                        lines = [f"🏆 명예의 전당 상위 {rk['ranked']}건 · 누적 이력 {rk['total']}건 · "
                                 f"중복 {rk['deduped']}건 제외", "=" * 64]
                        rows = db.hof_list(limit=50, ranked_only=True)
                        for i, h in enumerate(rows, 1):
                            lines.append(
                                f"{i:>2}. {h['cond_txt'][:50]} | 승률 {h['best_win_rate']:.0f}% "
                                f"| 손익비 {h['best_pf']:.2f} | 샘플 {h['sample_count']}회 "
                                f"| 점수 {h.get('score', 0):.0f}")
                        if not rows:
                            lines.append("아직 상위 랭킹이 없습니다.")
                            lines.append("입성 조건: 매도 3건 이상 + 승률 50% 이상 (모의 매매 성적 기준)")
                        result, ok = "\n".join(lines), True
                    except Exception as e:
                        result, ok = f"명예의 전당 조회 오류: {e}", False
                elif kind == "photo_validate":
                    # ★📷 사진 검색식 21개 엄밀 검증 (일자별 지원) - '사진으로 남긴 검색식' 검증
                    try:
                        import validation
                        try:
                            v_start = self.v_start.get().strip() or None
                            v_end = self.v_end.get().strip() or None
                            v_syms = int(self.v_syms.get().strip() or "100")
                        except Exception:
                            v_start = v_end = None
                            v_syms = 100
                        range_txt = f" · 기간 {v_start or '시작'}~{v_end or '최근'} · 종목 {v_syms}개"
                        import photo_conditions
                        tpls = photo_conditions.PHOTO_TEMPLATES
                        results = []
                        for t in tpls:
                            try:
                                slots = photo_conditions.template_slots(t)
                                tf = t.get("tf", "day")
                                # ★ 봉 기준 표시 (사진 조건식 [일]/[주]/[월]/[분])
                                tf_txt = {"day": "[일]", "week": "[주]", "month": "[월]",
                                          "min1": "[1분]", "min3": "[3분]", "min15": "[15분]"}.get(tf, "")
                                r = validation.validate_condition(
                                    {"cond_key": f"사진{t['photo']}", "cond_txt": f"{tf_txt} {t['name']}",
                                     "slots": slots},
                                    max_symbols=max(20, min(v_syms, 2000)),
                                    start=v_start, end=v_end)
                                r["photo"] = t["photo"]
                                r["tf"] = tf
                                results.append(r)
                            except Exception as e:
                                results.append({"photo": t["photo"], "txt": t["name"],
                                                "grade": "기각", "stats": {}, "note": f"오류 {e}"})
                        order = {"채택 후보": 0, "조건부": 1, "수익만": 2, "기각": 3}
                        results.sort(key=lambda r: (order.get(r.get("grade", "기각"), 9),
                                                    -(r.get("stats") or {}).get("percentile", 0)))
                        lines = [f"📷 사진 검색식 21개 엄밀 검증{range_txt}", "=" * 64]
                        for r in results:
                            st = r.get("stats") or {}
                            tf_txt = {"day": "[일]", "week": "[주]", "month": "[월]",
                                      "min1": "[1분]", "min3": "[3분]", "min15": "[15분]"}.get(r.get("tf"), "")
                            lines.append(f"[사진{r.get('photo')}]{tf_txt} {r.get('txt','')[:36]} → {r.get('grade','기각')}"
                                         f" | 매매{st.get('trades',0)}건 승률{st.get('win_rate',0)}% "
                                         f"백분위{st.get('percentile',0)}%")
                        result, ok = "\n".join(lines), True
                    except Exception as e:
                        result, ok = f"사진 검색식 검증 오류: {e}", False
                elif kind == "validation":
                    # ★🎯 엄밀 검증 (지수 대비 + 무작위 대조군 + 등급) - ★ 일자별/종목수 선택 지원
                    try:
                        import validation
                        # 입력값 읽기 (빈칸=전체)
                        try:
                            v_start = self.v_start.get().strip() or None
                            v_end = self.v_end.get().strip() or None
                            v_syms = int(self.v_syms.get().strip() or "100")
                        except Exception:
                            v_start = v_end = None
                            v_syms = 100
                        range_txt = f" · 기간 {v_start or '시작'}~{v_end or '최근'} · 종목 {v_syms}개"
                        res = validation.validate_active_conditions(
                            max_symbols=max(20, min(v_syms, 2000)), start=v_start, end=v_end)
                        lines = [f"🎯 엄밀 검증 ({res['total']}개 조건식 · 등급순){range_txt}",
                                 "    " + " · ".join(f"{g} {n}" for g, n in res["summary"].items()),
                                 "=" * 64]
                        for r in res["results"]:
                            lines.append(validation.format_result(r))
                            lines.append("-" * 60)
                        result, ok = "\n".join(lines), True
                    except Exception as e:
                        result, ok = f"엄밀 검증 오류: {e}", False
                else:
                    result, ok = "", True
            except Exception as e:
                import traceback
                result, ok = f"테스트 오류:\n{traceback.format_exc()}", False
            self.root.after(0, lambda r=result, o=ok, k=kind: self._show_test_result(k, r, o))

        threading.Thread(target=worker, daemon=True).start()

    def _show_test_result(self, kind, result, ok):
        # ★ 버튼 완료 피드백: 원래 스타일로 복원
        btn = getattr(self, "_pending_btn", None)
        self._pending_btn = None
        if btn is not None:
            try:
                btn.config(state="normal", style="Done.TButton")
                btn.after(1200, lambda: btn.config(style="Run.TButton" if btn.cget("style") == "Done.TButton" else btn.cget("style")))
            except Exception:
                pass
        label = {"self": "자체 점검", "hof": "명예의 전당",
                 "control_round": "총괄 라운드", "team_data": "자료수집 팀",
                 "team_validate": "검증 팀", "team_paper": "모의매매 팀"}.get(kind, kind)
        txt = result if isinstance(result, str) else str(result)
        self._set_text(self.test_out, f"=== {label} ===\n\n{txt}")
        self._set_status(f"{label} 완료")
        self._load_pnl()
        self._load_archive()

    def _update_bt_date_state(self):
        if not hasattr(self, 'bt_date'):
            return  # 백테스트 날짜 위젯 없음 - 스킵
        """입력 날짜가 거래일인지 즉시 표시"""
        try:
            from db import is_trading_day, prev_trading_day
            d = self.bt_date.get().strip()
            if not d:
                return
            from datetime import date as _d
            _d.fromisoformat(d)  # 형식 검증
            if is_trading_day(d):
                self.bt_date_state.config(text="✅ 거래일", foreground=GREEN)
            else:
                prev = prev_trading_day(d)
                self.bt_date_state.config(
                    text=f"⚠️ 비거래일(주말/공휴일) → {prev}로 자동 보정", foreground=YELLOW)
        except Exception:
            self.bt_date_state.config(text="형식: YYYY-MM-DD", foreground=MUTED)

    def _paper_loop(self):
        """모의 실전 루프: 장중 정각(3분)마다 진입/청산 체크"""
        import time as _t
        from engine import next_watch_time
        import paper_test
        period = max(1, int(getattr(CFG, "WATCH_PERIOD_MINUTES", 3)))
        while self.paper_running:
            try:
                nxt = next_watch_time(period=period)
                wait_s = max(1, int((nxt - now_kst()).total_seconds()))
                waited = 0
                while waited < wait_s and self.paper_running:
                    _t.sleep(min(wait_s - waited, 60))
                    waited += 60
                if not self.paper_running:
                    break
                now = now_kst()
                if 9 <= now.hour < 15 or (now.hour == 15 and now.minute <= 30):
                    self._alog(f"[{now_kst():%H:%M:%S}] 🔄 모의 실전 사이클\n")
                    r = paper_test.run_paper_once()
                    if r["entered"]:
                        self._alog(f"[{now_kst():%H:%M:%S}]   진입 {len(r['entered'])}건\n")
                    if r["exited"]:
                        exited_txt = ", ".join(e["symbol"] + " " + format(e["ret"], "+.1f") + "%" for e in r["exited"][:5])
                        self._alog(f"[{now_kst():%H:%M:%S}]   청산 {len(r['exited'])}건 ({exited_txt})\n")
                    self.root.after(0, self._refresh_live)
            except Exception as e:
                import traceback
                self._alog(f"[{now_kst():%H:%M:%S}] ❌ 모의 실전 오류: {e}\n")
                for _ in range(30):
                    if not self.paper_running:
                        break
                    _t.sleep(1)
        self.root.after(0, lambda: self.paper_btn.config(text="🖥 모의 실전 (상위 조건식 자동)"))

    def _load_conditions(self):
        """🧪 조건식 성적표 (원형+변형 · 전 종목 스캔 기준)"""
        try:
            import condition_manager as cm
            rows = cm.list_conditions_with_stats()   # ★ retired(폐기)는 기본 제외 (2026-09-01)
            self.tree_cond.delete(*self.tree_cond.get_children())
            n_active = n_back = 0
            for c in rows:
                st = c["stats"]
                st_txt = {"active": "운영", "backlog": "대기", "retired": "폐기"}.get(c["status"], c["status"])
                if c["status"] == "active":
                    n_active += 1
                else:
                    n_back += 1
                self.tree_cond.insert("", "end", values=(
                    c["cond_no"], c["cond_txt"][:60],
                    st.get("buys", 0), st.get("sells", 0),
                    f"{st.get('profit', 0):,}", f"{st.get('loss', 0):,}",
                    f"{st.get('net', 0):+,}", f"{st.get('win_rate', 0):.0f}%", st_txt))
            # ★ 폐기(퇴출)는 목록에서 숨기고 개수만 표시 (복구는 revive_retired.py)
            try:
                n_ret = len(db.get_conditions(status="retired"))
            except Exception:
                n_ret = 0
            _ret_txt = f" · 🗑 폐기 {n_ret}개 숨김" if n_ret else ""
            self.cond_summary.config(
                text=f"운영 {n_active} · 대기 {n_back}{_ret_txt} · {now_kst():%H:%M:%S}")
        except Exception:
            pass

    def _on_cond_click(self):
        """🧪 조건식 클릭 → 그 조건식이 매수한 종목 목록 + 차트 보기"""
        try:
            sel = self.tree_cond.selection()
            if not sel:
                return
            no = self.tree_cond.item(sel[0], "values")[0]
            import condition_manager as cm
            conds = cm.list_conditions_with_stats()
            c = next((x for x in conds if x["cond_no"] == no), None)
            if not c:
                return
            ledger = cm.ledger(c["id"])
            if not ledger:
                messagebox.showinfo("조건식", f"{no}번: 아직 매수 종목이 없습니다.")
                return
            win = tk.Toplevel(self.root)
            win.title(f"🧪 {no}번 조건식 매수 종목 ({len(ledger)}종목)")
            win.configure(bg=BG)
            win.geometry("720x520")
            box = ttk.Frame(win, style="Card.TFrame", padding=8)
            box.pack(fill="both", expand=True)
            tree = ttk.Treeview(box, columns=("sym", "name", "entry", "qty", "ret", "status"),
                                show="headings")
            for col, h, w in [("sym", "코드", 70), ("name", "종목명", 140), ("entry", "진입가", 95),
                              ("qty", "수량", 45), ("ret", "수익률", 75), ("status", "상태", 60)]:
                tree.heading(col, text=h)
                tree.column(col, width=w, anchor="center" if col != "name" else "w")
            for l in ledger:
                ret_txt = f"{l['ret']:+.2f}%" if l["ret"] is not None else "-"
                st_txt = "보유" if l["status"] == "open" else "청산"
                tree.insert("", "end", values=(l["symbol"], l["name"], f"{l['entry']:,.0f}",
                                               l["qty"], ret_txt, st_txt))
            tree.pack(fill="both", expand=True, pady=(0, 6))
            ttk.Label(box, text="종목 더블클릭 → 매수타점 차트 보기", style="Muted.TLabel").pack(anchor="w")

            def _chart_from_tree(t):
                try:
                    s = t.selection()
                    if not s:
                        return
                    sym = t.item(s[0], "values")[0]
                    import charting
                    p = charting.draw_candle_chart(sym, days=60)
                    self._display_chart(p, sym)
                except Exception as ex:
                    messagebox.showerror("차트", str(ex))
            tree.bind("<Double-1>", _chart_from_tree)
        except Exception:
            pass

    def _show_chart(self):
        """📈 매수타점 차트 생성 + 새 창에 표시"""
        sym = self.chart_sym.get().strip()
        if not sym:
            return
        def worker():
            import charting
            path = charting.draw_candle_chart(sym, days=60)
            self.root.after(0, lambda: self._display_chart(path, sym))
        self._set_status(f"📈 {sym} 차트 생성 중...")
        threading.Thread(target=worker, daemon=True).start()

    def _display_chart(self, path, sym):
        if not path:
            messagebox.showinfo("차트", f"{sym}: 일봉 데이터 부족\n'📥 데이터 수집' 버튼으로 백필 후 다시 시도.")
            return
        try:
            from PIL import ImageTk, Image
            win = tk.Toplevel(self.root)
            win.title(f"📈 {sym} 매수타점 차트")
            win.configure(bg=BG)
            img = Image.open(path)
            # 화면에 맞게 축소 (너무 크면)
            max_w, max_h = 1280, 800
            if img.width > max_w or img.height > max_h:
                ratio = min(max_w / img.width, max_h / img.height)
                img = img.resize((int(img.width * ratio), int(img.height * ratio)), Image.LANCZOS)
            photo = ImageTk.PhotoImage(img)
            lbl = ttk.Label(win, image=photo)
            lbl.image = photo
            lbl.pack(padx=8, pady=8)
            ttk.Label(win, text=f"저장: {path} · 이 PNG를 채팅에 올리면 AI가 설명/변경 제안",
                      style="Muted.TLabel").pack(pady=(0, 8))
            ttk.Button(win, text="🤖 AI 설명", command=lambda: self._chart_ai(win)).pack(pady=(0, 10))
        except Exception as e:
            messagebox.showerror("차트", f"차트 표시 오류: {e}")

    def _chart_ai(self, win=None):
        """🤖 AI가 차트 데이터 해석 (새 창에 표시)"""
        sym = self.chart_sym.get().strip()
        if not sym:
            return
        target = win
        def worker():
            import ai_consult
            txt = ai_consult.analyze_chart(sym, days=60)
            self.root.after(0, lambda: self._show_ai_chart_text(target, txt))
        self._set_status(f"🤖 {sym} 차트 AI 분석 중...")
        threading.Thread(target=worker, daemon=True).start()

    def _show_ai_chart_text(self, win, txt):
        if win is None or not win.winfo_exists():
            win = tk.Toplevel(self.root)
            win.title("🤖 AI 차트 설명")
            win.configure(bg=BG)
            win.geometry("760x620")
        for w in win.winfo_children():
            if isinstance(w, RO_Text):
                w.replace(txt)
                return
        box = RO_Text(win, wrap="word", bg="#0d1117", fg=TEXT, insertbackground=TEXT,
                      font=("Consolas", 10))
        box.pack(fill="both", expand=True, padx=10, pady=10)
        box.replace(txt)

    def _chart_signals(self):
        """🔍 최근 매수/매도 신호 텍스트"""
        sym = self.chart_sym.get().strip()
        if not sym:
            return
        import charting
        txt = charting.recent_signals_text(sym, limit=15) or "(신호 기록 없음)"
        win = tk.Toplevel(self.root)
        win.title(f"🔍 {sym} 최근 신호")
        win.configure(bg=BG)
        win.geometry("560x420")
        box = RO_Text(win, wrap="word", bg="#0d1117", fg=TEXT, insertbackground=TEXT,
                      font=("Consolas", 10))
        box.pack(fill="both", expand=True, padx=10, pady=10)
        box.replace(txt)

    def _toggle_live_mode(self):
        """⚡ 실시간 모드 (OpenAPI+ 영웅문) - 실시간 매수/매도
        - Windows + 영웅문 로그인 + pykiwoom 필요
        - 불가능 환경(리눅스/영웅문 없음)이면 안내 후 REST 유지
        """
        import live_trader as lt
        if getattr(self, "live_running", False):
            self.live_running = False
            lt.disconnect()
            self.live_btn.config(text="⚡ 실시간 모드")
            self.live_state.config(text="", foreground=MUTED)
            self._alog(f"[{now_kst():%H:%M:%S}] ⏹ 실시간 모드 중지 (REST 폴백)\n")
            return
        # Qt 이벤트 펌프 시작 (Tkinter와 공존)
        if lt.init_qt() is None:
            self._alog(f"[{now_kst():%H:%M:%S}] ⚠️ 실시간 모드 불가: {lt.get_error()}\n"
                f"   (Windows + pip install pykiwoom PyQt5 + 영웅문 로그인 필요)\n"
                f"   REST 모드로 계속 운영됩니다.\n")
            return
        if not lt.connect():
            self._alog(f"[{now_kst():%H:%M:%S}] ⚠️ 실시간 연결 실패: {lt.get_error()}\n"
                f"   영웅문 실행 + 로그인 상태 확인. REST 모드로 계속 운영됩니다.\n")
            self.live_state.config(text="📡 REST", foreground=MUTED)
            return
        self.live_running = True
        self.live_btn.config(text="⏸ 실시간 중지", style="Danger.TButton")
        self.live_state.config(text="⚡ LIVE", foreground=GREEN)
        self._alog(f"[{now_kst():%H:%M:%S}] ⚡ 실시간 모드 시작 (계좌 {lt._state['account'] or '-'})\n")
        # 감시 후보 구독 + 자동 전략
        try:
            from scalp import scalp_candidates
            cands = scalp_candidates(max_n=50)
            lt.subscribe(cands)
            lt.enable_auto_strategy()
            self._alog(f"[{now_kst():%H:%M:%S}] ⚡ 실시간 구독 {len(cands)}개 + 자동 판단/주문 활성\n")
        except Exception as e:
            self._alog(f"[{now_kst():%H:%M:%S}] ⚠️ 구독 오류: {e}\n")
        # Qt 펌프 (Tkinter 메인루프에서 주기적으로 Qt 이벤트 처리)
        def _pump():
            if getattr(self, "live_running", False):
                try:
                    lt.process_events()
                except Exception:
                    pass
                self.root.after(50, _pump)
        _pump()

    def _toggle_pilot(self):
        """🚀 자동 파일럿 시작/정지 - 데이터 우선, AI가 지시, 명예의 전당 운영 (개입 없음)"""
        if getattr(self, "pilot_running", False):
            self.pilot_running = False
            self.pilot_btn.config(text="🚀 자동 파일럿 시작")
            self.pilot_state.config(text="⏹ 중지됨", foreground=MUTED)
            self._alog(f"[{now_kst():%H:%M:%S}] ⏹ 자동 파일럿 중지\n")
            return
        import auto_pilot
        st = auto_pilot.status()
        self.pilot_running = True
        self.pilot_btn.config(text="⏸ 자동 파일럿 중지", style="Danger.TButton")
        self.pilot_state.config(text="▶ 운영 중", foreground=GREEN)
        self._alog(f"[{now_kst():%H:%M:%S}] 🚀 자동 파일럿 시작 (데이터: {st['data']})\n")
        if st.get("hof_count"):
            retired = len(db.retired_list(limit=1000))
            self._alog(f"[{now_kst():%H:%M:%S}] 🏆 명예의 전당 {st['hof_count']}건 · 퇴출 {retired}건\n")
        threading.Thread(target=self._pilot_loop, daemon=True).start()

    def _pilot_loop(self):
        """🚀 자동 파일럿 루프 (4팀 총괄 - 간결)
        - 장중: 정각 3분마다 모의매매 팀 (실제 모의 확인)
        - 장마감/휴장: 총괄 라운드 (자료수집→검증→모의매매→명예의 전당) 반복
        """
        import time as _t
        import teams
        from engine import next_watch_time
        period = max(1, int(getattr(CFG, "WATCH_PERIOD_MINUTES", 3)))
        round_no = 0
        last_session = None
        while self.pilot_running:
            try:
                sess = teams.market_session()
                if sess["mode"] != last_session:
                    mode_txt = {"intraday": "장중 - 모의매매 팀",
                                "after_hours": "장마감 - 총괄 라운드",
                                "holiday": "휴장 - 총괄 라운드"}.get(sess["mode"], sess["mode"])
                    self._alog(f"[{now_kst():%H:%M:%S}] 🕐 세션: {mode_txt}\n")
                    last_session = sess["mode"]
                if sess["mode"] == "intraday":
                    # ── ⚡ 장초반(09:00~09:40): 스캘핑 1분 주기 (빠른 매수/눌림매수) ──
                    try:
                        import scalp
                        _in_scalp = scalp._in_window(now_kst())
                    except Exception:
                        _in_scalp = False
                    if _in_scalp:
                        self.root.after(0, lambda: self.pilot_state.config(
                            text="▶ 장초반: 스캘핑 운영 중 (1분)", foreground=ACCENT))
                        _t.sleep(20)  # 1분 주기 근사 (네이버 분봉 반영 대기)
                        # ★🔴 2026-09-02: 스캘핑 개별 보호 (사용자: "중간에 에러 떠서 9시 매수 안 됨")
                        #   기존엔 스캘핑에서 예외가 나면 아래 채널/조건식 매매까지 통째로
                        #   건너뛰고 30초 대기 → 매 사이클 반복 = 9시대 매수 전멸.
                        #   수정: 스캘핑이 죽어도 채널·조건식 매매는 반드시 계속.
                        try:
                            r = scalp.run_scalp_cycle()
                            self._alog(f"[{now_kst():%H:%M:%S}] ⚡ 스캘핑: 진입 {len(r.get('entered', []))}건 · "
                                f"청산 {len(r.get('exited', []))}건 · {r.get('note', '')}\n")
                        except Exception as _se:
                            self._alog(f"[{now_kst():%H:%M:%S}] ⚠️ 스캘핑 오류(매수는 계속): {str(_se)[:70]}\n")
                        # ★ 2026-08-28 수정: 스캘핑 시간(09:00~09:40)에도 채널 실행
                        #   (기존엔 여기서 continue라 9:20 테마/9:00 기준선이 9:40까지 밀렸음)
                        #   channels_auto는 시각 게이트+1일1회 상태를 자체 관리하므로 중복 없음
                        try:
                            import channels_auto
                            channels_auto.run_channels(
                                log_fn=lambda m: self._alog(f"[{now_kst():%H:%M:%S}] {m}\n"))
                        except Exception:
                            pass
                        # ★🔴 2026-09-01 수정: 장초반에도 조건식 모의매매 병행 (3분마다)
                        #   기존엔 continue 때문에 조건식 매수가 09:40까지 전혀 안 돌았음
                        #   ("아침에 매수가 안 된다" 원인). 스캘핑 20초 주기와 별개로
                        #   WATCH_PERIOD(기본 3분)마다 1회씩 조건식 스캔·진입·청산 실행.
                        try:
                            import time as _tt2
                            if _tt2.time() - getattr(self, "_last_paper_ts", 0) >= period * 60:
                                self._last_paper_ts = _tt2.time()
                                r2 = teams.PaperTeam().run(n=_cfg_env_int("PAPER_TOP_N", 20))
                                self._alog(f"[{now_kst():%H:%M:%S}] 🖥 조건식 매매(장초반 병행): "
                                    f"진입 {len(r2.get('entered', []))}건 · "
                                    f"청산 {len(r2.get('exited', []))}건\n")
                        except Exception:
                            pass
                        self.root.after(0, self._refresh_live)
                        continue
                    # ── 장중 (9:40 이후): 기존 모의매매 3분 주기 ──
                    # ★ 모의매매 실행 중 = 빨간 ● 표시 (사용자 요청: 실행 중이 확실히 보이게)
                    self._paper_active = True
                    self.root.after(0, lambda: self.pilot_state.config(
                        text="🔴 모의매매 실행 중", foreground=RED))
                    try:
                        if hasattr(self, "team_paper"):
                            self.root.after(0, lambda: self.team_paper.config(
                                text="🔴 모의매매 실행 중...", foreground=RED))
                    except Exception:
                        pass
                    nxt = next_watch_time(period=period)
                    wait_s = max(1, int((nxt - now_kst()).total_seconds()))
                    waited = 0
                    while waited < wait_s and self.pilot_running:
                        _t.sleep(min(wait_s - waited, 30))
                        waited += 30
                    if not self.pilot_running:
                        break
                    r = teams.PaperTeam().run(n=_cfg_env_int("PAPER_TOP_N", 20))
                    # ★🔗 매수 채널 자동 실행 (AI픽/급등/세력선/기준선 - 하루 1회씩 시간대별)
                    try:
                        import channels_auto
                        ran = channels_auto.run_channels(
                            log_fn=lambda m: self._alog(f"[{now_kst():%H:%M:%S}] {m}\n"))
                    except Exception:
                        pass
                    for line in teams.PaperTeam().last_log[-2:]:
                        self._alog(f"[{now_kst():%H:%M:%S}] {line}\n")
                    self._paper_active = False
                    self.root.after(0, self._refresh_live)
                else:  # after_hours / holiday
                    # ★ 개장 임박 프리즈 (사용자: '9시 5분이면 이미 늦음 - 장전에 준비해야')
                    #   거래일 08:35~09:00에는 새 라운드를 시작하지 않고 대기
                    #   (라운드가 08:50에 시작해 30분 걸리면 9시 매수를 놓치는 문제 방지)
                    _now = now_kst()
                    try:
                        from db import is_trading_day as _itd
                        _pre_open = (_itd(_now.date()) and
                                     (_now.hour == 8 and _now.minute >= 35))
                    except Exception:
                        _pre_open = False
                    if _pre_open:
                        self.root.after(0, lambda: self.pilot_state.config(
                            text="⏰ 개장 대기 (08:35~09:00 라운드 정지 - 9시 정각 매매 준비)",
                            foreground=ACCENT))
                        # 장전 준비: 급등 레이더 최신화 (가볍게 1회만)
                        try:
                            import preopen_radar as _pr
                            if not getattr(self, "_preopen_done", "") == _now.strftime("%Y%m%d"):
                                _cands = _pr.preopen_rank(top=15, max_scan=150)
                                _pr.save("preopen", _cands)
                                self._preopen_done = _now.strftime("%Y%m%d")
                                if _cands:
                                    self._alog(f"[{now_kst():%H:%M:%S}] 📡 개장 전 급등 후보 {len(_cands)}개 준비 완료 "
                                        f"(1위 {_cands[0]['symbol']})\n")
                        except Exception:
                            pass
                        _t.sleep(20)   # 20초 간격으로 재확인 → 09:00 즉시 장중 전환
                        continue
                    round_no += 1
                    self.root.after(0, lambda: self.pilot_state.config(
                        text=f"▶ 총괄 라운드 {round_no} 중", foreground=ACCENT))
                    res = teams.CONTROL.round(paper_n=10)
                    for line in teams.CONTROL.last_log[-6:]:
                        self._alog(f"[{now_kst():%H:%M:%S}] {line}\n")
                    self.root.after(0, self._refresh_live)
                    for _ in range(3):
                        if not self.pilot_running:
                            break
                        _t.sleep(5)
            except Exception as e:
                import traceback
                self._alog(f"[{now_kst():%H:%M:%S}] ❌ 자동 파일럿 오류: {e}\n")
                for _ in range(5):
                    if not self.pilot_running:
                        break
                    _t.sleep(6)
        self.root.after(0, lambda: self.pilot_btn.config(text="🚀 자동 파일럿 시작"))
        self.root.after(0, lambda: self.pilot_state.config(text="⏹ 중지됨", foreground=MUTED))

    def _toggle_backfill(self):
        """📥 데이터 수집 시작/중지 (수동) - 전 종목 일봉(90일)+분봉 수집"""
        if getattr(self, "backfill_running", False):
            self.backfill_running = False
            self.backfill_btn.config(text="📥 데이터 수집")
            self._alog(f"[{now_kst():%H:%M:%S}] ⏹ 데이터 수집 중지됨\n")
            return
        self.backfill_running = True
        self.backfill_btn.config(text="⏸ 수집 중지", style="Danger.TButton")
        self._alog(f"[{now_kst():%H:%M:%S}] 📥 데이터 수집 시작 (전 종목 일봉 {CFG.BACKFILL_DAYS}일 + 분봉 · "
            f"백그라운드, 중지 버튼으로 멈춤)\n")
        threading.Thread(target=self._backfill_loop, daemon=True).start()

    def _backfill_loop(self):
        """수동 데이터 수집 루프: 미수신+갭 종목 반복 (전 종목 커버) - 진행 현황 실시간 표시"""
        import time as _t
        import backfill_history as _bf
        done_all = False
        self._bf_fail_streak = 0   # ★ 연속 실패 백오프 (네이버 차단 시 대기 + 배치 축소)
        while self.backfill_running:
            try:
                # ★ 연속 실패가 쌓이면 배치 축소 (500→250→125→60) - 차단 회피
                cur_per = max(60, CFG.BACKFILL_PER_RUN // (2 ** min(self._bf_fail_streak, 3)))
                br = _bf.auto_backfill(per_run=cur_per)
                got = br.get("symbols_ok", 0)
                note = br.get("note", "")
                self._alog(f"[{now_kst():%H:%M:%S}] ✅ 수집: {got}종목 {br.get('bars',0)}봉 {note}\n")
                if br.get("minutes"):
                    self._alog(f"[{now_kst():%H:%M:%S}] {br['minutes']}\n")
                # ★ 일봉 진행률 표시 (받아지고 있는지 눈으로 - target은 KONEX 제외 전 종목)
                try:
                    _n = db.count_universe()
                    _t = 0
                    with db.get_conn() as _c:
                        _t = _c.execute(
                            "SELECT COUNT(*) c FROM universe WHERE market != 'KONEX'"
                        ).fetchone()["c"]
                    _ready = db.backfill_coverage(min_days=30).get("ready", 0)
                    self._alog(f"[{now_kst():%H:%M:%S}] 📊 일봉 진행: {_ready}/{_t} 종목 "
                        f"({_ready * 100 // _t if _t else 0}%) · 목록 {_n}개\n")
                except Exception:
                    pass
                # ★ 완료 판정: 받을 종목 0개 + 일봉 30봉+ 대상(KONEX 제외) 전부 도달일 때만
                try:
                    with db.get_conn() as _c:
                        _tgt = _c.execute(
                            "SELECT COUNT(*) c FROM universe WHERE market != 'KONEX'"
                        ).fetchone()["c"]
                except Exception:
                    _tgt = 0
                _rdy = db.backfill_coverage(min_days=30).get("ready", 0)
                if (not got or "이미" in note) and _tgt and _rdy >= _tgt:
                    done_all = True
                    break
                if not got and note != "이미 전 종목 백필 완료":
                    # ★ 실패(0건 수신) → 연속 실패 백오프 (네이버 차단 대비)
                    self._bf_fail_streak += 1
                    wait = min(30 * (2 ** min(self._bf_fail_streak, 5)), 600)
                    self._alog(f"[{now_kst():%H:%M:%S}] ⚠️ 수신 0건 (연속 실패 {self._bf_fail_streak}회) - "
                        f"{wait // 60 if wait >= 120 else wait}초 후 재시도 · 배치 {cur_per}개로 축소\n")
                    for _ in range(wait // 2):
                        if not self.backfill_running:
                            break
                        _t.sleep(2)
                    continue
                # 성공했으면 연속 실패 초기화
                if self._bf_fail_streak and got > 0:
                    self._alog(f"[{now_kst():%H:%M:%S}] ✅ 연속 실패 {self._bf_fail_streak}회에서 회복\n")
                self._bf_fail_streak = 0
                if not got or "이미" in note:
                    # 받을 종목은 0개인데 진행률 미달 → 목록 오류로 보고 재로드 후 계속
                    self._alog(f"[{now_kst():%H:%M:%S}] ⚠️ 받을 종목 0개인데 진행률 미달 - 전 종목 목록 재로드\n")
                    try:
                        import universe
                        _r = universe.refresh_universe()
                        self._alog(f"[{now_kst():%H:%M:%S}] 유니버스 재로드: {_r.get('method')} ({_r.get('count')}개)\n")
                    except Exception as _e:
                        self._alog(f"[{now_kst():%H:%M:%S}] ⚠️ 유니버스 재로드 실패: {_e}\n")
                    for _ in range(10):
                        if not self.backfill_running:
                            break
                        _t.sleep(2)
                    continue
                # 다음 배치까지 잠깐 대기 (중지 반응성)
                for _ in range(20):
                    if not self.backfill_running:
                        break
                    _t.sleep(2)
            except Exception as e:
                self._alog(f"[{now_kst():%H:%M:%S}] ⚠️ 수집 오류: {e}\n")
                for _ in range(5):
                    if not self.backfill_running:
                        break
                    _t.sleep(3)
        if done_all:
            self._alog(f"[{now_kst():%H:%M:%S}] 🎉 데이터 수집 완료 (전 종목 일봉+분봉)\n")
        self.backfill_running = False
        self.root.after(0, lambda: self.backfill_btn.config(text="📥 데이터 수집"))
        self.root.after(0, self._refresh_live)

    def _set_status(self, text):
        self.status.config(text=f"{text} | {now_kst():%H:%M:%S}")

    def _set_text(self, widget, text):
        widget.replace(text)

def _capture(func, *args, **kwargs):
    """print 출력을 잡아서 문자열로 반환"""
    import io
    import contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        func(*args, **kwargs)
    return buf.getvalue().strip()


def main():
    # .exe로 실행 시: exe가 있는 폴더를 기준으로 .env / trading.db / prompts 찾기
    if getattr(sys, "frozen", False):
        os.chdir(os.path.dirname(sys.executable))
    db.init_db()
    from engine import bootstrap_population
    bootstrap_population()
    # ★ 웹 대시보드 서버 자동 기동 (앱 열면 http://localhost:8000 도 같이 켜짐)
    #   실패해도 조용히 넘어가지 않고 원인을 콘솔/로그로 남김 (사용자: '8000이 안 켜짐')
    _dash_port = None
    _board_port = None
    try:
        import web_status
        _p, _st = web_status.start_server()
        _dash_port = _p
        if not _st and _p:
            print(f"📊 대시보드: 기존 서버 사용 (port {_p})")
    except Exception as _e:
        print(f"❌ 웹 대시보드 시작 실패: {_e}")
        try:
            import traceback
            traceback.print_exc()
        except Exception:
            pass
    # ★ 파일럿 현황판도 자동 기동 (http://localhost:8890 - 라운드 진행률/성과)
    try:
        import pilot_board
        _bp, _bs = pilot_board.start_server()
        _board_port = _bp
        # 현황판 상단에 대시보드 링크 표시용 (포트 폴백 대응)
        try:
            pilot_board.DASH_PORT = _dash_port or 8000
        except Exception:
            pass
    except Exception:
        pass
    # ★ 브라우저 자동 열기 (사용자: '로컬호스트도 자동으로 켜지고 웹도 다 켜지면')
    #   기본 ON - 끄려면 .env에 AUTO_OPEN_BROWSER=false
    try:
        if os.getenv("AUTO_OPEN_BROWSER", "true").lower() == "true":
            import webbrowser
            import threading as _th

            def _open_tabs():
                import time as _t
                _t.sleep(2.0)   # 서버 기동 대기
                if _board_port:
                    webbrowser.open_new_tab(f"http://localhost:{_board_port}")
                if _dash_port:
                    _t.sleep(0.7)
                    webbrowser.open_new_tab(f"http://localhost:{_dash_port}")
            _th.Thread(target=_open_tabs, daemon=True).start()
            print(f"🌐 브라우저 자동 열기: 현황판({_board_port}) + 대시보드({_dash_port})")
    except Exception:
        pass
    # ★ 매도 가드 자동 기동 (라운드가 오래 걸려도 손절은 90초마다 독립 감시)
    #   사용자 사고: 라운드 1단계(수집)가 길어지면 매도 체크까지 못 가 손절 놓침 → 가드가 방지
    try:
        import sell_guard
        sell_guard.start_guard()
        print("🛡 매도 가드 시작 (90초 주기 - 손절 독립 감시)")
    except Exception as _e:
        print(f"⚠️ 매도 가드 시작 실패: {_e}")
    # ★ 장중 연구 워커 (2026-08-27 사용자: '장중에도 문제없는 것들은 지금 돌려라')
    #   09:40~15:30에 팜리그/대기검증/빌더를 백그라운드 실행 (키움 API 미사용 - 매매 방해 0)
    try:
        import lab_worker
        if lab_worker.start_worker():
            print("🔬 장중 연구 워커 시작 (09:40~15:30 팜리그·검증·빌더 병행)")
    except Exception as _e:
        print(f"⚠️ 연구 워커 시작 실패: {_e}")
    root = tk.Tk()
    app = AutoTraderApp(root)
    # ★ 앱 종료 시 대시보드 서버도 함께 정지
    def _on_close():
        try:
            import web_status
            web_status.stop_server()
        except Exception:
            pass
        try:
            root.destroy()
        except Exception:
            pass
    root.protocol("WM_DELETE_WINDOW", _on_close)
    root.mainloop()


if __name__ == "__main__":
    main()
