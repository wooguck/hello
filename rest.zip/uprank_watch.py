# -*- coding: utf-8 -*-
"""
📈 상승률 상위 풀 전방검증 (uprank_watch.py) - 2026-08-27 추가
================================================================
사용자 아이디어: "당일 상승률 200위에서 검증하고, 잘 나온 애들 다시 검사"

⚠️ 함정 방지 설계:
  '오늘 오른 종목'의 과거를 백테스트하면 생존편향으로 수익이 공짜로 부풀려짐
  (실측: 엣지 0인 무작위 데이터에서도 +1%p 착시 발생)

✅ 올바른 방향 (이 모듈):
  [1] snapshot(): 매일 장마감 무렵 '그날' 상승률 상위 200 명단을 날짜 도장 찍어 저장
      → strategy/upranks/YYYY-MM-DD.json (그 시점에 안 것만 - 미래 정보 0)
  [2] forward_report(days=N): 저장된 과거 명단이 '그 이후' 실제로 어땠는지 집계
      → 상승상위 풀 평균 vs 시장 전체 평균 (공정 비교)
      → 이게 플러스로 확인되면: 상승상위 풀을 조건식 스캔 우선순위로 쓸 근거가 생김
      → 마이너스면: '급등 다음날 사면 물린다'는 증거 - 채널 파라미터 조정 근거

teams 라운드(장외)에서 하루 1회 자동 snapshot.
수동: python uprank_watch.py            (오늘 스냅샷)
      python uprank_watch.py --report   (전방 성적 리포트)
"""
import argparse
import json
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import sys

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

DIR = os.path.join("strategy", "upranks")
TOP_N = _cfg_env_int("UPRANK_TOP_N", 200)


def _today():
    return db.now_kst().strftime("%Y-%m-%d")


def snapshot(top_n=None, log_fn=None):
    """오늘 상승률 상위 명단 저장 (하루 1회 - 이미 있으면 스킵)
    반환: {"saved": bool, "n": 종목수, "path": 파일}
    """
    def _log(m):
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    top_n = top_n or TOP_N
    os.makedirs(DIR, exist_ok=True)
    path = os.path.join(DIR, f"{_today()}.json")
    if os.path.exists(path):
        return {"saved": False, "n": 0, "path": path, "note": "오늘 이미 저장됨"}
    # 거래일 아니면 스킵 (주말/휴장 명단은 무의미)
    try:
        from db import is_trading_day
        if not is_trading_day(db.now_kst().date()):
            return {"saved": False, "n": 0, "path": "", "note": "휴장일 - 스킵"}
    except Exception:
        pass
    rows = []
    # 1순위: 네이버 상승상위 API (momentum_channel 재사용 - 코스피+코스닥)
    try:
        import momentum_channel as mc
        ups = mc.fetch_up_ranks(max_n=top_n)
        for u in ups:
            rows.append({"symbol": u.get("symbol"), "name": u.get("name", ""),
                         "chg": u.get("chg"), "price": u.get("price")})
    except Exception:
        pass
    # 2순위 폴백: 내부 일봉으로 당일(최신봉) 등락률 계산해 상위 추출
    if len(rows) < 20:
        try:
            cov = db.backfill_coverage(min_days=2)
            cand = []
            for s in list(cov["symbols"].keys()):
                bars = db.get_stock_daily(s, max_days=2)
                if len(bars) >= 2 and bars[-2]["close"]:
                    chg = (bars[-1]["close"] / bars[-2]["close"] - 1) * 100
                    cand.append({"symbol": s, "name": "", "chg": round(chg, 2),
                                 "price": bars[-1]["close"], "date": bars[-1]["date"]})
            cand.sort(key=lambda x: -(x["chg"] or 0))
            rows = cand[:top_n]
        except Exception:
            pass
    if not rows:
        return {"saved": False, "n": 0, "path": "", "note": "명단 수집 실패 (네트워크/데이터)"}
    json.dump({"date": _today(), "top_n": top_n, "rows": rows},
              open(path, "w", encoding="utf-8"), ensure_ascii=False)
    _log(f"📈 [상승풀] 오늘 상승 상위 {len(rows)}종목 명단 저장 (전방검증용 - "
         f"{len(list_snapshots())}일치 축적)")
    return {"saved": True, "n": len(rows), "path": path}


def list_snapshots():
    if not os.path.isdir(DIR):
        return []
    return sorted(f[:-5] for f in os.listdir(DIR) if f.endswith(".json"))


def _forward_ret(symbol, from_date, days):
    """from_date '다음 거래일 시가급 종가' 기준 days일 후 수익률 (미래 방향만 봄)
    반환 None = 데이터 없음"""
    bars = db.get_stock_daily(symbol, max_days=400)
    dates = [b["date"] for b in bars]
    # from_date 이후 첫 봉 = 진입 (스냅샷 당일 종가에 사는 게 아니라 다음날 - 보수적)
    idx = None
    for i, d in enumerate(dates):
        if d > from_date:
            idx = i
            break
    if idx is None or idx + days >= len(bars):
        return None
    p0 = bars[idx]["close"]
    p1 = bars[idx + days]["close"]
    if not p0 or p0 <= 0:
        return None
    return (p1 / p0 - 1) * 100


def forward_report(days=5, max_pool=200, control_n=200, log_fn=None):
    """저장된 과거 명단들의 '그 이후' 성적 vs 무작위 대조군
    days: 진입(스냅샷 다음날) 후 보유 거래일 수
    반환: {"snapshots": n, "pool_avg": %, "control_avg": %, "edge": %p, "samples": n}
    """
    import random
    snaps = list_snapshots()
    # days일 뒤 데이터가 존재해야 하므로 너무 최근 것은 자동 제외됨
    pool_rets, ctrl_rets = [], []
    used = 0
    # 대조군 풀: 데이터 있는 전 종목
    try:
        cov = db.backfill_coverage(min_days=days + 10)
        all_syms = list(cov["symbols"].keys())
    except Exception:
        all_syms = []
    rng = random.Random(20260827)
    for d in snaps:
        try:
            s = json.load(open(os.path.join(DIR, f"{d}.json"), encoding="utf-8"))
        except Exception:
            continue
        rows = (s.get("rows") or [])[:max_pool]
        got = 0
        for r in rows:
            fr = _forward_ret(r["symbol"], d, days)
            if fr is not None:
                pool_rets.append(fr)
                got += 1
        if got == 0:
            continue
        used += 1
        # 같은 날짜 기준 무작위 대조군 (같은 수만큼)
        if all_syms:
            for sym in rng.sample(all_syms, min(control_n, len(all_syms))):
                fr = _forward_ret(sym, d, days)
                if fr is not None:
                    ctrl_rets.append(fr)
    if not pool_rets:
        return {"snapshots": used, "pool_avg": None, "control_avg": None,
                "edge": None, "samples": 0,
                "note": "아직 표본 없음 - 스냅샷이 며칠 쌓인 뒤 다시 (days일 후 데이터 필요)"}
    pool_avg = sum(pool_rets) / len(pool_rets)
    ctrl_avg = sum(ctrl_rets) / len(ctrl_rets) if ctrl_rets else None
    edge = (pool_avg - ctrl_avg) if ctrl_avg is not None else None
    win = len([x for x in pool_rets if x > 0]) / len(pool_rets) * 100
    out = {"snapshots": used, "days": days,
           "pool_avg": round(pool_avg, 2),
           "pool_win": round(win, 1),
           "control_avg": round(ctrl_avg, 2) if ctrl_avg is not None else None,
           "edge": round(edge, 2) if edge is not None else None,
           "samples": len(pool_rets)}
    if log_fn:
        try:
            log_fn(f"📈 [상승풀 전방검증] {used}일치 · 진입후 {days}일 보유: "
                   f"풀 {pool_avg:+.2f}% vs 대조군 "
                   f"{(f'{ctrl_avg:+.2f}%' if ctrl_avg is not None else '?')} "
                   f"(우위 {(f'{edge:+.2f}%p' if edge is not None else '?')})")
        except Exception:
            pass
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", action="store_true", help="전방 성적 리포트")
    ap.add_argument("--days", type=int, default=5, help="보유 거래일 (기본 5)")
    ap.add_argument("--top", type=int, default=TOP_N)
    args = ap.parse_args()
    if args.report:
        r = forward_report(days=args.days, log_fn=print)
        print()
        print("=" * 60)
        print(f"📈 상승률 상위 풀 전방검증 (스냅샷 {r['snapshots']}일치)")
        print("=" * 60)
        if r.get("pool_avg") is None:
            print(f"  {r.get('note','표본 없음')}")
        else:
            print(f"  풀 평균 (진입후 {r['days']}일): {r['pool_avg']:+.2f}%  "
                  f"(승률 {r['pool_win']}% · 표본 {r['samples']:,}건)")
            if r["control_avg"] is not None:
                print(f"  무작위 대조군            : {r['control_avg']:+.2f}%")
                print(f"  ─────────────────────────")
                print(f"  진짜 우위                : {r['edge']:+.2f}%p")
                if r["edge"] > 0.3:
                    print("  → 상승상위 풀에 우위 있음: 조건식 스캔 우선순위로 쓸 근거 ↑")
                elif r["edge"] < -0.3:
                    print("  → 급등 다음날 진입은 오히려 불리: MOMENTUM 필터 강화 근거")
                else:
                    print("  → 우위 불분명: 표본 더 필요하거나 풀 자체론 엣지 없음")
        print()
        print("  ※ 이 숫자는 '명단 저장 이후'만 봄 - 생존편향 없음 (전방검증)")
    else:
        r = snapshot(top_n=args.top, log_fn=print)
        print(r)
