@echo off
title Verify System
cd /d %~dp0
echo.
echo ============================================
echo  Running self test... (about 30 sec)
echo ============================================
python verify_final.py
echo.
echo  If you see "26 items all passed" - READY.
pause
