# -*- coding: utf-8 -*-
"""
🔎 남은 미수집 종목 정체 확인 (check_remaining.py)
===================================================
"진행률 98%에서 안 끝나는" 마지막 종목들이 무엇인지 확인합니다.
- DB에 몇 봉 있는지
- 다음(카카오)에서 몇 봉을 주는지 (0.8초 간격, 최대 40종목만 샘플)
→ 신규상장(원래 30봉이 안 됨) / 거래정지·폐지(404) / 진짜 미수신 을 구분

실행: python check_remaining.py
결과를 복사해서 알려주세요.
"""
import os
import sys
import time
import sqlite3

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import requests
import db
import backfill_history as bf

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36")


def daum_bars(sym):
    """다음에서 이 종목이 주는 봉 수 (404=폐지/미지원, 403=차단)"""
    try:
        r = requests.get(f"https://finance.daum.net/api/charts/A{sym}/days",
                         params={"limit": 40, "adjusted": "true"},
                         headers={"User-Agent": UA,
                                  "Referer": f"https://finance.daum.net/quotes/A{sym}"},
                         timeout=10)
        if r.status_code != 200:
            return f"HTTP {r.status_code}"
        return len((r.json() or {}).get("data") or [])
    except Exception as e:
        return f"오류 {str(e)[:30]}"


def main():
    # 미수신/갭 종목 목록 (backfill과 같은 기준)
    unfilled = bf.get_unfilled_symbols()
    names = {}
    try:
        for u in db.get_universe():
            names[u.get("symbol")] = u.get("name") or ""
    except Exception:
        pass

    print(f"📋 미수신/갭 종목: {len(unfilled)}개")
    print("=" * 70)
    print(f"{'종목':8} {'이름':12} {'DB봉수':>6} {'다음응답':>10}  판정")
    print("-" * 70)

    stocks_dir = os.path.join(db.DATA_DIR, "stocks")
    new_listing = dead = blocked = mystery = 0
    sample = unfilled[:40]   # 다음 조회는 40종목까지만 (차단 방지)
    for i, sym in enumerate(sample):
        # DB 봉 수
        n_db = 0
        p = os.path.join(stocks_dir, f"{sym}.db")
        if os.path.exists(p):
            try:
                c = sqlite3.connect(p)
                n_db = c.execute("SELECT COUNT(*) FROM daily_bars").fetchone()[0]
                c.close()
            except Exception:
                pass
        d = daum_bars(sym)
        # 판정
        if isinstance(d, int):
            if d == 0:
                verdict = "폐지/미지원?"
                dead += 1
            elif d < 30:
                verdict = f"신규상장 (총 {d}봉뿐 - 30봉 기준 못 채움)"
                new_listing += 1
            elif n_db >= d:
                verdict = "이미 다 받음 (기준만 못 채움)"
                new_listing += 1
            else:
                verdict = "받으면 채워짐"
                mystery += 1
        elif "404" in str(d):
            verdict = "상장폐지/거래정지 (다음에 없음)"
            dead += 1
        elif "403" in str(d):
            verdict = "다음 차단 중"
            blocked += 1
        else:
            verdict = "확인 불가"
            mystery += 1
        nm = (names.get(sym) or "")[:10]
        print(f"{sym:8} {nm:12} {n_db:>6} {str(d):>10}  {verdict}")
        time.sleep(0.8)

    print("-" * 70)
    print(f"샘플 {len(sample)}개 분석: 신규상장/기준미달 {new_listing} · 폐지/정지 {dead} · "
          f"차단 {blocked} · 기타 {mystery}")
    if len(unfilled) > len(sample):
        print(f"(전체 {len(unfilled)}개 중 앞 {len(sample)}개만 조회 - 차단 방지)")
    print()
    if new_listing + dead >= len(sample) * 0.7:
        print("💡 결론: 남은 종목 대부분이 '원래 30봉이 존재하지 않는' 종목입니다")
        print("   (신규상장·거래정지·폐지) → 데이터 수집은 사실상 완료된 상태!")
        print("   검증/전략생성으로 넘어가도 됩니다.")


if __name__ == "__main__":
    main()
