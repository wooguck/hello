# -*- coding: utf-8 -*-
"""
🔐 .env 분리 도구 (split_env.py) - 2026-08-28
================================================================
사용자: ".env에는 키움 계좌 연결 + AI 연결 자료만 남기고 나머지는 새 곳으로"

동작:
  .env를 읽어서 →
    연결 정보(키움 키/계좌/AI 키/모델)만 .env에 남기고
    나머지 전부 settings.env로 이동
  백업: .env.split_bak (원본 그대로)

config.py가 둘 다 로드 (.env 우선). 한 번만 실행하면 됨.
실행: python split_env.py
"""
import os
import shutil
import sys

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# .env에 남길 것: 연결/인증 정보 (이름 패턴 - 대소문자 무관)
#   2026-08-28 수정: 접두사 목록 방식이 키 이름 변형을 놓쳐 앱키가 settings로 샜음 → 정규식으로
import re
CRED_PAT = re.compile(
    r"(KEY|SECRET|ACCOUNT|ACCT|TOKEN|MOCK|DRY_RUN|AI_PROVIDER|AI_MODEL|PASSWORD|PASSWD)",
    re.IGNORECASE)


def main():
    if not os.path.exists(".env"):
        print("❌ .env 없음 - 이 폴더(rest)에서 실행하세요")
        return
    shutil.copy(".env", ".env.split_bak")
    lines = None
    for enc in ("utf-8", "cp949", "euc-kr"):
        try:
            lines = open(".env", encoding=enc).read().splitlines()
            break
        except Exception:
            continue
    if lines is None:
        lines = open(".env", encoding="utf-8", errors="replace").read().splitlines()
    keep, move = [], []
    for ln in lines:
        s = ln.strip()
        if not s or s.startswith("#"):
            # 주석/빈줄은 양쪽 다 안 넣음 (settings.env는 새로 정리)
            continue
        key = s.split("=", 1)[0].strip()
        if CRED_PAT.search(key):
            keep.append(ln)
        else:
            move.append(ln)
    # settings.env: 기존 내용 보존 + 이동분 병합 (중복 키는 이동분 우선)
    existing = {}
    if os.path.exists("settings.env"):
        for ln in open("settings.env", encoding="utf-8").read().splitlines():
            if "=" in ln and not ln.strip().startswith("#"):
                existing[ln.split("=", 1)[0].strip()] = ln
    for ln in move:
        existing[ln.split("=", 1)[0].strip()] = ln
    with open("settings.env", "w", encoding="utf-8") as f:
        f.write("# ================================================\n")
        f.write("# settings.env - 일반 설정 (키/계좌는 .env에)\n")
        f.write("# 우선순위: .env > 이 파일 > 기본값\n")
        f.write("# ================================================\n")
        for k in sorted(existing):
            f.write(existing[k] + "\n")
    with open(".env", "w", encoding="utf-8") as f:
        f.write("# ================================================\n")
        f.write("# .env - 연결 정보만 (키움/AI/안전스위치)\n")
        f.write("# 일반 설정은 settings.env / 자동 튜닝값은 strategy/auto_params.json\n")
        f.write("# ================================================\n")
        for ln in keep:
            f.write(ln + "\n")
    print("=" * 56)
    print("🔐 .env 분리 완료")
    print("=" * 56)
    print(f"  .env 에 남김      : {len(keep)}줄 (키움/AI/DRY_RUN)")
    print(f"  settings.env 이동 : {len(move)}줄 (일반 설정)")
    print(f"  백업              : .env.split_bak (원본)")
    print("\n  ⚠️ 앱 재시작 필요 (config가 둘 다 읽습니다)")


if __name__ == "__main__":
    main()
