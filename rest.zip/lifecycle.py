# -*- coding: utf-8 -*-
"""
♻️ 조건식 자동 승격/강등 (lifecycle.py)
=========================================
사용자 요청: "대기(backlog)도 검증은 해보고, 싹수 있으면 운영으로 올리고,
매수는 운영만, 명예의 전당 상위는 운영 보장 - 전부 자동으로"

라운드에서 자동 호출 (teams.py) - 하는 일:
  ① 대기(backlog) 조건식도 엄밀 검증 (백테스트+대조군, 라운드마다 최대 N개씩 순환)
  ② 승격: 대기 중 '채택 후보/조건부' 등급 → 운영(active) 복귀
  ③ 강등: 운영 중 '기각' 등급 + 실전 표본 5건 이상 승률 낮음 → 대기
  ④ 명예의 전당 상위 5개: 무조건 운영 유지 (대기로 밀려있으면 자동 복귀)
  (매수는 원래 active만 - paper_test.top_conditions 구조 그대로)

단독 실행: python lifecycle.py   (1회 수동 실행)
"""
import json
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import logging
import sys

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

log = logging.getLogger("lifecycle")

PROMOTE_GRADES = ("채택 후보", "조건부")   # 승격 허용 등급
BACKLOG_VALIDATE_PER_ROUND = _cfg_env_int("LC_BACKLOG_PER_ROUND", 10)  # 회당 대기 검증 수 (5→10 - features 캐시로 빨라져 여유)


def _latest_grade(cond_key):
    """해당 조건식의 최신 엄밀 검증 등급 (없으면 None)"""
    try:
        with db.get_conn() as conn:
            r = conn.execute(
                "SELECT grade, trades FROM validation_results WHERE cond_key=? "
                "ORDER BY id DESC LIMIT 1", (str(cond_key),)).fetchone()
        return (r["grade"], r["trades"] or 0) if r else (None, 0)
    except Exception:
        return (None, 0)


def validate_backlog(max_n=BACKLOG_VALIDATE_PER_ROUND, max_symbols=None):
    if max_symbols is None:
        # ★ 2026-09-02: 150→400종목 (사용자: "제대로 전종목에서 확인" -
        #   대기 검증도 표본을 키워 우연 통과/우연 기각 감소)
        max_symbols = _cfg_env_int("LC_BACKLOG_SYMBOLS", 400)
    """★ 대기 조건식도 검증 (오래 안 본 것부터 순환) → validation_results에 저장"""
    from validation import validate_condition, save_validation_results
    try:
        backlog = db.get_conditions(status="backlog")
    except Exception:
        return []
    if not backlog:
        return []
    # 최근 검증이 오래된 순 (한 번도 안 된 것 우선)
    def _age(c):
        g, _t = _latest_grade(c["id"])
        try:
            with db.get_conn() as conn:
                r = conn.execute("SELECT MAX(created_at) m FROM validation_results "
                                 "WHERE cond_key=?", (str(c["id"]),)).fetchone()
            return r["m"] or ""
        except Exception:
            return ""
    backlog.sort(key=_age)
    results = []
    for c in backlog[:max_n]:
        try:
            slots = json.loads(c.get("slots_json") or "[]")
        except Exception:
            slots = []
        if not slots:
            continue
        try:
            r = validate_condition({"cond_key": str(c["id"]),
                                    "cond_txt": c.get("cond_txt", ""),
                                    "slots": [tuple(s) for s in slots]},
                                   max_symbols=max_symbols)
            r["cond_no"] = c.get("cond_no")
            results.append(r)
        except Exception as e:
            log.warning(f"대기 검증 실패 {c.get('cond_no')}: {str(e)[:50]}")
    if results:
        try:
            save_validation_results(results)
        except Exception:
            pass
    return results


def auto_lifecycle(log_fn=None):
    """승격/강등/명전 보장 - 라운드에서 호출. 반환: 요약 dict"""
    def _log(m):
        log.info(m)
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    out = {"validated_backlog": 0, "promoted": [], "demoted": [], "hof_kept": []}

    # ① 대기도 검증 (순환)
    res = validate_backlog()
    out["validated_backlog"] = len(res)
    if res:
        _log(f"♻️ 대기 조건식 검증 {len(res)}건 (순환)")

    # ② 승격: 대기 중 통과 등급 → 운영
    try:
        for c in db.get_conditions(status="backlog"):
            grade, trades = _latest_grade(c["id"])
            if grade in PROMOTE_GRADES and trades >= 20:
                db.set_condition_status(c["id"], "active")
                out["promoted"].append(c.get("cond_no"))
                _log(f"♻️⬆️ 승격: {c.get('cond_no')}번 [{grade}] 대기→운영 (검증 {trades}건 통과)")
    except Exception as e:
        _log(f"승격 처리 오류: {str(e)[:50]}")

    # ③ 강등: 운영 중 '기각' + 실전 승률 낮음 → 대기 (명전 상위는 보호)
    hof_keys = set()
    try:
        hof_keys = {str(h.get("cond_key")) for h in db.hof_list(limit=5, ranked_only=True)}
    except Exception:
        pass
    try:
        stats = db.paper_stats_per_condition()
        for c in db.get_conditions(status="active"):
            ck = str(c["id"])
            if ck in hof_keys:
                continue                     # 명전 상위 보호
            grade, trades = _latest_grade(ck)
            st = stats.get(ck, {})
            live_n = st.get("sells", 0)
            live_wr = st.get("win_rate", 0)
            if grade == "기각" and trades >= 30 and live_n >= 5 and live_wr < 45:
                db.set_condition_status(c["id"], "backlog")
                out["demoted"].append(c.get("cond_no"))
                _log(f"♻️⬇️ 강등: {c.get('cond_no')}번 [기각+실전승률{live_wr}%] 운영→대기")
    except Exception as e:
        _log(f"강등 처리 오류: {str(e)[:50]}")

    # ③-2 ★ 기각 자동 퇴출 (2026-09-02: 90일→14일 단축 - 사용자: "쓸모없는 조건식"
    #   대기 197개 정체 해소. 검증에서 '기각' 받은 대기는 2주면 충분히 기회 줬음)
    try:
        from datetime import timedelta
        _retire_days = _cfg_env_int("LC_RETIRE_DAYS", 14)
        cut = (db.now_kst() - timedelta(days=_retire_days)).isoformat()
        purged = 0
        for c in db.get_conditions(status="backlog"):
            if (c.get("created_at") or "9999") > cut:
                continue                      # 아직 유예기간 안 지남
            grade, _t = _latest_grade(c["id"])
            if grade in ("기각", "무효(데이터오류)"):
                with db.get_conn() as conn:
                    conn.execute(
                        "INSERT OR REPLACE INTO retired_conditions "
                        "(cond_key, cond_txt, slots_json, retired_at, reason) VALUES (?,?,?,?,?)",
                        (str(c["id"]), c["cond_txt"], c.get("slots_json"),
                         db.now_kst_iso(), f"{_retire_days}일+ 기각 자동퇴출"))
                    conn.execute("UPDATE conditions SET status='retired' WHERE id=?", (c["id"],))
                purged += 1
        if purged:
            out["auto_retired"] = purged
            _log(f"♻️🗑 기각 자동퇴출: {purged}개 ({_retire_days}일+ 대기·기각 - retired 보관)")
    except Exception as e:
        _log(f"자동퇴출 오류: {str(e)[:40]}")

    # ③-3 ★🌱 충원 모드 (2026-09-01 사용자: "대량 퇴출했으면 그만큼 찾아서 편입해야")
    #   운영(active) 조건식이 목표(LC_MIN_ACTIVE, 기본 12) 미만이면:
    #     a) 대기 검증을 2배로 추가 실행 (승격 후보 빨리 발굴)
    #     b) 퇴출 보관함 재심 (revive_retired - 통과하면 backlog 부활)
    #     c) strategy/refill_mode.json 켬 → teams가 팜리그/빌더/급등유전자 가속
    #   ※ 승격 기준 자체는 안 낮춤 (머릿수 채우려고 쓰레기 편입 금지 - 과적합 방지 규율)
    try:
        MIN_ACTIVE = _cfg_env_int("LC_MIN_ACTIVE", 12)
        active_n = len(db.get_conditions(status="active"))
        backlog_n = len(db.get_conditions(status="backlog"))
        _rf_path = os.path.join("strategy", "refill_mode.json")
        if active_n < MIN_ACTIVE:
            _log(f"🌱 충원모드 ON: 운영 {active_n}/{MIN_ACTIVE}개 (대기 {backlog_n}) "
                 f"- 검증·재심·생성 가속")
            # a) 대기 검증 추가분 (이번 라운드 몫 외에 한 번 더)
            try:
                extra = validate_backlog(max_n=BACKLOG_VALIDATE_PER_ROUND)
                if extra:
                    out["validated_backlog"] += len(extra)
                    _log(f"🌱 대기 검증 추가 {len(extra)}건 (충원 가속)")
            except Exception:
                pass
            # a-2) 추가 검증 통과분 즉시 승격 반영
            try:
                for c in db.get_conditions(status="backlog"):
                    grade, trades = _latest_grade(c["id"])
                    if grade in PROMOTE_GRADES and trades >= 20 and \
                            c.get("cond_no") not in out["promoted"]:
                        db.set_condition_status(c["id"], "active")
                        out["promoted"].append(c.get("cond_no"))
                        _log(f"🌱⬆️ 충원 승격: {c.get('cond_no')}번 [{grade}] 대기→운영")
            except Exception:
                pass
            # b) 퇴출 보관함 재심 (30일 간격 규칙은 revive가 자체 관리)
            try:
                import revive_retired as _rv
                rv = _rv.revive_batch(
                    max_n=_cfg_env_int("LC_REVIVE_PER_ROUND", 3),
                    max_symbols=150, log_fn=_log)
                if rv.get("revived"):
                    out["revived"] = rv["revived"]
            except Exception as e:
                _log(f"🌱 재심 스킵: {str(e)[:40]}")
            # c) 가속 플래그 (teams가 읽음: 팜 매라운드/빌더 5라운드/유전자 3라운드)
            try:
                json.dump({"on": True, "active": active_n, "target": MIN_ACTIVE,
                           "backlog": backlog_n, "at": db.now_kst_iso()},
                          open(_rf_path, "w", encoding="utf-8"))
            except Exception:
                pass
            out["refill"] = {"active": active_n, "target": MIN_ACTIVE}
        else:
            # 목표 충족 → 플래그 끔
            try:
                if os.path.exists(_rf_path):
                    json.dump({"on": False, "active": active_n, "target": MIN_ACTIVE,
                               "at": db.now_kst_iso()},
                              open(_rf_path, "w", encoding="utf-8"))
            except Exception:
                pass
    except Exception as e:
        _log(f"충원모드 오류: {str(e)[:40]}")

    # ④ 명예의 전당 상위 5개는 무조건 운영 유지
    try:
        for h in db.hof_list(limit=5, ranked_only=True):
            ck = h.get("cond_key")
            try:
                with db.get_conn() as conn:
                    r = conn.execute("SELECT id, cond_no, status FROM conditions WHERE id=?",
                                     (int(ck),)).fetchone()
                if r and r["status"] != "active":
                    db.set_condition_status(r["id"], "active")
                    out["hof_kept"].append(r["cond_no"])
                    _log(f"♻️🏆 명전 보장: {r['cond_no']}번 대기→운영 복귀 (명예의 전당 상위)")
            except Exception:
                continue
    except Exception:
        pass

    if not (out["promoted"] or out["demoted"] or out["hof_kept"]):
        _log(f"♻️ 승격/강등 대상 없음 (대기 검증 {out['validated_backlog']}건만)")
    return out


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    db.init_db()
    r = auto_lifecycle()
    print("결과:", r)
