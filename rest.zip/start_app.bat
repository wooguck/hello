@echo off
title Auto Trading App
cd /d %~dp0
echo.
echo ============================================
echo  Starting Auto Trading App
echo  - Autopilot starts automatically
echo  - 09:00-09:40 scalp (1min), then swing (3min)
echo  - Click LIVE button for realtime mode
echo  - Close window to stop.
echo ============================================
python desktop_app.py
pause
