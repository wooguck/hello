# -*- coding: utf-8 -*-
"""
📕 손실 교훈 노트 (loss_lessons.py) - 2026-08-28 추가
================================================================
발상의 전환: "이기는 법을 찾지 말고, 지는 패턴을 피하자"
(같은 수익률 개선이라도 승자 연구보다 패자 회피가 보통 더 잘 일반화됨)

하는 일:
  손실 거래들(-1% 이하 청산)의 매수 시점 공통 특징을 자동 집계:
    ① 매수 시각대 (09시대/10시대/.../14시대)
    ② 매수 요일
    ③ 채널별 손실 집중도
    ④ 진입 시 지수 상황 (entry_index_pct)
    ⑤ 보유 시간 (몇 분/일 만에 죽었나)
  → 승리 거래와 비율 비교 → "손실이 유의미하게 몰리는 조건" 도출
  → 표본 충분(각 30건+)하고 손실 집중이 뚜렷(승:패 1:2 이상)하면
    '매수 금지 시간대/조건' 제안 (자동 적용 아님 - 사용자 승인제)

실행: python loss_lessons.py
"""
import argparse
import sys
from collections import defaultdict

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

MIN_SAMPLE = 30       # 판단 최소 표본 (전체)
MIN_BUCKET = 8        # 구간별 최소 표본


def _log(m=""):
    print(m, flush=True)


def report(days=60, log_fn=None):
    def L(m):
        _log(m)
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    with db.get_conn() as conn:
        rows = conn.execute(
            "SELECT cond_key, symbol, entry_time, exit_time, ret_pct, entry_index_pct "
            "FROM paper_positions WHERE status='closed' "
            "AND exit_time > datetime('now', ?)", (f"-{days} days",)).fetchall()
    wins = [dict(r) for r in rows if (r["ret_pct"] or 0) > 0.5]
    losses = [dict(r) for r in rows if (r["ret_pct"] or 0) < -1.0]
    L("=" * 62)
    L(f"📕 손실 교훈 노트 (최근 {days}일 · 승리 {len(wins)} vs 손실 {len(losses)})")
    L("=" * 62)
    if len(wins) + len(losses) < MIN_SAMPLE:
        L(f"  표본 {len(wins)+len(losses)}건 < {MIN_SAMPLE} - 아직 교훈 뽑기 이름")
        L("  (모의매매가 쌓이면 '지는 패턴'이 여기 나타납니다)")
        return []

    def bucket(rows_, fn):
        d = defaultdict(int)
        for r in rows_:
            k = fn(r)
            if k is not None:
                d[k] += 1
        return d

    def hour_of(r):
        try:
            return str(r["entry_time"])[11:13] + "시"
        except Exception:
            return None

    def weekday_of(r):
        try:
            import datetime as dt
            return "월화수목금토일"[dt.datetime.fromisoformat(str(r["entry_time"])[:19]).weekday()]
        except Exception:
            return None

    def channel_of(r):
        ck = str(r["cond_key"] or "")
        return ck if ck in ("AI_PICK", "MOMENTUM", "FORCE_LINE", "BASELINE", "THEME", "MANUAL") \
            else "SCALP" if ck.startswith(("SCALP", "LIVE")) else "조건식"

    def index_of(r):
        v = r.get("entry_index_pct")
        if v is None:
            return None
        return "지수하락중" if v < -0.5 else "지수상승중" if v > 0.5 else "지수보합"

    lessons = []
    for name, fn in (("매수 시각", hour_of), ("요일", weekday_of),
                     ("채널", channel_of), ("진입 시 지수", index_of)):
        w, l = bucket(wins, fn), bucket(losses, fn)
        keys = sorted(set(w) | set(l))
        L(f"\n  [{name}]  (승리:손실)")
        for k in keys:
            wn, ln = w.get(k, 0), l.get(k, 0)
            tot = wn + ln
            if tot < MIN_BUCKET:
                L(f"    {k:8s} {wn:3d}:{ln:<3d} (표본부족)")
                continue
            loss_rate = ln / tot * 100
            flag = ""
            if ln >= wn * 2 and ln >= MIN_BUCKET:
                flag = " 🔴 손실 집중!"
                lessons.append({"dim": name, "bucket": k, "win": wn, "loss": ln,
                                "loss_rate": round(loss_rate, 1)})
            elif wn >= ln * 2 and wn >= MIN_BUCKET:
                flag = " 🟢 승률 우수"
            L(f"    {k:8s} {wn:3d}:{ln:<3d} 손실률 {loss_rate:.0f}%{flag}")

    L("")
    if lessons:
        L("  📌 제안 (자동 적용 안 함 - 승인제):")
        for x in lessons:
            L(f"    · [{x['dim']}] '{x['bucket']}' 구간 매수 재검토 "
              f"(손실 {x['loss']}건 vs 승리 {x['win']}건)")
        L("    → 원하시면 해당 구간 매수 금지 필터를 넣어드립니다")
    else:
        L("  ✅ 뚜렷하게 지는 패턴 없음 (또는 표본 더 필요)")
    return lessons


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=60)
    args = ap.parse_args()
    db.init_db()
    report(days=args.days)
