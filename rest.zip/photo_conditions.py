"""
사진 조건검색식 대량 테스트 (photo_conditions.py)
==================================================
사용자가 올린 조건검색식 사진 60장(사진_텍스트추출_전체정리.md)에서 추출한
대표 조건식들을 템플릿으로 등록하고, 그대로 + 파라미터 변형해서 대량 백테스트합니다.

"이거를 먼저 테스트하고 다른 것들도 점검" 요청 반영:
- 사진 기반 템플릿을 최우선 테스트 (이 파일이 1순위)
- 템플릿 그대로 + 각 파라미터를 변형한 변형체까지 생성 → 수백~수천 개 대량 테스트
- 결과는 screener_results에 저장되어 AI 스크리너/모의 실전과 연동

실행:
    python photo_conditions.py --batch 300          # 템플릿+변형 대량 테스트
    python photo_conditions.py --templates          # 템플릿 목록만
"""
import json
import logging
import random
import time
from concurrent.futures import ThreadPoolExecutor

import db
from config import CFG
from screener import (SLOTS, slot_txt, evaluate_screen, load_features,
                      load_screener_symbols, FEE)

log = logging.getLogger("photo")

# ── ★ 사진 조건식 템플릿 (사진 1~60에서 추출, 슬롯 조합으로 표현) ──
# 각 항목: {name, photo, desc, slots:[(슬롯키, 파라미터)], vars:{슬롯키: 파라미터변형 후보}}
PHOTO_TEMPLATES = [
    {"name": "대체거래소 매수(사진1)", "photo": 1,
     "tf": "min3",
     "desc": "10/20이평 상승 + 10>20>50 정배열 + 거래대금",
     "slots": [("ma_rising", {"n": 10}), ("ma_rising", {"n": 20}),
               ("ma_align_10_20_50", {}), ("vol_ratio20", {"x": 1.5})],
     "vars": {"vol_ratio20": [{"x": 1.5}, {"x": 2.0}, {"x": 3.0}]}},
    {"name": "린다 8020(사진2)", "photo": 2,
     "tf": "min3",
     "desc": "1봉 변동 7% + 저가매수 + RSI(3) 20이하 + 200이평 위",
     "slots": [("mom5_down", {"x": 8}), ("rsi_under", {"x": 30}),
               ("ma_above", {"n": 200}), ("vol_ratio20", {"x": 1.5})],
     "vars": {"rsi_under": [{"x": 25}, {"x": 30}, {"x": 34}]}},
    {"name": "MACD 다중(사진3-4)", "photo": 3,
     "tf": "min15",
     "desc": "MACD Signal 상향돌파 + MACD 0선 위 + 등락률 7%↑",
     "slots": [("macd_signal_cross", {}), ("macd_above_zero", {}),
               ("mom5_up", {"x": 3}), ("vol_ratio20", {"x": 1.5})],
     "vars": {"mom5_up": [{"x": 2}, {"x": 3}, {"x": 5}]}},
    {"name": "당일상승 매니저(사진6)", "photo": 6,
     "tf": "day",
     "desc": "거래대금 250위 + 거래량 150% + RSI 상승 + (고저)/2 ≤ (고저종)/3",
     "slots": [("vol_surge", {"x": 1.5}), ("rsi_rising", {}),
               ("ma_above", {"n": 20}), ("high_break", {})],
     "vars": {"vol_surge": [{"x": 1.5}, {"x": 2.0}]}},
    {"name": "20EMA 눌림 후 돌파(사진7/19)", "photo": 7,
     "tf": "day",
     "desc": "20>50>200 정배열 + 1봉전 눌림 + 골든크로스 + 5이평 위",
     "slots": [("ma_align_20_50_200", {}), ("below_ma_prev", {"n": 20}),
               ("golden_cross", {"n": 1}), ("ma_above", {"n": 5})],
     "vars": {"below_ma_prev": [{"n": 20}, {"n": 50}]}},
    {"name": "MASS 검색기(사진8/10/11)", "photo": 8,
     "tf": "day",
     "desc": "MACD Signal 상승 + 스토캐스틱 %K상승 %K>%D + 20이평 상승 + 50이평 위",
     "slots": [("macd_signal_rising", {}), ("stoch_k_rising", {}),
               ("stoch_k_above_d", {}), ("ma_rising", {"n": 20}),
               ("ma_above", {"n": 50})],
     "vars": {}},
    {"name": "퀀트 알고리즘(사진9)", "photo": 9,
     "tf": "min3",
     "desc": "RSI 74이하 + 5/20이평 위 + 거래량 200% + 20봉 최고종가 + 10>20>50>200",
     "slots": [("rsi_under", {"x": 74}), ("ma_above", {"n": 20}),
               ("vol_ratio20", {"x": 2.0}), ("chigh20", {}),
               ("ma_align_10_20_50", {}), ("chg_under", {"x": 3})],
     "vars": {"vol_ratio20": [{"x": 2.0}, {"x": 3.0}]}},
    {"name": "단타강한종목(사진16)", "photo": 16,
     "tf": "day",
     "desc": "5봉 최고종가 + 60/120이평 위 + 60봉 신고가 + 거래대금",
     "slots": [("chigh5", {}), ("ma_above", {"n": 60}),
               ("high60_break", {}), ("vol_ratio20", {"x": 1.5})],
     "vars": {"vol_ratio20": [{"x": 1.5}, {"x": 2.0}]}},
    {"name": "ICT N파동(사진17)", "photo": 17,
     "tf": "min3",
     "desc": "시가<종가 + 5일 하락 후 반등 + 3분 고가돌파(일봉 근사)",
     "slots": [("mom5_down", {"x": 5}), ("chg_under", {"x": 8}),
               ("prev_high_break", {}), ("ma_above", {"n": 5})],
     "vars": {"mom5_down": [{"x": 5}, {"x": 8}]}},
    {"name": "%정배열 이평밀집(사진29/30)", "photo": 29,
     "tf": "day",
     "desc": "20>60>120 + 5봉 신고가 + 이격도 밀집 + 골든크로스 + 5이평 상승",
     "slots": [("ma_align_20_60_120", {}), ("high5_break", {}),
               ("disp_tight", {"x": 2}), ("golden_cross", {"n": 1}),
               ("ma_rising", {"n": 5})],
     "vars": {"disp_tight": [{"x": 1}, {"x": 2}, {"x": 5}]}},
    {"name": "일목 구름대 돌파(사진33)", "photo": 33,
     "tf": "day",
     "desc": "RSI 상승 + 20이평 위 + 거래대금 (선행스팬을 20/60이평으로 근사)",
     "slots": [("rsi_rising", {}), ("ma_above", {"n": 20}),
               ("ma_above", {"n": 60}), ("vol_ratio20", {"x": 1.5})],
     "vars": {}},
    {"name": "RSI 전략(사진34)", "photo": 34,
     "tf": "day",
     "desc": "1봉전 RSI 34이하 + RSI 상승반전",
     "slots": [("rsi_under", {"x": 34}), ("rsi_rising", {}),
               ("ma_above", {"n": 5}), ("vol_ratio20", {"x": 1.5})],
     "vars": {"rsi_under": [{"x": 30}, {"x": 34}, {"x": 40}]}},
    {"name": "삼선전환(사진35)", "photo": 35,
     "tf": "month",
     "desc": "MACD Osc 상승 + 5이평 상승 + 스토캐스틱 %K 상승 + 등락률 10%이하",
     "slots": [("macd_osc_rising", {}), ("ma_rising", {"n": 5}),
               ("stoch_k_rising", {}), ("chg_under", {"x": 10})],
     "vars": {}},
    {"name": "S봉후 낌봉(사진38)", "photo": 38,
     "tf": "day",
     "desc": "11봉내 상승 10% + 5>10>15>20 정배열 + 120봉 신고가 + MACD 0위",
     "slots": [("period_rise", {"N": 11, "x": 10}), ("ma_align_5_10_15", {}),
               ("high20_break", {}), ("macd_above_zero", {}),
               ("ma_rising", {"n": 10})],
     "vars": {"period_rise": [{"N": 11, "x": 10}, {"N": 5, "x": 5}]}},
    {"name": "S봉후 방향성(사진44)", "photo": 44,
     "tf": "day",
     "desc": "16봉내 상승 10% + 20/45이평 상승 + MACD Signal 상승 + 5봉 신고거래량",
     "slots": [("period_rise", {"N": 16, "x": 10}), ("ma_rising", {"n": 20}),
               ("macd_signal_rising", {}), ("vol_high5", {}),
               ("high20_break", {})],
     "vars": {}},
    {"name": "엔벨위 첫5일선이탈(사진47)", "photo": 47,
     "tf": "day",
     "desc": "10봉내 상승 + 60봉 신고가 + 엔벨로프 상한 + 5일선 데드크로스",
     # ★ 수정: 데드크로스를 '3봉 내'로 (당일 데드+10일선 상승 동시는 거의 불가→0건이던 원인)
     "slots": [("period_rise", {"N": 10, "x": 10}), ("high60_break", {}),
               ("env_break", {"p": 5}), ("dead_cross_1_5", {"n": 3}),
               ("ma_rising", {"n": 10})],
     "vars": {"env_break": [{"p": 2}, {"p": 5}]}},
    {"name": "쌍바닥(사진49)", "photo": 49,
     "tf": "day",
     "desc": "60<120<240 + 20<10<5 역배열 + 60이평 위 + 150봉 신저가 근접 + 5봉내 반등",
     "slots": [("ma_below_rev", {"n": 240}), ("ma_below_rev", {"n": 120}),
               ("ma_above", {"n": 60}), ("low_near", {"N": 150, "x": 30}),
               ("period_rise", {"N": 5, "x": 5})],
     "vars": {"low_near": [{"N": 150, "x": 30}, {"N": 60, "x": 30}]}},
    {"name": "7쌍바닥(사진50)", "photo": 50,
     "tf": "day",
     "desc": "7/28 데드 후 골든 + 224/56/7이평 위",
     # ★ 수정: 원본 의미대로 '10봉 내 데드 후 오늘 골든' (당일 골든+데드 동시는 논리모순→0건)
     "slots": [("golden_cross_1_5", {"n": 1}), ("dead_cross_1_5", {"n": 10}),
               ("ma_above", {"n": 60}), ("ma_above", {"n": 7})],
     "vars": {"dead_cross_1_5": [{"n": 5}, {"n": 10}]}},
    {"name": "피델릭스(사진53)", "photo": 53,
     "tf": "day",
     "desc": "2연속 양봉 + 5봉 신고가/최고종가/신고거래량 + 20이평 위 + 2일 연속증가",
     "slots": [("up_candles", {"n": 2}), ("high5_break", {}),
               ("vol_high5", {}), ("chigh5", {}), ("ma_above", {"n": 20}),
               ("vol_2day_up", {})],
     "vars": {"up_candles": [{"n": 1}, {"n": 2}]}},
    {"name": "5일선(사진56)", "photo": 56,
     "tf": "day",
     "desc": "5이평 상승 + 볼린저 상한 돌파 + 9봉/26봉 신고가",
     "slots": [("ma_rising", {"n": 5}), ("boll_break_up", {}),
               ("high5_break", {}), ("chigh20", {})],
     "vars": {}},
    {"name": "황제주 찾기(사진13/18)", "photo": 13,
     "tf": "day",
     "desc": "5/10이평 정배열 + 연속상승 + 480봉 고가대비 -50%~-15% (저평가 대형주)",
     "slots": [("ma_align", {}), ("up_candles", {"n": 2}),
               ("fall_from_high250", {"x": 30}), ("ma_above", {"n": 20})],
     "vars": {"fall_from_high250": [{"x": 15}, {"x": 30}, {"x": 50}]}},
]


def template_slots(tpl, variant=None):
    """템플릿 슬롯에 변형(variant: {슬롯키: 대체 파라미터 dict}) 적용"""
    slots = []
    for k, p in tpl["slots"]:
        if variant and k in variant:
            p = {**p, **variant[k]}
        slots.append((k, p))
    return slots


def template_txt(slots):
    return " AND ".join(slot_txt(k, p) for k, p in slots)


def build_screens(batch=300, rng=None):
    """사진 템플릿 그대로 + 파라미터 변형체 → 대량 조건식 목록 (중복 제거)"""
    if rng is None:
        rng = random
    screens = []
    # 1) 템플릿 원본 (우선)
    for tpl in PHOTO_TEMPLATES:
        slots = template_slots(tpl)
        screens.append({"slots": slots, "txt": template_txt(slots),
                        "key": json.dumps(slots, sort_keys=True), "tpl": tpl["name"], "photo": tpl["photo"]})
    # 2) 변형체: 각 템플릿의 vars 조합 + 슬롯 일부 교체/파라미터 변형
    attempts = 0
    while len(screens) < batch and attempts < batch * 6:
        attempts += 1
        tpl = rng.choice(PHOTO_TEMPLATES)
        slots = template_slots(tpl)
        # 변형 1: vars에 있는 슬롯 파라미터 교체
        if tpl.get("vars"):
            vk = rng.choice(list(tpl["vars"].keys()))
            slots = template_slots(tpl, {vk: rng.choice(tpl["vars"][vk])})
        # 변형 2: 슬롯 1개 무작위 교체 (같은 성격 다른 슬롯으로)
        if rng.random() < 0.3:
            i = rng.randrange(len(slots))
            slots[i] = (rng.choice(list(SLOTS.keys())), {})
        txt = template_txt(slots)
        screens.append({"slots": slots, "txt": txt,
                        "key": json.dumps(slots, sort_keys=True), "tpl": tpl["name"], "photo": tpl["photo"]})
    # 중복 제거
    seen, uniq = set(), []
    for sc in screens:
        if sc["key"] not in seen:
            seen.add(sc["key"])
            uniq.append(sc)
    return uniq


def run_photo_test(batch=300, hold_days=5, max_symbols=400, oos=True):
    """★ 사진 조건식 대량 테스트: 템플릿+변형 → 전 종목 평가 → 상위 정렬/저장"""
    t0 = time.time()
    symbols = load_screener_symbols(max_symbols=max_symbols)
    feats = load_features(symbols, max_symbols=max_symbols)
    if not feats:
        return {"tested": 0, "results": [], "note": "일봉 데이터 부족 - 백필 진행 후 재시도"}
    screens = build_screens(batch=batch)
    def _eval(sc):
        return {**sc, **evaluate_screen(feats, sc["slots"], hold_days=hold_days,
                                        split="train" if oos else None)}
    results = []
    if len(screens) <= 8:
        for sc in screens:
            results.append(_eval(sc))
    else:
        with ThreadPoolExecutor(max_workers=8) as ex:
            results = list(ex.map(_eval, screens))
    def _score(r):
        if r["signal_count"] < 20:
            return -1
        if r["win_rate"] < 50:
            return -1
        return r["win_rate"] * max(min(r["avg_ret"], 0.10), -0.20) * min(1, r["signal_count"] / 100)
    results.sort(key=lambda r: -_score(r))
    if oos:
        for r in results[:15]:
            o = evaluate_screen(feats, r["slots"], hold_days=hold_days, split="test")
            r["oos_signal"] = o["signal_count"]
            r["oos_win_rate"] = o["win_rate"]
            r["oos_avg"] = o["avg_ret"]
            r["oos_pf"] = o["pf"]
            r["oos_pass"] = o["signal_count"] >= 15 and o["win_rate"] >= 50 and o["avg_ret"] > 0
    # DB 저장
    try:
        rid = db.save_screener_run({"batch": batch, "hold_days": hold_days,
                                    "symbols": len(feats), "source": "photo",
                                    "note": "사진 조건식 템플릿 테스트"})
        for r in results[:100]:
            db.save_screener_result(rid, r["key"], r["txt"], r["slots"],
                                    r["signal_count"], r["win_rate"], r["avg_ret"],
                                    r["total_return"], r["pf"], round(r.get("bench_diff", 0), 4),
                                    oos_pass=r.get("oos_pass"), oos_win_rate=r.get("oos_win_rate"),
                                    oos_avg=r.get("oos_avg"))
    except Exception as e:
        log.warning(f"사진 조건식 결과 저장 실패: {e}")
    el = time.time() - t0
    note = (f"[사진 조건식] 템플릿 {len(PHOTO_TEMPLATES)}개 + 변형 {len(screens)}개 × {len(feats)}종목 · "
            f"{hold_days}일 보유 · 수수료 {FEE*100:.1f}% · OOS{' 적용' if oos else ''} · {el:.0f}초")
    return {"tested": len(screens), "results": results[:30], "good": [r for r in results if r.get("oos_pass")],
            "note": note, "templates": len(PHOTO_TEMPLATES), "elapsed": round(el, 1)}


def list_templates():
    """템플릿 목록 출력"""
    lines = [f"📷 사진 조건식 템플릿 {len(PHOTO_TEMPLATES)}개", "=" * 60]
    for t in PHOTO_TEMPLATES:
        lines.append(f"[사진{t['photo']}] {t['name']}")
        lines.append(f"   {t['desc']}")
        lines.append(f"   → {template_txt(template_slots(t))}")
    return "\n".join(lines)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="사진 조건검색식 대량 테스트")
    parser.add_argument("--batch", type=int, default=300)
    parser.add_argument("--templates", action="store_true")
    parser.add_argument("--hold", type=int, default=5)
    args = parser.parse_args()
    db.init_db()
    logging.basicConfig(level=logging.INFO)
    if args.templates:
        print(list_templates())
    else:
        res = run_photo_test(batch=args.batch, hold_days=args.hold)
        print("\n" + res["note"])
        print("=" * 70)
        print(f"{'승률':>6} {'손익비':>6} {'평균%':>8} {'샘플':>6} {'OOS':>5}  조건식(사진)")
        for r in res["results"][:20]:
            oos = "✅" if r.get("oos_pass") else "-"
            tpl = r.get("tpl", "")[:16]
            print(f"{r['win_rate']:>6.1f} {r['pf']:>6.2f} {r['avg_ret']*100:>8.2f} "
                  f"{r['signal_count']:>6} {oos:>5}  [{tpl}] {r['txt'][:44]}")
