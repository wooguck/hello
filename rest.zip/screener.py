"""
조건식 스크리너 - 키움 조건검색식과 같은 환경의 자동 대량 테스트
================================================================
영웅문 조건검색식에 들어가는 조건들(이동평균/거래량/RSI/모멘텀/신고가 등)을
"조건 슬롯"으로 구현하고, 파라미터를 자동으로 변형해가며 수백~수천 개의
조건식을 한 번에 백테스트합니다.

동작 루프 (사용자 요청 - "동일한 환경에서 자동 변형 + 대량 테스트 + 검산 + 또 바꾸고"):
  1) 조건 슬롯 3개를 조합해 조건식 생성 (파라미터는 범위에서 샘플)
  2) 전 종목 일봉 지표를 미리 계산(캐시) 후, 각 조건식을 모든 종목×날짜에 평가
  3) 신호 발생 시점의 5일(또는 3일) 후 수익률로 승률/손익비/수익 집계 (수수료 차감)
  4) 상위 결과는 DB 저장, 다음 라운드에서 상위 조건식 파라미터를 변형(유전)해 재검산
  5) 사용자가 PC에서 조건 풀/파라미터 범위를 조정 가능 (.env/설정)

실행:
    python screener.py --batch 300          # 조건식 300개 생성·테스트
    python screener.py --batch 1000 --evolve  # 상위 기반 변형 1000개
"""
import json
import logging
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import random
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

import db
from config import CFG

log = logging.getLogger("screener")

FEE = float(getattr(CFG, "FEE_ROUND_TRIP_PCT", 0.2)) / 100.0

# ── 조건 슬롯 라이브러리 (영웅문 조건검색식 스타일) ────────────────
# 각 슬롯: (설명, 파라미터 범위, 평가함수(feats, i, p) -> bool)
# feats: {key: [시계열]} - build_features() 출력, i: 날짜 인덱스(최신=끝)

def _slot_ma_above(f, i, p):
    n = p.get("n", 20)
    return i >= n and f["close"][i] > f[f"ma{n}"][i]

def _slot_ma_below(f, i, p):
    n = p.get("n", 20)
    return i >= n and f["close"][i] < f[f"ma{n}"][i]

def _slot_vol_surge(f, i, p):
    x = p.get("x", 2.0)
    return i >= 1 and f["vol_prev"][i] >= x and f["volume"][i] > 0

def _slot_vol_ratio20(f, i, p):
    x = p.get("x", 2.0)
    return f["vol_ratio20"][i] >= x

def _slot_rsi_oversold(f, i, p):
    x = p.get("x", 30)
    v = f["rsi14"][i]
    return v is not None and v < x

def _slot_rsi_overbought(f, i, p):
    x = p.get("x", 70)
    v = f["rsi14"][i]
    return v is not None and v > x

def _slot_mom5_up(f, i, p):
    x = p.get("x", 3) / 100.0
    return f["mom5"][i] >= x

def _slot_mom5_down(f, i, p):
    x = abs(p.get("x", 5)) / 100.0
    return f["mom5"][i] <= -x

def _slot_high_break(f, i, p):
    return f["high20_r"][i] >= 0.99  # 20일 고가 99% 이상

def _slot_low_rebound(f, i, p):
    return f["low20_r"][i] <= 1.02 and f["chg"][i] > 0  # 20일 저가 근접 + 오늘 상승

def _slot_fall_from_high60(f, i, p):
    x = abs(p.get("x", 30)) / 100.0
    return f["high60r"][i] <= -x

def _slot_golden_cross(f, i, p):
    n = p.get("n", 1)
    for k in range(max(1, i - n), i + 1):
        if f["ma5"][k] > f["ma10"][k] and f["ma5"][k - 1] <= f["ma10"][k - 1]:
            return True
    return False

def _slot_ma_align(f, i, p):
    return i >= 20 and f["ma5"][i] > f["ma10"][i] > f["ma20"][i] and f["close"][i] > f["ma5"][i]

def _slot_vol_2day_up(f, i, p):
    return i >= 1 and f["volume"][i] > f["volume"][i - 1] and (i < 2 or f["volume"][i - 1] > f["volume"][i - 2])

SLOTS = {
    "ma_above":       ("이동평균선 위 (MA{n})", ["n"], [5, 10, 20, 60], _slot_ma_above),
    "ma_below":       ("이동평균선 아래 (MA{n})", ["n"], [5, 10, 20, 60], _slot_ma_below),
    "vol_surge":      ("거래량 전일대비 {x}배↑", ["x"], [1.5, 2.0, 3.0, 5.0], _slot_vol_surge),
    "vol_ratio20":    ("거래량 20일평균대비 {x}배↑", ["x"], [1.5, 2.0, 3.0], _slot_vol_ratio20),
    "rsi_oversold":   ("RSI(14) {x} 이하 (과매도)", ["x"], [25, 30, 35, 40], _slot_rsi_oversold),
    "rsi_overbought": ("RSI(14) {x} 이상 (과매수)", ["x"], [60, 65, 70, 75], _slot_rsi_overbought),
    "mom5_up":        ("5일 수익률 +{x}%↑ (모멘텀)", ["x"], [2, 3, 5, 8], _slot_mom5_up),
    "mom5_down":      ("5일 수익률 -{x}%↓ (하락)", ["x"], [5, 8, 10], _slot_mom5_down),
    "high_break":     ("20일 신고가 돌파 (99%↑)", [], [], _slot_high_break),
    "low_rebound":    ("20일 저점 근접 + 반등", [], [], _slot_low_rebound),
    "fall_from_high60": ("60일 고가 대비 -{x}%↓ (낙폭)", ["x"], [20, 30, 40], _slot_fall_from_high60),
    "golden_cross":   ("골든크로스 (MA5>MA10, 최근 {n}일)", ["n"], [1, 2, 3], _slot_golden_cross),
    "ma_align":       ("이동평균 정배열 (5>10>20)", [], [], _slot_ma_align),
    "vol_2day_up":    ("거래량 2일 연속 증가", [], [], _slot_vol_2day_up),
    "vp_break":       ("최대 매물대 상단 돌파 (60봉)", [], [],
                       lambda f, i, p: bool(f.get("vp_break") and f["vp_break"][i])),
    # ── ★ 사진 조건검색식용 슬롯 (사진 1~60에서 추출) ──
    "ma_align_20_50_200": ("장기 정배열 (20>50>200)", [], [],
                           lambda f, i, p: i >= 199 and f["ma20"][i] is not None
                           and f["ma20"][i] > f["ma50"][i] > f["ma200"][i]),
    "ma_align_20_60_120": ("장기 정배열 (20>60>120)", [], [],
                           lambda f, i, p: i >= 119 and f["ma20"][i] is not None
                           and f["ma20"][i] > f["ma60"][i] > f["ma120"][i]),
    "ma_align_10_20_50": ("정배열 (10>20>50)", [], [],
                          lambda f, i, p: i >= 49 and f["ma10"][i] is not None
                          and f["ma10"][i] > f["ma20"][i] > f["ma50"][i]),
    "ma_align_5_10_15": ("단기 정배열 (5>10>15)", [], [],
                         lambda f, i, p: i >= 14 and f["ma5"][i] is not None
                         and f["ma5"][i] > f["ma10"][i] > f["ma15"][i]),
    "ma_rising":      ("MA{n} 상승추세유지", ["n"], [5, 10, 20, 50],
                       lambda f, i, p: bool(f["ma_rising"].get(p["n"], [False])[i])),
    "below_ma_prev":  ("1봉전 종가 < MA{n} (눌림)", ["n"], [20, 50, 60],
                       lambda f, i, p: i >= 1 and f[f"ma{p['n']}"][i - 1] is not None
                       and f["close"][i - 1] < f[f"ma{p['n']}"][i - 1]),
    "rsi_under":      ("RSI {x} 이하", ["x"], [30, 34, 40, 50, 70, 74],
                       lambda f, i, p: f["rsi14"][i] is not None and f["rsi14"][i] <= p["x"]),
    "rsi_rising":     ("RSI 1봉 연속 상승", [], [], lambda f, i, p: f["rsi_rising"][i]),
    "macd_rising":    ("MACD 1봉 연속 상승", [], [], lambda f, i, p: f["macd_rising"][i]),
    "macd_signal_rising": ("MACD Signal 1봉 연속 상승", [], [],
                           lambda f, i, p: f["macd_signal_rising"][i]),
    "macd_osc_rising": ("MACD Osc 1봉 연속 상승", [], [], lambda f, i, p: f["macd_osc_rising"][i]),
    "macd_signal_cross": ("MACD Signal 상향돌파", [], [], lambda f, i, p: f["macd_signal_cross"][i]),
    "macd_above_zero": ("MACD 0선 위", [], [], lambda f, i, p: f["macd_above_zero"][i]),
    "boll_break_up":  ("볼린저(20,2) 상한 돌파", [], [],
                       lambda f, i, p: f["boll_up"][i] is not None and f["close"][i] > f["boll_up"][i]),
    "stoch_k_rising": ("스토캐스틱 %K 1봉 연속 상승", [], [], lambda f, i, p: f["stoch_k_rising"][i]),
    "stoch_k_above_d": ("스토캐스틱 %K > %D", [], [], lambda f, i, p: f["stoch_k_above_d"][i]),
    "stoch_k_under":  ("스토캐스틱 %K {x} 이하", ["x"], [20, 30, 50, 70],
                       lambda f, i, p: f["stoch_k"][i] is not None and f["stoch_k"][i] <= p["x"]),
    "high5_break":    ("5봉 신고가 (고가)", [], [], lambda f, i, p: f["high5_break"][i]),
    "high20_break":   ("20봉 신고가 (고가)", [], [], lambda f, i, p: f["high20_break"][i]),
    "high60_break":   ("60봉 신고가 (고가)", [], [], lambda f, i, p: f["high60_break"][i]),
    "high250_near":   ("250봉 신고가 -10% 이내 근접", [], [],
                       lambda f, i, p: f["high250_r"][i] >= 0.90),
    "chigh5":         ("종가 5봉 최고", [], [], lambda f, i, p: f["chigh5"][i]),
    "chigh20":        ("종가 20봉 최고", [], [], lambda f, i, p: f["chigh20"][i]),
    "low_near":       ("{N}봉 신저가 {x}% 이내 근접", ["N", "x"], [(60, 30), (150, 30), (20, 10)],
                       lambda f, i, p: f[f"low{p['N']}_r"][i] <= 1 + p["x"] / 100),
    "up_candles":     ("{n}봉 연속 양봉", ["n"], [1, 2, 3],
                       lambda f, i, p: f["up_candles"][i] >= p["n"]),
    "down_candles":   ("{n}봉 연속 음봉", ["n"], [1, 2], lambda f, i, p: f["down_candles"][i] >= p["n"]),
    "period_rise":    ("{N}봉이내 전일종가대비 +{x}% 이상", ["N", "x"], [(5, 5), (10, 9), (11, 10), (16, 10)],
                       lambda f, i, p: f[f"period_rise_{p['N']}"][i] >= p["x"]),
    "vol_high5":      ("5봉중 신고거래량", [], [], lambda f, i, p: f["vol_high5"][i]),
    "prev_high_break": ("전일 고가 상향돌파", [], [],
                        lambda f, i, p: i >= 1 and f["close"][i] > f["high"][i - 1]),
    "chg_under":      ("등락률 {x}% 이하 (추격방지)", ["x"], [3, 5, 8, 10],
                       lambda f, i, p: f["chg"][i] * 100 <= p["x"]),
    "disp_tight":     ("이격도(5,20) {x}% 이내 (밀집)", ["x"], [1, 2, 5],
                       lambda f, i, p: f["disp5_20"][i] is not None and abs(f["disp5_20"][i]) <= p["x"]),
    "env_break":      ("엔벨로프(20,{p}%) 상한 돌파", ["p"], [2, 5],
                       # ★ 버그 수정: f"env20_up{p}"는 dict가 통째로 들어가 KeyError→0건이었음
                       lambda f, i, p: f[f"env20_up{p['p']}"][i] is not None
                       and f["close"][i] > f[f"env20_up{p['p']}"][i]),
    # ★ N봉 이내 발생 문법 (키움 원본과 동일하게) - 기본 n=1이면 기존 '당일 발생'과 같음
    #   (사진50 쌍바닥처럼 골든+데드를 같이 쓰는 조건식은 '서로 다른 날 발생'이므로
    #    당일 기준으로는 논리 모순 → 영원히 0건이던 버그 수정)
    "dead_cross_1_5": ("1이평 5이평 데드크로스 ({n}봉내)", ["n"], [1, 3, 5, 10],
                       lambda f, i, p: any(
                           j >= 1 and f["ma1"][j] is not None and f["ma5"][j] is not None
                           and f["ma1"][j - 1] is not None and f["ma5"][j - 1] is not None
                           and f["ma1"][j] < f["ma5"][j] and f["ma1"][j - 1] >= f["ma5"][j - 1]
                           for j in range(max(1, i - (p.get("n", 1) - 1)), i + 1))),
    "golden_cross_1_5": ("1이평 5이평 골든크로스 ({n}봉내)", ["n"], [1, 3, 5, 10],
                         lambda f, i, p: any(
                             j >= 1 and f["ma1"][j] is not None and f["ma5"][j] is not None
                             and f["ma1"][j - 1] is not None and f["ma5"][j - 1] is not None
                             and f["ma1"][j] > f["ma5"][j] and f["ma1"][j - 1] <= f["ma5"][j - 1]
                             for j in range(max(1, i - (p.get("n", 1) - 1)), i + 1))),
    "ma1_above_60":   ("1이평 > 60이평", [], [],
                       lambda f, i, p: i >= 59 and f["ma1"][i] is not None and f["ma60"][i] is not None
                       and f["ma1"][i] > f["ma60"][i]),
    "ma1_above_120":  ("1이평 > 120이평", [], [],
                       lambda f, i, p: i >= 119 and f["ma1"][i] is not None and f["ma120"][i] is not None
                       and f["ma1"][i] > f["ma120"][i]),
    "ma_below_rev":   ("역배열 (MA{n} 아래, 하락추세)", ["n"], [60, 120, 240],
                       lambda f, i, p: i >= p["n"] - 1 and f[f"ma{p['n']}"][i] is not None
                       and f["close"][i] < f[f"ma{p['n']}"][i]),
    "fall_from_high250": ("250봉 고가 대비 -{x}%↓ (황제주 낙폭)", ["x"], [15, 30, 50],
                          lambda f, i, p: f["high250_r"][i] > 0 and (f["high250_r"][i] - 1) * 100 <= -abs(p["x"])),
}


def slot_txt(key, p):
    """조건식 텍스트 (예: '이동평균선 위 (MA20)')"""
    name, params, _vals, _fn = SLOTS[key]
    try:
        return name.format(**{k: p.get(k) for k in params})
    except Exception:
        return name


def make_screen(n_slots=3, rng=None, slot_pool=None, param_ranges=None):
    """조건식 1개 생성: 슬롯 n_slots개 (중복 없이) + 파라미터 샘플
    slot_pool: 사용할 슬롯 키 제한 (AI 지시) - None이면 전체
    param_ranges: {슬롯키: [허용값]} 파라미터 범위 제한 (AI 지시) - None이면 기본
    반환: {"slots": [(key, params), ...], "txt": "...", "key": 해시}
    """
    if rng is None:
        rng = random
    pool = list(SLOTS.keys()) if not slot_pool else [k for k in SLOTS if k in slot_pool]
    if len(pool) < 2:
        pool = list(SLOTS.keys())
    keys = rng.sample(pool, min(n_slots, len(pool)))
    slots = []
    for k in keys:
        name, params, vals, _fn = SLOTS[k]
        p = {}
        for prm in params:
            allowed = vals
            if param_ranges and k in param_ranges and param_ranges[k]:
                allowed = [v for v in vals if v in param_ranges[k]] or vals
            p[prm] = rng.choice(allowed)
        slots.append((k, p))
    txt = " AND ".join(slot_txt(k, p) for k, p in slots)
    return {"slots": slots, "txt": txt,
            "key": json.dumps(slots, sort_keys=True)}


def _ema_series(vals, w):
    """EMA 시계열 (앞부분 None)"""
    out = [None] * len(vals)
    k = 2.0 / (w + 1)
    e = None
    for i, v in enumerate(vals):
        e = v if e is None else v * k + e * (1 - k)
        out[i] = e
    return out


def resample_daily(bars, timeframe="day"):
    """★ 봉 기준 리샘플링: 일봉 → 주봉/월봉 (사진 조건식의 봉 기준 반영)
    bars: [{date, open, high, low, close, volume}] 오래된순
    timeframe: 'day'|'week'|'month' (분봉은 별도 경로 - scalp)
    반환: 리샘플된 bars (같은 형식, date=구간 끝 날짜)
    """
    if timeframe in (None, "", "day", "min1", "min3", "min5", "min15"):
        return bars  # 일봉/분봉은 그대로
    if len(bars) < 2:
        return bars
    out = []
    if timeframe == "week":
        # 주 단위 그룹 (월~일, date 기준 ISO 주)
        groups = {}
        order = []
        for b in bars:
            d = str(b.get("date", ""))[:10]
            try:
                from datetime import date as _d
                dt = _d.fromisoformat(d)
                key = dt.isocalendar()[:2]  # (ISO year, week)
            except Exception:
                key = d[:7]
            if key not in groups:
                groups[key] = []
                order.append(key)
            groups[key].append(b)
        for key in order:
            g = groups[key]
            out.append({"date": str(g[-1].get("date", ""))[:10],
                        "open": g[0].get("open") or g[0]["close"],
                        "high": max(b.get("high") or b["close"] for b in g),
                        "low": min(b.get("low") or b["close"] for b in g),
                        "close": g[-1]["close"],
                        "volume": sum(b.get("volume") or 0 for b in g)})
    elif timeframe == "month":
        groups = {}
        order = []
        for b in bars:
            d = str(b.get("date", ""))[:10]
            key = d[:7]  # YYYY-MM
            if key not in groups:
                groups[key] = []
                order.append(key)
            groups[key].append(b)
        for key in order:
            g = groups[key]
            out.append({"date": str(g[-1].get("date", ""))[:10],
                        "open": g[0].get("open") or g[0]["close"],
                        "high": max(b.get("high") or b["close"] for b in g),
                        "low": min(b.get("low") or b["close"] for b in g),
                        "close": g[-1]["close"],
                        "volume": sum(b.get("volume") or 0 for b in g)})
    return out


def build_features(bars):
    """
    일봉 시계열에서 조건 평가용 지표 계산 (전 종목 공유 캐시용)
    bars: [{close, high, low, open, volume}, ...] 오래된순 (open 없으면 close 대체)
    반환: {key: [시계열]} - 인덱스 = 날짜 (최신=끝), 값 None 가능
    """
    n = len(bars)
    if n < 25:
        return None
    close = [b["close"] for b in bars]
    high = [b["high"] or b["close"] for b in bars]
    low = [b["low"] or b["close"] for b in bars]
    op = [b.get("open") or b["close"] for b in bars]
    vol = [b["volume"] or 0 for b in bars]
    f = {"close": close, "high": high, "low": low, "open": op, "volume": vol}
    # 이동평균 (다양한 기간 - 사진 조건식용)
    # ★ 7/240 추가: 사진50(MA7)·사진49(MA240 역배열)가 피처 없음 → 0건이던 버그 수정
    for w in (1, 5, 7, 10, 15, 20, 50, 60, 120, 200, 240):
        f[f"ma{w}"] = [None] * n
        for i in range(n):
            if i >= w - 1:
                f[f"ma{w}"][i] = sum(close[i - w + 1:i + 1]) / w
    # RSI(14)
    f["rsi14"] = [None] * n
    gains, losses = [], []
    for i in range(1, n):
        ch = close[i] - close[i - 1]
        gains.append(max(0, ch))
        losses.append(max(0, -ch))
        if i >= 14:
            ag = sum(gains[i - 14:i]) / 14
            al = sum(losses[i - 14:i]) / 14
            f["rsi14"][i] = 100.0 if al == 0 else 100 - 100 / (1 + ag / al)
    # RSI 상승 여부
    f["rsi_rising"] = [False] * n
    for i in range(1, n):
        if f["rsi14"][i] is not None and f["rsi14"][i - 1] is not None:
            f["rsi_rising"][i] = f["rsi14"][i] > f["rsi14"][i - 1]
    # 모멘텀
    f["mom5"] = [0.0] * n
    f["chg"] = [0.0] * n
    for i in range(n):
        if i >= 5 and close[i - 5] > 0:
            f["mom5"][i] = close[i] / close[i - 5] - 1
        if i >= 1 and close[i - 1] > 0:
            f["chg"][i] = close[i] / close[i - 1] - 1
    # 거래량 지표
    f["vol_prev"] = [1.0] * n
    f["vol_ratio20"] = [0.0] * n
    f["vol_high5"] = [False] * n   # 5봉중 신고거래량
    for i in range(n):
        if i >= 1 and vol[i - 1] > 0:
            f["vol_prev"][i] = vol[i] / vol[i - 1]
        if i >= 20:
            avg20 = sum(vol[i - 20:i]) / 20
            f["vol_ratio20"][i] = vol[i] / avg20 if avg20 > 0 else 0
        if i >= 4:
            f["vol_high5"][i] = vol[i] >= max(vol[i - 4:i])
    # MACD(12,26,9)
    ema12 = _ema_series(close, 12)
    ema26 = _ema_series(close, 26)
    macd = [None] * n
    for i in range(n):
        if ema12[i] is not None and ema26[i] is not None:
            macd[i] = ema12[i] - ema26[i]
    sig_in = [m if m is not None else 0.0 for m in macd]
    macd_sig = _ema_series(sig_in, 9)
    f["macd"] = macd
    f["macd_signal"] = macd_sig
    f["macd_osc"] = [(m - s) if (m is not None and s is not None) else None
                     for m, s in zip(macd, macd_sig)]
    f["macd_rising"] = [False] * n
    f["macd_signal_rising"] = [False] * n
    f["macd_osc_rising"] = [False] * n
    f["macd_signal_cross"] = [False] * n  # MACD가 Signal 상향돌파
    f["macd_above_zero"] = [False] * n
    for i in range(1, n):
        if macd[i] is not None and macd[i - 1] is not None:
            f["macd_rising"][i] = macd[i] > macd[i - 1]
        if macd_sig[i] is not None and macd_sig[i - 1] is not None:
            f["macd_signal_rising"][i] = macd_sig[i] > macd_sig[i - 1]
        if f["macd_osc"][i] is not None and f["macd_osc"][i - 1] is not None:
            f["macd_osc_rising"][i] = f["macd_osc"][i] > f["macd_osc"][i - 1]
        if macd[i] is not None and macd_sig[i] is not None \
                and macd[i - 1] is not None and macd_sig[i - 1] is not None:
            f["macd_signal_cross"][i] = macd[i] > macd_sig[i] and macd[i - 1] <= macd_sig[i - 1]
    for i in range(n):
        if macd[i] is not None:
            f["macd_above_zero"][i] = macd[i] > 0
    # Bollinger(20,2)
    f["boll_up"] = [None] * n
    for i in range(n):
        if i >= 19:
            m = f["ma20"][i]
            sd = (sum((x - m) ** 2 for x in close[i - 19:i + 1]) / 20) ** 0.5
            f["boll_up"][i] = m + 2 * sd
    # Stochastic slow(12,5,5): %K = (C-LL12)/(HH12-LL12)*100, %D = %K 3기간 평균
    f["stoch_k"] = [None] * n
    for i in range(n):
        if i >= 11:
            ll = min(low[i - 11:i + 1])
            hh = max(high[i - 11:i + 1])
            f["stoch_k"][i] = (close[i] - ll) / (hh - ll) * 100 if hh > ll else 50.0
    ks = [k if k is not None else 50.0 for k in f["stoch_k"]]
    f["stoch_d"] = [sum(ks[max(0, i - 2):i + 1]) / (i + 1 - max(0, i - 2)) for i in range(n)]
    f["stoch_k_rising"] = [False] * n
    f["stoch_k_above_d"] = [False] * n
    for i in range(1, n):
        if f["stoch_k"][i] is not None and f["stoch_k"][i - 1] is not None:
            f["stoch_k_rising"][i] = f["stoch_k"][i] > f["stoch_k"][i - 1]
    for i in range(n):
        if f["stoch_k"][i] is not None and f["stoch_d"][i] is not None:
            f["stoch_k_above_d"][i] = f["stoch_k"][i] > f["stoch_d"][i]
    # Envelope 상한 (MA20 × (1+p/100))
    f["env20_up2"] = [None] * n
    f["env20_up5"] = [None] * n
    for i in range(n):
        if f["ma20"][i]:
            f["env20_up2"][i] = f["ma20"][i] * 1.02
            f["env20_up5"][i] = f["ma20"][i] * 1.05
    # 이격도(5,20)%
    f["disp5_20"] = [None] * n
    for i in range(n):
        if f["ma5"][i] and f["ma20"][i] and f["ma20"][i] > 0:
            f["disp5_20"][i] = (f["ma5"][i] / f["ma20"][i] - 1) * 100
    # 고가/저가 N봉 대비 + N봉 최고종가 + N봉 신고가/신저가
    # ★ 150 추가: 사진49 low_near(150봉 신저가) 피처 없음 → 0건이던 버그 수정
    for N in (5, 20, 60, 120, 150, 250):
        f[f"high{N}_r"] = [0.0] * n
        f[f"low{N}_r"] = [1.0] * n
        f[f"chigh{N}"] = [False] * n   # 종가가 N봉 최고
        for i in range(n):
            if i >= N - 1:
                h = max(high[i - N + 1:i + 1])
                l = min(low[i - N + 1:i + 1])
                f[f"high{N}_r"][i] = close[i] / h if h > 0 else 0
                f[f"low{N}_r"][i] = close[i] / l if l > 0 else 1
                f[f"chigh{N}"][i] = close[i] >= h
    # 고가 N봉 신고가 (고가 기준)
    f["high5_break"] = [False] * n
    f["high20_break"] = [False] * n
    f["high60_break"] = [False] * n
    for i in range(n):
        if i >= 4 and high[i] >= max(high[i - 4:i]):
            f["high5_break"][i] = True
        if i >= 19 and high[i] >= max(high[i - 19:i]):
            f["high20_break"][i] = True
        if i >= 59 and high[i] >= max(high[i - 59:i]):
            f["high60_break"][i] = True
    # ★ 매물대 돌파 (2026-08-28 사용자: "어떤 매물대 통과 시 오르는지 연구")
    #   최근 60봉의 가격대를 10구간으로 나눠 거래량 가중 분포(=매물대) 계산.
    #   '최대 매물대 상단'을 종가가 뚫은 날 = 위에 팔 사람이 없어진 자리 (돌파 가설)
    f["vp_break"] = [False] * n
    for i in range(60, n):
        win = range(i - 60, i)
        lo60 = min(low[j] for j in win)
        hi60 = max(high[j] for j in win)
        if hi60 <= lo60:
            continue
        buckets = [0.0] * 10
        for j in win:
            b = int((close[j] - lo60) / (hi60 - lo60 + 1e-9) * 9.99)
            buckets[max(0, min(9, b))] += vol[j] or 0
        top_b = buckets.index(max(buckets))
        top_price = lo60 + (hi60 - lo60) * (top_b + 1) / 10   # 최대 매물대 상단
        # 어제까지 매물대 아래/안 → 오늘 종가가 상단 돌파
        f["vp_break"][i] = (close[i] > top_price and close[i - 1] <= top_price)

    # N봉 연속 양봉 / 음봉
    # ★ 2026-08-27 버그 수정: 기존엔 양봉/음봉을 한 루프에서 같이 세고 보합에서만 멈춰서
    #   '연속'이 아니라 '누적 개수'가 됨 (56, 57, 58...) → up_candles>=2가 사실상 항상 참.
    #   올바른 정의: 최신 봉부터 거꾸로 '끊기지 않고' 이어진 양봉(음봉) 수
    f["up_candles"] = [0] * n
    f["down_candles"] = [0] * n
    for i in range(n):
        cnt_u = 0
        for j in range(i, -1, -1):
            if close[j] > op[j]:
                cnt_u += 1
            else:
                break
        cnt_d = 0
        for j in range(i, -1, -1):
            if close[j] < op[j]:
                cnt_d += 1
            else:
                break
        f["up_candles"][i] = cnt_u
        f["down_candles"][i] = cnt_d
    # N봉이내 기간 등락률 (전일종가 대비 최대 상승)
    # ★ 16 추가: 사진44 period_rise(N=16) 피처 없음 → 0건이던 버그 수정
    f["period_rise_5"] = [0.0] * n
    f["period_rise_10"] = [0.0] * n
    f["period_rise_11"] = [0.0] * n
    f["period_rise_16"] = [0.0] * n
    for i in range(n):
        for N, key in ((5, "period_rise_5"), (10, "period_rise_10"), (11, "period_rise_11"),
                       (16, "period_rise_16")):
            if i >= N:
                base = close[i - N]
                if base > 0:
                    f[key][i] = (close[i] / base - 1) * 100
    # 이평 상승 추세유지 (현재 > 직전)
    f["ma_rising"] = {w: [False] * n for w in (5, 10, 20, 50)}
    for w in (5, 10, 20, 50):
        for i in range(1, n):
            if f[f"ma{w}"][i] is not None and f[f"ma{w}"][i - 1] is not None:
                f["ma_rising"][w][i] = f[f"ma{w}"][i] > f[f"ma{w}"][i - 1]
    return f


def evaluate_screen(feats, slots, hold_days=5, fee=FEE, split=None):
    """
    조건식 1개를 모든 종목×날짜에 평가 → 신호 후 hold_days일 수익률 집계
    feats: {symbol: build_features 결과}
    split: None(전체) | "train"(앞 70%만 학습) | "test"(뒤 30%만 검증=표본 밖)
    반환: {signal_count, win_rate, avg_ret, total_return, pf, bench_diff}
    """
    import math
    rets = []
    bench = []
    for sym, f in feats.items():
        if not f:
            continue
        n = len(f["close"])
        # 표본 분할: train=앞 70% / test=뒤 30% (과적합 검증 - 신뢰의 핵심)
        i_lo, i_hi = 21, n - hold_days
        if split == "train":
            i_hi = int(n * 0.7) - hold_days
        elif split == "test":
            i_lo = max(21, int(n * 0.7))
        if i_hi <= i_lo:
            continue
        fns = [SLOTS[k][3] for k, _p in slots]
        prms = [p for _k, p in slots]
        vol = f.get("volume") or []
        for i in range(i_lo, i_hi):
            c0 = f["close"][i]
            if c0 <= 0 or c0 < CFG.MOCK_PRICE_MIN or c0 > CFG.MOCK_PRICE_MAX:
                continue
            # 가격 필터(800~10만)는 스크리너에서도 기본 적용
            # ★ 거래대금 필터 (2026-08-27): 5일평균 3억 미만 잡주는 실전에서 안 사므로 검증 제외
            #   (validation.py 실전-검증 일치 필터와 동일 기준 - 잡주 환상수익 차단)
            if i >= 5 and vol:
                amt5 = sum((f["close"][k] or 0) * (vol[k] or 0)
                           for k in range(i - 4, i + 1)) / 5
                if amt5 < _cfg_env_float("VALIDATE_MIN_AMOUNT", 300000000):
                    continue
            bench.append(f["close"][i + hold_days] / c0 - 1)
            hit = True
            for fn, p in zip(fns, prms):
                try:
                    if not fn(f, i, p):
                        hit = False
                        break
                except Exception:
                    hit = False
                    break
            if hit:
                rets.append(f["close"][i + hold_days] / c0 - 1 - fee)
    n_sig = len(rets)
    if n_sig == 0:
        return {"signal_count": 0, "win_rate": 0, "avg_ret": 0,
                "total_return": 0, "pf": 0, "bench_diff": 0}
    wins = [r for r in rets if r > 0]
    losses = [r for r in rets if r <= 0]
    gp = sum(wins)
    gl = abs(sum(losses))
    pf = gp / gl if gl > 0 else (999.0 if gp > 0 else 0)
    bench_avg = sum(bench) / len(bench) if bench else 0
    return {
        "signal_count": n_sig,
        "win_rate": round(len(wins) / n_sig * 100, 2),
        "avg_ret": round(sum(rets) / n_sig, 4),
        "total_return": round(sum(rets), 2),
        "pf": round(pf, 2),
        "bench_diff": round(sum(rets) / n_sig - bench_avg, 4),
    }


# ── 데이터 로드 (전 종목 일봉 → 지표 캐시) ─────────────────

def load_screener_symbols(max_symbols=400):
    """스크리닝 대상: 백필 일봉 있는 종목 우선 (부족 시 유니버스 일부 fetch)"""
    from strategy_auto import get_daily_series
    syms = []
    try:
        bars_map = db.get_latest_backfill_bars(limit_symbols=max_symbols)
        syms = list(bars_map.keys())
    except Exception:
        pass
    if len(syms) < 50:
        # 백필 부족 → 감시 풀/유니버스에서 fetch
        extra = []
        try:
            from engine import get_watch_candidates
            extra = [c["symbol"] for c in get_watch_candidates(limit=80)]
        except Exception:
            pass
        if not extra:
            try:
                extra = [u["symbol"] for u in db.get_universe()[:100]]
            except Exception:
                extra = []
        for s in extra:
            if s not in syms:
                syms.append(s)
        syms = syms[:max_symbols]
    return syms


def load_features(symbols, max_symbols=400, tf="day"):
    """종목별 지표 캐시 (백필 일봉, 부족 시 실시간 fetch)
    tf: 'day'|'week'|'month' — 주봉/월봉이면 일봉을 리샘플링해 평가 (사진 조건식 봉 기준 반영)
    """
    from strategy_auto import get_daily_series
    from backfill_history import fetch_daily
    out = {}
    for sym in symbols[:max_symbols]:
        bars = get_daily_series(sym, max_days=1000)
        if len(bars) < 30:
            try:
                fd = fetch_daily(sym, days=100)
                if len(fd) >= 30:
                    bars = [{"close": b["close"], "high": b["high"],
                             "low": b["low"], "volume": b["volume"]} for b in fd]
            except Exception:
                pass
        if len(bars) >= 30:
            # ★ 봉 기준 반영: 주봉/월봉 리샘플링 (일봉보다 봉 수 줄어듦 - 충분히 길게 요청)
            rbars = resample_daily(bars, tf)
            if len(rbars) >= 25:
                f = build_features(rbars)
            else:
                f = build_features(bars)  # 부족하면 일봉 폴백
            if f:
                f["tf"] = tf
                out[sym] = f
    return out


# ── 대량 실행 ─────────────────────────────────────────

def run_screener(batch=300, hold_days=5, evolve=False, top_keep=10, n_slots=3,
                 symbols=None, max_symbols=400, log_progress=True,
                 slot_pool=None, param_ranges=None, oos=True, source="daily"):
    """
    ★ 조건식 대량 백테스트 (AI 지시 방향 반영 가능)
    - batch개 조건식을 (슬롯 조합 + 파라미터 랜덤)으로 생성
    - slot_pool: 슬롯 키 제한 (AI 지시) / param_ranges: 파라미터 범위 제한 (AI 지시)
    - evolve=True면 직전 DB 상위 결과의 파라미터를 변형해 다음 라운드 생성 (자동 진화)
    - oos=True면 ★ 표본 밖 검증: 앞 70%(train)로 선정 → 뒤 30%(test)로 재검증 (과적합 방지 - 신뢰 핵심)
    - source='daily'|'minute': 일봉/분봉 모두 조건검색으로 검증 가능 (사용자 요청)
    반환: {run_id, batch, tested, signals, elapsed, bench_avg, results(top, oos 포함), note}
    """
    t0 = time.time()
    if symbols is None:
        symbols = load_screener_symbols(max_symbols=max_symbols)
    if source == "minute":
        feats = load_minute_features(symbols, max_symbols=max_symbols)
        if not feats:
            return {"run_id": None, "tested": 0, "signals": 0, "elapsed": 0,
                    "results": [], "note": "분봉 데이터 부족 - 백필(전 종목 분봉) 진행 후 재시도"}
        # 분봉은 조건 평가 함수가 다름
        return _run_minute_screener(batch, hold_days, evolve, top_keep, n_slots,
                                    symbols, feats, slot_pool, param_ranges, oos, t0)
    feats = load_features(symbols, max_symbols=max_symbols)
    if not feats:
        return {"run_id": None, "tested": 0, "signals": 0, "elapsed": 0,
                "results": [], "note": "일봉 데이터 부족 - 백필 진행 후 재시도"}
    n_sym = len(feats)
    bench = []
    for f in feats.values():
        for i in range(21, len(f["close"]) - hold_days):
            c0 = f["close"][i]
            if c0 > 0:
                bench.append(f["close"][i + hold_days] / c0 - 1)
    bench_avg = sum(bench) / len(bench) if bench else 0

    # 조건식 배치 생성 (AI 방향 반영: slot_pool/param_ranges)
    rng = random.Random(int(time.time()))
    screens = []
    if evolve:
        prev = db.get_screener_results(limit=top_keep)
        base = []
        for r in prev:
            try:
                base.append(json.loads(r["slots_json"]))
            except Exception:
                continue
        for _ in range(batch):
            if base and rng.random() < 0.7:
                sc = rng.choice(base)
                slots = []
                for k, p in sc:
                    if k not in SLOTS or (slot_pool and k not in slot_pool):
                        continue
                    name, params, vals, _fn = SLOTS[k]
                    np_ = dict(p)
                    for prm in params:
                        if rng.random() < 0.4:
                            allowed = vals
                            if param_ranges and k in param_ranges and param_ranges[k]:
                                allowed = [v for v in vals if v in param_ranges[k]] or vals
                            np_[prm] = rng.choice(allowed)
                    slots.append((k, np_))
                if len(slots) < 2:
                    slots = make_screen(n_slots, rng, slot_pool, param_ranges)["slots"]
                txt = " AND ".join(slot_txt(k, p) for k, p in slots)
                screens.append({"slots": slots, "txt": txt,
                                "key": json.dumps(slots, sort_keys=True)})
            else:
                screens.append(make_screen(n_slots, rng, slot_pool, param_ranges))
    else:
        for _ in range(batch):
            screens.append(make_screen(n_slots, rng, slot_pool, param_ranges))
    # 중복 제거
    seen, uniq = set(), []
    for sc in screens:
        if sc["key"] not in seen:
            seen.add(sc["key"])
            uniq.append(sc)
    screens = uniq

    # 병렬 평가 (학습 구간)
    def _eval(sc):
        return {**sc, **evaluate_screen(feats, sc["slots"], hold_days=hold_days,
                                        split="train" if oos else None)}
    results = []
    if len(screens) <= 8:
        for sc in screens:
            results.append(_eval(sc))
    else:
        with ThreadPoolExecutor(max_workers=min(8, len(screens))) as ex:
            results = list(ex.map(_eval, screens))

    # 정렬: 신호>=30 && 승률>=50% 우선, 샘플 가중
    def _score(r):
        if r["signal_count"] < 30:
            return -1
        if r["win_rate"] < 50:
            return -1
        return r["win_rate"] * max(min(r["avg_ret"], 0.10), -0.20) * min(1, r["signal_count"] / 100)
    results.sort(key=lambda r: -_score(r))

    # ★ 표본 밖(OOS) 검증: 상위 N개를 뒤 30% 구간에 재평가 (과적합이면 여기서 탈락)
    if oos:
        top_n = min(15, len(results))
        for r in results[:top_n]:
            o = evaluate_screen(feats, r["slots"], hold_days=hold_days, split="test")
            r["oos_signal"] = o["signal_count"]
            r["oos_win_rate"] = o["win_rate"]
            r["oos_avg"] = o["avg_ret"]
            r["oos_pf"] = o["pf"]
            # OOS에서도 신호 20+/승률 50%+ 여야 '검증 통과'로 표시
            r["oos_pass"] = o["signal_count"] >= 20 and o["win_rate"] >= 50 and o["avg_ret"] > 0
    good = [r for r in results if r["signal_count"] >= 30]

    # DB 저장
    run_id = None
    try:
        run_id = db.save_screener_run({"batch": batch, "hold_days": hold_days,
                                       "symbols": n_sym, "bench_avg": round(bench_avg, 4),
                                       "evolve": evolve, "oos": oos, "source": source,
                                       "slot_pool": slot_pool, "param_ranges": param_ranges})
        for r in results[:100]:
            db.save_screener_result(run_id, r["key"], r["txt"], r["slots"],
                                    r["signal_count"], r["win_rate"], r["avg_ret"],
                                    r["total_return"], r["pf"], round(r["bench_diff"], 4),
                                    oos_pass=r.get("oos_pass"), oos_win_rate=r.get("oos_win_rate"),
                                    oos_avg=r.get("oos_avg"))
    except Exception as e:
        log.warning(f"스크리너 결과 저장 실패: {e}")

    el = time.time() - t0
    total_sig = sum(r["signal_count"] for r in results)
    oos_txt = " · OOS 검증(뒤30%)" if oos else ""
    note = (f"조건식 {len(results)}개(중복제거) × {n_sym}종목 · {hold_days}일 보유 · "
            f"수수료 {FEE*100:.1f}% 차감 · 벤치마크 {bench_avg*100:+.2f}%{oos_txt} · {el:.0f}초")
    return {"run_id": run_id, "tested": len(results), "signals": total_sig,
            "elapsed": round(el, 1), "bench_avg": round(bench_avg, 4),
            "symbols": n_sym, "results": results[:30], "good": good[:15], "note": note,
            "oos": oos, "source": source}


# ── 분봉 조건식 검증 (모든 데이터는 조건검색으로 검증 가능 - 사용자 요청) ──

SLOTS_MINUTE = {
    "m_ret30": ("오전 30분 수익률 +{x}%↑", ["x"], [0.5, 1.0, 2.0],
                lambda f, i, p: f["ret30"][i] >= p["x"] / 100.0),
    "m_up3":   ("분봉 3연속 상승", [], [],
                lambda f, i, p: all(f["close"][j] > f["close"][j - 1] for j in range(i - 2, i + 1))),
    "m_vol_spike": ("분봉 거래량 전분기 대비 {x}배↑", ["x"], [2.0, 3.0, 5.0],
                    lambda f, i, p: f["volprev"][i] >= p["x"]),
    "m_high_break": ("당일 고가 갱신", [], [],
                     lambda f, i, p: f["close"][i] >= f["high"][i]),
    "m_ret60": ("장중 60분 수익률 +{x}%↑", ["x"], [1.0, 2.0, 3.0],
                lambda f, i, p: f["ret60"][i] >= p["x"] / 100.0),
    "m_vol_up": ("분봉 거래량 증가(전분 대비)", [], [],
                 lambda f, i, p: f["volprev"][i] > 1.2),
}


def build_minute_features(bars):
    """
    분봉 시계열 → 조건 평가용 지표 (분봉 조건식 검증용)
    bars: [{bar_time, price, volume}, ...] 오래된순
    반환: {key: [시계열]} - 당일 기준 인덱스 (같은 날 봉만 사용)
    """
    if not bars or len(bars) < 30:
        return None
    # 당일 봉만 (마지막 날짜)
    today = bars[-1]["bar_time"][:10]
    day = [b for b in bars if b["bar_time"][:10] == today]
    if len(day) < 30:
        return None
    close = [b["price"] for b in day]
    vol = [b.get("volume") or 0 for b in day]
    n = len(close)
    f = {"close": close, "volume": vol, "high": list(close)}
    f["ret30"] = [0.0] * n
    f["ret60"] = [0.0] * n
    f["volprev"] = [1.0] * n
    for i in range(n):
        if i >= 30 and close[i - 30] > 0:
            f["ret30"][i] = close[i] / close[i - 30] - 1
        if i >= 60 and close[i - 60] > 0:
            f["ret60"][i] = close[i] / close[i - 60] - 1
        if i >= 1 and vol[i - 1] > 0:
            f["volprev"][i] = vol[i] / vol[i - 1]
    return f


def load_minute_features(symbols, max_symbols=400):
    """분봉 종목별 지표 캐시 (data/minutes_*.db)"""
    out = {}
    for sym in symbols[:max_symbols]:
        bars = db.get_minute_bars(sym, days=8)
        f = build_minute_features(bars)
        if f:
            out[sym] = f
    return out


def _run_minute_screener(batch, hold_days, evolve, top_keep, n_slots, symbols, feats,
                         slot_pool, param_ranges, oos, t0):
    """분봉 조건식 스크리너 (당일 장중 신호 → 이후 60분 수익률 집계)"""
    rng = random.Random(int(time.time()))
    pool = list(SLOTS_MINUTE.keys()) if not slot_pool else \
        [k for k in SLOTS_MINUTE if k in slot_pool]
    if len(pool) < 2:
        pool = list(SLOTS_MINUTE.keys())
    screens = []
    for _ in range(batch):
        keys = rng.sample(pool, min(n_slots, len(pool)))
        slots = []
        for k in keys:
            name, params, vals, _fn = SLOTS_MINUTE[k]
            p = {}
            for prm in params:
                allowed = vals
                if param_ranges and k in param_ranges and param_ranges[k]:
                    allowed = [v for v in vals if v in param_ranges[k]] or vals
                p[prm] = rng.choice(allowed)
            slots.append((k, p))
        txt = " AND ".join(f"{SLOTS_MINUTE[k][0].format(**dict(zip(SLOTS_MINUTE[k][1], p.values())))}"
                           if SLOTS_MINUTE[k][1] else SLOTS_MINUTE[k][0]
                           for k, p in slots)
        screens.append({"slots": slots, "txt": txt, "key": json.dumps(slots, sort_keys=True)})
    seen, uniq = set(), []
    for sc in screens:
        if sc["key"] not in seen:
            seen.add(sc["key"])
            uniq.append(sc)
    screens = uniq

    hold = max(10, hold_days)  # 분봉은 10~60분 후 수익률 (5일 아님)
    rets_by_screen = []
    for sc in screens:
        rets, bench = [], []
        for sym, f in feats.items():
            n = len(f["close"])
            for i in range(1, n - hold):
                c0 = f["close"][i]
                if c0 <= 0 or c0 < CFG.MOCK_PRICE_MIN or c0 > CFG.MOCK_PRICE_MAX:
                    continue
                bench.append(f["close"][i + hold] / c0 - 1)
                hit = all(SLOTS_MINUTE[k][3](f, i, p) for k, p in sc["slots"])
                if hit:
                    rets.append(f["close"][i + hold] / c0 - 1 - FEE)
        n_sig = len(rets)
        wins = [r for r in rets if r > 0]
        gp = sum(wins)
        gl = abs(sum(r for r in rets if r <= 0))
        pf = gp / gl if gl > 0 else (999.0 if gp > 0 else 0)
        bench_avg = sum(bench) / len(bench) if bench else 0
        rets_by_screen.append({**sc, "signal_count": n_sig,
                               "win_rate": round(len(wins) / n_sig * 100, 2) if n_sig else 0,
                               "avg_ret": round(sum(rets) / n_sig, 4) if n_sig else 0,
                               "total_return": round(sum(rets), 2),
                               "pf": round(pf, 2),
                               "bench_diff": round((sum(rets) / n_sig - bench_avg) if n_sig else 0, 4),
                               "oos_pass": None})
    def _score(r):
        if r["signal_count"] < 10:
            return -1
        if r["win_rate"] < 50:
            return -1
        return r["win_rate"] * max(min(r["avg_ret"], 0.10), -0.20)
    rets_by_screen.sort(key=lambda r: -_score(r))
    el = time.time() - t0
    note = (f"[분봉] 조건식 {len(rets_by_screen)}개 × {len(feats)}종목 · 진입 후 {hold}분 · "
            f"수수료 {FEE*100:.1f}% · {el:.0f}초")
    return {"run_id": None, "tested": len(rets_by_screen), "signals": 0,
            "elapsed": round(el, 1), "bench_avg": 0, "symbols": len(feats),
            "results": rets_by_screen[:30], "good": [], "note": note,
            "oos": oos, "source": "minute"}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="조건식 스크리너 (대량 백테스트)")
    parser.add_argument("--batch", type=int, default=300, help="조건식 수 (기본 300)")
    parser.add_argument("--evolve", action="store_true", help="상위 결과 기반 변형(다음 라운드)")
    parser.add_argument("--hold", type=int, default=5, help="보유 일수 (기본 5)")
    args = parser.parse_args()
    db.init_db()
    logging.basicConfig(level=logging.INFO)
    res = run_screener(batch=args.batch, hold_days=args.hold, evolve=args.evolve)
    print("\n" + res["note"])
    print("=" * 60)
    print(f"{'승률':>6} {'손익비':>6} {'평균%':>8} {'샘플':>6}  조건식")
    for r in res["results"][:20]:
        print(f"{r['win_rate']:>6.1f} {r['pf']:>6.2f} {r['avg_ret']*100:>8.2f} "
              f"{r['signal_count']:>6}  {r['txt'][:60]}")
