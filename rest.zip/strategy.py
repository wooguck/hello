"""전략(Strategy) 정의 + 지표 계산 로직

전략 = 파라미터 딕셔너리 하나. evaluate_entry/exit 안에 실제 매매 조건 구현.
PARAM_RANGES는 유전 알고리즘이 조작할 DNA.
"""
import random
from typing import List, Dict

PARAM_RANGES = {
    # ── 기존 9개 ──
    "ema_fast": (3, 20),
    "ema_slow": (10, 60),
    "rsi_buy": (20, 40),
    "rsi_sell": (60, 85),
    "volume_mult": (1.2, 3.0),
    "stop_loss_pct": (1.0, 5.0),
    "take_profit_pct": (2.0, 15.0),
    "max_holding_days": (1, 10),
    "chegyul_threshold": (80, 200),
    # ── 신규 5개 (의미 있는 트레이딩 파라미터) ──
    "rsi_period": (5, 30),               # RSI 계산 기간 (14가 기본, 5~30 탐색)
    "volume_ma_period": (5, 40),         # 거래량 이동평균 기간 (체결강도/거래량 비교용)
    "buy_score_threshold": (5, 15),      # AI 매수 점수 기준 (rule 기반 프롬프트 판단의 문턱)
    "trailing_stop_pct": (1.0, 5.0),     # 트레일링 스탑 % (최고점 대비 하락 시 청산)
    "volatility_breakout": (1.0, 3.0),   # 변동성 돌파 배수 (전일 고가 대비 배수)
}

# ── 변이 단위 (의미 있는 수치로만 변형 - 0.01 단위 마이크로 변이 방지) ──
PARAM_STEPS = {
    "ema_fast": 1, "ema_slow": 1, "rsi_buy": 1, "rsi_sell": 1,
    "volume_mult": 0.1, "stop_loss_pct": 0.5, "take_profit_pct": 0.5,
    "max_holding_days": 1, "chegyul_threshold": 5,
    "rsi_period": 1, "volume_ma_period": 1,
    "buy_score_threshold": 1, "trailing_stop_pct": 0.5, "volatility_breakout": 0.1,
}


def fill_default_params(params: dict) -> dict:
    """
    새 DNA가 추가됐을 때 기존 전략에 기본값(중간값)을 채워주는 마이그레이션.
    기존 데이터는 절대 삭제하지 않고, 없는 키만 추가한다.
    """
    merged = dict(params or {})
    for key, (lo, hi) in PARAM_RANGES.items():
        if key not in merged or merged[key] is None:
            if isinstance(lo, int) and isinstance(hi, int):
                merged[key] = int(round((lo + hi) / 2))
            else:
                merged[key] = round((lo + hi) / 2, 2)
    return merged


def random_params() -> dict:
    params = {}
    for key, (lo, hi) in PARAM_RANGES.items():
        if isinstance(lo, int) and isinstance(hi, int):
            params[key] = random.randint(lo, hi)
        else:
            params[key] = round(random.uniform(lo, hi), 2)
    # 파라미터 간 논리 보정
    if params["ema_fast"] >= params["ema_slow"]:
        params["ema_slow"] = params["ema_fast"] + random.randint(1, 10)
        if params["ema_slow"] > PARAM_RANGES["ema_slow"][1]:
            params["ema_slow"] = PARAM_RANGES["ema_slow"][1]
            params["ema_fast"] = max(PARAM_RANGES["ema_fast"][0], params["ema_slow"] - 5)
    if params["rsi_buy"] >= params["rsi_sell"]:
        params["rsi_buy"] = min(PARAM_RANGES["rsi_buy"][1], params["rsi_sell"] - 5)
    return params


# ── 지표 계산 (순수 파이썬) ─────────────────────────
def ema(prices: List[float], period: int) -> List[float]:
    if not prices or period <= 0:
        return []
    if len(prices) < period:
        return [sum(prices) / len(prices)] * len(prices)
    k = 2 / (period + 1)
    sma = sum(prices[:period]) / period
    ema_list = [sma] * (period - 1)
    prev = sma
    for p in prices[period - 1:]:
        prev = p * k + prev * (1 - k)
        ema_list.append(prev)
    return ema_list[-len(prices):]


def rsi(prices: List[float], period: int = 14) -> float:
    if len(prices) < period + 1:
        return 50.0
    gains, losses = [], []
    for i in range(1, len(prices)):
        diff = prices[i] - prices[i - 1]
        gains.append(diff if diff > 0 else 0)
        losses.append(abs(diff) if diff < 0 else 0)
    if len(gains) < period:
        return 50.0
    avg_gain = sum(gains[-period:]) / period
    avg_loss = sum(losses[-period:]) / period
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))


def sma(prices: List[float], period: int) -> float:
    if not prices:
        return 0
    if len(prices) < period:
        return sum(prices) / len(prices)
    return sum(prices[-period:]) / period


def _to_float(v):
    try:
        s = str(v).replace(",", "").replace("+", "").replace("-", "").strip()
        return float(s) if s else 0.0
    except Exception:
        return 0.0


def calc_indicators(candles: List[Dict]) -> Dict:
    """candles: [{"close":..., "volume":...}, ...] 오래된순 -> 최신순"""
    if not candles:
        return {}
    closes_f = [_to_float(c.get("close", c.get("cur_prc", 0))) for c in candles]
    closes_f = [x for x in closes_f if x > 0]
    volumes_f = [_to_float(c.get("volume", c.get("trde_qty", 0))) for c in candles]
    if not closes_f:
        return {}
    result = {
        "price": closes_f[-1],
        "sma_5": sma(closes_f, 5),
        "sma_20": sma(closes_f, 20),
        "rsi_14": rsi(closes_f, 14),
        "volume": volumes_f[-1] if volumes_f else 0,
        "volume_avg_20": sma(volumes_f, 20) if volumes_f else 0,
    }
    ema12 = ema(closes_f, 12)
    ema26 = ema(closes_f, 26)
    if ema12 and ema26:
        result["ema_12"] = ema12[-1]
        result["ema_26"] = ema26[-1]
    return result


# ── 매수/매도 판단 ─────────────────────────
def evaluate_entry(params: dict, market_data: dict) -> bool:
    try:
        price = market_data.get("price")
        if not price:
            return False
        rsi_val = market_data.get("rsi", market_data.get("oscillator", market_data.get("rsi_14")))
        chegyul = market_data.get("체결강도", market_data.get("chegyul", 100))
        ema_fast = market_data.get("ema_fast", market_data.get("ema_12"))
        ema_slow = market_data.get("ema_slow", market_data.get("ema_26"))
        volume_ratio = market_data.get("volume_ratio", 1.0)

        if rsi_val is not None and rsi_val > params["rsi_buy"]:
            return False
        if ema_fast is not None and ema_slow is not None and ema_fast <= ema_slow:
            return False
        try:
            if float(chegyul) < params["chegyul_threshold"]:
                return False
        except Exception:
            pass
        if volume_ratio is not None and volume_ratio < params["volume_mult"]:
            return False
        return True
    except Exception:
        return False


def evaluate_exit(params: dict, market_data: dict, entry_price: float, holding_days: int) -> bool:
    price = market_data.get("price")
    if price is None or entry_price == 0:
        return False
    try:
        change_pct = (price - entry_price) / entry_price * 100
    except Exception:
        return False
    if change_pct <= -abs(params["stop_loss_pct"]):
        return True
    if change_pct >= params["take_profit_pct"]:
        return True
    if holding_days >= params["max_holding_days"]:
        return True
    rsi_val = market_data.get("rsi", market_data.get("oscillator", market_data.get("rsi_14")))
    if rsi_val is not None:
        try:
            if float(rsi_val) >= params["rsi_sell"]:
                return True
        except Exception:
            pass
    ema_fast = market_data.get("ema_fast", market_data.get("ema_12"))
    ema_slow = market_data.get("ema_slow", market_data.get("ema_26"))
    if ema_fast is not None and ema_slow is not None and ema_fast < ema_slow:
        return True
    return False


def compute_fitness(win_rate: float, avg_return: float, max_drawdown: float,
                    trade_count: int, min_trades: int) -> float:
    """
    적합도 = 승률 * 평균수익률, MDD 패널티 적용.
    ★ 20건 미만이어도 계산함 (완전 배제 대신):
      - 0건: 0.0 (아직 실적 없음)
      - 1~19건: 신뢰도 가중치(confidence)를 곱해서 점수를 낮춤
        confidence = trade_count / min_trades  (예: 5건이면 0.25배)
      - min_trades 이상: 가중치 1 + 거래수 소폭 보너스
    """
    if trade_count <= 0:
        return 0.0  # 실적 없음 - 완전 배제하지 않고 0으로
    mdd_abs = abs(max_drawdown) if max_drawdown else 0
    mdd_penalty = 1.0 / (1.0 + mdd_abs / 10.0)
    raw = win_rate * avg_return
    if trade_count < min_trades:
        # 표본 부족 신뢰도 가중치 (거래 20건이면 1.0, 5건이면 0.25)
        confidence = trade_count / min_trades
        return round(raw * mdd_penalty * confidence, 4)
    count_bonus = min(1.5, 1.0 + (trade_count - min_trades) / 200.0)
    return round(raw * mdd_penalty * count_bonus, 4)


