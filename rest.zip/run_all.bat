@echo off
title RUN - Collect Data + Start App
cd /d "C:\Users\wowman\Desktop\rest"
echo.
echo ============================================================
echo   [1/2] Collect data (first time takes 1-3h, then skips)
echo ============================================================
python collect_data.py --once
echo.
echo ============================================================
echo   [2/2] Start Auto Trading App
echo ============================================================
python desktop_app.py
pause
