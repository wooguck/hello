# -*- coding: utf-8 -*-
"""
📺 자동 파일럿 실시간 현황판 (pilot_board.py)
==============================================
자동 파일럿(4팀)이 "뭘 했고, 성과가 나왔는지"를 한 화면에서 보는 웹 현황판.
5초마다 자동 새로고침 - 브라우저 켜두면 실시간으로 흐름이 보입니다.

보여주는 것:
  🏆 명예의 전당      : 백테스트로 검증된 최고 조건식들 (성적순)
  🎯 엄밀 검증 이력    : 최근 검증 결과 (등급/백분위/초과수익)
  📅 모의매매 예약     : 검증 통과 → 다음날 실전 모의 투입 예약분
  🖥 모의매매 성과     : 진행 중 포지션 + 청산 성적 (승률/손익)
  🔎 스크리너 상위     : 대량 테스트 상위 조건식
  📥 데이터 현황       : 수집 상태
  📋 최근 로그        : logs/ 파일 tail (4팀이 지금 뭘 하는지)

실행:
  python pilot_board.py            # http://localhost:8890
  (앱과 동시에 켜도 됨 - 키움 API 안 씀, 로컬 DB만 읽음)
"""
import json
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import sys
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db


# 시스템 대시보드(web_status) 포트 - 앱이 기동하며 채워줌 (폴백 8000~8005 대응)
DASH_PORT = 8000


def trade_detail(pos_id):
    """거래 1건 상세: 앞뒤 일봉 + 매수/매도 마커 + AI 판정 이력 (차트는 프런트에서 SVG)"""
    try:
        with db.get_conn() as conn:
            r = conn.execute("SELECT * FROM paper_positions WHERE id=?", (pos_id,)).fetchone()
        if not r:
            return {"error": "없음"}
        r = dict(r)
        sym = r["symbol"]
        from validation import _load_bars
        bars = _load_bars(sym, max_days=60)
        # AI 판정 이력 (해당 종목, 진입~청산 구간)
        with db.get_conn() as conn:
            js = conn.execute(
                "SELECT judged_at, kind, decision, engine, score, reason FROM judgments "
                "WHERE symbol=? ORDER BY id DESC LIMIT 12", (sym,)).fetchall()
        name = ""
        try:
            name = db.name_map().get(sym, "")
        except Exception:
            pass
        return {"id": r["id"], "symbol": sym, "name": name,
                "cond": r.get("cond_txt"), "kind": r.get("order_kind"),
                "entry_time": r.get("entry_time"), "entry_price": r.get("entry_price"),
                "exit_time": r.get("exit_time"), "exit_price": r.get("exit_price"),
                "ret": r.get("ret_pct"), "why": r.get("exit_reason"),
                "plan": r.get("sell_plan"), "target": r.get("target_price"),
                "stop": r.get("stop_price"), "hi": r.get("highest_return"),
                "bars": [{"d": b["date"], "o": b["open"], "h": b["high"],
                          "l": b["low"], "c": b["close"]} for b in bars[-40:]],
                "judgments": [dict(j) for j in js]}
    except Exception as e:
        return {"error": str(e)[:80]}


def handle_wish(text):
    """★ 소원함 (사용자: '아쉬운 점 적으면 AI가 검색식으로 만들어 적용')
    글 → AI가 슬롯 DSL 초안 → backlog 등록 (검증 통과해야 매수 - 기존 안전절차 그대로)
    AI 없으면 접수만 (wish_box.json에 저장 - 다음에 사람이/AI가 처리)"""
    text = (text or "").strip()[:300]
    if not text:
        return {"ok": False, "msg": "내용이 비었습니다"}
    os.makedirs("strategy", exist_ok=True)
    inbox = os.path.join("strategy", "wish_box.json")
    wishes = []
    try:
        wishes = json.load(open(inbox, encoding="utf-8"))
    except Exception:
        pass
    entry = {"at": db.now_kst_iso(), "text": text, "status": "접수"}
    # AI로 슬롯 변환 시도
    try:
        from ai_judge import call_llm
        from screener import SLOTS
        slot_doc = "\n".join(f"- {k}: {v[0]} (파라미터 {v[1]} 선택지 {v[2]})"
                             for k, v in list(SLOTS.items())[:52])
        ans = call_llm(
            "당신은 주식 검색식 설계자입니다. JSON만 출력하세요.",
            f"사용자 요청: {text}\n\n사용 가능한 슬롯:\n{slot_doc}\n\n"
            f'요청을 슬롯 1~3개 조합으로 번역하세요. 불가능하면 {{"error":"이유"}}.\n'
            f'출력: {{"slots": [["슬롯키", {{"파라미터": 값}}], ...], "name": "짧은이름"}}')
        j = json.loads(ans[ans.index("{"):ans.rindex("}") + 1])
        if j.get("slots"):
            valid = all(sl[0] in SLOTS for sl in j["slots"])
            if valid:
                no = db.next_cond_no()
                cid = db.create_condition(no, f"[소원] {j.get('name', text[:30])}",
                                          j["slots"], source="wish")
                db.set_condition_status(cid, "backlog")
                entry["status"] = f"검색식 생성 → {no}번 (backlog - 검증 통과해야 매수)"
                entry["cond_no"] = no
                entry["slots"] = j["slots"]
    except Exception as e:
        entry["status"] = f"접수됨 (AI 변환 대기: {str(e)[:40]})"
    wishes.append(entry)
    json.dump(wishes[-50:], open(inbox, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return {"ok": True, "msg": entry["status"], "text": text}


def gather():
    """모든 성과/현황 데이터 수집 (로컬 DB만 - 키움 API 호출 없음)"""
    out = {"time": db.now_kst().strftime("%m-%d %H:%M:%S"), "dash_port": DASH_PORT}
    # ★★ 돈 요약 (사용자: '돈을 벌기 위한 시스템' - 최상단에 돈부터)
    try:
        with db.get_conn() as conn:
            # ★ 2026-08-27 사용자: "현황판엔 '실제 모의투자' 내용만" → 돈 요약은 real만 집계
            #   (real = 키움 모의계좌에 실제 주문 체결 / virtual = 기록만.
            #    virtual 건수는 참고로 함께 표시 - 숨기면 '왜 안 맞지' 혼란)
            def _pnl(where, kind="real"):
                kw = f"AND order_kind='{kind}'" if kind else ""
                rows = conn.execute(
                    "SELECT ret_pct, entry_price, qty FROM paper_positions "
                    f"WHERE status='closed' {kw} AND {where}").fetchall()
                won = sum((r["ret_pct"] or 0) / 100 * (r["entry_price"] or 0) * (r["qty"] or 0)
                          for r in rows)
                wins = sum(1 for r in rows if (r["ret_pct"] or 0) > 0)
                return {"n": len(rows), "won": round(won), 
                        "wr": round(wins / len(rows) * 100, 1) if rows else 0}
            today = db.now_kst().strftime("%Y-%m-%d")
            out["money"] = {
                "today": _pnl(f"exit_time LIKE '{today}%'"),
                "week": _pnl("exit_time > datetime('now','-7 days')"),
                "all": _pnl("1=1"),
                "virtual_n": (_pnl("1=1", kind="virtual") or {}).get("n", 0)}  # 가상 건수 참고
            # 채널별 7일 비교 (BASELINE 대비가 핵심)
            ch_rows = conn.execute(
                "SELECT CASE WHEN cond_key IN ('AI_PICK','MOMENTUM','FORCE_LINE','BASELINE','MANUAL','THEME') "
                "THEN cond_key WHEN cond_key LIKE 'SCALP%' THEN 'SCALP' ELSE '조건식' END ch, "
                "COUNT(*) n, AVG(ret_pct) avg, "
                "SUM(CASE WHEN ret_pct>0 THEN 1 ELSE 0 END)*100.0/COUNT(*) wr "
                "FROM paper_positions WHERE status='closed' AND order_kind='real' "
                "AND exit_time > datetime('now','-7 days') GROUP BY ch ORDER BY avg DESC").fetchall()
            out["channels"] = [{"ch": r["ch"], "n": r["n"], "avg": round(r["avg"] or 0, 2),
                                "wr": round(r["wr"] or 0, 1)} for r in ch_rows]
            # ★ 전략별 상세 (2026-08-27 사용자: '각 전략별로 나눠져서 쉽게 확인')
            #   채널별: 오늘 매수/청산 · 보유 · 실현손익(real 기준) · 최근 청산 3건
            det_rows = conn.execute(
                "SELECT CASE WHEN cond_key IN ('AI_PICK','MOMENTUM','FORCE_LINE','BASELINE','MANUAL','THEME') "
                "THEN cond_key WHEN cond_key LIKE 'SCALP%' THEN 'SCALP' "
                "WHEN cond_key LIKE 'LIVE%' THEN 'SCALP' ELSE '조건식' END ch, "
                "status, order_kind, symbol, cond_txt, ret_pct, entry_price, qty, "
                "entry_time, exit_time, exit_reason FROM paper_positions "
                "WHERE entry_time > datetime('now','-7 days') OR status='open'").fetchall()
            chd = {}
            for r in det_rows:
                d = chd.setdefault(r["ch"], {"open": 0, "today_buy": 0, "today_exit": 0,
                                             "real_won": 0, "real_n": 0, "virt_n": 0,
                                             "recent": []})
                if r["status"] == "open":
                    d["open"] += 1
                if (r["entry_time"] or "").startswith(today):
                    d["today_buy"] += 1
                if r["status"] == "closed":
                    if (r["exit_time"] or "").startswith(today):
                        d["today_exit"] += 1
                    if r["order_kind"] == "real":
                        d["real_n"] += 1
                        d["real_won"] += (r["ret_pct"] or 0) / 100 * (r["entry_price"] or 0) * (r["qty"] or 0)
                    else:
                        d["virt_n"] += 1
                    if len(d["recent"]) < 3:
                        d["recent"].append({"sym": r["symbol"], "ret": round(r["ret_pct"] or 0, 2),
                                            "kind": r["order_kind"],
                                            "why": (r["exit_reason"] or "")[:24]})
            for d in chd.values():
                d["real_won"] = round(d["real_won"])
            out["channel_detail"] = chd
    except Exception:
        out["money"] = None
        out["channels"] = []
        out["channel_detail"] = {}
    # ★ 👻 가상 명예전당 (2026-08-28 사용자: '가상이 모으는 종목 - 기대치 높은 순')
    #   가상기록 청산들을 조건식별 집계 → 기대점수 = 평균수익 × 승률가중 × 표본가중 - MDD 패널티
    try:
        with db.get_conn() as conn:
            vrows = conn.execute(
                "SELECT cond_txt, symbol, ret_pct, entry_time, exit_time, entry_price, exit_price "
                "FROM paper_positions WHERE status='closed' AND order_kind='virtual' "
                "ORDER BY exit_time DESC LIMIT 500").fetchall()
        agg = {}
        for r in vrows:
            key = (r["cond_txt"] or "")[:40]
            a = agg.setdefault(key, {"rets": [], "syms": [], "trades": []})
            a["rets"].append(r["ret_pct"] or 0)
            if r["symbol"] not in a["syms"]:
                a["syms"].append(r["symbol"])
            if len(a["trades"]) < 12:
                a["trades"].append({"sym": r["symbol"], "ret": round(r["ret_pct"] or 0, 2),
                                    "in": (r["entry_time"] or "")[5:16], "out": (r["exit_time"] or "")[5:16],
                                    "ep": r["entry_price"], "xp": r["exit_price"]})
        vhof = []
        _nm = {}
        try:
            _nm = db.name_map()
        except Exception:
            pass
        for key, a in agg.items():
            rs = a["rets"]
            n = len(rs)
            if n < 2:
                continue
            win = len([x for x in rs if x > 0]) / n * 100
            avg = sum(rs) / n
            wins_s = sum(x for x in rs if x > 0)
            loss_s = abs(sum(x for x in rs if x <= 0)) or 0.001
            pf = min(wins_s / loss_s, 3.0)
            # MDD 근사 (누적수익 고점 대비)
            eq, pk, mdd = 0.0, 0.0, 0.0
            for x in rs[::-1]:
                eq += x
                pk = max(pk, eq)
                mdd = max(mdd, pk - eq)
            score = avg * (win / 50.0) * (n / (n + 10)) * max(0.3, 1 - mdd / 100)
            vhof.append({"cond": key, "n": n, "win": round(win, 1), "avg": round(avg, 2),
                         "best": round(max(rs), 2), "mdd": round(mdd, 1),
                         "score": round(score, 3),
                         "sym_names": [f"{s} {_nm.get(s, '')[:6]}".strip() for s in a["syms"][:8]],
                         "trades": a["trades"]})
        # ★ 2026-08-28 사용자: "검증 계속 해서 확률 잘 나오는 순" - 최신 검증 등급 결합
        try:
            with db.get_conn() as conn:
                _g = conn.execute(
                    "SELECT cond_txt, grade FROM validation_results WHERE id IN "
                    "(SELECT MAX(id) FROM validation_results GROUP BY cond_key)").fetchall()
            _gmap = {}
            for r in _g:
                _k = (r["cond_txt"] or "")[:40]
                _gmap[_k] = r["grade"]
                # [별명] 접두 형태도 매칭
                if _k.startswith("[") and "]" in _k:
                    _gmap[_k[:_k.index("]") + 1]] = r["grade"]
            for v in vhof:
                v["grade"] = _gmap.get(v["cond"]) or _gmap.get(
                    v["cond"][:v["cond"].index("]") + 1] if v["cond"].startswith("[") and "]" in v["cond"] else "") or ""
        except Exception:
            pass
        vhof.sort(key=lambda x: -x["score"])
        out["vhof"] = vhof[:15]
    except Exception:
        out["vhof"] = []
    # ★ 🫀 4팀 하트비트 (사용자: '일만 하고 있는 것만 확인되면 됨')
    try:
        import time as _tt
        hb = {}
        _files = {"수집/라운드": "strategy/round_progress.json",
                  "데이터수집": "logs/collect_data.log",
                  "검증": "strategy/control_state.json",
                  "팜리그": "strategy/farm_league.json",
                  "레이더": "strategy/preopen_radar.json",
                  "미국섹터": "strategy/us_sector.json",
                  "테마헌터": "strategy/theme_hunter.json"}
        for name, path in _files.items():
            try:
                age = _tt.time() - os.path.getmtime(path)
                hb[name] = ("🟢" if age < 3600 else "🟡" if age < 21600 else "🔴") +                            (f"{int(age//60)}분전" if age < 3600 else f"{int(age//3600)}시간전")
            except Exception:
                hb[name] = "⚪기록없음"
        out["heartbeat"] = hb
    except Exception:
        out["heartbeat"] = {}
    # ★ 🌱 조건식 수급 현황 (2026-09-01 사용자: "대량 퇴출했으면 그만큼 편입해야")
    #   운영/대기/퇴출 개수 + 충원모드 여부 + 최근 편입(팜 데뷔/승격/부활) 이력
    try:
        pool = {"active": len(db.get_conditions(status="active")),
                "backlog": len(db.get_conditions(status="backlog")),
                "retired": len(db.get_conditions(status="retired")),
                "refill": False, "target": _cfg_env_int("LC_MIN_ACTIVE", 12),
                "recent_in": []}
        try:
            _rf = json.load(open(os.path.join("strategy", "refill_mode.json"),
                                 encoding="utf-8"))
            pool["refill"] = bool(_rf.get("on"))
        except Exception:
            pass
        # 최근 7일 새로 만들어진 조건식 (팜/빌더/유전자/부활/소원)
        try:
            with db.get_conn() as conn:
                rows = conn.execute(
                    "SELECT cond_no, cond_txt, source, status, created_at FROM conditions "
                    "WHERE created_at > datetime('now','-7 days') "
                    "ORDER BY created_at DESC LIMIT 10").fetchall()
            _src = {"farm": "⚾팜", "builder": "🧱빌더", "surge": "🧬유전자",
                    "rule": "🧬유전자", "revive": "♻️부활", "wish": "💌소원",
                    "photo": "📷사진", "variation": "🔀변형"}
            pool["recent_in"] = [{"no": r["cond_no"],
                                  "txt": (r["cond_txt"] or "")[:36],
                                  "src": _src.get(r["source"], r["source"] or "?"),
                                  "st": {"active": "운영", "backlog": "대기"}.get(
                                      r["status"], r["status"]),
                                  "at": (r["created_at"] or "")[5:16].replace("T", " ")}
                                 for r in rows if r["status"] != "retired"]
        except Exception:
            pass
        out["pool"] = pool
    except Exception:
        out["pool"] = None
    # ★ 📋 조건식별 성적 연동표 (2026-09-01 사용자: "조건식 연동 수익률 유기적이지 않음")
    #   운영/대기 조건식마다: 최신 검증등급 + 실제(real) 모의성적 + 가상 건수를 한 줄로
    #   → "이 조건식이 검증은 몇 등급이고 실제로 얼마 벌었나"가 한눈에 연결됨
    try:
        conds = db.get_conditions(status="active") + db.get_conditions(status="backlog")
        # 최신 검증 등급 (cond_key = conditions.id)
        gmap = {}
        try:
            with db.get_conn() as conn:
                _has_ns = "n_symbols" in {c[1] for c in conn.execute(
                    "PRAGMA table_info(validation_results)").fetchall()}
                _q_ns = ", n_symbols" if _has_ns else ""
                for r in conn.execute(
                        f"SELECT cond_key, grade, avg_ret, trades{_q_ns} FROM validation_results "
                        "WHERE id IN (SELECT MAX(id) FROM validation_results "
                        "GROUP BY cond_key)").fetchall():
                    gmap[str(r["cond_key"])] = {
                        "grade": r["grade"], "vavg": r["avg_ret"], "vn": r["trades"],
                        # ★ 검증 규모: 1000종목+ = 전종목급 (2026-09-02 사용자: "전체 검증 애매함")
                        "vsym": (r["n_symbols"] if _has_ns else None)}
        except Exception:
            pass
        # 실제(real) / 가상(virtual) 성적 분리 집계
        perf = {}
        try:
            with db.get_conn() as conn:
                for r in conn.execute(
                        "SELECT cond_key, order_kind, "
                        "COUNT(*) n, "
                        "SUM(CASE WHEN status='closed' THEN 1 ELSE 0 END) sells, "
                        "SUM(CASE WHEN status='closed' AND ret_pct>0 THEN 1 ELSE 0 END) wins, "
                        "SUM(CASE WHEN status='closed' THEN ret_pct/100.0*entry_price*qty "
                        "ELSE 0 END) net "
                        "FROM paper_positions GROUP BY cond_key, order_kind").fetchall():
                    d = perf.setdefault(str(r["cond_key"]), {})
                    d[r["order_kind"] or "virtual"] = {
                        "n": r["n"], "sells": r["sells"] or 0, "wins": r["wins"] or 0,
                        "net": round(r["net"] or 0)}
        except Exception:
            pass
        rows = []
        for c in conds:
            ck = str(c["id"])
            g = gmap.get(ck) or {}
            pr = (perf.get(ck) or {}).get("real") or {}
            pv = (perf.get(ck) or {}).get("virtual") or {}
            sells = pr.get("sells", 0)
            _vs = g.get("vsym")
            rows.append({"no": c.get("cond_no"), "txt": (c.get("cond_txt") or "")[:44],
                         "st": "운영" if c["status"] == "active" else "대기",
                         "grade": g.get("grade") or "",
                         # 검증 규모 라벨: 전종목(1000+) / N종목 / 미상
                         "vscope": ("전종목" if (_vs or 0) >= 1000 else
                                    f"{_vs}종목" if _vs else ""),
                         "buys": pr.get("n", 0), "sells": sells,
                         "win": round(pr.get("wins", 0) / sells * 100, 1) if sells else None,
                         "net": pr.get("net", 0), "vn": pv.get("n", 0)})
        # 정렬: 운영 먼저 → 실적 있는 것 → 순손익 큰 순
        rows.sort(key=lambda x: (x["st"] != "운영", -(x["sells"]), -(x["net"] or 0)))
        out["condstats"] = rows[:40]
    except Exception:
        out["condstats"] = []
    # ★ 📅 일별 성과 (real만 - 최근 10거래일)
    try:
        with db.get_conn() as conn:
            drows = conn.execute(
                "SELECT date(exit_time) d, COUNT(*) n, "
                "SUM(ret_pct/100.0*entry_price*qty) won, "
                "SUM(CASE WHEN ret_pct>0 THEN 1 ELSE 0 END)*100.0/COUNT(*) wr "
                "FROM paper_positions WHERE status='closed' AND order_kind='real' "
                "GROUP BY date(exit_time) ORDER BY d DESC LIMIT 10").fetchall()
        out["daily"] = [{"d": r["d"], "n": r["n"], "won": round(r["won"] or 0),
                         "wr": round(r["wr"] or 0, 1)} for r in drows]
    except Exception:
        out["daily"] = []
    # ★ AI 활동 상태 (2026-08-27 사용자: 'AI가 유기적으로 활동하고 있는지')
    try:
        ai = {"provider": "", "live": False, "today_judgments": 0, "coach": 0, "governor": ""}
        try:
            from config import CFG as _C
            ai["provider"] = f"{getattr(_C, 'AI_PROVIDER', '')}/{getattr(_C, 'AI_MODEL', '')}"
            ai["live"] = bool(getattr(_C, "GEMINI_API_KEY", "") or os.getenv("GEMINI_API_KEY"))
        except Exception:
            pass
        with db.get_conn() as conn:
            _today = db.now_kst().strftime("%Y-%m-%d")
            r = conn.execute("SELECT COUNT(*) n FROM judgments WHERE judged_at LIKE ?",
                             (_today + "%",)).fetchone()
            ai["today_judgments"] = r["n"] if r else 0
            r2 = conn.execute("SELECT engine, COUNT(*) n FROM judgments WHERE judged_at LIKE ? "
                              "GROUP BY engine", (_today + "%",)).fetchall()
            ai["by_engine"] = {x["engine"] or "rule": x["n"] for x in r2}
            # ★ 2026-09-01: 매수/매도 판단 건수 분리 (사용자: "매수 매도시 AI가 처리함이 확인되는지")
            r3 = conn.execute("SELECT kind, COUNT(*) n FROM judgments WHERE judged_at LIKE ? "
                              "GROUP BY kind", (_today + "%",)).fetchall()
            ai["by_kind"] = {x["kind"]: x["n"] for x in r3}
            # 마지막 판단 시각·내용 (증거 한 줄)
            r4 = conn.execute("SELECT judged_at, symbol, kind, decision, engine FROM judgments "
                              "ORDER BY id DESC LIMIT 1").fetchone()
            if r4:
                ai["last"] = (f"{(r4['judged_at'] or '')[5:16]} {r4['symbol']} "
                              f"{'매수' if r4['kind']=='buy' else '매도'}판단→{r4['decision']}"
                              f"({r4['engine'] or 'rule'})")
        try:
            _cl = json.load(open(os.path.join("strategy", "coach_log.json"), encoding="utf-8"))
            ai["coach"] = len(_cl if isinstance(_cl, list) else _cl.get("suggestions", []))
        except Exception:
            pass
        try:
            _gv = open(os.path.join("strategy", "governor_log.jsonl"), encoding="utf-8").read().strip().splitlines()
            if _gv:
                _last = json.loads(_gv[-1])
                ai["governor"] = f"{_last.get('action', '')} ({str(_last.get('at', ''))[:16]})"
        except Exception:
            pass
        out["ai"] = ai
    except Exception:
        out["ai"] = {}
    # ★🩺 자가진단 결과 (2026-09-01 사용자: "확인도구 없이 안 되는지" - 자동 표시)
    #   teams 라운드가 하루 1회 system_doctor를 자동 실행 → 여기서 읽어서 보여줌
    try:
        _dr = json.load(open(os.path.join("strategy", "doctor_report.json"),
                             encoding="utf-8"))
        # 오래된 진단(2일+)은 그 자체가 경고 (라운드가 안 돌고 있다는 뜻)
        from datetime import datetime as _ddt
        _age_h = (db.now_kst().replace(tzinfo=None)
                  - _ddt.fromisoformat(_dr.get("at", "2000-01-01T00:00:00"))).total_seconds() / 3600
        _dr["stale"] = _age_h > 48
        out["doctor"] = _dr
    except Exception:
        out["doctor"] = None
    # ★ 오늘 매수 깔때기 (2026-08-31 사용자: "매수가 원활하지 않음 - 왜?")
    try:
        _sk = json.load(open(os.path.join("strategy", "skip_stats.json"), encoding="utf-8"))
        if _sk.get("date") == db.now_kst().strftime("%Y-%m-%d"):
            out["funnel"] = _sk
        else:
            out["funnel"] = None
    except Exception:
        out["funnel"] = None
    # ★ 아침 준비 자료 활용 현황 (2026-08-27 사용자: '기존에 만든 자료 아침에 잘 활용하나')
    try:
        prep = {"radar_date": "", "radar_n": 0, "gap_n": 0, "used_today": []}
        try:
            _pr = json.load(open(os.path.join("strategy", "preopen_radar.json"), encoding="utf-8"))
            prep["radar_date"] = _pr.get("date", "")
            prep["radar_n"] = len(_pr.get("preopen") or [])
            prep["gap_n"] = len(_pr.get("opening_gap") or [])
            # 오늘 매수 중 레이더 후보였던 것 (자료→매수 연결 확인)
            radar_syms = {c.get("symbol") for c in (_pr.get("preopen") or [])} | \
                         {c.get("symbol") for c in (_pr.get("opening_gap") or [])}
            with db.get_conn() as conn:
                _today = db.now_kst().strftime("%Y-%m-%d")
                rows = conn.execute("SELECT DISTINCT symbol FROM paper_positions "
                                    "WHERE entry_time LIKE ?", (_today + "%",)).fetchall()
                prep["used_today"] = [r["symbol"] for r in rows if r["symbol"] in radar_syms]
        except Exception:
            pass
        out["prep"] = prep
    except Exception:
        out["prep"] = {}
    # ★ 라운드 진행률 (teams.py가 기록하는 round_progress.json)
    try:
        import time as _t
        with open(os.path.join("strategy", "round_progress.json"), encoding="utf-8") as f:
            rp = json.load(f)
        step = rp.get("step", 0)
        total = rp.get("steps_total", 4)
        elapsed = _t.time() - rp.get("started_at", _t.time())
        prev = rp.get("prev_elapsed") or 0
        # 예상 남은 시간: 직전 라운드 소요시간 기준 (없으면 단계 비례)
        if step >= total:
            eta, pct = 0, 100
        elif prev > 30:
            pct = min(99, int(elapsed / prev * 100))
            eta = max(0, int(prev - elapsed))
        else:
            pct = int(step / total * 100)
            eta = None
        stale = (_t.time() - rp.get("now", 0)) > 3600  # 1시간+ 갱신 없음 = 옛날 기록
        out["round"] = {"n": rp.get("round", 0), "step": step, "total": total,
                        "name": rp.get("step_name", ""), "pct": pct,
                        "elapsed": int(elapsed), "eta": eta, "stale": stale}
    except Exception:
        out["round"] = None
    # 데이터 현황
    try:
        st = db.data_collection_stats()
        pct = round(st["stock_files"] / st["universe"] * 100, 1) if st["universe"] else 0
        out["data"] = (f"종목 {st['stock_files']:,}/{st['universe']:,} ({pct}%) · "
                       f"일봉 {st['daily_bars']:,} · 분봉 {st['minute_bars']:,} · {st['total_mb']}MB")
    except Exception as e:
        out["data"] = str(e)[:60]
    # 명예의 전당 (★ 실전 상세: 스타일/평균보유/승률/기대수익/MDD - 사용자 요청)
    try:
        hof_rows = []
        for h in db.hof_list(limit=10):
            ck = str(h.get("cond_key"))
            live = {"n": 0}
            try:
                with db.get_conn() as conn:
                    rows = conn.execute(
                        "SELECT ret_pct, entry_time, exit_time FROM paper_positions "
                        "WHERE status='closed' AND cond_key=? ORDER BY exit_time", (ck,)).fetchall()
                rets = [r["ret_pct"] or 0 for r in rows]
                if rets:
                    wins = [x for x in rets if x > 0]
                    # 평균 보유시간 → 스타일 판정 (당일/단기/스윙)
                    from datetime import datetime as _dt
                    holds = []
                    for r in rows:
                        try:
                            holds.append((_dt.fromisoformat(r["exit_time"])
                                          - _dt.fromisoformat(r["entry_time"])).total_seconds() / 86400)
                        except Exception:
                            pass
                    avg_hold = sum(holds) / len(holds) if holds else 0
                    style = "당일" if avg_hold < 0.8 else ("단기" if avg_hold < 3 else "스윙")
                    # MDD (누적 수익률 곡선 기준)
                    cum = peak = mdd = 0.0
                    for x in rets:
                        cum += x
                        peak = max(peak, cum)
                        mdd = max(mdd, peak - cum)
                    live = {"n": len(rets),
                            "win": round(len(wins) / len(rets) * 100, 1),
                            "exp": round(sum(rets) / len(rets), 2),   # 기대수익(평균)
                            "mdd": round(mdd, 1),
                            "hold": round(avg_hold, 1), "style": style}
            except Exception:
                pass
            hof_rows.append({"txt": (h.get("cond_txt") or "")[:40],
                             "win": h.get("best_win_rate"), "pf": h.get("best_pf"),
                             "n": h.get("sample_count"), "live": live})
        out["hof"] = hof_rows
    except Exception:
        out["hof"] = []
    # 엄밀 검증 이력 (★ 2026-08-28: 폐기된 조건식 제외 - 살아있는 것만)
    try:
        from validation import load_validation_history
        _vh = load_validation_history(limit=60)
        try:
            _alive = {str(c["id"]) for c in db.get_conditions(status="active")} |                      {str(c["id"]) for c in db.get_conditions(status="backlog")}
            _vh = [v for v in _vh if str(v.get("cond_key")) in _alive]
        except Exception:
            pass
        # ★ 2026-08-28 사용자: "탈락된 애들은 빠지게" - 기각은 목록에서 제외, 개수만 요약
        _pass = [v for v in _vh if v.get("grade") in ("채택 후보", "조건부", "수익만")]
        _rej = [v for v in _vh if v.get("grade") == "기각"]
        out["valid_rejected_n"] = len(_rej)
        # ★ 탈락 보관함 (2026-08-28 사용자: '탈락자료 뒷구석에 쌓아두기' - 삭제 아님 보관)
        out["rejected_archive"] = [{"txt": (v.get("cond_txt") or v.get("txt") or "")[:44],
                                    "at": (v.get("created_at") or v.get("checked_at") or "")[:16],
                                    "trades": v.get("trades") if v.get("trades") is not None
                                    else (v.get("stats") or {}).get("trades")} for v in _rej[:10]]
        out["valid"] = [{"txt": (v.get("txt") or v.get("cond_txt") or "")[:48],
                         "grade": v.get("grade"), "pct": (v.get("stats") or {}).get("percentile"),
                         "avg": (v.get("stats") or {}).get("avg_ret"),
                         "trades": (v.get("stats") or {}).get("trades"),
                         "at": (v.get("checked_at") or v.get("at") or "")[:16]}
                        for v in _pass[:12]]
    except Exception:
        out["valid"] = []
    # ★ 추천 전략 카드 (스크린샷 스타일 - 검증 통과 상위를 카드로)
    try:
        with db.get_conn() as conn:
            rows = conn.execute(
                "SELECT * FROM validation_results WHERE id IN "
                "(SELECT MAX(id) FROM validation_results GROUP BY cond_key) "
                "AND grade IN ('채택 후보','조건부') "
                "ORDER BY CASE grade WHEN '채택 후보' THEN 0 ELSE 1 END, avg_ret DESC "
                "LIMIT 4").fetchall()
        cards = []
        for r in rows:
            r = dict(r)
            name = (r.get("cond_txt") or "")
            short = name[:name.index("]") + 1] if name.startswith("[") and "]" in name else name[:20]
            cards.append({"name": short, "full": name[:60], "grade": r.get("grade"),
                          "win": r.get("win_rate"), "avg": r.get("avg_ret"),
                          "mdd": r.get("mdd"), "trades": r.get("trades"),
                          "pctl": r.get("percentile"), "excess": r.get("excess")})
        out["cards"] = cards
    except Exception:
        out["cards"] = []
    # 예약 모의매매
    try:
        out["sched"] = [{"txt": (s.get("cond_txt") or "")[:50], "grade": s.get("grade"),
                         "date": s.get("date")} for s in db.get_scheduled_paper()][:8]
    except Exception:
        out["sched"] = []
    # 모의매매 성과 (★ 키움 API 호출 없이 로컬 DB만으로 계산
    #   - paper_test.paper_summary()는 보유 종목마다 시세 API를 불러
    #     앱과 동시에 켜면 429/토큰충돌 유발 → 현황판은 캐시 가격만 사용)
    try:
        with db.get_conn() as conn:
            closed = conn.execute(
                "SELECT ret_pct FROM paper_positions WHERE status='closed' AND order_kind='real'").fetchall()
            open_rows = conn.execute(
                "SELECT symbol, entry_price, qty FROM paper_positions WHERE status='open' AND order_kind='real'").fetchall()
        rets = [r["ret_pct"] or 0 for r in closed]
        wins = [r for r in rets if r > 0]
        losses = [r for r in rets if r <= 0]
        gl = abs(sum(losses))
        unreal = 0.0
        for o in open_rows:
            p = db.get_latest_price(o["symbol"]) or o["entry_price"]  # 캐시만 (API 없음)
            unreal += (p - o["entry_price"]) * o["qty"]
        out["paper"] = {"trades": len(rets), "wins": len(wins), "losses": len(losses),
                        "win_rate": round(len(wins) / len(rets) * 100, 1) if rets else 0,
                        "pf": round(sum(wins) / gl, 2) if gl > 0 else (999.0 if wins else 0),
                        "open": len(open_rows), "unrealized_pnl": round(unreal)}
        opens = db.get_paper_open()
        # ★ 2026-08-28 사용자: "실제 거래되는 애들만 메인에, 가상은 가상매매란에 따로"
        def _pos_row(p):
            ck = str(p.get("cond_key") or "")
            ch = (ck if ck in ("AI_PICK", "MOMENTUM", "FORCE_LINE", "BASELINE", "MANUAL", "THEME")
                  else "SCALP" if ck.startswith(("SCALP", "LIVE")) else "조건식")
            return {"sym": p["symbol"], "cond": (p.get("cond_txt") or "")[:28], "ch": ch,
                    "entry": p.get("entry_price"), "qty": p.get("qty"),
                    "hi": p.get("highest_return"), "kind": p.get("order_kind") or "virtual"}
        rows_all = sorted((_pos_row(p) for p in opens), key=lambda x: x["ch"])
        out["positions_real"] = [r for r in rows_all if r["kind"] == "real"][:20]
        out["positions_virtual"] = [r for r in rows_all if r["kind"] != "real"][:20]
        out["positions"] = rows_all[:15]   # (구버전 호환)
        # 최근 청산 10건
        with db.get_conn() as conn:
            rows = conn.execute(
                "SELECT id, symbol, ret_pct, exit_reason, exit_time, cond_txt, entry_time, order_kind "
                "FROM paper_positions "
                "WHERE status='closed' ORDER BY exit_time DESC LIMIT 12").fetchall()
        def _hold_txt(r):
            try:
                from datetime import datetime as _dt
                h = (_dt.fromisoformat(r["exit_time"]) - _dt.fromisoformat(r["entry_time"]))
                d = h.days
                return f"{d}일" if d >= 1 else f"{int(h.total_seconds() // 60)}분"
            except Exception:
                return "-"
        def _cond_name(txt):
            # [별명] 있으면 별명만, 없으면 앞부분
            txt = txt or ""
            if txt.startswith("[") and "]" in txt:
                return txt[:txt.index("]") + 1]
            return txt[:14]
        out["recent_exits"] = [{"id": r["id"], "sym": r["symbol"], "ret": r["ret_pct"],
                                "cond": _cond_name(r["cond_txt"]),
                                "hold": _hold_txt(r),
                                "kind": r["order_kind"] or "virtual",
                                "why": (r["exit_reason"] or "")[:26],
                                "at": (r["exit_time"] or "")[5:16]} for r in rows]
    except Exception:
        out["paper"] = {}
        out["positions"] = []
        out["recent_exits"] = []
    # 스크리너 상위
    try:
        out["screen"] = [{"txt": (r.get("cond_txt") or "")[:50], "win": r.get("win_rate"),
                          "pf": r.get("pf"), "n": r.get("signal_count"),
                          "oos": r.get("oos_pass")} for r in
                         db.get_screener_results(limit=8, min_signals=20)]
    except Exception:
        out["screen"] = []
    # 최근 로그 tail
    logs = []
    try:
        cand = []
        if os.path.isdir("logs"):
            for f in os.listdir("logs"):
                p = os.path.join("logs", f)
                if f.endswith((".log", ".txt")) and os.path.getsize(p) > 0:
                    cand.append((os.path.getmtime(p), p))
        cand.sort(reverse=True)
        for _mt, p in cand[:2]:
            try:
                with open(p, encoding="utf-8", errors="replace") as fh:
                    tail = fh.readlines()[-15:]
                logs.append({"file": os.path.basename(p), "lines": [l.rstrip()[:110] for l in tail]})
            except Exception:
                continue
    except Exception:
        pass
    out["logs"] = logs
    # ★ 건강 신호등 (보통 사람용 - 오류 유무를 한 글자로)
    #   최근 로그에서 오류 패턴 스캔: 🔴 오류 있음 / 🟡 경고만 / 🟢 정상
    try:
        bad = warn = 0
        for l in logs:
            for ln in l.get("lines", []):
                if any(k in ln for k in ("❌", "Traceback", "ERROR", "8005", "실패")):
                    bad += 1
                elif "⚠️" in ln or "WARNING" in ln:
                    warn += 1
        out["health"] = {"level": ("bad" if bad >= 3 else "warn" if (bad or warn >= 5) else "ok"),
                         "bad": bad, "warn": warn}
    except Exception:
        out["health"] = {"level": "ok", "bad": 0, "warn": 0}
    # ── 🚫 일일 손실 서킷브레이커 상태 (2026-08-27 추가) ──
    try:
        import paper_test as _pt
        ok_cb, pnl_cb, lim_cb = _pt.daily_circuit_ok()
        out["circuit"] = {"tripped": (not ok_cb), "today_pnl": round(pnl_cb),
                          "limit": round(lim_cb)}
    except Exception:
        out["circuit"] = {"tripped": False, "today_pnl": 0, "limit": 0}
    return out


HTML = """<!DOCTYPE html><html><head><meta charset="utf-8"><title>📺 파일럿 현황판</title>
<style>
:root{--bg:#0b0e14;--card:#12161f;--card2:#171c27;--line:#232a38;--txt:#dbe2ec;--sub:#7d8896;
--red:#ff5c5c;--blue:#5cabff;--green:#4ade80;--gold:#fbbf24;--accent:#6366f1}
*{box-sizing:border-box}
body{margin:0;background:linear-gradient(180deg,#0b0e14 0%,#0d1220 100%);color:var(--txt);
 font-family:'Pretendard','Malgun Gothic',sans-serif;font-size:13px;min-height:100vh}
.top{padding:12px 20px;background:rgba(18,22,31,.92);backdrop-filter:blur(8px);
 border-bottom:1px solid var(--line);display:flex;justify-content:space-between;align-items:center;
 position:sticky;top:0;z-index:10;box-shadow:0 2px 12px rgba(0,0,0,.35)}
.top b{font-size:15px;letter-spacing:.3px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;padding:14px 16px}
@media(max-width:900px){.grid{grid-template-columns:1fr}}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px 16px;
 box-shadow:0 1px 6px rgba(0,0,0,.25);transition:border-color .15s}
.card:hover{border-color:#31405c}
.card h3{margin:0 0 10px;font-size:13.5px;color:#eef2f8;border-bottom:1px solid var(--line);
 padding-bottom:8px;letter-spacing:.2px}
table{width:100%;border-collapse:collapse}
td,th{padding:5px 7px;border-bottom:1px solid #1c2330;font-size:12px;text-align:left}
tr:hover td{background:rgba(99,102,241,.05)}
th{color:var(--sub);font-weight:600;font-size:11px;text-transform:uppercase;letter-spacing:.4px}
.red{color:var(--red)}.blue{color:var(--blue)}.green{color:var(--green)}.gold{color:var(--gold)}.dim{color:var(--sub)}
.badge{padding:2px 9px;border-radius:20px;font-size:10.5px;font-weight:700;letter-spacing:.2px}
.g0{background:linear-gradient(135deg,#16a34a,#22c55e);color:#fff}
.g1{background:linear-gradient(135deg,#b45309,#d97706);color:#fff}
.g2{background:#252c3a;color:#aeb8c4}.g3{background:linear-gradient(135deg,#b91c1c,#dc2626);color:#fff}
.empty{color:var(--sub);padding:10px;font-size:12px;text-align:center}
pre{background:#0b0e14;border:1px solid var(--line);border-radius:8px;padding:10px;font-size:11px;
 overflow-x:auto;margin:4px 0;color:var(--sub)}
.stat{display:inline-block;margin-right:16px}.stat b{font-size:17px}
.tabbtn{background:var(--card2);color:var(--txt);border:1px solid var(--line);border-radius:20px;
 padding:6px 16px;margin-right:8px;cursor:pointer;font-size:12.5px;transition:all .15s}
.tabbtn:hover{border-color:var(--accent)}
.tabbtn.on{background:linear-gradient(135deg,#4f46e5,#6366f1);color:#fff;border-color:transparent;
 box-shadow:0 2px 10px rgba(99,102,241,.35)}
</style></head><body>
<div class="top"><b>📺 자동 파일럿 실시간 현황판</b> <span id="health"></span>
<span>
  <a id="dashlink" href="#" target="_blank" style="color:#58a6ff;text-decoration:none;margin-right:14px">📊 시스템 대시보드 열기 →</a>
  <span class="dim" id="time">-</span>
</span></div>
<div id="money" style="padding:10px 18px"></div>
<div style="padding:0 18px" class="dim" id="data">-</div>
<div style="padding:4px 18px" id="round"></div>
<div style="padding:4px 18px 0" id="cards"></div>
<div style="padding:6px 18px" id="chtimes" class="dim" style="font-size:12px"></div>
<div id="hbbar" style="padding:4px 18px;font-size:11px" class="dim"></div>
<div style="padding:4px 18px">
  <button class="tabbtn" onclick="showTab('t_real')" id="b_t_real">📌 실제 모의성과</button>
  <button class="tabbtn" onclick="showTab('t_cond')" id="b_t_cond">📋 조건식 성적표</button>
  <button class="tabbtn" onclick="showTab('t_daily')" id="b_t_daily">📅 일별 성과</button>
  <button class="tabbtn" onclick="showTab('t_lab')" id="b_t_lab">👻 가상 연구소</button>
  <button class="tabbtn" onclick="showTab('t_sys')" id="b_t_sys">🔧 시스템</button>
</div>

<div class="grid" id="t_real">
  <div class="card"><h3>🖥 실제 모의매매 성과 <span class="dim" style="font-size:11px">(키움 모의계좌 체결분만)</span></h3>
    <div id="paper" style="margin-bottom:8px"></div>
    <table id="exits"></table></div>
  <div class="card"><h3>📌 보유 - 실제 모의매매</h3><table id="pos"></table></div>
</div>
<div class="grid" id="t_cond" style="display:none">
  <div class="card" style="grid-column:1/-1"><h3>🌱 조건식 수급 <span class="dim" style="font-size:11px">(운영·대기·퇴출 개수와 최근 7일 새 편입 - 퇴출분은 여기 안 보임·개수만)</span></h3>
    <div id="pool" style="margin-bottom:6px"></div><table id="poolin"></table></div>
  <div class="card" style="grid-column:1/-1"><h3>📋 조건식 연동 성적표 <span class="dim" style="font-size:11px">(검증등급 ↔ 실제(real) 모의성적 한눈에 - 가상 기록은 건수만)</span></h3><table id="condstats"></table></div>
  <div class="card"><h3>🏆 명예의 전당 <span class="dim" style="font-size:11px">(백테스트 검증 최고 조건식)</span></h3><table id="hof"></table></div>
  <div class="card"><h3>🎯 엄밀 검증 이력 <span class="dim" style="font-size:11px">(대조군+지수 비교 등급)</span></h3><table id="valid"></table></div>
  <div class="card"><h3>📅 다음날 모의매매 예약 <span class="dim" style="font-size:11px">(검증 통과분)</span></h3><table id="sched"></table></div>
  <div class="card"><h3>🔎 스크리너 상위</h3><table id="screen"></table></div>
</div>
<div class="grid" id="t_daily" style="display:none">
  <div class="card"><h3>📅 일별 실현손익 <span class="dim">(실제 모의만)</span></h3><table id="dailytbl"></table></div>
</div>
<div class="grid" id="t_sys" style="display:none">
  <div class="card" style="grid-column:1/-1"><h3>🩺 자가진단 <span class="dim" style="font-size:11px">(매일 밤 라운드가 자동 실행 - 직접 돌릴 필요 없음)</span></h3>
    <div id="docsum" style="margin-bottom:6px"></div><table id="doctbl"></table></div>
  <div class="card"><h3>🫀 팀 하트비트</h3><div id="hb2"></div></div>
  <div class="card"><h3>🔗 바로가기</h3>
    <div style="line-height:2.2">
      <a id="dash2" href="#" target="_blank" style="color:var(--blue)">📊 구 대시보드(8000) 열기 →</a><br>
      <span class="dim" style="font-size:11px">시스템 도구는 앱(exe)의 탭 또는 CLI: system_doctor · fix_data.bat · trade_stats · gate_report · sell_shadow · loss_lessons</span>
    </div></div>
  <div class="card" style="grid-column:1/-1"><h3>📋 최근 로그</h3><div id="logs2"></div></div>
</div>
<div class="grid" id="t_lab" style="display:none">
  <div class="card" style="grid-column:1/-1"><h3>👻 가상 연구소 명예전당 <span class="dim" style="font-size:11px">(기대점수순 - 아직 실전 투입 전인 가상 기록. 클릭=타점 보기)</span></h3><table id="vhof"></table></div>
  <div class="card"><h3>👻 보유 - 가상 기록</h3><table id="posv"></table></div>
  <div class="card" style="grid-column:1/-1"><h3>💌 소원함 <span class="dim">(아쉬운 점을 글로 적으면 AI가 검색식 초안으로 만들어 대기열에 넣습니다)</span></h3>
    <div style="display:flex;gap:8px">
      <input id="wishtext" placeholder="예: 거래량 터지고 20일선 위로 올라선 종목을 잡아줘" style="flex:1;background:#0b0e14;border:1px solid var(--line);border-radius:8px;padding:8px 12px;color:var(--txt)">
      <button class="tabbtn" onclick="sendWish()">보내기</button>
    </div>
    <div id="wishresult" class="dim" style="margin-top:6px;font-size:12px"></div>
  </div>
</div>

<div style="padding:0 12px 12px"><div class="card"><h3>📋 최근 로그 (4팀이 지금 뭘 하는지)</h3><div id="logs"></div></div></div>
<script>
function $(i){return document.getElementById(i)}
function esc(s){return String(s??'').replace(/</g,'&lt;')}
async function openTrade(id){
  const d=await (await fetch('/api/trade?id='+id)).json();
  if(d.error){alert(d.error);return}
  const bars=d.bars||[];
  let svg='';
  if(bars.length>2){
    const W=680,H=240,P=30;
    const lo=Math.min(...bars.map(b=>b.l)),hi=Math.max(...bars.map(b=>b.h));
    const x=i=>P+(W-2*P)*i/(bars.length-1), y=v=>H-P-(H-2*P)*(v-lo)/(hi-lo||1);
    svg=`<svg width="${W}" height="${H}" style="background:#0b0e14;border-radius:8px">`;
    bars.forEach((b,i)=>{const up=b.c>=b.o;const col=up?'#f85149':'#58a6ff';
      svg+=`<line x1="${x(i)}" y1="${y(b.h)}" x2="${x(i)}" y2="${y(b.l)}" stroke="${col}" stroke-width="1"/>`;
      svg+=`<rect x="${x(i)-2.5}" y="${Math.min(y(b.o),y(b.c))}" width="5" height="${Math.max(2,Math.abs(y(b.o)-y(b.c)))}" fill="${col}"/>`});
    const ed=(d.entry_time||'').slice(0,10), xd=(d.exit_time||'').slice(0,10);
    bars.forEach((b,i)=>{
      if(b.d===ed&&d.entry_price)svg+=`<circle cx="${x(i)}" cy="${y(d.entry_price)}" r="7" fill="none" stroke="#4ade80" stroke-width="2.5"/><text x="${x(i)}" y="${y(d.entry_price)-11}" fill="#4ade80" font-size="11" text-anchor="middle">매수</text>`;
      if(b.d===xd&&d.exit_price)svg+=`<circle cx="${x(i)}" cy="${y(d.exit_price)}" r="7" fill="none" stroke="#fbbf24" stroke-width="2.5"/><text x="${x(i)}" y="${y(d.exit_price)-11}" fill="#fbbf24" font-size="11" text-anchor="middle">매도</text>`});
    if(d.target)svg+=`<line x1="${P}" y1="${y(d.target)}" x2="${W-P}" y2="${y(d.target)}" stroke="#4ade80" stroke-dasharray="4" opacity="0.4"/>`;
    if(d.stop)svg+=`<line x1="${P}" y1="${y(d.stop)}" x2="${W-P}" y2="${y(d.stop)}" stroke="#ff5c5c" stroke-dasharray="4" opacity="0.4"/>`;
    svg+='</svg>';
  }
  const js=(d.judgments||[]).map(j=>`<div class="dim" style="font-size:11px;padding:2px 0">🧠 ${(j.judged_at||'').slice(5,16)} [${j.kind==='buy'?'매수':'매도'}판단] <b>${esc(j.decision||'')}</b> (${esc(j.engine||'rule')}${j.score?` ${j.score}점`:''}) - ${esc((j.reason||'').slice(0,60))}</div>`).join('')||'<div class="dim">AI 판정 기록 없음</div>';
  const el=document.createElement('div');
  el.id='trademodal';
  el.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:99;display:flex;align-items:center;justify-content:center';
  el.innerHTML=`<div class="card" style="max-width:740px;width:94%;max-height:88vh;overflow:auto" onclick="event.stopPropagation()">
    <h3>${esc(d.symbol)} ${esc(d.name||'')} <span class="${d.ret>0?'red':'blue'}">${d.ret>0?'+':''}${d.ret}%</span>
      <span class="badge ${d.kind==='real'?'g0':'g2'}">${d.kind==='real'?'실제모의':'가상'}</span>
      <span style="float:right;cursor:pointer" onclick="document.getElementById('trademodal').remove()">✕</span></h3>
    <div style="font-size:12px;margin-bottom:6px;padding:6px 10px;background:#0b0e14;border-radius:8px;border-left:3px solid var(--accent)">
      📥 <b>매수 방법</b>: ${esc(d.cond||'-')} <span class="dim">(${d.kind==='real'?'키움 모의계좌 실제 체결':'가상 기록'})</span><br>
      📤 <b>매도 사유</b>: ${esc(d.why||'-')}</div>
    ${svg}
    <div style="margin:8px 0;font-size:12px">
      🟢 매수 ${(d.entry_price||0).toLocaleString()}원 (${(d.entry_time||'').slice(5,16)}) →
      🟡 매도 ${(d.exit_price||0).toLocaleString()}원 (${(d.exit_time||'').slice(5,16)})
      · 최고 <b class="red">+${d.hi||0}%</b> · 사유: ${esc(d.why||'-')}</div>
    ${d.plan?`<div class="dim" style="font-size:11px;margin-bottom:6px">📌 지침: ${esc(d.plan)}</div>`:''}
    <div style="border-top:1px solid var(--line);padding-top:6px"><b style="font-size:12px">AI 판정 이력</b>${js}</div>
  </div>`;
  el.onclick=()=>el.remove();
  document.body.appendChild(el);
}
async function sendWish(){
  const t=document.getElementById('wishtext').value.trim();
  if(!t){return}
  document.getElementById('wishresult').textContent='⏳ AI가 검색식으로 번역 중...';
  const r=await (await fetch('/api/wish?text='+encodeURIComponent(t))).json();
  document.getElementById('wishresult').textContent=(r.ok?'✅ ':'❌ ')+r.msg;
  if(r.ok)document.getElementById('wishtext').value='';
}
function showTab(t){for(const x of ['t_real','t_cond','t_daily','t_lab','t_sys']){$(x).style.display=x===t?'':'none';const b=$('b_'+x);if(b)b.className='tabbtn'+(x===t?' on':'')}}
try{showTab('t_real')}catch(e){}
function pct(v,inv){if(v==null)return '-';const c=(v>0)!=(inv||false)?'red':'blue';return `<span class="${c}">${v>0?'+':''}${(+v).toFixed(1)}%</span>`}
async function refresh(){
 try{
  const d=await (await fetch('/api/all')).json();
  $('time').innerText='갱신 '+d.time+' (5초마다 자동)';
  const hl=d.health||{level:'ok'};
  const cb=d.circuit||{tripped:false};
  $('health').innerHTML=(cb.tripped?`<span class="badge g3">🚫 서킷브레이커! 오늘 손실 ${(cb.today_pnl||0).toLocaleString()}원 - 신규매수 정지 (매도는 계속·내일 해제)</span> `:'')+
   (hl.level==='ok'?'<span class="badge g0">🟢 시스템 정상</span>':
   hl.level==='warn'?`<span class="badge g1">🟡 경고 ${hl.warn}건 (아래 로그 확인)</span>`:
   `<span class="badge g3">🔴 오류 ${hl.bad}건! (아래 로그 확인)</span>`)+
   // 🩺 자가진단 배지 (하루 1회 자동 - 시스템 탭에 상세)
   (d.doctor?(d.doctor.stale?` <span class="badge g1">🩺 진단 오래됨(${(d.doctor.at||'').slice(5,10)}) - 라운드 안 도는 중?</span>`
     :d.doctor.fail>0?` <span class="badge g3" style="cursor:pointer" onclick="showTab('t_sys')">🩺 자가진단 실패 ${d.doctor.fail}건! (클릭)</span>`
     :d.doctor.warn>0?` <span class="badge g1" style="cursor:pointer" onclick="showTab('t_sys')">🩺 진단 주의 ${d.doctor.warn}건 (클릭)</span>`
     :` <span class="badge g0">🩺 자가진단 통과</span>`)
    :' <span class="dim" style="font-size:11px">🩺 첫 자가진단은 오늘 밤 자동 실행</span>');
  // 🩺 시스템 탭 자가진단 상세
  if(d.doctor){
    $('docsum').innerHTML=`<span class="dim">진단 ${esc(d.doctor.at||'')}</span> · <span class="badge g0">✅ ${d.doctor.ok||0}</span> <span class="badge g1">🟡 ${d.doctor.warn||0}</span> <span class="badge g3">🔴 ${d.doctor.fail||0}</span>${d.doctor.stale?' <span class="badge g1">⚠️ 48시간+ 지난 진단 - 밤 라운드가 도는지 확인 필요</span>':''}`;
    $('doctbl').innerHTML='<tr><th>상태</th><th>항목</th><th>내용</th><th>조치</th></tr>'+
     (d.doctor.items||[]).map(it=>`<tr><td>${it.status}</td><td style="white-space:nowrap">${esc(it.name)}</td><td style="text-align:left">${esc(it.detail)}</td><td style="text-align:left" class="dim">${esc(it.fix||'')}</td></tr>`).join('');
  }else{try{$('docsum').innerHTML='<span class="dim">아직 진단 기록 없음 - 오늘 밤 라운드에서 자동 실행됩니다</span>';$('doctbl').innerHTML='';}catch(e){}}
  if(d.dash_port){const dl=$('dashlink'); if(dl)dl.href='http://localhost:'+d.dash_port;}
  $('cards').innerHTML=(d.cards||[]).length?
   '<div style="display:flex;gap:10px;flex-wrap:wrap">'+d.cards.map(c=>{
    const g0=c.grade==='채택 후보';
    return `<div style="flex:1;min-width:230px;background:#161b22;border:1px solid ${g0?'#e3b341':'#30363d'};border-radius:10px;padding:12px 14px">
     <div style="display:flex;justify-content:space-between;align-items:center">
      <b style="font-size:14px">${esc(c.name)}</b>
      <span class="badge ${g0?'g0':'g1'}">${c.grade}</span></div>
     <div class="dim" style="font-size:11px;margin:3px 0 8px">${esc(c.full)}</div>
     <div style="display:grid;grid-template-columns:1fr 1fr;gap:5px;font-size:12px">
      <div>🎯 승률 <b class="${(c.win||0)>=50?'red':'blue'}">${c.win??'-'}%</b></div>
      <div>📈 평균 <b class="${(c.avg||0)>0?'red':'blue'}">${c.avg>0?'+':''}${c.avg??'-'}%</b></div>
      <div>🛡 MDD <b class="blue">${c.mdd??'-'}%</b></div>
      <div>🔁 매매 <b>${c.trades??'-'}건</b></div>
      <div>🎲 대조군 <b>${c.pctl??'-'}%</b></div>
      <div>📊 지수초과 <b class="${(c.excess||0)>0?'red':'blue'}">${c.excess>0?'+':''}${c.excess??'-'}%p</b></div>
     </div></div>`;}).join('')+'</div>':'';
  const m=d.money;
  if(m){const f=v=>`<b class="${v>=0?'red':'blue'}" style="font-size:20px">${v>=0?'+':''}${(v||0).toLocaleString()}원</b>`;
   $('money').innerHTML=`<div style="display:flex;gap:12px;flex-wrap:wrap">
    <div class="card" style="flex:1;min-width:170px">💰 오늘 실현손익 <span class="badge g0">실제모의</span><br>${f(m.today.won)}<span class="dim"> (${m.today.n}건 승률${m.today.wr}%)</span></div>
    <div class="card" style="flex:1;min-width:170px">📅 7일 실현손익 <span class="badge g0">실제모의</span><br>${f(m.week.won)}<span class="dim"> (${m.week.n}건 승률${m.week.wr}%)</span></div>
    <div class="card" style="flex:1;min-width:170px">📊 누적 실현손익 <span class="badge g0">실제모의</span><br>${f(m.all.won)}<span class="dim"> (${m.all.n}건 승률${m.all.wr}%${m.virtual_n?` · 가상기록 ${m.virtual_n}건 별도`:''})</span></div>
    <div class="card" style="flex:2;min-width:260px">🏁 채널 경쟁 (7일 평균수익)<br>
     ${(d.channels||[]).map(c=>{const base=c.ch==='BASELINE';
       return `<span style="margin-right:10px;${base?'border-bottom:1px dashed #e3b341':''}">${base?'🎲':''}${esc(c.ch)} <b class="${c.avg>0?'red':'blue'}">${c.avg>0?'+':''}${c.avg}%</b><span class="dim">/${c.n}건</span></span>`}).join('')||'<span class="dim">청산 표본 없음</span>'}
    </div></div>
    <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:10px" id="chdetail"></div>`;
   // ★ 전략별 상세 카드 (오늘 매수/청산 · 보유 · 실제모의 손익 · 최근 청산)
   const cd=d.channel_detail||{};
   const icons={'조건식':'📋','AI_PICK':'🤖','MOMENTUM':'🚀','FORCE_LINE':'🐋','BASELINE':'🎲','SCALP':'⚡','MANUAL':'✋'};
   $('chdetail').innerHTML=Object.keys(cd).map(ch=>{const x=cd[ch];
     return `<div class="card" style="flex:1;min-width:210px">
      <b>${icons[ch]||''} ${esc(ch)}</b><br>
      <span class="dim">오늘</span> 매수 ${x.today_buy} · 청산 ${x.today_exit} · <span class="dim">보유</span> ${x.open}<br>
      <span class="dim">7일 실제모의</span> <b class="${x.real_won>=0?'red':'blue'}">${x.real_won>=0?'+':''}${(x.real_won||0).toLocaleString()}원</b><span class="dim">/${x.real_n}건${x.virt_n?` (+가상${x.virt_n})`:''}</span><br>
      ${(x.recent||[]).map(r=>`<span class="dim" style="font-size:11px">${esc(r.sym)} <b class="${r.ret>0?'red':'blue'}">${r.ret>0?'+':''}${r.ret}%</b>${r.kind==='virtual'?'ⓥ':''}</span>`).join(' · ')||''}
     </div>`}).join('')||'<span class="dim">최근 7일 전략 활동 없음</span>';
   // ★ AI 활동 + 아침 준비자료 활용 배지
   const ai=d.ai||{}, pp=d.prep||{};
   const bk=ai.by_kind||{};
   const aiTxt=`🧠 AI: ${ai.live?'🟢연결':'⚪규칙모드'} ${esc(ai.provider||'')} · 오늘 판단 ${ai.today_judgments||0}건 (매수 ${bk.buy||0}·매도 ${bk.sell||0})${ai.coach?` · 코치제안 ${ai.coach}`:''}${ai.governor?` · 거버너 ${esc(ai.governor)}`:''}${ai.last?`<br><span class="dim" style="font-size:11px">마지막: ${esc(ai.last)}</span>`:'<br><span class="dim" style="font-size:11px">⚠️ 판단 기록 없음 - 매수/매도가 실제로 돌면 여기 쌓입니다</span>'}`;
   const ppTxt=pp.radar_date?`📡 아침자료: ${esc(pp.radar_date)} 레이더 ${pp.radar_n}종목·갭 ${pp.gap_n}종목 → 오늘 매수 연결 ${(pp.used_today||[]).length}건${(pp.used_today||[]).length?` (${pp.used_today.slice(0,3).map(esc).join(',')})`:''}`:'📡 아침자료: 아직 없음 (밤 라운드가 생성)';
   $('chdetail').innerHTML+=`<div class="card" style="flex:2;min-width:300px"><div>${aiTxt}</div><div style="margin-top:4px">${ppTxt}</div></div>`;}
  // 🫀 4팀 하트비트 바
  const hb=d.heartbeat||{};
  $('hbbar').innerHTML='🫀 '+Object.keys(hb).map(k=>`${k} ${hb[k]}`).join(' · ')
   +(d.funnel?` &nbsp;|&nbsp; 🔽 오늘 매수깔때기: 신호 ${d.funnel.signals||0} → 진입 ${d.funnel.entered||0} (${Object.entries(d.funnel.skips||{}).map(([k,v])=>k+' '+v).join(' · ')||'스킵 없음'})`:'');
  try{$('hb2').innerHTML=Object.keys(hb).map(k=>`<div style="padding:3px 0">${k}: ${hb[k]}</div>`).join('');
  const dl2=$('dash2'); if(dl2&&d.dash_port)dl2.href='http://localhost:'+d.dash_port;
  $('logs2').innerHTML=$('logs')?$('logs').innerHTML:'';}catch(e){}
  // 📅 일별 성과
  $('dailytbl').innerHTML='<tr><th>날짜</th><th>거래</th><th>실현손익</th><th>승률</th></tr>'+
   ((d.daily||[]).map(r=>`<tr><td>${r.d}</td><td>${r.n}</td><td class="${r.won>=0?'red':'blue'}">${r.won>=0?'+':''}${(r.won||0).toLocaleString()}원</td><td>${r.wr}%</td></tr>`).join('')||'<tr><td colspan=4 class="empty">실제 모의 청산 아직 없음</td></tr>');
  // 👻 가상 연구소 명예전당 (클릭=타점)
  $('vhof').innerHTML='<tr><th>순위</th><th>조건식</th><th>기대점수</th><th>평균</th><th>승률</th><th>최고</th><th>MDD</th><th>매매</th><th>모은 종목</th></tr>'+
   ((d.vhof||[]).map((v,i)=>`<tr style="cursor:pointer" onclick="var x=document.getElementById('vh${i}');x.style.display=x.style.display==='none'?'':'none'">
     <td>${i+1}</td><td class="gold">${esc(v.cond)}${v.grade?` <span class="badge ${{'채택 후보':'g0','조건부':'g1','수익만':'g2'}[v.grade]||'g3'}">${esc(v.grade)}</span>`:''}</td><td><b>${v.score}</b></td>
     <td class="${v.avg>0?'red':'blue'}">${v.avg>0?'+':''}${v.avg}%</td><td>${v.win}%</td>
     <td class="red">+${v.best}%</td><td class="blue">${v.mdd}%</td><td>${v.n}</td>
     <td class="dim" style="font-size:11px">${(v.sym_names||[]).map(esc).join(', ')}</td></tr>
    <tr id="vh${i}" style="display:none"><td colspan=9>${(v.trades||[]).map(t=>`<span class="dim" style="font-size:11px;margin-right:10px">📍${esc(t.sym)} ${(t.ep||0).toLocaleString()}→${(t.xp||0).toLocaleString()} <b class="${t.ret>0?'red':'blue'}">${t.ret>0?'+':''}${t.ret}%</b> (${t.in}~${t.out})</span>`).join('')}</td></tr>`).join('')
   ||'<tr><td colspan=9 class="empty">가상 기록 축적 중 (조건식들이 가상으로 모으는 종목이 여기 랭킹됩니다)</td></tr>');
  $('data').innerHTML='📥 데이터: '+esc(d.data);
  const r=d.round;
  if(r&&!r.stale){
    const eta=r.eta!=null?` · 예상 남은 ${Math.floor(r.eta/60)}분 ${r.eta%60}초`:'';
    const done=r.step>=r.total;
    $('round').innerHTML=`<div class="card" style="padding:8px 14px">
     🔄 <b>라운드 ${r.n}</b> ${done?'<span class="green">완료</span>':esc(r.name)+' 진행 중'}
     <span style="display:inline-block;width:220px;height:10px;background:#21262d;border-radius:5px;vertical-align:middle;margin:0 8px">
      <span style="display:block;width:${r.pct}%;height:10px;background:${done?'#238636':'#1f6feb'};border-radius:5px"></span></span>
     <b>${r.pct}%</b> <span class="dim">(단계 ${Math.min(r.step+1,r.total)}/${r.total} · 경과 ${Math.floor(r.elapsed/60)}분${eta})</span></div>`;
  } else { $('round').innerHTML=r?'<span class="dim">라운드 기록이 오래됨 - 파일럿 실행 확인</span>':''; }
  const p=d.paper||{};
  $('paper').innerHTML=`
   <span class="stat">청산 <b>${p.trades||0}</b>건</span>
   <span class="stat">승률 <b class="${(p.win_rate||0)>=50?'red':'blue'}">${p.win_rate||0}%</b></span>
   <span class="stat">손익비 <b>${p.pf||0}</b></span>
   <span class="stat">보유 <b>${p.open||0}</b></span>
   <span class="stat">평가손익 <b class="${(p.unrealized_pnl||0)>=0?'red':'blue'}">${(p.unrealized_pnl||0).toLocaleString()}원</b></span>`;
  $('exits').innerHTML='<tr><th>최근 청산</th><th>수익률</th><th>조건식</th><th>보유</th><th>사유</th><th>시각</th></tr>'+
   ((d.recent_exits||[]).map(e=>`<tr style="cursor:pointer" onclick="openTrade(${e.id})"><td>${e.sym}${e.kind==='virtual'?'<span class="dim">ⓥ</span>':''}</td><td>${pct(e.ret)}</td><td class="gold">${esc(e.cond||'')}</td><td>${e.hold||'-'}</td><td class="dim">${esc(e.why)}</td><td class="dim">${e.at}</td></tr>`).join('')||'<tr><td colspan=6 class="empty">아직 청산 없음 - 모의매매가 돌면 여기 쌓입니다</td></tr>');
  const chIco={'조건식':'📋','AI_PICK':'🤖','MOMENTUM':'🚀','FORCE_LINE':'🐋','BASELINE':'🎲','SCALP':'⚡','MANUAL':'✋','THEME':'🎯'};
  const posRow=x=>`<tr><td>${chIco[x.ch]||''}${esc(x.ch)}</td><td>${x.sym}</td><td>${(x.entry||0).toLocaleString()}</td><td>${x.qty}</td><td>${pct(x.hi)}</td><td class="dim">${esc(x.cond)}</td></tr>`;
  $('pos').innerHTML='<tr><th>전략</th><th>종목</th><th>진입가</th><th>수량</th><th>최고수익</th><th>내용</th></tr>'+
   ((d.positions_real||[]).map(posRow).join('')||'<tr><td colspan=6 class="empty">실제 모의매매 보유 없음</td></tr>');
  $('posv').innerHTML='<tr><th>전략</th><th>종목</th><th>진입가</th><th>수량</th><th>최고수익</th><th>내용</th></tr>'+
   ((d.positions_virtual||[]).map(posRow).join('')||'<tr><td colspan=6 class="empty">가상 기록 없음</td></tr>');
  // 🌱 조건식 수급 (운영/대기/퇴출 + 충원모드 + 최근 편입)
  const pl=d.pool;
  if(pl){
    $('pool').innerHTML=`<span class="badge g0">운영 ${pl.active}개</span> <span class="badge g1">대기 ${pl.backlog}개</span> <span class="badge g2">🗑 퇴출 ${pl.retired}개 (숨김 보관)</span> `+
      (pl.refill?`<span class="badge g3">🌱 충원모드 ON - 운영 ${pl.active}/${pl.target}개 부족 → 팜·빌더·재심 가속 중</span>`
                :`<span class="dim" style="font-size:11px">목표 ${pl.target}개 충족 - 평시 탐색 주기</span>`);
    $('poolin').innerHTML='<tr><th>편입일</th><th>출신</th><th>번호</th><th>조건식</th><th>상태</th></tr>'+
      ((pl.recent_in||[]).map(r=>`<tr><td class="dim">${r.at}</td><td>${r.src}</td><td>${r.no}</td><td>${esc(r.txt)}</td><td>${r.st==='운영'?'<span class="badge g0">운영</span>':'<span class="badge g1">대기</span>'}</td></tr>`).join('')
      ||'<tr><td colspan=5 class="empty">최근 7일 새 편입 없음 - 밤 라운드가 돌면 팜 데뷔/빌더 등록이 여기 쌓입니다</td></tr>');
  }
  // 📋 조건식 연동 성적표 (검증등급 ↔ real 성적)
  const gcls={'채택 후보':'g0','조건부':'g1','수익만':'g2','기각':'g3','무효(데이터오류)':'g3'};
  $('condstats').innerHTML='<tr><th>번호</th><th>조건식</th><th>상태</th><th>검증등급</th><th>실매수</th><th>실매도</th><th>실승률</th><th>실순손익</th><th>가상</th></tr>'+
   ((d.condstats||[]).map(c=>`<tr><td>${c.no}</td><td style="text-align:left">${esc(c.txt)}</td>`+
     `<td>${c.st==='운영'?'<span class="badge g0">운영</span>':'<span class="badge g1">대기</span>'}</td>`+
     `<td>${c.grade?`<span class="badge ${gcls[c.grade]||'g2'}">${c.grade}</span>${c.vscope?`<br><span class="dim" style="font-size:10px">${c.vscope==='전종목'?'🌍 전종목':c.vscope} 검증</span>`:''}`:'<span class="dim">검증 전</span>'}</td>`+
     `<td>${c.buys||0}</td><td>${c.sells||0}</td>`+
     `<td>${c.win==null?'-':`<span class="${c.win>=50?'red':'blue'}">${c.win}%</span>`}</td>`+
     `<td class="${(c.net||0)>0?'red':(c.net||0)<0?'blue':'dim'}">${(c.net||0).toLocaleString()}원</td>`+
     `<td class="dim">${c.vn||0}건</td></tr>`).join('')
   ||'<tr><td colspan=9 class="empty">조건식 없음</td></tr>');
  $('hof').innerHTML='<tr><th>조건식</th><th>스타일</th><th>실전승률</th><th>기대수익</th><th>MDD</th><th>평균보유</th><th>거래</th></tr>'+
   ((d.hof||[]).map(h=>{const l=h.live||{};
    return `<tr><td class="gold">${esc(h.txt)}</td>`+
     (l.n?`<td>${l.style}</td><td class="${l.win>=50?'red':'blue'}">${l.win}%</td><td class="${l.exp>0?'red':'blue'}">${l.exp>0?'+':''}${l.exp}%</td><td class="blue">${l.mdd}%</td><td>${l.hold}일</td><td>${l.n}건</td>`
         :`<td colspan=5 class="dim">실전 표본 없음 (등재승률 ${h.win??'-'}%)</td><td>0</td>`)+`</tr>`;}).join('')
   ||'<tr><td colspan=7 class="empty">아직 없음 - 파일럿이 검증 통과 조건식을 찾으면 등재됩니다</td></tr>');
  const gc={'채택 후보':'g0','조건부':'g1','수익만':'g2','기각':'g3'};
  $('valid').innerHTML='<tr><th>조건식</th><th>등급</th><th>백분위</th><th>평균</th><th>매매</th><th>검증시각</th></tr>'+
   ((d.valid||[]).map(v=>`<tr><td>${esc(v.txt)}</td><td><span class="badge ${gc[v.grade]||'g2'}">${v.grade||'-'}</span></td><td>${v.pct??'-'}</td><td>${pct(v.avg)}</td><td>${v.trades??'-'}</td><td class="dim">${v.at}</td></tr>`).join('')||'<tr><td colspan=6 class="empty">통과 등급 아직 없음 (검증 축적 중)</td></tr>')+
   (d.valid_rejected_n?`<tr><td colspan=6 class="dim" style="text-align:center;cursor:pointer" onclick="var x=document.getElementById('rejbox');x.style.display=x.style.display==='none'?'':'none'">🗑 탈락 보관함 ${d.valid_rejected_n}건 (클릭해서 열기/닫기)</td></tr>`:'')+
   `<tr id="rejbox" style="display:none"><td colspan=6>${(d.rejected_archive||[]).map(r=>`<div class="dim" style="font-size:11px">✗ ${esc(r.txt)} (매매 ${r.trades??'-'}건 · ${r.at})</div>`).join('')||'<span class="dim">보관 자료 없음</span>'}</td></tr>`;
  $('sched').innerHTML='<tr><th>조건식</th><th>등급</th><th>투입일</th></tr>'+
   ((d.sched||[]).map(s=>`<tr><td>${esc(s.txt)}</td><td>${s.grade||''}</td><td>${s.date||''}</td></tr>`).join('')||'<tr><td colspan=3 class="empty">예약 없음</td></tr>');
  $('screen').innerHTML='<tr><th>조건식</th><th>승률</th><th>PF</th><th>신호</th><th>OOS</th></tr>'+
   ((d.screen||[]).map(s=>`<tr><td>${esc(s.txt)}</td><td>${s.win??'-'}%</td><td>${s.pf??'-'}</td><td>${s.n??'-'}</td><td>${s.oos?'✅':'-'}</td></tr>`).join('')||'<tr><td colspan=5 class="empty">아직 없음</td></tr>');
  $('logs').innerHTML=(d.logs||[]).map(l=>`<div class="dim" style="margin-top:4px">${l.file}</div><pre>${l.lines.map(esc).join('\\n')}</pre>`).join('')||'<div class="empty">logs/ 폴더에 로그 없음</div>';
 }catch(e){$('time').innerText='서버 연결 끊김 - pilot_board.py 실행 확인';}
}
async function loadTimes(){
  try{
    const t=await (await fetch('/api/channel_times')).json();
    const nm={CH_T_BASELINE:'🎲기준선',CH_T_AIPICK:'🤖AI픽',CH_T_RADAR:'📡갭스캔',CH_T_MOMENTUM:'🚀급등',CH_T_FORCE:'🐋세력선'};
    const fmt=v=>`${String(Math.floor(v/100)).padStart(2,'0')}:${String(v%100).padStart(2,'0')}`;
    $('chtimes').innerHTML='⏰ 채널 실행시각: '+Object.keys(nm).map(k=>
      `<span style="margin-right:10px">${nm[k]} <a href="#" style="color:#58a6ff;text-decoration:none" onclick="editTime('${k}',${t[k]});return false">${fmt(t[k])}</a></span>`).join('')
      +'<span class="dim">(클릭해서 변경 - .env/재시작 불필요)</span>';
  }catch(e){}
}
async function editTime(key,cur){
  const v=prompt(key+' 실행시각 (HHMM 형식, 900~1500):',cur);
  if(!v)return;
  const n=parseInt(v);
  if(isNaN(n)||n<900||n>1500){alert('900~1500 사이 숫자로 (예: 905 = 09:05)');return;}
  const r=await (await fetch('/api/channel_times?set='+key+':'+n)).json();
  if(r.ok){alert('✅ 저장! 다음 장중 사이클부터 즉시 적용');loadTimes();}
  else alert('실패: '+(r.error||''));
}
loadTimes();
refresh(); setInterval(refresh, 5000);
</script></body></html>"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        q = dict(urllib.parse.parse_qsl(u.query))
        if u.path == "/api/trade":
            # ★ 거래 상세 (2026-08-28 사용자: '클릭하면 매수/매도 시점 차트 + AI 판정')
            body = json.dumps(trade_detail(q.get("id")), ensure_ascii=False,
                              default=str).encode("utf-8")
            ct = "application/json; charset=utf-8"
        elif u.path == "/api/wish":
            # ★ 소원함: 글로 적으면 → AI가 검색식 초안 생성 → backlog 등록 (승인제)
            body = json.dumps(handle_wish(q.get("text", "")), ensure_ascii=False,
                              default=str).encode("utf-8")
            ct = "application/json; charset=utf-8"
        elif u.path == "/api/all":
            body = json.dumps(gather(), ensure_ascii=False, default=str).encode("utf-8")
            ct = "application/json; charset=utf-8"
        elif u.path == "/api/channel_times":
            # ★ 채널 시간 조회/저장 (.env 안 건드림 - strategy/channel_times.json)
            path = os.path.join("strategy", "channel_times.json")
            if q.get("set"):
                try:
                    cur = {}
                    try:
                        cur = json.load(open(path, encoding="utf-8"))
                    except Exception:
                        pass
                    for kv in q["set"].split(","):
                        k, v = kv.split(":")
                        k = k.strip().upper()
                        v = int(v)
                        if k in ("CH_T_BASELINE", "CH_T_AIPICK", "CH_T_RADAR",
                                 "CH_T_MOMENTUM", "CH_T_FORCE") and 900 <= v <= 1500:
                            cur[k] = v
                    os.makedirs("strategy", exist_ok=True)
                    json.dump(cur, open(path, "w", encoding="utf-8"))
                    body = json.dumps({"ok": True, "saved": cur},
                                      ensure_ascii=False).encode("utf-8")
                except Exception as e:
                    body = json.dumps({"ok": False, "error": str(e)[:80]}).encode("utf-8")
            else:
                cur = {}
                try:
                    cur = json.load(open(path, encoding="utf-8"))
                except Exception:
                    pass
                defaults = {"CH_T_BASELINE": 900, "CH_T_AIPICK": 901, "CH_T_RADAR": 902,
                            "CH_T_MOMENTUM": 930, "CH_T_FORCE": 1400}
                defaults.update(cur)
                body = json.dumps(defaults).encode("utf-8")
            ct = "application/json; charset=utf-8"
        else:
            body = HTML.encode("utf-8")
            ct = "text/html; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


# ── 자동 기동 (데스크톱 앱에서 호출 - 백그라운드 스레드) ──
_server = None
_server_thread = None


def start_server(port=8890, host="0.0.0.0"):
    """현황판 서버를 백그라운드 스레드로 시작 (이미 켜져 있으면 스킵)
    데스크톱 앱 시작 시 자동 호출 → 앱만 열면 localhost:8890도 같이 켜짐
    """
    global _server, _server_thread
    import threading
    if _server is not None:
        return port, False
    try:
        srv = ThreadingHTTPServer((host, port), Handler)
    except OSError:
        return port, False   # 포트 사용 중 (별도 실행분) → 그쪽 사용
    _server = srv
    _server_thread = threading.Thread(target=srv.serve_forever, daemon=True)
    _server_thread.start()
    print(f"📺 파일럿 현황판: http://localhost:{port}")
    return port, True


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8890)
    args = ap.parse_args()
    srv = ThreadingHTTPServer(("0.0.0.0", args.port), Handler)
    print(f"📺 파일럿 현황판: http://localhost:{args.port}  (5초 자동 갱신 · Ctrl+C 종료)")
    srv.serve_forever()


if __name__ == "__main__":
    main()
