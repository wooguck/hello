# -*- coding: utf-8 -*-
"""
🔬 비주얼 검증 랩 (visual_lab.py)
==================================
조건식의 매수/매도 시점을 **차트 위에 그림으로** 확인하고,
익절/손절/트레일링/보유일 파라미터를 **슬라이더로 조정**하면서
즉시 재백테스트 + 엄밀 검증(무작위 대조군·등급)까지 하는 웹 도구.

- 기존 시스템과 완전 연동:
  · 조건식: db.conditions(사진 조건식 포함) + photo_conditions 템플릿
  · 백테스트: validation.run_backtest_detail (모의매매와 같은 규칙)
  · 등급: validation._random_control + grade_condition (엄밀 검증과 동일)
  · 데이터: data/stocks/*.db (수집해둔 일봉)

실행:
  python visual_lab.py            # http://localhost:8899 접속
  python visual_lab.py --port 8899
"""
import argparse
import json
import os
import sys
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db
import validation as V
from screener import SLOTS

_LOCK = threading.Lock()   # 백테스트 동시 실행 방지 (메모리 보호)


# ── 조건식 목록 (DB 활성 + 사진 템플릿) ──────────────────
def list_conditions():
    out = []
    try:
        for c in db.get_conditions(status="active"):
            try:
                slots = json.loads(c.get("slots_json") or "[]")
            except Exception:
                slots = []
            if slots:
                out.append({"id": f"db:{c['id']}", "txt": c.get("cond_txt", "")[:80],
                            "slots": slots, "src": "등록 조건식"})
    except Exception:
        pass
    try:
        from photo_conditions import PHOTO_TEMPLATES, template_slots, template_txt
        for t in PHOTO_TEMPLATES:
            slots = template_slots(t)
            out.append({"id": f"photo:{t['photo']}", "txt": f"[사진{t['photo']}] {t['name']} - {template_txt(slots)[:60]}",
                        "slots": [[k, p] for k, p in slots], "src": "사진 템플릿"})
    except Exception:
        pass
    return out


def _norm_slots(slots):
    """[[key, params], ...] → [(key, params)] + 존재하는 슬롯만"""
    out = []
    for it in slots or []:
        try:
            k, p = it[0], it[1] if len(it) > 1 else {}
            if k in SLOTS:
                out.append((k, p or {}))
        except Exception:
            continue
    return out


def run_bt(slots, tp, sl, trail, hold, max_symbols=200, start=None, end=None):
    """백테스트 (파라미터 오버라이드) → trades + 통계"""
    try:
        cov = db.backfill_coverage(min_days=60)
        symbols = [s for s, c in cov["symbols"].items() if c >= 60][:max_symbols]
    except Exception:
        symbols = []
    if not symbols:
        return {"error": "일봉 60봉 이상 종목이 없습니다 - 데이터 수집 먼저"}
    res = V.run_backtest_detail(symbols, slots, start=start, end=end,
                                tp=tp, sl=sl, trail=trail, max_hold=hold,
                                max_symbols=max_symbols)
    trades = res["trades"]
    if not trades:
        return {"trades": [], "stats": {"trades": 0}, "note": "신호 없음"}
    avg = sum(t["ret_pct"] for t in trades) / len(trades)
    wins = [t for t in trades if t["ret_pct"] > 0]
    pf_den = abs(sum(t["ret_pct"] for t in trades if t["ret_pct"] <= 0)) or 0.001
    stats = {"trades": len(trades), "symbols": res["symbols_tested"],
             "avg_ret": round(avg, 2),
             "win_rate": round(len(wins) / len(trades) * 100, 1),
             "pf": round(sum(t["ret_pct"] for t in wins) / pf_den, 2),
             "elapsed": res["elapsed"]}
    return {"trades": trades, "stats": stats, "bars_loaded": res.get("bars_loaded")}


def run_validate(slots, tp, sl, trail, hold, max_symbols=200):
    """엄밀 검증: 백테스트 + 무작위 대조군 + 코스피 비교 + 등급"""
    bt = run_bt(slots, tp, sl, trail, hold, max_symbols=max_symbols)
    if bt.get("error"):
        return bt
    trades = bt["trades"]
    if len(trades) < 5:
        return {"grade": "기각", "note": f"매매 {len(trades)}건 - 표본 부족", "stats": bt["stats"]}
    bars = bt.get("bars_loaded") or {}
    _avgs, pct = V._random_control(trades, bars, runs=20)
    avg = bt["stats"]["avg_ret"]
    bench_vals = [t["bench_pct"] for t in trades if t.get("bench_pct") is not None]
    bench = sum(bench_vals) / len(bench_vals) if bench_vals else None
    grade = V.grade_condition(trades, pct, avg, bench)
    return {"grade": grade, "percentile": round(pct, 1),
            "bench_avg": round(bench, 2) if bench is not None else None,
            "excess": round(avg - (bench or 0), 2), "stats": bt["stats"],
            "note": ("무작위 대조군 " + str(round(pct, 1)) + "% 승리 · "
                     + ("코스피 대비 +" if bench is not None and avg > bench else "코스피 대비 ")
                     + (str(round(avg - (bench or 0), 2)) + "%p" if bench is not None else "벤치 없음"))}


def chart_data(symbol, days=260):
    bars = V._load_bars(symbol, max_days=days)
    return [{"d": b["date"], "o": b["open"], "h": b["high"],
             "l": b["low"], "c": b["close"], "v": b["volume"]} for b in bars]


def apply_env(params):
    """★ 파라미터 적용 (2026-08-28 변경: .env 대신 strategy/auto_params.json에 기록)
    - 사용자의 .env는 시스템이 절대 건드리지 않음 (수동 설정 공간으로 보존)
    - 읽기는 db.auto_param(): auto_params.json > .env > 기본값
    - 끄기: AUTO_OPT_APPLY=false (그러면 .env/기본값만 사용)
    """
    import json as _j
    os.makedirs("strategy", exist_ok=True)
    p = os.path.join("strategy", "auto_params.json")
    cur = {}
    try:
        cur = _j.load(open(p, encoding="utf-8"))
    except Exception:
        pass
    cur.update({
        "VALIDATE_TP_PCT": str(params["tp"]),
        "VALIDATE_SL_PCT": str(params["sl"]),
        "VALIDATE_TRAIL_PCT": str(params["trail"]),
        "VALIDATE_MAX_HOLD": str(params["hold"]),
        "PAPER_HOLD_DAYS": str(params["hold"]),
        "_updated_at": __import__("db").now_kst_iso(),
    })
    _j.dump(cur, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return {"applied": {k: v for k, v in cur.items() if not k.startswith("_")},
            "path": p}


def _apply_env_legacy(params):
    """(구버전 - .env 직접 수정. 더 이상 사용 안 함, 참고용 보존)"""
    keys = {
        "VALIDATE_TP_PCT": str(params["tp"]),
        "VALIDATE_SL_PCT": str(params["sl"]),
        "VALIDATE_TRAIL_PCT": str(params["trail"]),
        "VALIDATE_MAX_HOLD": str(params["hold"]),
        "PAPER_HOLD_DAYS": str(params["hold"]),
    }
    path = ".env"
    lines = []
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            lines = f.read().splitlines()
        try:
            import shutil
            shutil.copy(path, ".env.bak")
        except Exception:
            pass
    done = set()
    out = []
    for ln in lines:
        s = ln.strip()
        replaced = False
        for k, v in keys.items():
            if s.startswith(k + "=") or s.startswith("#" + k + "="):
                out.append(f"{k}={v}")
                done.add(k)
                replaced = True
                break
        if not replaced:
            out.append(ln)
    added = [k for k in keys if k not in done]
    if added:
        out.append("")
        out.append("# ── 비주얼 검증 랩에서 적용한 매도 파라미터 ──")
        for k in added:
            out.append(f"{k}={keys[k]}")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(out) + "\n")
    return {"ok": True, "applied": keys, "added": added,
            "note": "적용 완료 (.env.bak 백업) - 실행 중인 앱/수집기는 재시작해야 반영됩니다"}


HTML = """<!DOCTYPE html><html><head><meta charset="utf-8"><title>🔬 비주얼 검증 랩</title>
<style>
body{margin:0;background:#0d1117;color:#c9d1d9;font-family:'Malgun Gothic',sans-serif;font-size:13px}
.top{padding:10px 16px;background:#161b22;border-bottom:1px solid #30363d;display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.wrap{display:flex;height:calc(100vh - 56px)}
.side{width:360px;min-width:360px;overflow-y:auto;background:#10151c;border-right:1px solid #30363d;padding:12px}
.main{flex:1;display:flex;flex-direction:column;overflow:hidden}
select,button,input{background:#21262d;color:#c9d1d9;border:1px solid #30363d;border-radius:6px;padding:6px 10px;font-size:13px}
button{cursor:pointer}button:hover{background:#30363d}
button.primary{background:#1f6feb;border-color:#1f6feb;color:#fff}
button.green{background:#238636;border-color:#238636;color:#fff}
.param{margin:8px 0}.param label{display:flex;justify-content:space-between;color:#8b949e}
.param input[type=range]{width:100%}
.cards{display:flex;gap:6px;flex-wrap:wrap;margin:10px 0}
.card{background:#161b22;border:1px solid #30363d;border-radius:6px;padding:8px 10px;min-width:70px;text-align:center}
.card .k{font-size:10px;color:#8b949e}.card .v{font-size:15px;font-weight:bold}
.red{color:#f85149}.blue{color:#58a6ff}.gold{color:#e3b341}
.tlist{margin-top:8px}
.trow{padding:5px 8px;border-bottom:1px solid #21262d;cursor:pointer;display:flex;justify-content:space-between}
.trow:hover{background:#161b22}.trow.sel{background:#1f2937}
#cv{width:100%;flex:1}
#chartbox{flex:1;display:flex;flex-direction:column;padding:8px}
.badge{padding:2px 8px;border-radius:10px;font-size:11px;font-weight:bold}
.g0{background:#238636;color:#fff}.g1{background:#9e6a03;color:#fff}.g2{background:#30363d}.g3{background:#da3633;color:#fff}
#status{color:#8b949e;font-size:12px}
h4{margin:12px 0 4px;color:#8b949e;font-weight:normal;border-bottom:1px solid #21262d;padding-bottom:3px}
</style></head><body>
<div class="top">
  <b>🔬 비주얼 검증 랩</b>
  <select id="cond" style="max-width:520px"></select>
  <button class="primary" onclick="bt()">▶ 백테스트</button>
  <button class="green" onclick="validate()">🎯 엄밀 검증 (대조군+등급)</button>
  <button style="background:#8957e5;border-color:#8957e5;color:#fff" onclick="applyEnv()">💾 이 설정을 실전에 적용</button>
  <span id="grade"></span><span id="status"></span>
</div>
<div class="wrap">
<div class="side">
  <h4>⚙️ 매도 파라미터 (조정 → 다시 백테스트)</h4>
  <div class="param"><label>익절 TP <span id="tpv">5.0%</span></label>
    <input type="range" id="tp" min="1" max="20" step="0.5" value="5" oninput="pv()"></div>
  <div class="param"><label>손절 SL <span id="slv">3.0%</span></label>
    <input type="range" id="sl" min="1" max="10" step="0.5" value="3" oninput="pv()"></div>
  <div class="param"><label>트레일링 <span id="trv">2.0%</span></label>
    <input type="range" id="tr" min="0" max="8" step="0.5" value="2" oninput="pv()"></div>
  <div class="param"><label>최대 보유일 <span id="hdv">10일</span></label>
    <input type="range" id="hd" min="1" max="30" step="1" value="10" oninput="pv()"></div>
  <div class="param"><label>테스트 종목 수 <span id="msv">200</span></label>
    <input type="range" id="ms" min="50" max="1000" step="50" value="200" oninput="pv()"></div>
  <h4>📊 결과</h4>
  <div class="cards" id="stats"></div>
  <h4>📋 매매 내역 (클릭 → 차트)</h4>
  <div class="tlist" id="tlist"></div>
</div>
<div class="main"><div id="chartbox">
  <div id="cinfo" style="padding:4px 8px;color:#8b949e">조건식 선택 → 백테스트 → 매매 클릭하면 차트에 매수/매도 시점이 표시됩니다</div>
  <canvas id="cv"></canvas>
</div></div>
</div>
<script>
let CONDS=[], TRADES=[], BARS=[], SEL=-1, SYM="";
function $(i){return document.getElementById(i)}
function pv(){$('tpv').innerText=$('tp').value+'%';$('slv').innerText=$('sl').value+'%';
$('trv').innerText=$('tr').value+'%';$('hdv').innerText=$('hd').value+'일';$('msv').innerText=$('ms').value}
async function load(){
  const r=await fetch('/api/conditions'); CONDS=await r.json();
  $('cond').innerHTML=CONDS.map((c,i)=>`<option value="${i}">[${c.src}] ${c.txt}</option>`).join('');
}
function params(){return `tp=${$('tp').value}&sl=${$('sl').value}&trail=${$('tr').value}&hold=${$('hd').value}&ms=${$('ms').value}`}
async function bt(){
  const i=$('cond').value; if(i==='')return;
  $('status').innerText='⏳ 백테스트 중... (종목 수에 따라 수십 초)'; $('grade').innerHTML='';
  const r=await fetch('/api/backtest?idx='+i+'&'+params()); const d=await r.json();
  $('status').innerText=d.error||('완료 '+(d.stats.elapsed||0)+'초');
  if(d.error)return; TRADES=d.trades||[];
  const s=d.stats;
  $('stats').innerHTML=`
  <div class="card"><div class="k">매매</div><div class="v">${s.trades}</div></div>
  <div class="card"><div class="k">승률</div><div class="v ${s.win_rate>=50?'red':'blue'}">${s.win_rate||0}%</div></div>
  <div class="card"><div class="k">평균수익</div><div class="v ${s.avg_ret>0?'red':'blue'}">${s.avg_ret||0}%</div></div>
  <div class="card"><div class="k">손익비</div><div class="v">${s.pf||0}</div></div>
  <div class="card"><div class="k">종목</div><div class="v">${s.symbols||0}</div></div>`;
  $('tlist').innerHTML=TRADES.slice(0,300).map((t,j)=>
   `<div class="trow" id="tr${j}" onclick="pick(${j})"><span>${t.symbol} ${t.entry_date}</span>
    <span class="${t.ret_pct>0?'red':'blue'}">${t.ret_pct>0?'+':''}${t.ret_pct.toFixed(1)}% ${t.exit_reason||''}</span></div>`).join('');
}
async function validate(){
  const i=$('cond').value; if(i==='')return;
  $('status').innerText='⏳ 엄밀 검증 중... (백테스트+무작위 대조군 20회)';
  const r=await fetch('/api/validate?idx='+i+'&'+params()); const d=await r.json();
  $('status').innerText=d.note||'';
  const cls={'채택 후보':'g0','조건부':'g1','수익만':'g2','기각':'g3'}[d.grade]||'g2';
  $('grade').innerHTML=`<span class="badge ${cls}">${d.grade||'?'}</span>
   <span style="color:#8b949e;font-size:11px">대조군백분위 ${d.percentile||'-'} · 초과수익 ${d.excess||'-'}%p</span>`;
  if(d.stats)TRADES.length||bt();
}
async function pick(j){
  if(SEL>=0){const e=$('tr'+SEL); if(e)e.classList.remove('sel')}
  SEL=j; const e=$('tr'+j); if(e)e.classList.add('sel');
  const t=TRADES[j]; SYM=t.symbol;
  const r=await fetch('/api/chart?symbol='+t.symbol); BARS=await r.json();
  $('cinfo').innerHTML=`<b>${t.symbol}</b> 매수 ${t.entry_date} @${t.entry.toLocaleString()} →
   매도 ${t.exit_date} @${t.exit.toLocaleString()}
   <span class="${t.ret_pct>0?'red':'blue'}">${t.ret_pct>0?'+':''}${t.ret_pct.toFixed(2)}%</span>
   (${t.hold_days}일 · ${t.exit_reason||''})  <span style="color:#8b949e">▲매수 ▼매도 · 이 종목의 다른 매매도 함께 표시</span>`;
  draw();
}
function draw(){
  const cv=$('cv'), box=$('chartbox');
  cv.width=box.clientWidth-16; cv.height=box.clientHeight-40;
  const g=cv.getContext('2d'); g.fillStyle='#0d1117'; g.fillRect(0,0,cv.width,cv.height);
  if(!BARS.length)return;
  const n=BARS.length, W=cv.width-70, H=cv.height-30, X0=8, Y0=8;
  let hi=-1e18, lo=1e18;
  BARS.forEach(b=>{hi=Math.max(hi,b.h); lo=Math.min(lo,b.l)});
  const pad=(hi-lo)*0.05; hi+=pad; lo-=pad;
  const bw=W/n, y=v=>Y0+H*(1-(v-lo)/(hi-lo));
  // grid
  g.strokeStyle='#21262d'; g.fillStyle='#8b949e'; g.font='10px sans-serif';
  for(let k=0;k<=4;k++){const v=lo+(hi-lo)*k/4, yy=y(v);
    g.beginPath(); g.moveTo(X0,yy); g.lineTo(X0+W,yy); g.stroke();
    g.fillText(Math.round(v).toLocaleString(), X0+W+4, yy+3)}
  // MA20
  g.strokeStyle='#e3b341'; g.beginPath(); let started=false;
  for(let i=19;i<n;i++){let s=0; for(let k=i-19;k<=i;k++)s+=BARS[k].c;
    const yy=y(s/20), xx=X0+bw*i+bw/2;
    if(!started){g.moveTo(xx,yy);started=true}else g.lineTo(xx,yy)}
  g.stroke();
  // candles
  for(let i=0;i<n;i++){const b=BARS[i], xx=X0+bw*i;
    const up=b.c>=b.o; g.strokeStyle=g.fillStyle=up?'#f85149':'#58a6ff';
    g.beginPath(); g.moveTo(xx+bw/2,y(b.h)); g.lineTo(xx+bw/2,y(b.l)); g.stroke();
    const t=y(Math.max(b.o,b.c)), h2=Math.max(1,Math.abs(y(b.o)-y(b.c)));
    g.fillRect(xx+Math.max(0.5,bw*0.15), t, Math.max(1,bw*0.7), h2)}
  // trade markers (이 종목의 모든 매매)
  const dts={}; BARS.forEach((b,i)=>dts[b.d]=i);
  TRADES.filter(t=>t.symbol===SYM).forEach(t=>{
    const ei=dts[t.entry_date], xi=dts[t.exit_date];
    if(ei!==undefined){const xx=X0+bw*ei+bw/2, yy=y(BARS[ei].l)+12;
      g.fillStyle='#3fb950'; g.beginPath(); g.moveTo(xx,yy-8); g.lineTo(xx-5,yy); g.lineTo(xx+5,yy); g.fill();
      g.font='bold 10px sans-serif'; g.fillText('매수',xx-11,yy+11)}
    if(xi!==undefined){const xx=X0+bw*xi+bw/2, yy=y(BARS[xi].h)-12;
      g.fillStyle=t.ret_pct>0?'#f85149':'#58a6ff'; g.beginPath();
      g.moveTo(xx,yy+8); g.lineTo(xx-5,yy); g.lineTo(xx+5,yy); g.fill();
      g.fillText('매도',xx-11,yy-4)}});
  // dates
  g.fillStyle='#8b949e';
  for(let k=0;k<5;k++){const i=Math.min(n-1,Math.round(n*k/4));
    g.fillText(BARS[i].d.slice(2), X0+bw*i, Y0+H+14)}
}
async function applyEnv(){
  if(!confirm(`현재 설정을 .env에 적용할까요?\\n익절 ${$('tp').value}% · 손절 ${$('sl').value}% · 트레일링 ${$('tr').value}% · 보유 ${$('hd').value}일\\n(모의매매/검증 모두 이 기준을 사용하게 됩니다)`))return;
  const r=await fetch('/api/apply?'+params()); const d=await r.json();
  $('status').innerText=d.note||d.error||'';
  alert(d.ok?('✅ 적용 완료!\\n'+JSON.stringify(d.applied,null,1)+'\\n\\n⚠️ 실행 중인 앱은 재시작해야 반영됩니다'):('실패: '+(d.error||'')));
}
window.onresize=()=>{if(BARS.length)draw()};
load();
</script></body></html>"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        q = dict(urllib.parse.parse_qsl(u.query))
        try:
            if u.path == "/":
                body = HTML.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            elif u.path == "/api/conditions":
                self._json(list_conditions())
            elif u.path == "/api/backtest":
                conds = list_conditions()
                idx = int(q.get("idx", 0))
                if idx >= len(conds):
                    return self._json({"error": "조건식 없음"})
                slots = _norm_slots(conds[idx]["slots"])
                with _LOCK:
                    r = run_bt(slots, float(q.get("tp", 5)), float(q.get("sl", 3)),
                               float(q.get("trail", 2)), int(q.get("hold", 10)),
                               max_symbols=int(q.get("ms", 200)))
                r.pop("bars_loaded", None)
                self._json(r)
            elif u.path == "/api/validate":
                conds = list_conditions()
                idx = int(q.get("idx", 0))
                if idx >= len(conds):
                    return self._json({"error": "조건식 없음"})
                slots = _norm_slots(conds[idx]["slots"])
                with _LOCK:
                    r = run_validate(slots, float(q.get("tp", 5)), float(q.get("sl", 3)),
                                     float(q.get("trail", 2)), int(q.get("hold", 10)),
                                     max_symbols=int(q.get("ms", 200)))
                self._json(r)
            elif u.path == "/api/chart":
                self._json(chart_data(q.get("symbol", "005930")))
            elif u.path == "/api/apply":
                r = apply_env({"tp": float(q.get("tp", 5)), "sl": float(q.get("sl", 3)),
                               "trail": float(q.get("trail", 2)), "hold": int(q.get("hold", 10))})
                self._json(r)
            else:
                self._json({"error": "not found"}, 404)
        except Exception as e:
            try:
                self._json({"error": str(e)[:200]}, 500)
            except Exception:
                pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8899)
    args = ap.parse_args()
    srv = ThreadingHTTPServer(("0.0.0.0", args.port), Handler)
    print(f"🔬 비주얼 검증 랩: http://localhost:{args.port}  (Ctrl+C 종료)")
    print("   조건식 선택 → ▶백테스트 → 매매 클릭(차트에 ▲매수 ▼매도) → 슬라이더 조정 → 🎯엄밀 검증")
    srv.serve_forever()


if __name__ == "__main__":
    main()
