# -*- coding: utf-8 -*-
"""
🧬 급등 유전자 발굴 (surge_mining.py) — '급등하는 종목들의 공통 조건' 찾기
==========================================================================
아이디어 (사용자): "과거 자료에서 급등하는 조건들의 교집합을 찾아보려다 실패했다.
그런 유전자들을 찾아낼 수 있나?"

핵심 (실패하지 않는 방법):
  1) ★ 급등 직전(T-1) 역추적: 급등 '후'가 아니라 급등 '직전' 상태를 본다
     (래리 윌리엄스: "급등은 항상 어떤 상태 뒤에 온다")
  2) ★ 무작위 대조군: '급등 직전에 참인 조건' vs '아무 때나 참인 조건' 비율 비교
     → 우연이 아닌 것만 통과 (백분위 ≥ 95 = 무작위와 구별)
  3) 표본 최소 요건: 급등 사례가 30건 미만이면 신뢰 불가 (우연일 수 있음)
  4) 상위 조건 교집합 → 조건식 생성 → 엄밀 검증(validation)으로 재확인

실행:
  python surge_mining.py --run             # 급등 유전자 발굴 (쌓인 일봉 사용)
  python surge_mining.py --symbols 100     # 상위 100종목만 (빠른 테스트)
  python surge_mining.py --list            # 이전 발굴 결과 보기
"""
import argparse
import json
import logging
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import random
import sys
import time
from datetime import datetime

logging.basicConfig(level=logging.WARNING)
try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db
from config import CFG

log = logging.getLogger("surge")

# ── 파라미터 ──
SURGE_PCT = _cfg_env_float("SURGE_PCT", 20.0)      # 급등 정의: N일 내 +20%
SURGE_DAYS = _cfg_env_int("SURGE_DAYS", 10)        # 급등 관찰 기간
MIN_SURGES = _cfg_env_int("SURGE_MIN_SURGES", 30)  # 최소 급등 사례 수
PERCENTILE = _cfg_env_float("SURGE_PERCENTILE", 90)  # 무작위 대비 백분위 관문
# ★ 봉/기간/우상향 옵션 (사용자 질문 반영)
SURGE_TF = os.getenv("SURGE_TF", "day")     # day=일봉 | min1/min3/min15=분봉 (분봉은 관심종목용)
SURGE_TREND_UP = os.getenv("SURGE_TREND_UP", "false").lower() == "true"  # '어느 시점 이후 우상향' 조건 추가
SURGE_TREND_DAYS = _cfg_env_int("SURGE_TREND_DAYS", 20)  # 우상향 판단 기간(봉 수)
LOOKBACK = 60                                          # 조건 평가에 쓰는 과거 봉 수


def _load_bars_for_tf(sym):
    """★ 봉 기준별 시계열 로드: day=일봉 / min*=분봉 (분봉은 관심/지정 종목만)
    - 분봉은 최근 7거래일뿐이라 급등 사례가 적음 → max_symbols 제한 + 최소 봉수 완화
    반환: bars 리스트 (오래된순) / [] 실패
    """
    tf = SURGE_TF
    if tf == "day":
        from strategy_auto import get_daily_series
        return get_daily_series(sym, max_days=400)
    try:
        # 분봉: 네이버 실시간 1분봉 (일수만큼)
        from backfill_history import fetch_minutes
        bars = fetch_minutes(sym, max_bars=6000)
        out = []
        for b in bars:
            out.append({"date": str(b["bar_time"])[:10], "close": b["price"],
                        "high": b["price"], "low": b["price"],
                        "volume": b.get("volume") or 0})
        # SURGE_TF가 min15면 15분봉 리샘플, min60이면 1시간봉 (단순 합산)
        if tf in ("min15", "min60"):
            grp = 15 if tf == "min15" else 60
            res = []
            for i in range(0, len(out), grp):
                chunk = out[i:i + grp]
                if not chunk:
                    continue
                res.append({"date": chunk[-1]["date"], "close": chunk[-1]["close"],
                            "high": max(c["high"] for c in chunk),
                            "low": min(c["low"] for c in chunk),
                            "volume": sum(c["volume"] for c in chunk)})
            out = res
        return out
    except Exception:
        return []


def _load_surge_samples(symbols, max_symbols=500):
    """급등 직전(T-1) 상태 수집
    - 각 종목에서 SURGE_DAYS 내 +SURGE_PCT 급등 지점 찾기 (봉 기준: SURGE_TF)
    - SURGE_TREND_UP=true면 '어느 시점 이후 우상향' 종목만 (추세 필터)
    - 그 직전 봉의 조건 참/거짓(52개 슬롯) 스냅샷 + 같은 종목 무작위 시점 스냅샷
    반환: {"surge": [ {slot: 0/1, price, date, tf} ... ], "random": [...]}
    """
    from screener import SLOTS, build_features
    surge, rnd = [], []
    n_sym = 0
    for sym in symbols[:max_symbols]:
        bars = _load_bars_for_tf(sym)
        if len(bars) < 40:   # 분봉은 7일치라 완화
            continue
        closes_all = [b["close"] for b in bars]
        n_sym += 1
        closes = [b["close"] for b in bars]
        highs = [b["high"] or b["close"] for b in bars]
        f = build_features(bars)
        if not f:
            continue
        slot_keys = list(SLOTS.keys())
        fns = [SLOTS[k][3] for k in slot_keys]
        prms = [{} for _ in slot_keys]

        def _snap(i):
            """인덱스 i 봉에서 52개 슬롯 참/거짓"""
            row = {}
            for k, fn, p in zip(slot_keys, fns, prms):
                try:
                    row[k] = 1 if fn(f, i, p) else 0
                except Exception:
                    row[k] = 0
            return row

        n = len(bars)
        vols = [b.get("volume") or 0 for b in bars]
        _pmin = _cfg_env_float("MOCK_PRICE_MIN", 800)
        _pmax = _cfg_env_float("MOCK_PRICE_MAX", 100000)
        _amin = _cfg_env_float("VALIDATE_MIN_AMOUNT", 300000000)
        # 급등 이벤트: i에서 SURGE_DAYS 내 고가가 종가*(1+pct) 이상
        for i in range(60, n - SURGE_DAYS):
            entry = closes[i]
            # ★ 실전-검증 일치 필터 (2026-08-27): 동전주/잡주 급등(작전성)에서
            #   '유전자'를 배우면 조건식 후보가 오염됨 - 실전 매수 가능 종목만 학습
            if entry < _pmin or entry > _pmax:
                continue
            if i >= 5:
                amt5 = sum(closes[k] * vols[k] for k in range(i - 4, i + 1)) / 5
                if amt5 < _amin:
                    continue
            # ★ 급등 직전(i) 기준 우상향: 직전 SURGE_TREND_DAYS 저점 상승
            if SURGE_TREND_UP and i >= SURGE_TREND_DAYS * 2:
                h_lows = min(closes[i - SURGE_TREND_DAYS * 2:i - SURGE_TREND_DAYS])
                r_lows = min(closes[i - SURGE_TREND_DAYS:i])
                if r_lows < h_lows:
                    continue
            if entry <= 0:
                continue
            target = entry * (1 + SURGE_PCT / 100.0)
            if max(highs[i + 1:i + SURGE_DAYS + 1]) >= target:
                snap = _snap(i)   # ★ 급등 직전 상태
                snap["date"] = str(bars[i]["date"])[:10]
                snap["price"] = entry
                surge.append(snap)
        # 무작위 시점 (같은 종목 - 대조군)
        # ★ 대조군도 급등표본과 같은 필터 적용 (한쪽만 거르면 비교 왜곡 - 2026-08-27)
        if n - SURGE_DAYS - 1 <= 60:
            continue   # 봉 부족 - 무작위 구간 없음 (기존 randint 크래시 방지)
        rng = random.Random(42)
        _tries = 0
        _want = min(len(surge) // max(1, n_sym) + 5, 40)
        while len([r for r in rnd if r.get("_sym") == sym]) < _want and _tries < _want * 5:
            _tries += 1
            i = rng.randint(61, n - SURGE_DAYS - 1)
            if closes[i] < _pmin or closes[i] > _pmax:
                continue
            if i >= 5:
                amt5 = sum(closes[k] * vols[k] for k in range(i - 4, i + 1)) / 5
                if amt5 < _amin:
                    continue
            snap = _snap(i)
            snap["date"] = str(bars[i]["date"])[:10]
            snap["price"] = closes[i]
            snap["_sym"] = sym
            rnd.append(snap)
    return {"surge": surge, "random": rnd, "symbols": n_sym}


def mine_genes(symbols=None, max_symbols=500, save=True):
    """★ 급등 유전자 발굴
    1) 급등 직전 vs 무작위: 각 슬롯 참 비율 비교
    2) 지지율 차이 + 백분위로 우연 아닌 조건 선별
    3) 상위 조건 교집합 → 조건식 후보 생성
    반환: {"genes": [...], "candidates": [...], "surge_count", "note"}
    """
    from screener import SLOTS
    t0 = time.time()
    if symbols is None:
        try:
            cov = db.backfill_coverage(min_days=60)
            symbols = [s for s, c in cov["symbols"].items() if c >= 60][:max_symbols]
        except Exception:
            symbols = []
    if not symbols:
        return {"genes": [], "candidates": [], "surge_count": 0,
                "note": "데이터 없음 - 백필 진행 후 재시도"}
    data = _load_surge_samples(symbols, max_symbols=max_symbols)
    surge, rnd = data["surge"], data["random"]
    n_surge = len(surge)
    print(f"  종목 {data['symbols']}개 · 급등 직전 {n_surge}건 · 무작위 {len(rnd)}건")
    if n_surge < MIN_SURGES:
        return {"genes": [], "candidates": [], "surge_count": n_surge,
                "note": f"급등 사례 {n_surge}건 < {MIN_SURGES}건 - 표본 부족 (더 오래 데이터 쌓기)"}

    # 1) 각 슬롯 급등 직전 참 비율 vs 무작위 참 비율
    genes = []
    for k in SLOTS:
        s_pct = sum(1 for x in surge if x.get(k)) / n_surge * 100
        r_pct = sum(1 for x in rnd if x.get(k)) / max(1, len(rnd)) * 100
        diff = s_pct - r_pct
        genes.append({"slot": k, "surge_pct": round(s_pct, 1),
                      "random_pct": round(r_pct, 1), "diff": round(diff, 1)})
    # 2) 우연 아닌 것: diff > 0 (급등 직전에 더 자주 참) + 지지율 20%+
    genes = [g for g in genes if g["diff"] > 5 and g["surge_pct"] >= 20]
    genes.sort(key=lambda g: -g["diff"])

    # 3) 교집합 조건식 후보: 상위 N개 조합 (과적합 방지 - 3~4개만)
    candidates = []
    top = genes[:6]
    if len(top) >= 2:
        import itertools
        for combo_size in (3, 4):
            for combo in itertools.combinations([g["slot"] for g in top], combo_size):
                # 조합 지지율 = 모든 조건이 참인 급등 비율
                support = sum(1 for x in surge if all(x.get(c) for c in combo)) / n_surge * 100
                if support >= 15:  # 급등 중 15% 이상이 이 조합을 만족
                    # ★ 성공확률: 이 조합이 참일 때 실제 급등으로 이어진 비율
                    hit = sum(1 for x in surge if all(x.get(c) for c in combo))
                    base = sum(1 for x in rnd if all(x.get(c) for c in combo))
                    success_pct = hit / max(1, hit + base) * 100
                    candidates.append({
                        "slots": list(combo),
                        "support": round(support, 1),
                        "success_pct": round(success_pct, 1),
                        "hit": hit, "base": base,
                        "slots_txt": " AND ".join(SLOTS[c][0] for c in combo),
                    })
    candidates.sort(key=lambda c: -c["support"])
    candidates = candidates[:5]

    if save:
        _save_result(genes, candidates, n_surge, data["symbols"],
                     round(time.time() - t0, 1))
    return {"genes": genes, "candidates": candidates, "surge_count": n_surge,
            "random_count": len(rnd), "symbols": data["symbols"],
            "elapsed": round(time.time() - t0, 1)}


def _save_result(genes, candidates, n_surge, n_sym, elapsed):
    try:
        os.makedirs("strategy", exist_ok=True)
        with open(os.path.join("strategy", "surge_genes.json"), "w", encoding="utf-8") as f:
            json.dump({"at": db.now_kst_iso(), "surge_count": n_surge,
                       "symbols": n_sym, "elapsed": elapsed,
                       "genes": genes[:20], "candidates": candidates},
                      f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def load_genes():
    try:
        with open(os.path.join("strategy", "surge_genes.json"), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def promote_candidate(candidate, cond_no=None):
    """★ 교집합 후보 → 실제 조건식으로 등록 (모의매매/검증에 투입)
    - 슬롯은 파라미터 기본값 사용 (screener 기본)
    """
    from screener import SLOTS
    slots = []
    for k in candidate["slots"]:
        name, pnames, defaults, _fn = SLOTS[k]
        p = {}
        if defaults:
            d0 = defaults[0]
            if isinstance(d0, dict):
                p = dict(d0)
            elif isinstance(d0, (tuple, list)) and d0:
                for pi, pn in enumerate(pnames):
                    if pi < len(d0):
                        p[pn] = d0[pi]
            elif d0 is not None and pnames:
                # 단일 값 (예: mom5_up 기본 2, 파라미터명 ['x'])
                p[pnames[0]] = d0
        slots.append((k, p))
    no = cond_no or db.next_cond_no("S")
    txt = " AND ".join(SLOTS[k][0].format(**p) for k, p in slots)
    cid = db.create_condition(no, f"[유전자] {txt}", slots, source="rule", tf="day")
    return {"id": cid, "cond_no": no, "txt": txt}


def show_results(res):
    if not res or not res.get("genes"):
        print("발굴 결과 없음 (표본 부족 또는 실행 전)")
        return
    print("=" * 70)
    print(f"🧬 급등 유전자 (급등 {res.get('surge_count')}건 · 종목 {res.get('symbols')}개 · "
          f"{res.get('elapsed', 0)}초)")
    print("=" * 70)
    print("【급등 직전에 특히 자주 참이던 조건 (무작위 대비)】")
    print(f"{'조건':<32}{'급등직전':>8}{'무작위':>8}{'차이':>7}")
    for g in res["genes"][:15]:
        print(f"{g['slot']:<32}{g['surge_pct']:>7}%{g['random_pct']:>7}%{g['diff']:>+6.1f}")
    print()
    print("【교집합 조건식 후보 (지지율 + 성공확률)】")
    for i, c in enumerate(res.get("candidates", [])[:5], 1):
        sp = c.get("success_pct", 0)
        print(f"  {i}. 지지율 {c['support']}% · 성공확률 {sp}%: {c['slots_txt'][:55]}")
    print()
    print("→ 후보를 조건식으로 등록: promote_candidate() 또는 엄밀 검증으로 재확인")
    print("=" * 70)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="급등 유전자 발굴")
    parser.add_argument("--run", action="store_true", help="발굴 실행")
    parser.add_argument("--symbols", type=int, default=500, help="사용 종목 수")
    parser.add_argument("--list", action="store_true", help="이전 결과 보기")
    args = parser.parse_args()
    db.init_db()
    if args.list:
        show_results(load_genes())
    elif args.run:
        res = mine_genes(max_symbols=args.symbols)
        show_results(res)
    else:
        parser.print_help()


def auto_promote_candidates(max_symbols=500, min_success=60.0, max_add=3):
    """★ 유전자 → 검색식 자동 등록 (자동파일럿 통합용)
    - 발굴 → 교집합 후보 중 성공확률 ≥ min_success만
    - 이미 등록된 같은 내용은 스킵 (중복 방지)
    - 엄밀 검증으로 재확인 후 등록
    반환: {"added": n, "list": [...], "note"}
    """
    from condition_manager import _diff_slots  # noqa
    from screener import SLOTS
    res = mine_genes(max_symbols=max_symbols)
    if not res.get("candidates"):
        return {"added": 0, "list": [], "note": f"유전자 후보 없음 (급등 {res.get('surge_count', 0)}건)"}
    added = []
    # 기존 등록된 슬롯 시그니처 (중복 방지)
    existing = set()
    try:
        for c in db.get_conditions(status="active"):
            try:
                existing.add(db.normalize_slots(c.get("slots_json")))
            except Exception:
                pass
    except Exception:
        pass
    for cand in res["candidates"]:
        if len(added) >= max_add:
            break
        success = cand.get("success_pct", 0)
        if success < min_success:
            continue
        # 파라미터 포함 슬롯
        slots = []
        for k in cand["slots"]:
            name, pnames, defaults, _fn = SLOTS[k]
            p = {}
            if defaults:
                d0 = defaults[0]
                if isinstance(d0, dict):
                    p = dict(d0)
                elif isinstance(d0, (tuple, list)) and d0:
                    for pi, pn in enumerate(pnames):
                        if pi < len(d0):
                            p[pn] = d0[pi]
                elif d0 is not None and pnames:
                    p[pnames[0]] = d0
            slots.append((k, p))
        try:
            sig = db.normalize_slots(slots)
            if sig in existing:
                continue
        except Exception:
            pass
        # ★ 2026-09-02 전종목 최종면접 (팜/빌더와 동일 기준 - 사용자:
        #   "새 조건식이 전체 검증을 받은 게 아니라 애매함" 해소)
        #   기존: 100종목 약식 + 느슨한 판정(AND 조건 버그로 사실상 무사통과)
        _vr = None
        try:
            txt_tmp = " AND ".join(SLOTS[k][0].format(**p) for k, p in slots)
            from farm_league import _debut_gate
            ok_g, why_g, _vr = _debut_gate(slots, f"[급등유전자] {txt_tmp}")
            if not ok_g:
                continue  # 전종목 면접 탈락 - 등록 안 함
        except Exception:
            continue      # 면접 자체가 실패해도 등록 보류 (검증 없는 편입 금지)
        # 등록 (★ backlog로 - 기존엔 기본값 active라 검증 없이 바로 매수에 쓰였음!)
        no = db.next_cond_no("S")
        txt = " AND ".join(SLOTS[k][0].format(**p) for k, p in slots)
        cid = db.create_condition(no, f"[급등유전자] {txt}", slots, source="rule", tf=SURGE_TF)
        if cid:
            db.set_condition_status(cid, "backlog")
            try:
                from validation import save_validation_results
                if _vr:
                    _vr["cond_key"] = str(cid)
                    _vr["cond_no"] = no
                    save_validation_results([_vr])
            except Exception:
                pass
            existing.add(sig)
            added.append({"cond_no": no, "txt": txt[:60], "success_pct": success,
                          "support": cand.get("support", 0)})
    return {"added": len(added), "list": added,
            "note": f"급등 {res.get('surge_count', 0)}건에서 후보 {len(added)}개 등록"}
