# -*- coding: utf-8 -*-
"""
🏷 조건식 이름 자동 부여 (name_conditions.py)
==============================================
조건식들이 "MA10 상승추세유지 AND 정배열(10>20>50) AND ..." 같은 긴 문장이라
사람이 구분하기 어려움 → 짧고 기억하기 쉬운 별명을 자동 부여.

- AI(Gemini 키 있으면): 조건식 내용을 보고 한글 별명 생성 (예: "정배열 눌림줍기")
- 키 없으면: 규칙 기반 자동 작명 (핵심 슬롯 2개 조합. 예: "골든크로스+거래급증")
- 별명은 cond_txt 앞에 [별명] 형태로 저장 → 앱/현황판/성적표 어디서나 보임
- 이미 별명([xxx])이 있으면 건너뜀 (재실행 안전)

실행:
  python name_conditions.py          # 별명 없는 조건식 전부 작명
  python name_conditions.py --list   # 현재 이름 목록만 보기
"""
import argparse
import json
import re
import sys

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

# 슬롯 키 → 짧은 한글 태그 (규칙 작명용)
TAG = {
    "ma_above": "이평위", "ma_below": "이평아래", "ma_rising": "상승추세",
    "ma_align": "정배열", "ma_align_10_20_50": "정배열", "ma_align_20_50_200": "장기정배열",
    "ma_align_20_60_120": "장기정배열", "ma_align_5_10_15": "단기정배열",
    "ma_below_rev": "역배열", "below_ma_prev": "눌림",
    "vol_surge": "거래급증", "vol_ratio20": "거래증가", "vol_2day_up": "거래연속증가",
    "vol_high5": "신고거래량",
    "rsi_oversold": "과매도", "rsi_under": "RSI저점", "rsi_overbought": "과매수",
    "rsi_rising": "RSI상승",
    "mom5_up": "모멘텀", "mom5_down": "급락후", "fall_from_high60": "낙폭과대",
    "golden_cross": "골든크로스", "golden_cross_1_5": "골든크로스", "dead_cross_1_5": "데드후",
    "macd_signal_cross": "MACD돌파", "macd_above_zero": "MACD양전", "macd_rising": "MACD상승",
    "macd_osc_rising": "오실상승", "macd_signal_rising": "시그널상승",
    "high_break": "신고가", "high5_break": "5일신고", "high20_break": "20일신고",
    "high60_break": "60일신고", "high250_near": "연중고점", "chigh5": "종가신고", "chigh20": "종가신고",
    "low_rebound": "바닥반등", "low_near": "신저가권",
    "boll_break_up": "볼린저돌파", "env_break": "엔벨돌파",
    "stoch_k_rising": "스토캐스틱상승", "stoch_k_above_d": "스토캐스틱골든", "stoch_k_under": "스토캐스틱저점",
    "up_candles": "연속양봉", "down_candles": "연속음봉", "period_rise": "급등이력",
    "prev_high_break": "전고돌파", "chg_under": "추격방지", "disp_under": "이격축소",
    "ma1_above_60": "60선위", "ma1_above_120": "120선위",
}


def rule_name(slots):
    """규칙 작명: 중요 슬롯 2개 태그 조합"""
    tags = []
    for it in slots:
        k = it[0] if isinstance(it, (list, tuple)) else it
        t = TAG.get(k)
        if t and t not in tags:
            tags.append(t)
    if not tags:
        return "복합전략"
    return "+".join(tags[:2])


def ai_names(conds):
    """Gemini로 별명 일괄 생성. 실패 시 {} (규칙 폴백)"""
    try:
        from ai_judge import call_llm, AI_ENABLED, GEMINI_API_KEY, OPENAI_API_KEY
        if not (AI_ENABLED and (GEMINI_API_KEY or OPENAI_API_KEY)):
            return {}
        lines = [f"{c['id']}: {c['cond_txt'][:90]}" for c in conds[:40]]
        prompt = ("다음은 주식 조건검색식 목록입니다. 각각에 6자 이내 한글 별명을 지어주세요.\n"
                  "별명은 전략 특징이 드러나게 (예: 눌림줍기, 바닥반등, 불기둥, 조용한상승).\n"
                  "형식(꼭 지켜, 한 줄에 하나): id|별명\n\n" + "\n".join(lines))
        res = call_llm("당신은 트레이딩 전략에 재치있는 이름을 짓는 전문가입니다.", prompt)
        out = {}
        if res:
            for ln in res.splitlines():
                if "|" not in ln:
                    continue
                cid, nm = ln.split("|", 1)
                cid = cid.strip().lstrip("-• ").strip()
                nm = re.sub(r"[\[\]\"']", "", nm.strip())[:8]
                if cid and nm:
                    out[cid] = nm
        return out
    except Exception:
        return {}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true")
    args = ap.parse_args()

    conds = db.get_conditions(status=None) if hasattr(db, "get_conditions") else []
    try:
        conds = db.get_conditions(status="active") + db.get_conditions(status="backlog")
    except Exception:
        pass
    if args.list:
        for c in conds:
            print(f"  {c['cond_no']:>3}번 | {c['cond_txt'][:70]}")
        return

    # 별명 없는 것만
    unnamed = [c for c in conds if not str(c.get("cond_txt", "")).startswith("[")]
    print(f"🏷 조건식 {len(conds)}개 중 별명 없는 것 {len(unnamed)}개")
    if not unnamed:
        print("✅ 전부 별명 있음")
        return

    ai = ai_names(unnamed)
    provider = "AI" if ai else "규칙"
    print(f"작명 방식: {provider}" + ("" if ai else " (Gemini 미연결/실패 - 슬롯 태그 조합)"))

    used = set()
    n = 0
    with db.get_conn() as conn:
        for c in unnamed:
            cid = str(c["id"])
            name = ai.get(cid)
            if not name:
                try:
                    slots = json.loads(c.get("slots_json") or "[]")
                except Exception:
                    slots = []
                name = rule_name(slots)
            # 중복 별명이면 번호 붙임
            base = name
            k = 2
            while name in used:
                name = f"{base}{k}"
                k += 1
            used.add(name)
            new_txt = f"[{name}] {c['cond_txt']}"
            conn.execute("UPDATE conditions SET cond_txt=? WHERE id=?", (new_txt, c["id"]))
            n += 1
            print(f"  {c['cond_no']:>3}번 → [{name}]")
    print(f"\n✅ {n}개 작명 완료 - 앱/현황판/성적표에 [별명]으로 표시됩니다")


if __name__ == "__main__":
    main()
