@echo off
title Install - Live Mode (OpenAPI+)
cd /d %~dp0
echo.
echo ============================================
echo  [1/5] Python bit check (MUST be 32)
echo ============================================
python -c "import struct; print('bit:', struct.calcsize('P')*8)"
echo.
echo ============================================
echo  [2/5] Install base packages (if needed)
echo ============================================
pip install requests pillow matplotlib python-dotenv
echo.
echo ============================================
echo  [3/5] Install pykiwoom + PyQt5
echo ============================================
pip install pykiwoom PyQt5
if errorlevel 1 (
    echo.
    echo  Retry without cache...
    pip install pykiwoom --no-cache-dir
    pip install PyQt5
)
echo.
echo ============================================
echo  [4/5] Verify
echo ============================================
python -c "import pykiwoom, PyQt5; print('OK - live packages installed')"
echo.
echo ============================================
echo  [5/5] Next:
echo    1. Run Kiwoom HTS (Yeongweomun) and login
echo    2. python live_trader.py --selftest
echo    3. If OK, click LIVE button in app
echo ============================================
echo.
pause
