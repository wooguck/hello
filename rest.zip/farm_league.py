# -*- coding: utf-8 -*-
"""
⚾ 검색식 팜 리그 (farm_league.py) - 2026-08-27 추가
================================================================
사용자 아이디어: "유소년→중등→고등→프로처럼. 공격적으로 많이 만들고,
리그를 올라갈수록 시험이 엄격해지는 구조. 슬롯도 하나씩 추가하며 승급"

리그 구조 (아래는 넓게 = 공격적 생성 / 위는 좁게 = 엄격 검증):

  🧒 유소년 (youth)   : 대량 생성 (기본 500개/회 - 템플릿 변형+무작위 조합+빌더 생존자)
                        시험: 신호 30건+ & 학습기간 평균 > 0  → 통과 ~10~20%
  🎓 중등 (middle)    : 유소년 통과자. 시험: OOS(뒤 30%) 플러스 & 승률 45%+
  🏫 고등 (high)      : 중등 통과자. 시험: 무작위 대조군 30회 백분위 90+ (validation 약식)
  🏆 프로 (= backlog) : 고등 통과자만 conditions에 backlog 등록
                        → 이후 기존 파이프라인 그대로: lifecycle 엄밀검증(20건+)
                          통과해야 운영(active) = 실제 모의매수. 명전은 그 위.

  ★ 승급 실패해도 즉시 방출 아님: 3시즌(실행) 연속 같은 리그에 머물면 방출
  ★ 슬롯 성장: 중등 이상 생존자는 다음 시즌에 '슬롯 +1' 자식을 유소년에 자동 입단
    (사용자: "하나 두개로 돌렸다가 하나 더 추가" - 세대를 거치며 성장)
  ★ 쌍둥이 필터: 신호 겹침 80%+ 는 리그마다 상위 1개만 (slot_builder와 동일 원리)

상태 저장: strategy/farm_league.json (선수 명단 + 리그 + 시즌 성적 이력)
실행:
  python farm_league.py            # 1시즌 실행 (생성→시험→승급/방출)
  python farm_league.py --report   # 리그 현황판
자동: 라운드에서 10라운드마다 1시즌 (FARM_AUTO=true 기본)
"""
import argparse
import json
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import random
import sys
import time

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

STATE = os.path.join("strategy", "farm_league.json")
YOUTH_BATCH = _cfg_env_int("FARM_YOUTH_BATCH", 800)     # 시즌당 유소년 신규 생성 (500→800)
LEAGUE_CAP = {"youth": _cfg_env_int("FARM_CAP_YOUTH", 200),
              "middle": _cfg_env_int("FARM_CAP_MIDDLE", 60),
              "high": _cfg_env_int("FARM_CAP_HIGH", 20)}   # 리그별 정원 (2026-08-27 확대)
STALL_OUT = _cfg_env_int("FARM_STALL_OUT", 3)           # N시즌 승급 실패 시 방출
OVERLAP_MAX = _cfg_env_float("SB_OVERLAP_MAX", 0.8)
MAX_SYMBOLS = _cfg_env_int("FARM_MAX_SYMBOLS", 300)
PROMOTE_PER_SEASON = _cfg_env_int("FARM_PROMOTE_MAX", 6)  # 시즌당 프로 데뷔 상한 (4→6 확대)


def _log(m=""):
    print(m, flush=True)


def _load_state():
    try:
        return json.load(open(STATE, encoding="utf-8"))
    except Exception:
        return {"season": 0, "players": []}   # player: {slots, txt, league, stall, born, history}


def _save_state(st):
    os.makedirs("strategy", exist_ok=True)
    json.dump(st, open(STATE, "w", encoding="utf-8"), ensure_ascii=False, indent=1)


def _sig(slots):
    return json.dumps(sorted([list(s) for s in slots]), sort_keys=True)


def _gen_youth(existing_sigs, n, feats_keys):
    """유소년 신규 생성: ①템플릿 변형 ②무작위 1~2슬롯 ③빌더 생존자 편입"""
    from photo_conditions import build_screens
    from screener import SLOTS
    out, sigs = [], set(existing_sigs)
    # ① 사진 템플릿 변형 (검증된 뼈대의 변주)
    try:
        for sc in build_screens(batch=n // 2):
            s = _sig(sc["slots"])
            if s not in sigs:
                sigs.add(s)
                out.append({"slots": [list(x) for x in sc["slots"]], "src": "tpl"})
    except Exception:
        pass
    # ② 무작위 1~2슬롯 (완전 새로운 피 - 공격적 탐색)
    rng = random.Random()
    keys = list(SLOTS.keys())
    tries = 0
    while len(out) < n and tries < n * 6:
        tries += 1
        k = rng.sample(keys, rng.choice([1, 1, 2]))   # 1슬롯 위주 (단순 우선)
        slots = []
        for key in k:
            _nm, params, choices, _fn = SLOTS[key]
            p = {params[0]: rng.choice(choices)} if params else {}
            slots.append([key, p])
        s = _sig(slots)
        if s in sigs:
            continue
        sigs.add(s)
        out.append({"slots": slots, "src": "rand"})
    # ③ 슬롯 빌더 최근 생존자 (있으면)
    try:
        sb = json.load(open(os.path.join("strategy", "slot_builder.json"), encoding="utf-8"))
        for r in (sb.get("results") or [])[:10]:
            s = _sig(r["slots"])
            if s not in sigs:
                sigs.add(s)
                out.append({"slots": r["slots"], "src": "builder"})
    except Exception:
        pass
    return out[:n]


def _grow_children(players, existing_sigs):
    """중등+ 생존자의 '슬롯+1' 자식을 유소년 입단 (사용자: 하나씩 추가하며 성장)"""
    from screener import SLOTS
    rng = random.Random()
    keys = list(SLOTS.keys())
    kids, sigs = [], set(existing_sigs)
    for p in players:
        if p["league"] not in ("middle", "high") or len(p["slots"]) >= 4:
            continue
        base_keys = {s[0] for s in p["slots"]}
        for _ in range(2):                     # 부모당 자식 2명까지 시도
            key = rng.choice(keys)
            if key in base_keys:
                continue
            _nm, params, choices, _fn = SLOTS[key]
            pp = {params[0]: rng.choice(choices)} if params else {}
            slots = [list(x) for x in p["slots"]] + [[key, pp]]
            s = _sig(slots)
            if s in sigs:
                continue
            sigs.add(s)
            kids.append({"slots": slots, "src": f"child_of_{p['league']}"})
    return kids


def _txt(slots):
    from screener import SLOTS
    parts = []
    for k, p in slots:
        name = SLOTS[k][0]
        for pk, pv in (p or {}).items():
            name = name.replace("{" + pk + "}", str(pv))
        parts.append(name)
    return " AND ".join(parts)


def _exam(slots, feats):
    """3단계 시험 성적표: 학습/OOS/대조군백분위"""
    from screener import evaluate_screen
    tr = evaluate_screen(feats, [tuple(s) for s in slots], split="train")
    te = evaluate_screen(feats, [tuple(s) for s in slots], split="test")
    return tr, te


def _control_pct(slots, feats, tr, runs=30):
    """약식 무작위 대조군: 같은 신호 수만큼 무작위 날짜 매수 30회 → 백분위"""
    import random as _r
    rng = _r.Random(hash(_sig(slots)) & 0x7FFFFFFF)
    n_sig = tr["signal_count"]
    if n_sig < 5:
        return 0.0
    all_pts = []
    for sym, f in feats.items():
        if not f:
            continue
        n = len(f["close"])
        hi = int(n * 0.7) - 5
        if hi > 30:
            all_pts.append((sym, 30, hi))
    if not all_pts:
        return 0.0
    beat = 0
    for _ in range(runs):
        tot = cnt = 0
        for _k in range(min(n_sig, 200)):
            sym, lo, hi = rng.choice(all_pts)
            f = feats[sym]
            i = rng.randint(lo, hi - 1)
            c0 = f["close"][i]
            if c0 and c0 > 0:
                tot += (f["close"][i + 5] / c0 - 1) * 100
                cnt += 1
        if cnt and tr["avg_ret"] * 100 >= tot / cnt:
            beat += 1
    return beat / runs * 100


def _signal_fingerprint(slots, feats):
    from slot_builder import _signal_set
    return _signal_set([tuple(s) for s in slots], feats, "train")


def _debut_gate(slots, txt, L=None):
    """★ 프로 데뷔 전 '전종목 최종면접' (2026-09-02 사용자:
    "만들어진 조건식이 쓸모없다 - 차라리 제대로 전종목에서 확인하여 만드는 걸로")
    - 리그 시험은 300종목 표본이라 우연 통과가 섞임 → 그대로 데뷔시키면 대기만 쌓임
    - 데뷔 직전에 전종목급(기본 2500종목) 엄밀검증(대조군+지수비교) 실시
    - '채택 후보/조건부' + 매매 20건 이상만 데뷔. 탈락은 블랙리스트(재입단 금지)
    반환: (통과여부, 사유문구, 검증결과dict)
    """
    import validation as _v
    n_sym = _cfg_env_int("DEBUT_GATE_SYMBOLS", 2500)
    try:  # features 캐시 상한을 종목 수에 맞게 확장 (purge에서 배운 병목 예방)
        _v._FEAT_CACHE_MAX = max(_v._FEAT_CACHE_MAX, n_sym + 500)
    except Exception:
        pass
    r = _v.validate_condition({"cond_key": "debut-test", "cond_txt": txt,
                               "slots": [tuple(s) for s in slots]},
                              max_symbols=n_sym)
    g = r.get("grade") or ""
    stx = r.get("stats") or {}
    trades = stx.get("trades") or 0
    ok = g in ("채택 후보", "조건부") and trades >= 20
    why = f"{g or '등급없음'} · 매매 {trades}건 · 평균 {stx.get('avg_ret', '?')}%"
    return ok, why, r


def run_season(log_fn=None):
    """1시즌: 생성 → 시험 → 승급/방출 → 프로 데뷔(backlog 등록)"""
    def L(m):
        _log(m)
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    from screener import load_screener_symbols, load_features
    t0 = time.time()
    st = _load_state()
    st["season"] += 1
    season = st["season"]
    players = st["players"]
    L(f"⚾ [팜리그] 시즌 {season} 개막 (선수 {len(players)}명 보유)")

    symbols = load_screener_symbols(max_symbols=MAX_SYMBOLS)
    feats = load_features(symbols, max_symbols=MAX_SYMBOLS)
    if not feats:
        return {"error": "데이터 부족"}

    existing = {_sig(p["slots"]) for p in players}
    # 프로/기존 조건식과 중복 금지
    try:
        for c in db.get_conditions(status=None):
            try:
                existing.add(_sig(json.loads(c["slots_json"] or "[]")))
            except Exception:
                pass
    except Exception:
        pass
    # ★ 재입단 금지 (2026-08-27 사용자 지적 '중복되는 애들 계속 나올 가능성'):
    #   ① 과거 방출자 명단 (팜 자체 블랙리스트) ② 퇴출(retired) 조건식
    #   → 한 번 떨어진 조합은 다시 유소년에 못 들어옴 (같은 데이터면 같은 결과라 재시험 무의미)
    blacklist = set(st.get("blacklist") or [])
    existing |= blacklist
    try:
        with db.get_conn() as conn:
            for r in conn.execute("SELECT slots_json FROM retired_conditions").fetchall():
                try:
                    existing.add(_sig(json.loads(r["slots_json"] or "[]")))
                except Exception:
                    pass
    except Exception:
        pass

    # ── 신인 입단: 대량 생성 + 성장 자식 ──
    rookies = _gen_youth(existing, YOUTH_BATCH, list(feats.keys()))
    kids = _grow_children(players, existing | {_sig(r["slots"]) for r in rookies})
    for r in rookies + kids:
        players.append({"slots": r["slots"], "txt": _txt(r["slots"]), "src": r["src"],
                        "league": "youth", "stall": 0, "born": season, "history": []})
    L(f"  🧒 신인 입단: {len(rookies)}명 (템플릿/무작위/빌더) + 성장자식 {len(kids)}명")

    # ── 리그별 시험 ──
    promoted = {"youth": 0, "middle": 0, "high": 0}
    dropped = 0
    survivors = []
    for p in players:
        tr, te = _exam(p["slots"], feats)
        rec = {"season": season, "league": p["league"],
               "tr_n": tr["signal_count"], "tr_avg": round(tr["avg_ret"] * 100, 3),
               "te_n": te["signal_count"], "te_avg": round(te["avg_ret"] * 100, 3),
               "te_win": round(te["win_rate"], 1)}
        p["history"] = (p.get("history") or [])[-4:] + [rec]
        lg = p["league"]
        up = False
        if lg == "youth":
            # 유소년 시험: 표본 + 학습 플러스 (느슨 - 공격적으로 올려보냄)
            up = tr["signal_count"] >= 30 and tr["avg_ret"] > 0
            if up:
                p["league"] = "middle"
        elif lg == "middle":
            # 중등 시험: OOS 플러스 + 승률
            up = (te["signal_count"] >= 10 and te["avg_ret"] > 0
                  and te["win_rate"] >= 45)
            if up:
                p["league"] = "high"
        elif lg == "high":
            # 고등 시험: 무작위 대조군 백분위 90+ (프로 데뷔 후보)
            pct = _control_pct(p["slots"], feats, tr)
            rec["control_pct"] = round(pct, 1)
            up = pct >= 90 and te["avg_ret"] > 0
            if up:
                p["league"] = "pro_ready"
        if up:
            p["stall"] = 0
            promoted[lg] = promoted.get(lg, 0) + 1
        else:
            p["stall"] = p.get("stall", 0) + 1
        # 방출: N시즌 정체 (유소년은 1시즌 낙방이면 바로 - 자리 좁음)
        limit = 1 if p["league"] == "youth" else STALL_OUT
        if p["stall"] >= limit and p["league"] != "pro_ready":
            dropped += 1
            _bl = st.setdefault("blacklist", [])
            _bl.append(_sig(p["slots"]))          # ★ 방출자 블랙리스트 (재입단 금지)
            if len(_bl) > 20000:
                st["blacklist"] = _bl[-20000:]     # 상한 (파일 비대 방지)
            continue
        survivors.append(p)

    # ── 리그 정원: 쌍둥이 제거 + 최근 OOS 성적순 컷 ──
    final = []
    for lg, cap in (("pro_ready", 99), ("high", LEAGUE_CAP["high"]),
                    ("middle", LEAGUE_CAP["middle"]), ("youth", LEAGUE_CAP["youth"])):
        pool = [p for p in survivors if p["league"] == lg]
        pool.sort(key=lambda p: -(p["history"][-1]["te_avg"] if p["history"] else 0))
        kept, prints = [], []
        for p in pool:
            if len(kept) >= cap:
                break
            fp = _signal_fingerprint(p["slots"], feats)
            twin = False
            for ex in prints:
                inter = len(fp & ex)
                if inter and inter / max(1, len(fp | ex)) >= OVERLAP_MAX:
                    twin = True
                    break
            if twin:
                dropped += 1
                continue
            kept.append(p)
            prints.append(fp)
        final.extend(kept)

    # ── 프로 데뷔: ★전종목 최종면접 통과자만 backlog 등록 (2026-09-02 강화) ──
    #   사용자: "300종목 시험만 통과한 애들이 쓸모없이 쌓임 → 전종목에서 확인하고 데뷔"
    #   최종면접은 무겁기 때문에 시즌당 응시 상한(DEBUT_GATE_PER_SEASON, 기본 2명)
    debut = []
    exam_cap = _cfg_env_int("DEBUT_GATE_PER_SEASON", 2)
    examined = 0
    gate_on = os.getenv("DEBUT_GATE_ENABLED", "true").lower() == "true"
    for p in [x for x in final if x["league"] == "pro_ready"][:PROMOTE_PER_SEASON]:
        try:
            if gate_on:
                if examined >= exam_cap:
                    break                      # 다음 시즌에 응시 (pro_ready 유지)
                examined += 1
                ok, why, _vr = _debut_gate(p["slots"], p["txt"], L)
                if not ok:
                    # 최종면접 탈락 = 방출 + 블랙리스트 (재입단 금지)
                    _bl = st.setdefault("blacklist", [])
                    _bl.append(_sig(p["slots"]))
                    p["league"] = "debuted"    # 아래에서 명단 제거용 재사용
                    dropped += 1
                    L(f"  🎓❌ 최종면접 탈락(전종목): [{p['txt'][:40]}] {why} → 방출")
                    continue
                L(f"  🎓✅ 최종면접 통과(전종목): [{p['txt'][:40]}] {why}")
            no = db.next_cond_no()
            cid = db.create_condition(no, f"[팜{p['born']}기] {p['txt'][:70]}",
                                      p["slots"], source="farm")
            db.set_condition_status(cid, "backlog")
            # ★ 최종면접 결과를 그 조건식의 검증 이력으로 저장 (lifecycle 승격 즉시 판단 가능)
            if gate_on:
                try:
                    from validation import save_validation_results
                    _vr["cond_key"] = str(cid)
                    _vr["cond_no"] = no
                    save_validation_results([_vr])
                except Exception:
                    pass
            debut.append(no)
            p["league"] = "debuted"
            L(f"  🏆 프로 데뷔: {no}번 [{p['txt'][:45]}] → backlog "
              f"(전종목 면접 통과 - lifecycle 승격 대기)")
        except Exception as e:
            L(f"  ⚠️ 데뷔 실패: {str(e)[:40]}")
    final = [p for p in final if p["league"] != "debuted"]

    st["players"] = final
    _save_state(st)
    cnt = {}
    for p in final:
        cnt[p["league"]] = cnt.get(p["league"], 0) + 1
    L(f"  📊 시즌 {season} 결산: 승급 유소년{promoted['youth']}·중등{promoted['middle']}"
      f"·고등{promoted['high']} · 방출 {dropped} · 데뷔 {len(debut)}")
    L(f"  🏟 리그 현황: 유소년 {cnt.get('youth',0)} · 중등 {cnt.get('middle',0)} · "
      f"고등 {cnt.get('high',0)} · 데뷔대기 {cnt.get('pro_ready',0)} ({time.time()-t0:.0f}초)")
    return {"season": season, "promoted": promoted, "dropped": dropped,
            "debut": debut, "leagues": cnt}


def report():
    st = _load_state()
    _log("=" * 64)
    _log(f"⚾ 팜 리그 현황 (시즌 {st['season']})")
    _log("=" * 64)
    for lg, name in (("pro_ready", "🏆 데뷔 대기"), ("high", "🏫 고등"),
                     ("middle", "🎓 중등"), ("youth", "🧒 유소년")):
        pool = [p for p in st["players"] if p["league"] == lg]
        _log(f"\n{name} ({len(pool)}명)")
        for p in sorted(pool, key=lambda x: -(x["history"][-1]["te_avg"] if x["history"] else 0))[:8]:
            h = p["history"][-1] if p["history"] else {}
            _log(f"  [{len(p['slots'])}슬롯] {p['txt'][:46]:48s} "
                 f"OOS {h.get('te_avg', 0):+.2f}%·승률{h.get('te_win', 0):.0f}% "
                 f"({p['src']}·{p['born']}기·정체{p['stall']})")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", action="store_true")
    args = ap.parse_args()
    db.init_db()
    if args.report:
        report()
    else:
        run_season()
