"""키움 REST API 래퍼 v3 - 429 Rate Limit 재시도 + DRY_RUN fallback

공식 문서: https://openapi.kiwoom.com
- 토큰 발급: POST {base}/oauth2/token  body: grant_type, appkey, secretkey
  응답: { expires_dt, token_type, token }
- 공통 헤더: authorization: Bearer {token}, api-id: TR코드, cont-yn, next-key
"""
import os
import time
import logging
import requests
import random
from typing import Optional, List
from collections import defaultdict

from config import CFG

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("kiwoom_client")


class KiwoomAuthError(Exception):
    pass


class KiwoomClient:
    def __init__(self):
        self._token: Optional[str] = None
        self._token_type: str = "Bearer"
        self._token_expires_at = 0
        self._last_call_by_tr = defaultdict(float)
        self._is_mock_token = False

    def _is_dry_mock_no_key(self) -> bool:
        return (not CFG.APP_KEY or not CFG.APP_SECRET) and CFG.DRY_RUN

    def _clean_account_no(self) -> str:
        """
        계좌번호 정규화:
        - 10자리 → 그대로 사용
        - 8자리 → 모의투자 구분코드 '11'을 뒤에 붙여 10자리로 변환 (예: 12345678 → 1234567811)
        - 그 외 → 숫자만 추출해 사용하되 경고
        """
        raw = CFG.ACCOUNT_NO or ""
        digits = "".join([c for c in raw if c.isdigit()])
        if len(digits) == 10:
            return digits
        if len(digits) == 8:
            suffix = getattr(CFG, "ACCOUNT_SUFFIX", "11") or "11"
            resolved = digits + suffix
            log.info(f"[계좌] {len(digits)}자리 모의계좌 → 10자리 변환: {digits} + '{suffix}' = {resolved}")
            return resolved
        log.warning(f"[계좌] 계좌번호 형식이 8자리(모의)/10자리(실전)가 아님: {len(digits)}자리 ({digits})")
        return digits

    @staticmethod
    def _in_maintenance_window() -> bool:
        """★ 키움 서버 점검 시간대 - 이 시간엔 키움 API 호출을 아예 하지 않음
        ★ 2026-08-27 사용자 확인 실제 공지 반영 (기존 04:30~07:30 통짜 차단은 과도):
          월~토 06:50~06:55 / 일 05:00~05:15 (앞뒤 5분 여유 붙여 차단)
        .env 재정의: KIWOOM_MAINT_START/END (평일·토), KIWOOM_MAINT_SUN_START/END (일)
        빈값('')이면 비활성
        """
        try:
            from datetime import datetime as _dt
            try:
                from db import now_kst as _nk
                now = _nk()
            except Exception:
                now = _dt.now()
            cur = now.hour * 60 + now.minute

            def _rng(s, e):
                if not s or not e:
                    return False
                sh, sm = map(int, s.split(":"))
                eh, em = map(int, e.split(":"))
                return sh * 60 + sm <= cur < eh * 60 + em

            if now.weekday() == 6:   # 일요일
                return _rng(os.getenv("KIWOOM_MAINT_SUN_START", "04:55").strip(),
                            os.getenv("KIWOOM_MAINT_SUN_END", "05:20").strip())
            # 월~토
            return _rng(os.getenv("KIWOOM_MAINT_START", "06:45").strip(),
                        os.getenv("KIWOOM_MAINT_END", "07:00").strip())
        except Exception:
            return False

    def _get_token(self) -> str:
        if self._token and time.time() < self._token_expires_at - 60:
            return self._token
        # ★ 새벽 점검 시간대: 토큰 발급 시도 자체를 생략 (팅김/오류 로그 도배 방지)
        if self._in_maintenance_window():
            raise KiwoomAuthError("키움 서버 점검 시간대(새벽) - API 호출 생략, 07:30 이후 자동 재개")
        if self._is_dry_mock_no_key():
            self._token = "mock_dry_run_token"
            self._token_expires_at = time.time() + 3600
            self._is_mock_token = True
            return self._token
        if not CFG.APP_KEY or not CFG.APP_SECRET:
            raise KiwoomAuthError("APP_KEY/SECRET 미설정")
        url = f"{CFG.base_url}/oauth2/token"
        payload = {
            "grant_type": "client_credentials",
            "appkey": CFG.APP_KEY,
            "secretkey": CFG.APP_SECRET,
        }
        headers = {"Content-Type": "application/json;charset=UTF-8"}
        log.info(f"[Auth] 토큰 발급 요청: {url}")
        resp = requests.post(url, json=payload, headers=headers, timeout=10)
        if resp.status_code != 200:
            raise KiwoomAuthError(f"토큰 발급 실패: {resp.status_code} {resp.text}")
        data = resp.json()
        self._token = data.get("token") or data.get("access_token")
        token_type = data.get("token_type", "Bearer")
        expires_dt_str = data.get("expires_dt", "")
        try:
            from datetime import datetime
            expires_in = 23 * 3600
            if expires_dt_str:
                for fmt in ("%Y%m%d%H%M%S", "%Y-%m-%d %H:%M:%S", "%Y%m%d"):
                    try:
                        dt = datetime.strptime(expires_dt_str.strip()[:19], fmt)
                        expires_in = (dt - datetime.now()).total_seconds()
                        break
                    except Exception:
                        continue
        except Exception:
            expires_in = 23 * 3600
        self._token_expires_at = time.time() + max(expires_in, 3600)
        self._token_type = token_type
        self._is_mock_token = False
        if not self._token:
            raise KiwoomAuthError(f"토큰 응답에 token 없음: {data}")
        log.info(f"[Auth] 토큰 발급 성공 (만료: {expires_dt_str})")
        return self._token

    def _headers(self, api_id: str, cont_yn: str = "N", next_key: str = "") -> dict:
        token = self._get_token()
        auth_val = f"Bearer {token}" if not token.startswith("Bearer") else token
        h = {
            "Content-Type": "application/json;charset=UTF-8",
            "authorization": auth_val,
            "api-id": api_id,
        }
        if cont_yn:
            h["cont-yn"] = cont_yn
        if next_key:
            h["next-key"] = next_key
        if h["authorization"].count("Bearer") > 1:
            h["authorization"] = "Bearer " + h["authorization"].split()[-1]
        return h

    def _throttle(self, api_id: str = "default"):
        if self._is_mock_token or self._is_dry_mock_no_key():
            return
        limit = 1.2 if CFG.USE_MOCK else 0.4
        now = time.time()
        elapsed = now - self._last_call_by_tr[api_id]
        if elapsed < limit:
            time.sleep(limit - elapsed)
        self._last_call_by_tr[api_id] = time.time()

    def _request_with_retry(self, method, url, api_id, **kwargs):
        max_retries = 3
        resp = None
        for attempt in range(max_retries + 1):
            self._throttle(api_id)
            try:
                if method == "POST":
                    resp = requests.post(url, timeout=10, **kwargs)
                else:
                    resp = requests.get(url, timeout=10, **kwargs)
                if resp.status_code == 429:
                    wait = (2 ** attempt) + random.uniform(0, 0.5)
                    log.warning(f"429 Rate Limit {api_id} - {wait:.1f}초 대기 후 재시도 {attempt+1}/{max_retries}")
                    time.sleep(wait)
                    continue
                # ★ 8005 (Token 무효) 자동 복구: 토큰을 버리고 새로 발급받아 1회 재시도
                #   원인: 앱+수집기 등 여러 프로세스가 같은 앱키로 토큰을 각자 발급하면
                #   키움이 이전 토큰을 무효화함 → 한쪽에서 8005 발생. 재발급하면 해결.
                if attempt < max_retries:
                    try:
                        j = resp.json()
                        msg = str(j.get("return_msg", ""))
                        if j.get("return_code") == 3 and "8005" in msg:
                            log.warning(f"토큰 무효(8005) {api_id} - 토큰 재발급 후 재시도")
                            self._token = None
                            self._token_expires_at = 0
                            h = kwargs.get("headers")
                            if isinstance(h, dict):
                                token = self._get_token()
                                h["authorization"] = (f"Bearer {token}"
                                                      if not str(token).startswith("Bearer")
                                                      else token)
                            continue
                    except Exception:
                        pass
                return resp
            except requests.exceptions.RequestException as e:
                if attempt == max_retries:
                    raise e
                wait = 2 ** attempt
                log.warning(f"요청 예외 {api_id}: {e} - {wait}s 후 재시도")
                time.sleep(wait)
        return resp

    # ── 시세조회 ─────────────────────────────────────────
    def _naver_live_price(self, symbol: str):
        """★ 네이버 실시간 가격 폴백 (키 없음/모의/실패 시 랜덤 대신 실제 시세)
        - fchart 최신 일봉(당일 시/고/저/종/거래량 실시간 갱신) + m.stock basic(현재가/등락률)
        - 실패 시 None → 호출측이 0 반환
        """
        import re as _re
        try:
            import requests as _req
            r = _req.get(f"https://fchart.stock.naver.com/sise.nhn?symbol={symbol}"
                         f"&timeframe=day&count=3&requestType=0",
                         headers={"User-Agent": "Mozilla/5.0"}, timeout=8)
            items = _re.findall(r'<item data="([^"]+)"', r.text) if r.status_code == 200 else []
            if not items:
                return None
            last = items[-1].split("|")
            if len(last) < 6:
                return None
            o = float(last[1]); h = float(last[2]); l = float(last[3])
            c = float(last[4]); v = float(last[5])
            name = symbol
            chg = None
            try:
                r2 = _req.get(f"https://m.stock.naver.com/api/stock/{symbol}/basic",
                              headers={"User-Agent": "Mozilla/5.0"}, timeout=6)
                if r2.status_code == 200:
                    d2 = r2.json()
                    name = d2.get("stockName") or symbol
                    try:
                        chg = float(str(d2.get("fluctuationsRatio", "0")).replace(",", ""))
                    except Exception:
                        chg = None
            except Exception:
                pass
            return {"symbol": symbol, "name": name, "price": c, "chg_pct": chg,
                    "open": o, "high": h, "low": l, "volume": v, "amount": round(c * v),
                    "source": "naver_live"}
        except Exception:
            return None

    def get_stock_basic_info(self, symbol: str) -> dict:
        if self._is_dry_mock_no_key() or self._is_mock_token:
            nv = self._naver_live_price(symbol)
            if nv:
                return {"stk_nm": nv["name"], "cur_prc": str(int(nv["price"])),
                        "open_pric": str(int(nv["open"])), "high_pric": str(int(nv["high"])),
                        "low_pric": str(int(nv["low"])), "trde_qty": str(int(nv["volume"])),
                        "trd_amt": str(int(nv["amount"])), "mock": True, "source": "naver"}
            return {"stk_nm": f"모의-{symbol}", "cur_prc": "0", "mock": True}
        url = f"{CFG.base_url}/api/dostk/stkinfo"
        payload = {"stk_cd": symbol}
        resp = self._request_with_retry("POST", url, "ka10001", headers=self._headers(api_id="ka10001"), json=payload)
        if resp.status_code == 404:
            resp = self._request_with_retry("POST", f"{CFG.base_url}/api/dostk/stk", "ka10001",
                                            headers=self._headers(api_id="ka10001"), json=payload)
        resp.raise_for_status()
        return resp.json()

    def get_current_price(self, symbol: str) -> dict:
        try:
            raw = self.get_stock_basic_info(symbol)
            price = None
            name = symbol
            if isinstance(raw, dict):
                price = raw.get("cur_prc") or raw.get("cur_prc_org") or raw.get("prc") or raw.get("price")
                name = raw.get("stk_nm") or raw.get("stock_name") or name
                for key in ["stk_basic_info", "basic_info", "data", "output"]:
                    if key in raw and isinstance(raw[key], dict):
                        price = price or raw[key].get("cur_prc")
                        name = raw[key].get("stk_nm") or name
                    if key in raw and isinstance(raw[key], list) and raw[key]:
                        price = price or raw[key][0].get("cur_prc")
            price_val = 0
            if price:
                try:
                    s = str(price).replace(",", "").replace("+", "").replace("-", "").strip()
                    if s:
                        price_val = int(float(s))
                except Exception:
                    price_val = 0
            if price_val == 0:
                nv = self._naver_live_price(symbol)
                if nv:
                    return {"symbol": symbol, "price": int(nv["price"]), "name": nv["name"], "raw": nv,
                            "open_price": nv["open"], "high_price": nv["high"], "low_price": nv["low"],
                            "volume": nv["volume"], "amount": nv["amount"], "source": "naver_live",
                            "chg_pct": nv.get("chg_pct")}
                if CFG.DRY_RUN:
                    log.warning(f"{symbol} 가격 0원 (네이버도 실패) - 0 반환")
                    return {"symbol": symbol, "price": 0, "name": symbol, "raw": {}, "mock": True}
                return {"symbol": symbol, "price": 0, "name": symbol, "raw": {}, "error": "가격 0"}

            # ★ 시가/고가/저가/거래량/거래대금 추출 (봉 분석 + 검증용)
            def _pick(*keys):
                for k in keys:
                    v = raw.get(k)
                    if v not in (None, ""):
                        return v
                return None
            def _num(v):
                if v is None or v == "":
                    return 0
                try:
                    return float(str(v).replace(",", "").replace("+", "").replace("-", ""))
                except Exception:
                    return 0
            ohlcv = {
                "open_price": _num(_pick("open_pric", "open_price")),
                "high_price": _num(_pick("high_pric", "high_price")),
                "low_price": _num(_pick("low_pric", "low_price")),
                "volume": _num(_pick("trde_qty", "volume")),
                "amount": _num(_pick("trd_amt", "amount")),
            }
            return {"symbol": symbol, "price": price_val, "name": name, "raw": raw, **ohlcv}
        except Exception as e:
            log.warning(f"시세조회 실패({symbol}): {e}")
            nv = self._naver_live_price(symbol)
            if nv:
                return {"symbol": symbol, "price": int(nv["price"]), "name": nv["name"], "raw": nv,
                        "open_price": nv["open"], "high_price": nv["high"], "low_price": nv["low"],
                        "volume": nv["volume"], "amount": nv["amount"], "source": "naver_live"}
            if CFG.DRY_RUN:
                return {"symbol": symbol, "price": 0, "name": symbol, "raw": {}, "mock": True, "error": str(e)}
            return {"symbol": symbol, "price": 0, "name": symbol, "raw": {}, "error": str(e)}

    def get_chart_daily(self, symbol: str, date: str = "", tic_cnt: int = 500,
                        upd_stkpc_tp: int = 1, raw_base_dt: bool = False) -> dict:
        """주식 일봉차트 조회 (ka10081 - 주식일봉차트조회)
        ★ ka10081 = 일봉 (ka10080은 분봉 - 이전에 바꿔 쓰던 버그 수정)
        ★ 필수: dmst_stex_tp(KRX) + tic_scope(1=일봉) + tic_cnt(봉 수) + base_dt(기준일자)
          (base_dt 없으면 return_code=2 [1511] 에러 - 이번 사용자 사례)
        tic_cnt: 봉 수 (모의 서버가 500을 안 주면 100 등으로 조정 시도)
        upd_stkpc_tp: 1=수정주가, 0=원주가 (모의 서버 대응)
        raw_base_dt: True면 주말 보정 없이 주어진 날짜 그대로 (파라미터 변형 시도용)
        """
        if self._is_dry_mock_no_key() or self._is_mock_token:
            return self._mock_chart()
        url = f"{CFG.base_url}/api/dostk/chart"
        # ★ base_dt 필수: 미지정 시 오늘(KST) 기준일자 자동 - 이 날짜부터 과거로 tic_cnt만큼 조회
        if not date:
            try:
                from db import now_kst
                date = now_kst().strftime("%Y%m%d")
            except Exception:
                from datetime import datetime
                date = datetime.now().strftime("%Y%m%d")
        # ★ 주말/공휴일이면 직전 거래일로 보정 (토/일 → 금요일, 공휴일 → 이전 거래일)
        if not raw_base_dt:
            try:
                from datetime import datetime as _dt, timedelta as _td
                d = _dt.strptime(date, "%Y%m%d")
                # 최대 7일 뒤로 이동하며 주말 제외 (+ 공휴일 목록 있으면 사용)
                holidays = set()
                try:
                    from db import KRX_HOLIDAYS
                    if isinstance(KRX_HOLIDAYS, dict):
                        holidays = {str(v) for vs in KRX_HOLIDAYS.values() for v in vs}
                except Exception:
                    pass
                for _ in range(7):
                    if d.weekday() < 5 and d.strftime("%Y-%m-%d") not in holidays:
                        break
                    d = d - _td(days=1)
                date = d.strftime("%Y%m%d")
            except Exception:
                pass
        payload = {"dmst_stex_tp": "KRX", "stk_cd": symbol,
                   "tic_scope": "1", "tic_cnt": str(max(1, min(tic_cnt, 500))),
                   "base_dt": date,
                   "upd_stkpc_tp": str(upd_stkpc_tp)}
        try:
            resp = self._request_with_retry("POST", url, "ka10081", headers=self._headers(api_id="ka10081"), json=payload)
            if resp.status_code in (404, 500):
                resp = self._request_with_retry("POST", f"{CFG.base_url}/api/dostk/stk", "ka10081",
                                                headers=self._headers(api_id="ka10081"), json=payload)
            resp.raise_for_status()
            data = resp.json()
            # ★ 에러 응답이면 원인을 로그로 (return_code/return_msg - 진단용)
            if isinstance(data, dict) and data.get("return_code") not in (0, None):
                log.warning(f"차트 조회 에러({symbol}): return_code={data.get('return_code')} "
                            f"{data.get('return_msg', '')[:80]}")
            return data
        except Exception as e:
            log.warning(f"차트 조회 실패 {symbol}: {e} - 모의 차트로 대체")
            if CFG.DRY_RUN:
                return self._mock_chart()
            return {}

    def _mock_chart(self) -> dict:
        candles = []
        base = random.randint(50000, 100000)
        for _ in range(60):
            base = max(1000, base + random.randint(-2000, 2000))
            candles.append({"cur_prc": str(base), "trde_qty": str(random.randint(10000, 1000000))})
        return {"stk_dt_pole_chart_qry": candles, "mock": True}

    def get_all_indices(self) -> list:
        """전업종지수 (ka20003) - [(지수명, 값, 변화율), ...] 실패 시 []"""
        if self._is_dry_mock_no_key() or self._is_mock_token:
            return []
        url = f"{CFG.base_url}/api/dostk/inds"
        try:
            resp = self._request_with_retry("POST", url, "ka20003",
                                            headers=self._headers(api_id="ka20003"), json={})
            if resp.status_code in (404, 500):
                return []
            resp.raise_for_status()
            data = resp.json()
            out = []
            if isinstance(data, dict):
                lst = data.get("output") or data.get("data") or data.get("inds_list") or []
                for item in lst if isinstance(lst, list) else []:
                    if isinstance(item, dict):
                        name = item.get("inds_nm") or item.get("name")
                        value = item.get("inds_prc") or item.get("value")
                        change = item.get("prdy_ctrt") or item.get("change_pct")
                        if name and value:
                            try:
                                out.append((name, float(str(value).replace(",", "")),
                                            float(str(change or 0).replace(",", "").replace("+", ""))))
                            except Exception:
                                continue
            return out
        except Exception as e:
            log.warning(f"지수 조회 실패: {e}")
            return []

    # ── 순위 정보 (거래대금/거래량 상위 - 매수 후보 선정용) ──
    # ★ 5분 캐시: 순위는 금방 변하지만 레이트 리밋(1초/TR) 때문에 매 사이클 호출은 비효율.
    #   5분마다 갱신하면 하루 장중(6.5시간) 약 78회 호출 → 부담 없음.
    _rank_cache = {}
    RANK_CACHE_TTL = 300  # 5분

    def _get_rank(self, api_id, payload, cache_key):
        import time as _t
        now = _t.time()
        if cache_key in self._rank_cache:
            data, ts = self._rank_cache[cache_key]
            if now - ts < self.RANK_CACHE_TTL:
                return data
        url = f"{CFG.base_url}/api/dostk/rank"
        try:
            resp = self._request_with_retry("POST", url, api_id,
                                            headers=self._headers(api_id=api_id), json=payload)
            if resp.status_code in (404, 500):
                return []
            resp.raise_for_status()
            data = resp.json()
            self._rank_cache[cache_key] = (data, now)
            return data
        except Exception as e:
            log.warning(f"순위 조회 실패({api_id}): {e}")
            return {}

    def get_top_trading_value(self, limit=100, market="000") -> list:
        """거래대금 상위 (ka10032) - [(rank, symbol, name, value), ...] 실패 시 []
        market: 000 전체 / 001 코스피 / 101 코스닥
        5분 캐시 적용
        """
        if self._is_dry_mock_no_key() or self._is_mock_token:
            return []
        cache_key = f"ka10032_{market}_{limit}"
        payload = {"mrkt_tp": market, "sort_tp": "3", "stex_tp": "1",
                   "rank_strt": "0", "rank_cnt": str(limit)}
        data = self._get_rank("ka10032", payload, cache_key)
        out = []
        if isinstance(data, dict):
            lst = self._find_field(data, ("output", "output1", "output2", "rs",
                                          "data", "items", "rank_list")) or []
            for i, item in enumerate(lst if isinstance(lst, list) else []):
                if isinstance(item, dict):
                    sym = (item.get("stk_cd") or item.get("code") or "").replace("A", "")
                    if sym:
                        out.append((i + 1, sym, item.get("stk_nm") or item.get("name") or "",
                                    item.get("trde_prica") or item.get("trading_value") or ""))
        return out

    def get_top_volume(self, limit=100, market="000") -> list:
        """당일 거래량 상위 (ka10030) - [(rank, symbol, name, volume), ...] 실패 시 []
        market: 000 전체 / 001 코스피 / 101 코스닥
        5분 캐시 적용
        """
        if self._is_dry_mock_no_key() or self._is_mock_token:
            return []
        cache_key = f"ka10030_{market}_{limit}"
        payload = {"mrkt_tp": market, "sort_tp": "1", "stex_tp": "1",
                   "rank_strt": "0", "rank_cnt": str(limit)}
        data = self._get_rank("ka10030", payload, cache_key)
        out = []
        if isinstance(data, dict):
            lst = self._find_field(data, ("output", "output1", "output2", "rs",
                                          "data", "items", "rank_list")) or []
            for i, item in enumerate(lst if isinstance(lst, list) else []):
                if isinstance(item, dict):
                    sym = (item.get("stk_cd") or item.get("code") or "").replace("A", "")
                    if sym:
                        out.append((i + 1, sym, item.get("stk_nm") or item.get("name") or "",
                                    item.get("trde_qty") or item.get("volume") or ""))
        return out
        payload = {"mrkt_tp": market, "sort_tp": "3", "stex_tp": "1",
                   "rank_strt": "0", "rank_cnt": str(limit)}
        try:
            resp = self._request_with_retry("POST", url, "ka10032",
                                            headers=self._headers(api_id="ka10032"), json=payload)
            if resp.status_code in (404, 500):
                return []
            resp.raise_for_status()
            data = resp.json()
            out = []
            if isinstance(data, dict):
                lst = self._find_field(data, ("output", "output1", "output2", "rs",
                                              "data", "items", "rank_list")) or []
                for i, item in enumerate(lst if isinstance(lst, list) else []):
                    if isinstance(item, dict):
                        sym = (item.get("stk_cd") or item.get("code") or "").replace("A", "")
                        if sym:
                            out.append((i + 1, sym, item.get("stk_nm") or item.get("name") or "",
                                        item.get("trde_prica") or item.get("trading_value") or ""))
            return out
        except Exception as e:
            log.warning(f"거래대금 상위 조회 실패: {e}")
            return []

    def get_top_turnover(self, limit=100, market="000") -> list:
        """회전율 상위 (ka10038 종목별증권사순위... 회전율) - [(rank, symbol, name, turnover), ...]
        market: 000 전체 / 001 코스피 / 101 코스닥
        """
        if self._is_dry_mock_no_key() or self._is_mock_token:
            return []
        cache_key = f"ka10038_{market}_{limit}"
        payload = {"mrkt_tp": market, "sort_tp": "1", "stex_tp": "1",
                   "rank_strt": "0", "rank_cnt": str(limit)}
        data = self._get_rank("ka10038", payload, cache_key)
        out = []
        if isinstance(data, dict):
            lst = self._find_field(data, ("output", "output1", "output2", "rs",
                                          "data", "items", "rank_list")) or []
            for i, item in enumerate(lst if isinstance(lst, list) else []):
                if isinstance(item, dict):
                    sym = (item.get("stk_cd") or item.get("code") or "").replace("A", "")
                    if sym:
                        out.append((i + 1, sym, item.get("stk_nm") or item.get("name") or "",
                                    item.get("turnover_rt") or item.get("trde_rt") or ""))
        return out

    # ── 조건검색 ─────────────────────────────
    def get_condition_list(self) -> list:
        if self._is_dry_mock_no_key() or self._is_mock_token:
            return [{"seq": "0", "name": "모의조건식-샘플"}]
        url = f"{CFG.base_url}/api/dostk/condition"
        try:
            resp = self._request_with_retry("POST", url, "ka10171", headers=self._headers(api_id="ka10171"), json={})
            if resp.status_code in (404, 500):
                resp = self._request_with_retry("GET", url, "ka10171", headers=self._headers(api_id="ka10171"))
            resp.raise_for_status()
            data = resp.json()
            if isinstance(data, dict):
                return data.get("condition_list", data.get("list", data.get("data", [])))
            return data if isinstance(data, list) else []
        except Exception as e:
            log.warning(f"조건검색 목록 조회 실패: {e}")
            return []

    def get_condition_search_results(self, condition_seq: str) -> List[str]:
        if (not condition_seq and CFG.DRY_RUN) or self._is_mock_token or self._is_dry_mock_no_key():
            log.info("DRY_RUN 모의 조건검색 결과 반환")
            return CFG.UNIVERSE
        if not condition_seq:
            log.warning("조건검색 SEQ가 비어있어 빈 리스트 반환")
            return []
        url = f"{CFG.base_url}/api/dostk/condition"
        payload = {"seq": str(condition_seq)}
        try:
            resp = self._request_with_retry("POST", url, "ka10172", headers=self._headers(api_id="ka10172"), json=payload)
            if resp.status_code in (404, 500):
                resp = self._request_with_retry("GET", url, "ka10172", headers=self._headers(api_id="ka10172"), params=payload)
            resp.raise_for_status()
            data = resp.json()
            if isinstance(data, dict):
                lst = data.get("stk_list") or data.get("list") or data.get("data") or []
                if isinstance(lst, list):
                    result = []
                    for item in lst:
                        if isinstance(item, str):
                            result.append(item)
                        elif isinstance(item, dict):
                            result.append(item.get("stk_cd") or item.get("code") or "")
                    return [x for x in result if x]
                return []
            elif isinstance(data, list):
                return [d.get("stk_cd") if isinstance(d, dict) else d for d in data]
            return []
        except Exception as e:
            log.warning(f"조건검색 실행 실패 seq={condition_seq}: {e}")
            return []

    def get_stock_list(self) -> list:
        """종목정보 리스트 (ka10099) - 전 종목 코드/이름. 실패 시 []"""
        if self._is_dry_mock_no_key() or self._is_mock_token:
            return []
        url = f"{CFG.base_url}/api/dostk/stkinfo"
        try:
            resp = self._request_with_retry("POST", url, "ka10099",
                                            headers=self._headers(api_id="ka10099"), json={})
            if resp.status_code in (404, 500):
                return []
            resp.raise_for_status()
            data = resp.json()
            out = []
            if isinstance(data, dict):
                lst = (data.get("stk_list") or data.get("list") or
                       data.get("output") or data.get("data") or [])
                for item in lst if isinstance(lst, list) else []:
                    if isinstance(item, dict):
                        sym = item.get("stk_cd") or item.get("code")
                        name = item.get("stk_nm") or item.get("name")
                        if sym and name:
                            out.append((str(sym).strip(), str(name).strip()))
            return out
        except Exception as e:
            log.warning(f"종목정보 리스트 조회 실패: {e}")
            return []

    # ── 계좌 / 예수금 ─────────────────────────────
    def get_balance(self) -> dict:
        """예수금 상세 (kt00001) - 실패 시 error 반환"""
        if self._is_dry_mock_no_key() or self._is_mock_token:
            return {"entr": "10000000", "mock": True, "cash": "10000000",
                    "d1_entra": "10000000", "d2_entra": "9759160"}
        acnt = self._clean_account_no()
        if not acnt:
            return {"error": "ACCOUNT_NO 미설정", "entr": "0"}
        url = f"{CFG.base_url}/api/dostk/acnt"
        payload = {"qry_tp": "1", "acnt_tp": "1", "acnt_no": acnt, "acnt_no_10": acnt}
        try:
            resp = self._request_with_retry("POST", url, "kt00001", headers=self._headers(api_id="kt00001"), json=payload)
            resp.raise_for_status()
            data = resp.json()
            if data.get("return_code") not in (0, None) and "qry_tp" in data.get("return_msg", ""):
                payload["qry_tp"] = "2"
                resp = self._request_with_retry("POST", url, "kt00001", headers=self._headers(api_id="kt00001"), json=payload)
                resp.raise_for_status()
                data = resp.json()
            return data
        except Exception as e:
            log.warning(f"예수금 조회 실패: {e}")
            return {"error": str(e)}

    def _find_field(self, obj, field_names):
        """dict/list를 재귀 탐색해서 원하는 필드 값 찾기 (중첩 output1/output2 대응)"""
        if isinstance(obj, dict):
            for k, v in obj.items():
                if k in field_names and v not in (None, ""):
                    return v
                r = self._find_field(v, field_names)
                if r is not None:
                    return r
        elif isinstance(obj, list):
            for item in obj:
                r = self._find_field(item, field_names)
                if r is not None:
                    return r
        return None

    def get_account_evaluation(self) -> dict:
        """계좌평가현황 (kt00004) - 총평가금액/예수금/손익 등. 실패 시 {}
        ★ dmst_stex_tp(KRX) 필수 - 누락 시 1511 오류"""
        if self._is_dry_mock_no_key() or self._is_mock_token:
            return {"tot_evlt_amt": "10500000", "entr": "10000000", "mock": True,
                    "pchs_amt": "9000000", "evlt_pfls_amt": "500000"}
        acnt = self._clean_account_no()
        if not acnt:
            return {}
        url = f"{CFG.base_url}/api/dostk/acnt"
        payload = {"dmst_stex_tp": "KRX", "acnt_no": acnt, "acnt_no_10": acnt,
                   "qry_tp": "1", "acnt_tp": "1"}
        try:
            resp = self._request_with_retry("POST", url, "kt00004", headers=self._headers(api_id="kt00004"), json=payload)
            resp.raise_for_status()
            data = resp.json()
            if data.get("return_code") not in (0, None):
                log.warning(f"계좌평가 응답 오류: {data.get('return_msg')}")
            return data
        except Exception as e:
            log.warning(f"계좌평가 조회 실패: {e}")
            return {}

    def get_filled_positions(self) -> list:
        """체결잔고 (kt00005) - 보유 종목 목록. 실패 시 []
        ★ dmst_stex_tp(KRX) 필수"""
        if self._is_dry_mock_no_key() or self._is_mock_token:
            return []
        acnt = self._clean_account_no()
        if not acnt:
            return []
        url = f"{CFG.base_url}/api/dostk/acnt"
        payload = {"dmst_stex_tp": "KRX", "acnt_no": acnt, "acnt_no_10": acnt,
                   "qry_tp": "1", "acnt_tp": "1"}
        try:
            resp = self._request_with_retry("POST", url, "kt00005", headers=self._headers(api_id="kt00005"), json=payload)
            resp.raise_for_status()
            data = resp.json()
            # 재귀 탐색: output/output1/output2/rs 등 어느 구조든 종목 리스트 찾기
            if isinstance(data, dict):
                lst = self._find_field(data, ("output", "output1", "output2", "rs",
                                              "stk_list", "data", "items"))
                if isinstance(lst, list):
                    return lst
                # dict면 1개 종목으로 취급
                if isinstance(lst, dict):
                    return [lst]
            return []
        except Exception as e:
            log.warning(f"체결잔고 조회 실패: {e}")
            return []

    def get_account_overview(self) -> dict:
        """통합 계좌 현황 (UI용): 예수금/평가금액/평가손익/보유종목수
        kt00001 + kt00004 + kt00005 를 합쳐서 반환. 실패 시 원인 표시.
        """
        if self._is_dry_mock_no_key() or self._is_mock_token:
            return {"mock": True, "entr": 10000000, "total_asset": 10500000,
                    "pnl": 500000, "pnl_pct": 5.56, "positions": [],
                    "source": "mock"}
        acnt = self._clean_account_no()
        log.info(f"[계좌] 잔고 연동 시도: 계좌={acnt} (mock={CFG.USE_MOCK})")
        bal = self.get_balance()
        evl = self.get_account_evaluation()
        pos = self.get_filled_positions()

        def _num(v):
            try:
                s = str(v).replace(",", "").strip()
                if not s:
                    return 0
                return int(float(s))
            except Exception:
                return 0

        # 예수금: 여러 가능 필드에서 추출 (실제 응답 구조 대응)
        entr = _num(bal.get("entr") or bal.get("d1_entra") or bal.get("cash") or 0)
        if entr == 0:
            # 응답이 중첩(output 등)인 경우 재귀 탐색
            entr = _num(self._find_field(bal, ("entr", "d1_entra", "cash")) or 0)

        # 평가금액/손익/매입금액: 어느 깊이에서든 재귀 탐색
        # 실제 응답: tot_est_amt(총평가금액), aset_evlt_amt(평가손익), tot_pur_amt(총매입)
        total = _num(self._find_field(evl, ("tot_est_amt", "tot_evlt_amt", "estm_evlt_amt",
                                            "amt_evlt_amt", "tot_asset", "evlt_amt")) or 0)
        pnl = _num(self._find_field(evl, ("aset_evlt_amt", "evlt_pfls_amt", "tot_pfls",
                                          "pfls_amt", "tot_pnl", "lspft_amt")) or 0)
        pchs = _num(self._find_field(evl, ("tot_pur_amt", "pchs_amt", "tot_pchs_amt", "buy_amt")) or 0)
        pnl_pct = round(pnl / pchs * 100, 2) if pchs else 0

        errors = []

        # kt00004/kt00005가 오류(return_code!=0)면 원인 표시
        evl_code = evl.get("return_code")
        if evl_code not in (0, None):
            errors.append(f"계좌평가: {evl.get('return_msg', '')}")

        # 보유 종목: 실제 응답 stk_acnt_evlt_prst (또는 kt00005 결과)
        positions = []
        stk_list = self._find_field(evl, ("stk_acnt_evlt_prst", "output", "output1",
                                          "output2", "stk_list", "rs", "data", "items"))
        if not isinstance(stk_list, list) and pos:
            stk_list = pos
        for p in stk_list if isinstance(stk_list, list) else []:
            if isinstance(p, dict):
                positions.append({
                    "symbol": (p.get("stk_cd") or p.get("code") or "").replace("A", ""),
                    "name": p.get("stk_nm") or p.get("name") or "",
                    "qty": _num(p.get("rmnd_qty") or p.get("hold_qty") or p.get("qty") or 0),
                    "avail_qty": _num(p.get("ord_psbl_qty") or 0),
                    "avg_price": _num(p.get("avg_prc") or p.get("pchs_avg_pric") or 0),
                    "cur_price": _num(p.get("cur_prc") or p.get("cur_price") or 0),
                    "eval_amt": _num(p.get("evlt_amt") or 0),
                    "pnl": _num(p.get("pl_amt") or p.get("evlt_pfls_amt") or p.get("pnl") or 0),
                })

        if bal.get("error"):
            errors.append(f"예수금: {bal['error']}")
        if not evl:
            errors.append("계좌평가 조회 실패(kt00004)")
        if bal.get("return_code") not in (0, None):
            errors.append(f"예수금 return_code={bal.get('return_code')} {bal.get('return_msg','')}")
        log.info(f"[계좌] 예수금={entr} 평가금액={total} 보유종목={len(positions)} "
                 f"오류={errors if errors else '없음'}")
        return {"mock": False, "entr": entr, "total_asset": total, "pnl": pnl,
                "pnl_pct": pnl_pct, "positions": positions, "errors": errors,
                "source": "real", "raw_balance": bal, "raw_eval": evl}

    # ── 주문 ────────────────────────────────────────────
    def place_order(self, symbol: str, side: str, qty: int, price: float, order_type: str = "00") -> dict:
        log.info(f"[주문요청] {side} {symbol} {qty}주 @ {price} (mock={CFG.USE_MOCK}, dry_run={CFG.DRY_RUN})")
        if CFG.DRY_RUN:
            return {
                "status": "dry_run_skipped",
                "symbol": symbol, "side": side, "qty": qty, "price": price,
                "message": "DRY_RUN=True 로 실제 주문 생략 - .env에서 DRY_RUN=false로 바꿔야 실제 주문 나감",
            }
        acnt = self._clean_account_no()
        if not acnt:
            return {"status": "error", "message": "ACCOUNT_NO 미설정 - .env에 계좌번호 10자리 숫자만 입력"}
        url = f"{CFG.base_url}/api/dostk/ordr"
        api_id = "kt10000" if side == "buy" else "kt10001"
        payload = {
            "dmst_stex_tp": "KRX",
            "stk_cd": symbol,
            "ord_qty": str(qty),
            "ord_uv": str(int(price)) if price and order_type == "00" else "",
            "trde_tp": "0",
            "ord_dvsn": order_type,
            "acnt_no": acnt,
            "buy_sell_tp": "1" if side == "buy" else "2",
        }
        try:
            resp = self._request_with_retry("POST", url, api_id, headers=self._headers(api_id=api_id), json=payload)
            resp.raise_for_status()
            result = resp.json()
            log.info(f"[주문응답] {result}")
            return result
        except Exception as e:
            log.error(f"[주문실패] {symbol} {side} {qty}주: {e}")
            return {"status": "error", "error": str(e), "symbol": symbol, "side": side}


    # ── 체결강도 / 분봉 (프롬프트 판단용 실제 데이터) ──────
    def get_chegyul_data(self, symbol: str) -> dict:
        """
        체결강도 추이 조회 (ka10046 - 체결강도추이(시간별))
        반환: {"chegyul": float, "trend": [과거 체결강도들...], "source": "real"|"mock"}
        """
        if self._is_dry_mock_no_key() or self._is_mock_token:
            c = random.uniform(80, 250)
            return {"chegyul": round(c, 1),
                    "trend": [round(c - random.uniform(10, 30), 1),
                              round(c - random.uniform(2, 15), 1),
                              round(c, 1)],
                    "source": "mock"}
        url = f"{CFG.base_url}/api/dostk/chegyul"
        payload = {"stk_cd": symbol}
        try:
            resp = self._request_with_retry("POST", url, "ka10046",
                                            headers=self._headers(api_id="ka10046"), json=payload)
            if resp.status_code in (404, 500):
                resp = self._request_with_retry("POST", f"{CFG.base_url}/api/dostk/mrkcond", "ka10046",
                                                headers=self._headers(api_id="ka10046"), json=payload)
            if resp.status_code != 200:
                return {"chegyul": 100.0, "trend": [], "source": "error"}
            data = resp.json()
            chegyul = None
            trend = []
            if isinstance(data, dict):
                # 응답 구조 다양: data / output / stk_chegyul 등
                for key in ("data", "output", "chegyul_data"):
                    v = data.get(key)
                    if isinstance(v, dict):
                        chegyul = chegyul or v.get("chegyul") or v.get("cheg_rt")
                        if isinstance(v.get("trend"), list):
                            trend = v.get("trend")
                    elif isinstance(v, list) and v:
                        first = v[0] if isinstance(v[0], dict) else {}
                        chegyul = chegyul or first.get("chegyul") or first.get("cheg_rt")
                        trend = [item.get("chegyul") or item.get("cheg_rt", 0) for item in v if isinstance(item, dict)]
                if chegyul is None:
                    chegyul = data.get("chegyul") or data.get("cheg_rt") or data.get("output1")
            try:
                chegyul = float(str(chegyul).replace(",", "").replace("+", "").replace("-", ""))
            except Exception:
                chegyul = 100.0
            return {"chegyul": chegyul, "trend": trend, "source": "real", "raw": data}
        except Exception as e:
            log.warning(f"체결강도 조회 실패 {symbol}: {e}")
            return {"chegyul": 100.0, "trend": [], "source": "error", "error": str(e)}

    def get_minute_chart(self, symbol: str, minutes: int = 5) -> list:
        """
        분봉 차트 조회 (ka10080 - 주식분봉차트조회) - 최근 minutes 분
        ★ ka10080 = 분봉 (ka10081은 일봉 - 이전에 바꿔 쓰던 버그 수정)
        ★ tic_scope(1=1분봉) + tic_cnt(봉 수) 필수
        반환: [{"price":..., "qty":..., "amount":..., "time":...}, ...] 최신이 마지막
        time: "YYYYMMDDHHMM" (있으면 과거 보충 저장용)
        """
        if self._is_dry_mock_no_key() or self._is_mock_token:
            base = random.randint(30000, 150000)
            out = []
            for _ in range(max(minutes, 3)):
                base = max(1000, base + random.randint(-1500, 1500))
                qty = random.randint(5000, 500000)
                out.append({"price": base, "qty": qty, "amount": base * qty})
            return out
        url = f"{CFG.base_url}/api/dostk/chart"
        # ★ base_dt 필수 (같은 /chart 엔드포인트 - 없으면 1511 에러) - 오늘 KST 자동
        try:
            from db import now_kst
            base_dt = now_kst().strftime("%Y%m%d")
        except Exception:
            from datetime import datetime
            base_dt = datetime.now().strftime("%Y%m%d")
        payload = {"dmst_stex_tp": "KRX", "stk_cd": symbol,
                   "tic_scope": "1", "tic_cnt": str(min(max(minutes, 1), 500)),
                   "base_dt": base_dt}
        try:
            resp = self._request_with_retry("POST", url, "ka10080",
                                            headers=self._headers(api_id="ka10080"), json=payload)
            if resp.status_code in (404, 500):
                resp = self._request_with_retry("POST", f"{CFG.base_url}/api/dostk/stk", "ka10080",
                                                headers=self._headers(api_id="ka10080"), json=payload)
            if resp.status_code != 200:
                return []
            data = resp.json()
            candles = []
            if isinstance(data, dict):
                for key in ("stk_dt_min_chart", "data", "output", "items", "chart"):
                    if key in data and isinstance(data[key], list):
                        candles = data[key]
                        break
            out = []
            for c in candles:
                price = c.get("cur_prc") or c.get("close_prc") or c.get("price") or 0
                qty = c.get("trde_qty") or c.get("qty") or 0
                amount = c.get("trd_amt") or c.get("amount") or 0
                t = c.get("stk_bsop_date") or c.get("bsop_date") or c.get("time") or ""
                if isinstance(t, (int, float)):
                    t = str(int(t))
                t_hm = c.get("stk_cntg_hour") or c.get("cntg_hour") or c.get("time_hhmm") or ""
                if t and t_hm and len(t) == 8 and len(str(t_hm)) >= 4:
                    t = t + str(t_hm).zfill(4)[:4]
                try:
                    p = float(str(price).replace(",", "").replace("+", ""))
                    q = float(str(qty).replace(",", ""))
                    a = float(str(amount).replace(",", "")) if amount else p * q
                    out.append({"price": p, "qty": q, "amount": a, "time": str(t)})
                except Exception:
                    continue
            out.reverse()  # 오래된순 -> 최신순
            return out[-minutes:]
        except Exception as e:
            log.warning(f"분봉 조회 실패 {symbol}: {e}")
            return []

    def get_trading_amount_1m_3m(self, symbol: str) -> dict:
        """최근 1분/3분 거래대금 계산 (분봉 기반)
        반환: {"amount_1m":..., "amount_3m":..., "avg_3m":..., "source": "real"|"mock"}
        """
        minutes = self.get_minute_chart(symbol, minutes=5)
        is_mock = self._is_mock_token or self._is_dry_mock_no_key()
        if len(minutes) >= 3:
            amounts = [m.get("amount", 0) for m in minutes]
            amount_3m = sum(amounts[-3:])
            amount_1m = amounts[-1]
            return {"amount_1m": amount_1m, "amount_3m": amount_3m,
                    "avg_3m": amount_3m / 3,
                    "source": "mock" if is_mock else "real"}
        # 실데이터 실패 시 mock (테스트/DRY_RUN 통과용)
        if CFG.DRY_RUN or is_mock:
            amount_3m = random.randint(50_000_000, 500_000_000)
            amount_1m = int(amount_3m / 3 * random.uniform(0.8, 1.5))
            return {"amount_1m": amount_1m, "amount_3m": amount_3m,
                    "avg_3m": amount_3m / 3, "source": "mock"}
        return {"amount_1m": 0, "amount_3m": 0, "avg_3m": 0, "source": "error"}


client = KiwoomClient()
