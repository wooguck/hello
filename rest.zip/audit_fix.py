# -*- coding: utf-8 -*-
"""
🔧 감사 문제 자동 수복 (audit_fix.py)
======================================
data_audit_report.json(무결성 검사 결과)을 읽어 문제 종목만 자동으로 고칩니다.

처리 방식 (문제 유형별):
  ① 파일 없음     → 새로 수신 (네이버→다음→Yahoo) · 안 되면 폐지 자동 등록
  ② 봉 부족(<30)  → 일봉 비우고 전체 재수신
  ③ 오래됨(7일+)  → 재수신 (최신까지) · 여전히 옛날이면 폐지 등록
  ④ 중간 갭       → ★ 일봉 비우고 전체 재수신 (소스 접합부 구멍 제거 - 분봉은 보존)
  ⑤ 값 오류/중복  → ★ 일봉 비우고 전체 재수신 (불량 CSV 데이터 제거 - 분봉은 보존)
  ⑦ 파일 손상     → 파일 삭제 후 재수신

실행:
  python data_audit.py          # ← 먼저 (보고서 생성)
  python audit_fix.py           # 문제 종목 자동 수복
  python data_audit.py          # ← 다시 검사해서 ✅ 확인
"""
import json
import os
import sqlite3
import sys
import time
from datetime import datetime, timedelta

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db
import backfill_history as bf
from config import CFG


def _log(msg=""):
    print(msg, flush=True)


def wipe_daily(sym):
    """일봉만 비움 (분봉 보존)"""
    p = os.path.join(db.DATA_DIR, "stocks", f"{sym}.db")
    if not os.path.exists(p):
        return
    try:
        c = sqlite3.connect(p, timeout=10)
        c.execute("DELETE FROM daily_bars")
        c.commit()
        c.close()
    except Exception:
        try:
            os.remove(p)   # 손상 파일이면 통째로 삭제
        except Exception:
            pass


def main():
    if not os.path.exists("data_audit_report.json"):
        _log("❌ data_audit_report.json 없음 - 먼저 python data_audit.py 실행")
        return
    with open("data_audit_report.json", encoding="utf-8") as f:
        r = json.load(f)

    missing = list(r.get("missing_files", []))
    few = list((r.get("few_bars") or {}).keys())
    stale = list((r.get("stale") or {}).keys())
    gaps = list((r.get("gaps") or {}).keys())
    bad = [b["symbol"] for b in (r.get("bad_values") or [])]
    broken = [b["symbol"] for b in (r.get("broken_files") or [])]

    dead = bf._load_dead()
    wipe_set = set(few) | set(gaps) | set(bad) | set(broken)       # 비우고 다시
    all_targets = sorted((set(missing) | wipe_set | set(stale)) - dead)

    _log("=" * 64)
    _log("🔧 감사 문제 자동 수복")
    _log("=" * 64)
    _log(f"대상: 파일없음 {len(missing)} · 봉부족 {len(few)} · 오래됨 {len(stale)} · "
         f"갭 {len(gaps)} · 값오류 {len(bad)} · 손상 {len(broken)}")
    _log(f"→ 고유 종목 {len(all_targets)}개 (폐지 {len(dead)}종목 제외)")
    if not all_targets:
        _log("✅ 수복할 종목 없음!")
        return

    days = int(getattr(CFG, "BACKFILL_DAYS", 1000))
    old_cut = (datetime.now() - timedelta(days=30)).strftime("%Y%m%d")
    ok = fail = dead_new = 0
    saved = 0
    t0 = time.time()
    for i, sym in enumerate(all_targets):
        rows = bf.fetch_daily_retry(sym, days=days, tries=2)
        if rows:
            # ★ v2: '받기 성공 후'에만 비움 (비우고 나서 수신 실패하면 데이터만 날리는 사고 방지)
            if sym in wipe_set:
                wipe_daily(sym)   # 갭/값오류 종목: 비우고 새 데이터로 통째 교체 (일관성)
            n = bf.save_daily_to_snapshots(sym, rows)
            saved += n
            ok += 1
            last = rows[-1]["date"]
            if last < old_cut:
                bf._mark_dead(sym, f"수복 후에도 마지막 봉 {last} - 상장폐지 추정")
                dead_new += 1
        else:
            fail += 1
            # ★ v2: 재수신 실패여도 기존 마지막 봉이 아주 옛날(60일+)이면 폐지 확정
            #   (2008년 등에서 멈춘 종목이 네이버 일시 차단 때문에 계속 목록에 남던 구멍)
            p = os.path.join(db.DATA_DIR, "stocks", f"{sym}.db")
            old_last = ""
            if os.path.exists(p):
                try:
                    c = sqlite3.connect(p)
                    rr = c.execute("SELECT MAX(bar_date) FROM daily_bars").fetchone()
                    c.close()
                    old_last = (rr[0] or "") if rr else ""
                except Exception:
                    pass
            ancient_cut = (datetime.now() - timedelta(days=60)).strftime("%Y-%m-%d")
            if old_last and old_last < ancient_cut:
                bf._mark_dead(sym, f"수복 실패 + 기존 마지막 봉 {old_last} - 상장폐지 확정")
                dead_new += 1
            elif not os.path.exists(p) and sym in bf._load_dead():
                dead_new += 1
        el = time.time() - t0
        eta = ""
        if i >= 4:
            eta = f" · 남은 {int(el / (i + 1) * (len(all_targets) - i - 1) // 60)}분"
        sys.stdout.write(f"\r  ⏳ {i+1}/{len(all_targets)} {sym} · 성공 {ok} · 실패 {fail} · "
                         f"폐지 {dead_new} · {saved:,}봉 · {el:.0f}초{eta}   ")
        sys.stdout.flush()
        time.sleep(float(getattr(CFG, "BACKFILL_SLEEP_SEC", 0.5)))
    print()

    _log(f"\n✅ 수복 완료: 성공 {ok} · 실패 {fail} · 폐지 등록 {dead_new} · {saved:,}봉")
    fs = getattr(bf, "_FAIL_STATS", {})
    parts = [f"{k} {v}" for k, v in (fs.get("http") or {}).items()]
    if fs.get("dns"):
        parts.append(f"DNS {fs['dns']}")
    if parts:
        _log(f"   실패 원인: {' · '.join(parts)}")
    _log("\n👉 다음: python data_audit.py 로 재검사 → ✅/🟡 확인")


if __name__ == "__main__":
    main()
