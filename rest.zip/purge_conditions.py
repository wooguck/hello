# -*- coding: utf-8 -*-
"""
🧹 조건식 대청소 (purge_conditions.py) - 2026-08-28
================================================================
사용자: "지금까지 조건식들 전체 종목으로 백테스트해서 쓸모없는 것 지우고,
        앞으로 쌓이는 것도 테스트 통과한 것만 남게"

동작:
  [1] 전체 조건식(운영+대기, 사진 포함)을 전 종목으로 엄밀 검증
      (validate_condition: 백테스트+무작위 대조군+지수비교+물리한계캡+실전일치 필터)
  [2] 등급별 처분:
      채택 후보/조건부  → 유지 (운영)
      수익만           → 대기(backlog)로 (재검증 순환 대상)
      기각/표본부족     → 퇴출(retired_conditions 보관 - 삭제 아님, 복구 가능)
  [3] 명예의 전당 상위 5개는 성적 무관 보호 (기존 원칙)

앞으로 쌓이는 것: 이미 자동 (lifecycle이 5라운드마다 기각+부진 강등,
  farm 블랙리스트가 재입단 차단, 게이트가 기각 등급 매수 금지)
  + 이번에 추가: 90일 이상 '기각' 상태로 대기에 머문 것 자동 퇴출

실행:
  python purge_conditions.py            # 미리보기 (변경 없음)
  python purge_conditions.py --run      # 실제 실행
  python purge_conditions.py --run --max-symbols 4000   # 전 종목 (권장, 시간 김)
"""
import argparse
import json
import sys
import time

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db


def _log(m=""):
    print(m, flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", action="store_true", help="실제 실행 (없으면 미리보기)")
    ap.add_argument("--max-symbols", type=int, default=4000)
    ap.add_argument("--days", type=int, default=365,
                    help="검증 기간 (기본 365일=최근 1년. 0이면 전체 기간)")
    args = ap.parse_args()
    start_date = None
    if args.days > 0:
        from datetime import timedelta
        start_date = (db.now_kst() - timedelta(days=args.days)).strftime("%Y-%m-%d")

    import os as _os0
    # ★ features 캐시 상한을 종목 수에 맞춤 (기본 600 - 4000종목이면 캐시가 계속 비워져
    #   조건식마다 재계산했음 = 대청소 최대 병목. 365일 필터 후 봉이라 메모리 ~300MB 수준)
    _os0.environ.setdefault("VALIDATE_FEAT_CACHE", str(args.max_symbols + 500))
    from validation import validate_condition, save_validation_results
    conds = db.get_conditions(status="active") + db.get_conditions(status="backlog")
    _log("=" * 66)
    _log(f"🧹 조건식 대청소: {len(conds)}개 전수 검증 "
         f"(종목 {args.max_symbols} · 기간 {'최근 ' + str(args.days) + '일' if args.days else '전체'} "
         f"· {'실행' if args.run else '미리보기'})")
    _log("=" * 66)

    # 명전 보호 목록
    hof_keys = set()
    try:
        hof_keys = {str(h.get("cond_key")) for h in db.hof_list(limit=5, ranked_only=True)}
    except Exception:
        pass

    keep, to_backlog, to_retire = [], [], []
    results = []
    t0 = time.time()
    # ★ 2026-08-28 진행률: 이어하기 지원 (중단해도 검증 결과 재사용)
    import os as _os
    prog_p = _os.path.join("strategy", "purge_progress.json")
    done_cache = {}
    # ★ 2026-08-28 수정: 캐시에 실행 설정(기간/종목수) 도장 - 설정이 바뀌면 캐시 무효
    #   (사용자 발견: --days 365로 바꿨는데 이전 전체기간 결과 82,744건이 재사용됨)
    cache_tag = f"days={args.days}|symbols={args.max_symbols}"
    try:
        _c = json.load(open(prog_p, encoding="utf-8"))
        if _c.get("_tag") == cache_tag:
            done_cache = _c
        else:
            _log(f"  (설정 변경 감지: 이전 캐시 폐기 - {_c.get('_tag')} → {cache_tag})")
    except Exception:
        pass
    done_cache["_tag"] = cache_tag
    for i, c in enumerate(conds):
        # ── 진행률 + 예상 남은 시간 (★ 첫 개부터 즉시 표시) ──
        el = time.time() - t0
        pct = i / len(conds) * 100
        bar = "█" * int(pct // 5) + "░" * (20 - int(pct // 5))
        if i == 0:
            eta_txt = "측정 중 (첫 검증은 데이터 로딩 때문에 1~3분 - 이후 빨라짐)"
        else:
            eta = el / i * (len(conds) - i)
            eta_txt = f"남은 예상 {int(eta//60)}분 {int(eta%60)}초" if eta >= 60 else f"남은 예상 {int(eta)}초"
        print(f"\r  [{bar}] {i}/{len(conds)} ({pct:.0f}%) · {eta_txt} · "
              f"검증 중: {(c.get('cond_txt') or '')[:24]}   ", end="", flush=True)
        try:
            slots = json.loads(c.get("slots_json") or "[]")
        except Exception:
            slots = []
        if not slots:
            to_retire.append((c, "슬롯 없음"))
            continue
        ck = str(c["id"])
        if ck in done_cache and ck != "_tag":   # 이어하기: 같은 설정의 결과만 재사용
            r = done_cache[ck]
        else:
            r = validate_condition({"cond_key": ck, "cond_txt": c["cond_txt"],
                                    "slots": slots}, max_symbols=args.max_symbols,
                                   start=start_date)
            # 중간 저장 (trades는 무거워서 제외)
            done_cache[ck] = {k: v for k, v in r.items() if k != "trades"}
            done_cache[ck]["trades"] = []
            if i % 5 == 0:
                try:
                    json.dump(done_cache, open(prog_p, "w", encoding="utf-8"),
                              ensure_ascii=False, default=str)
                except Exception:
                    pass
        r["cond_no"] = c.get("cond_no")
        results.append(r)
        g = r.get("grade")
        st = r.get("stats") or {}
        protected = str(c["id"]) in hof_keys
        print()   # 진행바 줄바꿈
        line = (f"  [{i+1}/{len(conds)}] {c['cond_txt'][:40]:42s} → {g} "
                f"(매매 {st.get('trades', 0)} · 평균 {st.get('avg_ret', 0) or 0:+.2f}% · "
                f"백분위 {st.get('percentile', 0) or 0:.0f})")
        if protected:
            keep.append(c)
            _log(line + " 🏆명전보호")
        elif g in ("채택 후보", "조건부"):
            keep.append(c)
            _log(line + " ✅유지")
        elif g == "수익만":
            to_backlog.append(c)
            _log(line + " 🟡대기로")
        else:
            to_retire.append((c, g or "기각"))
            _log(line + " 🗑퇴출")
    _log(f"\n소요 {time.time()-t0:.0f}초")
    _log("=" * 66)
    _log(f"  ✅ 유지(운영): {len(keep)}개")
    _log(f"  🟡 대기 강등: {len(to_backlog)}개 (재검증 순환)")
    _log(f"  🗑 퇴출 보관: {len(to_retire)}개 (retired - 복구 가능, 팜 재입단 차단)")

    if not args.run:
        _log("\n미리보기였습니다. 실제 실행: python purge_conditions.py --run --max-symbols 4000")
        return

    # 실제 반영
    try:
        save_validation_results(results)
    except Exception:
        pass
    with db.get_conn() as conn:
        for c in keep:
            conn.execute("UPDATE conditions SET status='active' WHERE id=?", (c["id"],))
        for c in to_backlog:
            conn.execute("UPDATE conditions SET status='backlog' WHERE id=?", (c["id"],))
        for c, why in to_retire:
            conn.execute(
                "INSERT OR REPLACE INTO retired_conditions "
                "(cond_key, cond_txt, slots_json, retired_at, reason) VALUES (?,?,?,?,?)",
                (str(c["id"]), c["cond_txt"], c.get("slots_json"),
                 db.now_kst_iso(), f"대청소: {why}"))
            conn.execute("UPDATE conditions SET status='retired' WHERE id=?", (c["id"],))
    try:
        _os.remove(prog_p)   # 완료 - 이어하기 캐시 정리
    except Exception:
        pass
    _log(f"\n💾 반영 완료. 운영 {len(keep)} · 대기 {len(to_backlog)} · 퇴출 {len(to_retire)}")
    _log("   퇴출분은 retired_conditions에 보관 (팜리그 재입단도 자동 차단)")


if __name__ == "__main__":
    db.init_db()
    main()
