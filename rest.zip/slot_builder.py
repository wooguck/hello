# -*- coding: utf-8 -*-
"""
🧱 단순→복잡 조건식 빌더 (slot_builder.py) - 2026-08-27 추가
================================================================
사용자 아이디어: "한개 두개로도 높은 승률이 있다면 그거를 발전시키는" 방식.

[빌드 모드] (기본) 상향식 조합 성장:
  1단계: 슬롯 1개짜리 전부 검증 (52슬롯 × 파라미터) → 무작위 대조군 이기는 것만 생존
  2단계: 생존 슬롯끼리 2개 조합 → "두 부모 중 나은 쪽보다 좋아야" 생존
  3단계: 같은 방식으로 3개 조합까지 (기본 최대 3 - 과적합 방지 상한)
  → 최종 생존 조합을 backlog 조건식으로 등록 (바로 매수 안 함 - lifecycle
    검증(20건+통과) 후에야 운영 승격. 기존 안전 절차 그대로 통과해야 함)

  ★ 과적합 방지 장치:
    - 각 단계에서 OOS(뒤 30% 기간) 성적도 플러스여야 생존 (앞 70%로 뽑고 뒤 30%로 확인)
    - 조합이 커질 때 "간결성 보너스": 슬롯 추가로 평균수익이 +0.15%p 이상 좋아져야 채택
      (조건 하나 더 붙는 건 공짜가 아님 - 확실히 나아질 때만)
    - 신호 20건 미만은 무조건 탈락 (소표본 우연 차단)
    - 상한 3슬롯 (사진식 4~6슬롯보다 단순한 쪽을 탐색하는 도구)

[분해 모드] (--dissect N) 기존 조건식 슬롯 기여도 분석:
  조건식 N번의 슬롯을 하나씩 빼보며 성적 변화 측정
  → "이 슬롯 빼도 성적 그대로/더 좋음" = 군더더기 (없애면 신호 늘고 과적합 줄어듦)
  → "빼면 성적 급락" = 핵심 슬롯
  결과만 보여줌 (자동 수정 없음 - 사용자 승인제 원칙)

실행:
  python slot_builder.py                  # 상향식 빌드 (1→2→3슬롯)
  python slot_builder.py --max-level 2    # 2슬롯까지만
  python slot_builder.py --register       # 최종 생존 조합을 backlog 등록
  python slot_builder.py --dissect 5      # 5번 조건식 분해 (슬롯 기여도)
라운드 연동: teams가 20라운드마다 자동 1회 (SLOT_BUILDER_AUTO=true, 등록까지)
"""
import argparse
import itertools
import json
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import sys
import time

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

# ── 설정 ──
MIN_SIGNALS = _cfg_env_int("SB_MIN_SIGNALS", 20)        # 단계별 최소 신호 수
SURVIVE_TOP = _cfg_env_int("SB_SURVIVE_TOP", 8)         # 단계별 생존 상한
MAX_LEVEL = _cfg_env_int("SB_MAX_LEVEL", 3)             # 조합 최대 슬롯 수
IMPROVE_MIN = _cfg_env_float("SB_IMPROVE_MIN", 0.15)    # 슬롯 추가 최소 개선 %p
MAX_SYMBOLS = _cfg_env_int("SB_MAX_SYMBOLS", 300)


def _log(m=""):
    print(m, flush=True)


def _atoms():
    """1슬롯 원자 후보: 슬롯 × 대표 파라미터 (전 조합은 너무 많아 대표값 최대 2개)"""
    from screener import SLOTS
    out = []
    for key, (name, params, choices, _fn) in SLOTS.items():
        if not params:
            out.append([(key, {})])
        else:
            picks = choices[:2] if len(choices) >= 2 else choices  # 대표 2개
            for c in picks:
                out.append([(key, {params[0]: c})])
    return out


def _eval(slots, feats, split):
    """조합 1개 평가 (photo_conditions와 같은 evaluate_screen 재사용 - 검증 일관성)"""
    from screener import evaluate_screen
    return evaluate_screen(feats, [list(s) for s in slots], split=split)


def _passes(r_tr, r_te):
    """생존 판정: 학습(앞 70%) + OOS(뒤 30%) 둘 다 기준 충족"""
    if r_tr["signal_count"] < MIN_SIGNALS:
        return False
    if r_tr["avg_ret"] <= 0 or r_tr.get("bench_diff", 0) <= 0:
        return False           # 학습: 수익 + 시장(같은날 벤치) 초과
    if r_te["signal_count"] < max(5, MIN_SIGNALS // 3):
        return False
    if r_te["avg_ret"] <= 0:
        return False           # OOS: 뒤 30% 기간에도 플러스
    return True


def _score(r_tr, r_te):
    """랭킹 점수: OOS 성적 위주 (학습 성적은 뽑는 데 썼으니 덜 믿음)"""
    return r_te["avg_ret"] * 0.7 + r_tr["avg_ret"] * 0.3


OVERLAP_MAX = _cfg_env_float("SB_OVERLAP_MAX", 0.8)    # 신호 겹침 상한 (자카드)


def _signal_set(slots, feats, split="train"):
    """조합의 '신호 지문': 실제 신호가 뜬 (종목, 날짜인덱스) 집합
    → 슬롯 이름이 달라도 잡는 날이 같으면 같은 전략으로 판정하는 근거"""
    from screener import SLOTS
    import config as _cfgmod
    CFG = _cfgmod.CFG
    out = set()
    fns = [SLOTS[k][3] for k, _p in slots]
    prms = [p for _k, p in slots]
    for sym, f in feats.items():
        if not f:
            continue
        n = len(f["close"])
        i_lo, i_hi = 21, n - 5
        if split == "train":
            i_hi = int(n * 0.7) - 5
        elif split == "test":
            i_lo = max(21, int(n * 0.7))
        for i in range(i_lo, i_hi):
            c0 = f["close"][i]
            if c0 <= 0 or c0 < CFG.MOCK_PRICE_MIN or c0 > CFG.MOCK_PRICE_MAX:
                continue
            hit = True
            for fn, p in zip(fns, prms):
                try:
                    if not fn(f, i, p):
                        hit = False
                        break
                except Exception:
                    hit = False
                    break
            if hit:
                out.add((sym, i))
    return out


def _jaccard(a, b):
    if not a or not b:
        return 0.0
    inter = len(a & b)
    return inter / max(1, len(a | b))


def _dedup_by_overlap(sorted_cands, feats, keep, log=None):
    """점수순 후보에서 신호 겹침(자카드) >= OVERLAP_MAX 인 하위 후보 제거
    → '2봉 연속 양봉'이 '1봉 연속 양봉'과 같은 날만 잡으면 상위 하나만 생존"""
    kept, sets, dropped = [], [], 0
    for item in sorted_cands:
        if len(kept) >= keep:
            break
        sig = _signal_set(item[0], feats, "train")
        dup = False
        for s in sets:
            if _jaccard(sig, s) >= OVERLAP_MAX:
                dup = True
                break
        if dup:
            dropped += 1
            continue
        kept.append(item)
        sets.append(sig)
    if log and dropped:
        log(f"  🔁 신호 겹침 {OVERLAP_MAX*100:.0f}%+ 중복 {dropped}개 제거 (같은 날 잡는 쌍둥이)")
    return kept


def _txt(slots):
    from screener import SLOTS
    parts = []
    for k, p in slots:
        name = SLOTS[k][0]
        for pk, pv in (p or {}).items():
            name = name.replace("{" + pk + "}", str(pv))
        parts.append(name)
    return " AND ".join(parts)


def build(max_level=MAX_LEVEL, register=False, log_fn=None):
    """상향식 빌드: 1슬롯 → 생존끼리 2슬롯 → 3슬롯"""
    def L(m):
        _log(m)
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    from screener import load_screener_symbols, load_features
    t0 = time.time()
    symbols = load_screener_symbols(max_symbols=MAX_SYMBOLS)
    feats = load_features(symbols, max_symbols=MAX_SYMBOLS)
    if not feats:
        return {"error": "일봉 데이터 부족", "levels": {}}
    L(f"🧱 [빌더] 시작: {len(feats)}종목 · 상한 {max_level}슬롯 · "
      f"생존기준: 신호{MIN_SIGNALS}+ & 학습벤치초과 & OOS플러스")

    levels = {}
    # ── 1단계: 원자 ──
    survivors = []   # [(slots, r_tr, r_te, score)]
    for slots in _atoms():
        r_tr = _eval(slots, feats, "train")
        if r_tr["signal_count"] < MIN_SIGNALS or r_tr["avg_ret"] <= 0:
            continue
        r_te = _eval(slots, feats, "test")
        if not _passes(r_tr, r_te):
            continue
        survivors.append((slots, r_tr, r_te, _score(r_tr, r_te)))
    survivors.sort(key=lambda x: -x[3])
    survivors = _dedup_by_overlap(survivors, feats, SURVIVE_TOP, log=L)  # ★ 쌍둥이 제거
    levels[1] = survivors
    L(f"  1슬롯: 생존 {len(survivors)}개"
      + (f" · 1위 [{_txt(survivors[0][0])[:40]}] OOS {survivors[0][2]['avg_ret']:+.2f}%"
         if survivors else " (없음 - 단독으론 우위 없는 시장)"))

    # ── 2단계 이상: 생존 조합 성장 ──
    for level in range(2, max_level + 1):
        if not survivors:
            break
        prev = survivors
        seen = set()
        cand = []
        atoms = [s[0][0] for s in levels[1]] if levels.get(1) else []
        for (base_slots, b_tr, b_te, _s) in prev:
            base_keys = {k for k, _p in base_slots}
            for atom in atoms:
                k, p = atom
                if k in base_keys:
                    continue                     # 같은 슬롯 중복 금지
                new_slots = sorted(base_slots + [atom], key=lambda x: x[0])
                sig = json.dumps(new_slots, sort_keys=True)
                if sig in seen:
                    continue
                seen.add(sig)
                r_tr = _eval(new_slots, feats, "train")
                if r_tr["signal_count"] < MIN_SIGNALS:
                    continue
                r_te = _eval(new_slots, feats, "test")
                if not _passes(r_tr, r_te):
                    continue
                # ★ 간결성 보너스: 부모(더 단순한 쪽)보다 OOS가 IMPROVE_MIN 이상 좋아야
                if r_te["avg_ret"] < b_te["avg_ret"] + IMPROVE_MIN:
                    continue
                cand.append((new_slots, r_tr, r_te, _score(r_tr, r_te)))
        cand.sort(key=lambda x: -x[3])
        survivors = _dedup_by_overlap(cand, feats, SURVIVE_TOP, log=L)  # ★ 쌍둥이 제거
        levels[level] = survivors
        L(f"  {level}슬롯: 생존 {len(survivors)}개"
          + (f" · 1위 [{_txt(survivors[0][0])[:40]}] OOS {survivors[0][2]['avg_ret']:+.2f}%"
             if survivors else " (조합해도 단순한 쪽을 못 이김 - 정상적 결과)"))

    # ── 최종: 모든 레벨 통틀어 상위 → 저장/등록 ──
    all_final = []
    for lv, items in levels.items():
        for (slots, r_tr, r_te, sc) in items:
            all_final.append({"level": lv, "slots": [list(s) for s in slots],
                              "txt": _txt(slots),
                              "train_n": r_tr["signal_count"], "train_avg": round(r_tr["avg_ret"], 3),
                              "oos_n": r_te["signal_count"], "oos_avg": round(r_te["avg_ret"], 3),
                              "oos_win": round(r_te["win_rate"], 1), "score": round(sc, 3)})
    all_final.sort(key=lambda x: -x["score"])
    # ★ 레벨 통합 중복 제거: 부모 1슬롯과 자식 2슬롯이 사실상 같은 날만 잡으면 상위 1개만
    #   (등록도 이 목록 기준이라 '1위와 5위가 같은 것' 원천 차단)
    _ded = _dedup_by_overlap(
        [([tuple(x) for x in r["slots"]], None, None, r["score"]) for r in all_final],
        feats, 30, log=L)
    _keep_sigs = {json.dumps(sorted([list(s) for s in sl]), sort_keys=True) for sl, _a, _b, _c in _ded}
    all_final = [r for r in all_final
                 if json.dumps(sorted(r["slots"]), sort_keys=True) in _keep_sigs]
    os.makedirs("strategy", exist_ok=True)
    json.dump({"at": db.now_kst_iso(), "results": all_final[:30],
               "params": {"min_signals": MIN_SIGNALS, "improve_min": IMPROVE_MIN,
                          "max_level": max_level, "symbols": len(feats)}},
              open(os.path.join("strategy", "slot_builder.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)

    registered = []
    if register and all_final:
        existing = set()
        try:
            for c in db.get_conditions(status=None):
                try:
                    existing.add(db.normalize_slots(json.loads(c["slots_json"] or "[]")))
                except Exception:
                    pass
        except Exception:
            pass
        for r in all_final[:3]:                  # 상위 3개만 등록 (도배 방지)
            try:
                sig = db.normalize_slots(r["slots"])
                if sig in existing:
                    continue
                existing.add(sig)
                # ★ 2026-09-02 전종목 최종면접 (사용자: "쓸모없는 조건식 그만 - 전종목 확인 후 등록")
                #   300종목 OOS 통과만으론 backlog에 안 넣음. 팜 데뷔 게이트와 동일 기준.
                _vr = None
                if os.getenv("DEBUT_GATE_ENABLED", "true").lower() == "true":
                    try:
                        from farm_league import _debut_gate
                        ok_g, why_g, _vr = _debut_gate(r["slots"], r["txt"], L)
                        if not ok_g:
                            L(f"  🎓❌ 최종면접 탈락(전종목): [{r['txt'][:40]}] {why_g} - 등록 안 함")
                            continue
                        L(f"  🎓✅ 최종면접 통과(전종목): [{r['txt'][:40]}] {why_g}")
                    except Exception as _e:
                        L(f"  ⚠️ 최종면접 오류(등록 보류): {str(_e)[:40]}")
                        continue
                no = db.next_cond_no()
                cid = db.create_condition(no, f"[빌더{r['level']}] {r['txt'][:70]}",
                                          r["slots"], source="builder")
                db.set_condition_status(cid, "backlog")   # ★ 반드시 backlog (검증 전 매수 금지)
                if _vr:
                    try:
                        from validation import save_validation_results
                        _vr["cond_key"] = str(cid)
                        _vr["cond_no"] = no
                        save_validation_results([_vr])
                    except Exception:
                        pass
                registered.append(no)
                L(f"  📝 backlog 등록: {no}번 [{r['txt'][:45]}] "
                  f"(전종목 면접 통과 · OOS {r['oos_avg']:+.2f}%)")
            except Exception as e:
                L(f"  ⚠️ 등록 실패: {str(e)[:40]}")

    L(f"🧱 [빌더] 완료: {time.time()-t0:.0f}초 · 결과 strategy/slot_builder.json")
    return {"levels": {lv: len(v) for lv, v in levels.items()},
            "top": all_final[:5], "registered": registered}


def dissect(cond_id, log_fn=None):
    """분해 모드: 조건식의 슬롯을 하나씩 빼며 기여도 측정 (보고만 - 수정 없음)"""
    def L(m):
        _log(m)
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    from screener import load_screener_symbols, load_features
    conds = {str(c["id"]): c for c in db.get_conditions(status=None)}
    by_no = {str(c["cond_no"]): c for c in conds.values()}
    c = conds.get(str(cond_id)) or by_no.get(str(cond_id))
    if not c:
        L(f"❌ 조건식 {cond_id} 없음")
        return None
    try:
        slots = [tuple(s) for s in json.loads(c["slots_json"] or "[]")]
    except Exception:
        slots = []
    if len(slots) < 2:
        L("이미 1슬롯 이하 - 분해할 것 없음")
        return None

    symbols = load_screener_symbols(max_symbols=MAX_SYMBOLS)
    feats = load_features(symbols, max_symbols=MAX_SYMBOLS)
    full = _eval(slots, feats, None)
    L("=" * 62)
    L(f"🔬 분해: {c['cond_no']}번 [{c['cond_txt'][:50]}]")
    L(f"  전체({len(slots)}슬롯): 신호 {full['signal_count']} · "
      f"평균 {full['avg_ret']:+.3f}% · 승률 {full['win_rate']:.1f}%")
    L("-" * 62)
    rows = []
    for i, s in enumerate(slots):
        rest = [x for j, x in enumerate(slots) if j != i]
        r = _eval(rest, feats, None)
        diff = full["avg_ret"] - r["avg_ret"]   # 빼면 얼마나 나빠지나 (+면 핵심)
        tag = ("🟢 핵심" if diff > 0.1 else
               "🟡 미미" if diff > -0.05 else
               "🔴 군더더기(빼면 더 좋음)")
        L(f"  -{_txt([s])[:36]:38s} 빼면: 신호 {r['signal_count']:4d} · "
          f"평균 {r['avg_ret']:+.3f}% (기여 {diff:+.3f}%p) {tag}")
        rows.append({"slot": list(s), "txt": _txt([s]), "without_avg": round(r["avg_ret"], 3),
                     "without_n": r["signal_count"], "contribution": round(diff, 3), "tag": tag})
    L("-" * 62)
    L("  ※ 🔴 슬롯은 빼는 편이 신호도 늘고 성적도 좋음 - 수정은 사용자 판단 (자동 변경 안 함)")
    out = {"cond_no": c["cond_no"], "txt": c["cond_txt"], "full": full, "slots": rows}
    json.dump(out, open(os.path.join("strategy", f"dissect_{c['cond_no']}.json"),
                        "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
    L(f"📄 저장: strategy/dissect_{c['cond_no']}.json")
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-level", type=int, default=MAX_LEVEL)
    ap.add_argument("--register", action="store_true", help="상위 3개 backlog 등록")
    ap.add_argument("--dissect", default="", help="조건식 번호/ID 분해 (슬롯 기여도)")
    args = ap.parse_args()
    db.init_db()
    if args.dissect:
        dissect(args.dissect)
    else:
        r = build(max_level=args.max_level, register=args.register)
        print()
        print("=" * 62)
        print("🧱 상위 결과 (OOS 성적순)")
        print("=" * 62)
        for t in r.get("top", []):
            print(f"  [{t['level']}슬롯] {t['txt'][:52]}")
            print(f"        학습 {t['train_avg']:+.2f}%({t['train_n']}건) · "
                  f"OOS {t['oos_avg']:+.2f}%({t['oos_n']}건) · OOS승률 {t['oos_win']}%")
        if not r.get("top"):
            print("  생존 조합 없음 - 현재 데이터에선 단순 슬롯 우위가 확인 안 됨 (정직한 결과)")
        if r.get("registered"):
            print(f"\n📝 backlog 등록: {r['registered']} (lifecycle 검증 통과해야 운영)")
