# -*- coding: utf-8 -*-
"""
🚑 오류 센터 (error_center.py) - 오류 수집 + 대비책 + "수정 필요 목록" 한 곳에
================================================================================
사용자: "오류 등이 있을 시 대비책, 수정이 필요한 내용을 모아두는 곳"

하는 일:
  [1] 수집: logs/ 전체에서 오류/경고를 긁어 분류 (패턴별 그룹)
  [2] 진단: 알려진 오류 패턴이면 원인+대비책을 자동으로 붙임 (지식베이스)
  [3] 기록: strategy/error_center.json 에 누적 - "수정 필요 목록"
      현황판 신호등이 🔴일 때 여기를 보면 뭘 고칠지 나옴
  [4] 자가치유 안내: 자동 복구되는 오류(토큰 8005, 네이버 차단 등)는
      "대비책 이미 내장"으로 표시 - 사람이 할 일 없음을 명확히

실행:
  python error_center.py           # 스캔 + 목록
  python error_center.py --clear   # 해결된 항목 정리
"""
import argparse
import json
import os
import re
import sys
from datetime import datetime

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

OUT = os.path.join("strategy", "error_center.json")

# ★ 지식베이스: 패턴 → (원인, 대비책, 자동복구 여부)
KNOWN = [
    (r"8005|Token이 유효", "토큰 무효 (다중 프로세스 토큰 충돌 or 점검시간)",
     "자동 재발급 내장(v19) - 반복되면 키움API 쓰는 프로그램 동시 실행 확인", True),
    (r"HTTP 200 빈응답|네이버.*차단", "네이버 IP 차단",
     "다음→Yahoo 자동 폴백 내장 - 지속 시 공유기 재부팅(IP변경)", True),
    (r"403.*다음|다음.*403", "다음 차단 or 폐지 종목",
     "카나리아 판별+쿨다운 재시도 내장 - 사람 조치 불필요", True),
    (r"429|Rate Limit", "API 호출 한도 초과",
     "지수 백오프 재시도 내장 - 반복되면 키움API 동시 사용 프로그램 확인", True),
    (r"점검|maintenance", "키움 새벽 점검 (04:30~07:30)",
     "해당 시간 API 차단 내장 - 07:30 자동 재개", True),
    (r"상위 조건식 없음", "매수 후보 조건식 없음",
     "정상 (검증 통과 대기) - 매도/손절 관리는 계속됨(v16)", True),
    (r"자금부족|cash", "가상 잔고 부족",
     "보유 청산되면 자동 회복 - PAPER_BUY_AMOUNT 조정 가능", True),
    (r"MemoryError|메모리", "메모리 부족",
     "대용량 처리 시 발생 - 해당 작업 재실행 (분할 처리 내장)", False),
    (r"Traceback", "미분류 파이썬 예외",
     "★사람 확인 필요 - 이 로그 몇 줄을 복사해서 공유", False),
    (r"주문 실패|매도 주문 실패", "주문 거부",
     "★확인 필요 - 장운영시간/증거금/계좌상태. 반복되면 로그 공유", False),
    (r"계좌 연동 실패|계좌평가 조회 실패", "계좌 조회 실패",
     "점검시간이면 정상 - 장중 반복 시 키/계좌번호/서버(모의·실전) 확인", False),
]


def scan_logs(max_lines=3000):
    """logs/ 전체에서 오류/경고 수집 → 패턴 그룹핑"""
    groups = {}
    if not os.path.isdir("logs"):
        return groups
    for f in sorted(os.listdir("logs")):
        p = os.path.join("logs", f)
        if not f.endswith((".log", ".txt")):
            continue
        try:
            lines = open(p, encoding="utf-8", errors="replace").readlines()[-max_lines:]
        except Exception:
            continue
        for ln in lines:
            if not any(k in ln for k in ("❌", "⚠️", "ERROR", "WARNING", "Traceback",
                                          "실패", "오류", "8005", "429")):
                continue
            matched = None
            for pat, cause, fix, auto in KNOWN:
                if re.search(pat, ln):
                    matched = (pat, cause, fix, auto)
                    break
            key = matched[1] if matched else "미분류: " + ln.strip()[:50]
            g = groups.setdefault(key, {"count": 0, "sample": ln.strip()[:120],
                                        "file": f, "cause": key,
                                        "fix": matched[2] if matched else "★사람 확인 필요 - 로그 공유",
                                        "auto_recover": matched[3] if matched else False})
            g["count"] += 1
    return groups


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--clear", action="store_true")
    args = ap.parse_args()
    if args.clear:
        try:
            os.remove(OUT)
            print("정리 완료")
        except Exception:
            print("정리할 것 없음")
        return

    print("=" * 72)
    print("🚑 오류 센터 - 로그 스캔 + 대비책")
    print("=" * 72)
    groups = scan_logs()
    if not groups:
        print("  🟢 오류/경고 없음")
        return
    auto_ok = {k: v for k, v in groups.items() if v["auto_recover"]}
    need_fix = {k: v for k, v in groups.items() if not v["auto_recover"]}

    if auto_ok:
        print(f"\n✅ 자동 복구 내장 ({len(auto_ok)}종 - 사람 조치 불필요):")
        for k, v in sorted(auto_ok.items(), key=lambda x: -x[1]["count"]):
            print(f"   {v['count']:>4}회  {k}")
            print(f"         → {v['fix']}")
    if need_fix:
        print(f"\n🔧 수정 필요 목록 ({len(need_fix)}종 - ★확인 필요):")
        for k, v in sorted(need_fix.items(), key=lambda x: -x[1]["count"]):
            print(f"   {v['count']:>4}회  {k}")
            print(f"         샘플: {v['sample'][:90]}")
            print(f"         → {v['fix']}")
    else:
        print("\n🟢 수정 필요 항목 없음 - 전부 자동 복구 범위 내")

    os.makedirs("strategy", exist_ok=True)
    json.dump({"scanned_at": db.now_kst_iso(),
               "auto_recover": auto_ok, "need_fix": need_fix},
              open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"\n📄 저장: {OUT} (현황판 신호등 🔴일 때 이 파일/명령으로 확인)")


if __name__ == "__main__":
    main()
