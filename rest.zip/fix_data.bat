@echo off
REM ============================================================
REM  Data audit + auto repair (one-click)
REM  1) data_audit.py : scan all symbols (bad bars/dups/gaps/stale)
REM  2) audit_fix.py  : re-fetch only problem symbols
REM  3) data_audit.py : re-scan to confirm
REM  * Stop the app's data collection before running this.
REM ============================================================
setlocal
cd /d "%~dp0"

echo [1/3] Data integrity scan...
python data_audit.py
echo.
echo [2/3] Auto repair (takes time - do not close)...
python audit_fix.py
echo.
echo [3/3] Re-scan...
python data_audit.py
echo.
echo DONE. If problems remain, run this file once more.
pause
