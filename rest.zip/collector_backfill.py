# -*- coding: utf-8 -*-
"""
🔄 키움 OpenAPI+ 백필 콜렉터 (collector_backfill.py)
====================================================
예전 collector.py(검증됨) 기반 - "구멍 메우기 + 과거 깊이 받기" 모드로 개조.
네이버/다음 IP 차단과 무관 (OpenAPI+ = HTS 로그인 방식, IP 등록도 불필요)

원본과 달라진 점:
  1) ★ 수집 대상 = stock-bot DB에 "없거나 부족한 종목만" (이미 충분한 종목 스킵)
     - TARGET_MODE = "missing":  data/stocks/{code}.db 없거나 일봉 < MIN_BARS 인 종목만
     - TARGET_MODE = "all":      전 종목 (원본과 동일)
     - MISMATCH_FIRST = True:    mismatch_symbols.json 종목을 최우선으로
  2) ★ 일봉 페이지 제한 해제: max_page 1 → 20 (600봉/페이지 아님, TR당 최대 900봉
     수준이라 20페이지면 DAILY_YEARS 커버) - cutoff_date 도달 시 자동 중단 (원본 로직)
  3) ★ DAILY_YEARS = 4 (신버전 BACKFILL_DAYS=1000봉 ≈ 4년과 맞춤)
  4) 분봉은 기본 OFF (COLLECT_MINUTES=False) - 일봉부터. 필요하면 True로
  5) 저장 형식은 원본 그대로 ByDate CSV → 끝나면 import_bydate.py로 흡수

사용 순서 (32비트 파이썬 환경에서):
  ① python collector_backfill.py          ← 키움 로그인 창 → 자동 수집
  ② (64비트/일반 환경에서) python import_bydate.py --dir E:/StockData/ByDate
  ③ python collect_data.py --status       ← 채워졌는지 확인

⚠️ 키움 OpenAPI+ 조회 제한: 과도한 연속 조회 시 서버가 응답을 늦추거나 끊음.
   TR_INTERVAL 0.6초 기준 1000종목 × 4년(5페이지 내외) ≈ 1.5~2시간.
   중간에 끊겨도 completed_list 이어받기로 재실행하면 이어서 받음 (원본 기능).
"""
import sys
import os
import time
import json
import glob
import pandas as pd
from datetime import datetime, timedelta
from PyQt5.QtWidgets import *
from PyQt5.QAxContainer import *
from PyQt5.QtCore import *

# =================================================
# [⚙️ 설정]
# =================================================
BASE_PATH = "E:/StockData"
DATE_DIR = os.path.join(BASE_PATH, "ByDate")
LOG_FILE = os.path.join(BASE_PATH, "completed_backfill.txt")   # ★ 원본과 분리 (혼동 방지)
TR_INTERVAL = 0.6
DAILY_YEARS = 4            # ★ 1 → 4년 (신버전 1000봉과 맞춤. 오래 걸리면 2로)
MAX_DAILY_PAGES = 20       # ★ 1 → 20 (cutoff 도달하면 자동 중단되므로 여유 있게)
COLLECT_MINUTES = False    # ★ 분봉은 기본 끔 (일봉 먼저 - 필요 시 True)
TARGET_MODE = "missing"    # ★ "missing"=부족한 종목만 / "all"=전 종목
MIN_BARS = 200             # ★ missing 판단: 일봉 200봉(약 10개월) 미만이면 다시 받음
STALE_DAYS = 7             # ★ 최신 봉이 7일보다 오래됐으면 '갱신 필요' (1월에 멈춘 종목 등)
                           #   → 이런 종목은 1페이지만(최근 ~600봉) 받아 갭을 빠르게 메움
STOCKBOT_DIR = os.path.dirname(os.path.abspath(__file__))  # stock-bot 폴더 (여기에 놓고 실행)
MISMATCH_FIRST = True      # ★ mismatch_symbols.json 종목 최우선 수집
# =================================================

if sys.maxsize > 2**32:
    print("❌ 64비트 환경입니다. 32비트 가상환경에서 실행해주세요.")
    sys.exit()


def get_needed_symbols():
    """★ stock-bot DB를 보고 '받아야 할 종목' 목록 생성 (32비트에서도 sqlite3는 표준)
    반환: (충분, 깊이부족, 갱신필요(stale), mismatch)
    - 깊이부족: 봉 수 < MIN_BARS → 과거 4년치 풀 수집
    - 갱신필요: 봉 수는 충분한데 최신 봉이 STALE_DAYS보다 오래됨 (예: 1월에 멈춤)
                → 1페이지(최근 ~600봉)만 받아 갭 메움 (600봉 ≈ 2.5년이라 웬만한 갭 커버)
    """
    import sqlite3
    stocks_dir = os.path.join(STOCKBOT_DIR, "data", "stocks")
    need = set()
    stale = set()
    have_enough = set()
    fresh_cut = (datetime.now() - timedelta(days=STALE_DAYS)).strftime("%Y-%m-%d")
    if os.path.isdir(stocks_dir):
        for f in glob.glob(os.path.join(stocks_dir, "*.db")):
            sym = os.path.basename(f)[:-3]
            try:
                c = sqlite3.connect(f)
                r = c.execute("SELECT COUNT(*), MAX(bar_date) FROM daily_bars").fetchone()
                c.close()
                cnt = r[0] if r else 0
                last = (r[1] or "") if r else ""
                if cnt < MIN_BARS:
                    need.add(sym)              # 깊이 부족 → 풀 수집
                elif last < fresh_cut:
                    stale.add(sym)             # ★ 최신이 아님 (1월 멈춤 등) → 최근만 갱신
                else:
                    have_enough.add(sym)       # 충분 + 최신
            except Exception:
                need.add(sym)
    # mismatch 종목은 무조건 다시 (액면분할 어긋남 - DB 지웠어도 여기서 잡힘)
    mismatch = set()
    mm_path = os.path.join(STOCKBOT_DIR, "mismatch_symbols.json")
    if os.path.exists(mm_path):
        try:
            with open(mm_path, encoding="utf-8") as f:
                mismatch = set(json.load(f).keys())
        except Exception:
            pass
    return have_enough, need, stale, mismatch


class UniversalCollector(QAxWidget):
    def __init__(self):
        super().__init__()
        self.setControl("KHOPENAPI.KHOpenAPICtrl.1")

        os.makedirs(DATE_DIR, exist_ok=True)
        self.cutoff_date = (datetime.now() - timedelta(days=365 * DAILY_YEARS)).strftime("%Y%m%d")

        self.login_loop = QEventLoop()
        self.tr_loop = QEventLoop()
        self.remained_data = False

        self.current_name = "-"
        self.current_code = "-"
        self.current_rows = 0
        self.current_page = 0
        self.total_target = 0
        self.current_idx = 0
        self.start_time = time.time()

        self.OnEventConnect.connect(self._on_login)
        self.OnReceiveTrData.connect(self._on_tr_data)

    def login(self):
        print("🔑 로그인 중...")
        self.CommConnect()
        self.login_loop.exec_()
        print("✅ 로그인 완료.")

    def force_exit_loop(self):
        if self.tr_loop.isRunning():
            self.tr_loop.exit()
            self.remained_data = False
            self.print_dashboard("TIMEOUT")

    def print_dashboard(self, status):
        percent = (self.current_idx / max(1, self.total_target)) * 100
        el = time.time() - self.start_time
        # ★ 남은 시간 추정 (사용자: '얼마나 진행된지 몰라서')
        eta = ""
        if self.current_idx > 3:
            per_item = el / self.current_idx
            remain = per_item * (self.total_target - self.current_idx)
            eta = f"|남은 {int(remain // 60)}분"
        bar_len = 5
        filled = int(bar_len * percent / 100)
        bar = '█' * filled + '░' * (bar_len - filled)
        s_name = self.current_name
        if len(s_name) > 3: s_name = s_name[:2] + "."
        msg = (f"\r[{bar}] {percent:4.1f}%|{self.current_idx}/{self.total_target}"
               f"|{s_name}|P:{self.current_page}|{status}{eta}")
        sys.stdout.write(msg + "      ")
        sys.stdout.flush()

    def get_today_completed_codes(self):
        completed = set()
        if os.path.exists(LOG_FILE):
            try:
                today = datetime.now().strftime("%Y%m%d")
                with open(LOG_FILE, 'r') as f:
                    lines = f.readlines()
                    if lines and lines[0].strip() == today:
                        for line in lines[1:]: completed.add(line.strip())
            except: pass
        return completed

    def save_log(self, code):
        today = datetime.now().strftime("%Y%m%d")
        try:
            if not os.path.exists(LOG_FILE) or os.path.getsize(LOG_FILE) == 0:
                with open(LOG_FILE, 'w') as f: f.write(f"{today}\n{code}\n")
            else:
                with open(LOG_FILE, 'r') as f: header = f.readline().strip()
                if header != today:
                    with open(LOG_FILE, 'w') as f: f.write(f"{today}\n{code}\n")
                else:
                    with open(LOG_FILE, 'a') as f: f.write(f"{code}\n")
        except: pass

    def start_collection(self):
        print(f"\n🚀 [백필 모드] 과거 {DAILY_YEARS}년치 수집 시작 (대상: {TARGET_MODE})...")
        full_stock_list = self.get_clean_stock_list()

        # ★ stock-bot DB 기준으로 '부족한 종목만' 필터
        self.quick_update = set()   # ★ 갱신만 필요한 종목 (1페이지만 - 빠름)
        if TARGET_MODE == "missing":
            have_enough, need_db, stale, mismatch = get_needed_symbols()
            print(f"📊 stock-bot DB: 최신 {len(have_enough)}종목 · 깊이부족 {len(need_db)}종목 "
                  f"· 갱신필요 {len(stale)}종목 · 어긋남 {len(mismatch)}종목")
            filtered = []
            first = []
            updates = []
            for code, name in full_stock_list:
                if code in mismatch and MISMATCH_FIRST:
                    first.append((code, name))        # 어긋남 → 최우선 (풀 수집)
                elif code in have_enough:
                    continue                           # 충분+최신 → 스킵
                elif code in stale:
                    updates.append((code, name))       # ★ 갱신만 (1페이지 - 종목당 ~1초)
                    self.quick_update.add(code)
                else:
                    filtered.append((code, name))      # 없거나 부족 → 풀 수집
            full_stock_list = first + filtered + updates
            print(f"📋 수집 필요: {len(full_stock_list)}종목 "
                  f"(풀 수집 {len(first) + len(filtered)}개 + 최근갱신만 {len(updates)}개)")

        full_target = full_stock_list  # ★ 지수는 신버전이 따로 받음 - 제외 (원하면 원복)

        already_done = self.get_today_completed_codes()
        print(f"📂 오늘 완료된 종목: {len(already_done)}개 (Skip)")

        self.todo_list = []
        for code, name in full_target:
            if str(code) in already_done: continue
            self.todo_list.append((code, name))

        self.total_target = len(self.todo_list)
        self.start_time = time.time()

        if not self.todo_list:
            print("\n✨ 수집할 종목이 없습니다! (모두 충분)")
            sys.exit()

        est = self.total_target * (TR_INTERVAL + 0.7) * (3 if DAILY_YEARS >= 3 else 1.5)
        print(f"📋 수집 대상: {self.total_target}개 · 예상 {int(est // 60)}분 내외")
        print(f"   (중간에 끊겨도 재실행하면 이어받습니다 - {os.path.basename(LOG_FILE)})")
        self.collect_loop()

    def collect_loop(self):
        save_counter = 0; self.buffer = {}

        for i, (code, name) in enumerate(self.todo_list):
            self.current_idx = i + 1
            self.current_code = code
            self.current_name = name
            self.current_rows = 0
            self.current_page = 0

            self.print_dashboard("일..")
            self.request_data("stock_daily", "opt10081", code, False)

            if COLLECT_MINUTES:
                self.print_dashboard("분..")
                self.request_data("stock_minute", "opt10080", code, False)

            self.save_log(code)
            save_counter += 1
            if save_counter >= 30:
                self.flush_buffer_daily(False); self.flush_buffer_minute()
                save_counter = 0; self.buffer = {}

        if self.buffer: self.flush_buffer_daily(False); self.flush_buffer_minute()
        print("\n\n🎉 작업 완료!")
        print("👉 다음: (일반 환경에서) python import_bydate.py --dir E:/StockData/ByDate")
        sys.exit()

    def request_data(self, rqname, trcode, code, is_index):
        self.remained_data = True
        self.set_input_value("기준일자", datetime.now().strftime("%Y%m%d"))

        self.set_input_value("종목코드", code)
        self.set_input_value("수정주가구분", "1")
        if 'minute' in rqname: self.set_input_value("틱범위", "1:1분")

        self.comm_rq_data(rqname, trcode, 0, "1000")

        page_cnt = 0

        # ★ 백필 모드: 일봉도 연속조회로 과거까지 (cutoff_date 도달 시 자동 중단)
        #   갱신만 필요한 종목(quick_update)은 1페이지(최근 ~600봉)만 - 갭 메우기 고속
        if 'daily' in rqname:
            if code in getattr(self, "quick_update", set()):
                max_page = 1
            else:
                max_page = MAX_DAILY_PAGES
        else:
            max_page = 5

        while self.remained_data and page_cnt < max_page:
            for _ in range(6):
                time.sleep(0.1)
                QCoreApplication.processEvents()

            self.current_page = page_cnt + 1
            self.print_dashboard("수신")

            self.set_input_value("기준일자", datetime.now().strftime("%Y%m%d"))
            self.set_input_value("종목코드", code); self.set_input_value("수정주가구분", "1")
            if 'minute' in rqname: self.set_input_value("틱범위", "1:1분")

            self.comm_rq_data(rqname, trcode, 2, "1000")
            page_cnt += 1

    def save_with_retry(self, df, path):
        try:
            if os.path.exists(path):
                existing_df = pd.read_csv(path, dtype={'code': str})

                if 'time' in df.columns:
                    existing_keys = set(zip(existing_df['code'], existing_df['time'].astype(str)))
                    is_new = [(r.code, str(r.time)) not in existing_keys for r in df.itertuples()]
                    new_df = df[is_new]
                else:
                    existing_codes = set(existing_df['code'])
                    new_df = df[~df['code'].isin(existing_codes)]

                if not new_df.empty:
                    new_df.to_csv(path, mode='a', header=False, index=False, encoding='utf-8-sig')
            else:
                df.to_csv(path, mode='w', header=True, index=False, encoding='utf-8-sig')
        except: pass

    def flush_buffer_daily(self, is_index):
        if not self.buffer: return
        keys = [k for k in self.buffer.keys() if '_daily' in k]
        for key in keys:
            rows = self.buffer.pop(key); file_path = os.path.join(DATE_DIR, f"{key}.csv")
            cols = ['code', 'open', 'high', 'low', 'close', 'volume', 'value']
            df = pd.DataFrame(rows, columns=cols)
            self.save_with_retry(df, file_path)

    def flush_buffer_minute(self):
        if not self.buffer: return
        keys = [k for k in self.buffer.keys() if '_minute' in k]
        for key in keys:
            rows = self.buffer.pop(key); file_path = os.path.join(DATE_DIR, f"{key}.csv")
            df = pd.DataFrame(rows, columns=['code', 'time', 'open', 'high', 'low', 'close', 'volume'])
            self.save_with_retry(df, file_path)

    def _on_tr_data(self, screen_no, rqname, trcode, record_name, next, *args):
        cnt = self.dynamicCall("GetRepeatCnt(QString, QString)", trcode, rqname)
        self.current_rows += cnt

        for i in range(cnt):
            try:
                if 'minute' in rqname:
                    full_dt = self._get_comm_data(trcode, rqname, i, "체결시간")
                    date = full_dt[:8]; time_str = full_dt[8:]
                    self.current_date = date; key = f"{date}_minute"
                else:
                    date = self._get_comm_data(trcode, rqname, i, "일자")
                    time_str = ""; self.current_date = date; key = f"{date}_daily"

                if 'daily' in rqname and date < self.cutoff_date:
                    self.remained_data = False; break

                o = abs(int(self._get_comm_data(trcode, rqname, i, "시가")))
                h = abs(int(self._get_comm_data(trcode, rqname, i, "고가")))
                l = abs(int(self._get_comm_data(trcode, rqname, i, "저가")))
                c = abs(int(self._get_comm_data(trcode, rqname, i, "현재가")))
                v = int(self._get_comm_data(trcode, rqname, i, "거래량"))
                if 'daily' in rqname:
                    val = int(self._get_comm_data(trcode, rqname, i, "거래대금"))
                    row = (self.current_code, o, h, l, c, v, val)
                else:
                    row = (self.current_code, time_str, o, h, l, c, v)

                if key not in self.buffer: self.buffer[key] = []
                self.buffer[key].append(row)
            except: pass

        self.print_dashboard("OK")
        if self.remained_data: self.remained_data = (next == '2')
        self.tr_loop.exit()

    def get_code_name(self, c):
        n = self.dynamicCall("GetMasterCodeName(QString)", c).strip()
        try: return n.encode('latin1').decode('cp949')
        except: return n

    def get_clean_stock_list(self):
        kospi = self.get_codes("0"); kosdaq = self.get_codes("10")
        raw = set(kospi + kosdaq); clean = []
        bl = ["KODEX", "TIGER", "KBSTAR", "ACE", "SOL", "ETN", "스팩", "SPAC", "리츠", "우B", "우"]
        for c in raw:
            if not c.isdigit(): continue
            n = self.get_code_name(c); trash = False
            for b in bl:
                if b in n: trash = True; break
            if trash: continue
            clean.append((c, n))
        return sorted(clean, key=lambda x: x[0])

    def CommConnect(self): self.dynamicCall("CommConnect()")
    def _on_login(self, err): self.login_loop.exit()
    def get_codes(self, mkt): return [c for c in self.dynamicCall("GetCodeListByMarket(QString)", mkt).split(';') if c]
    def set_input_value(self, id, val): self.dynamicCall("SetInputValue(QString, QString)", id, val)
    def comm_rq_data(self, rn, tr, next, sn):
        self.dynamicCall("CommRqData(QString, QString, int, QString)", rn, tr, next, sn)
        QTimer.singleShot(5000, self.force_exit_loop)
        self.tr_loop.exec_()
    def _get_comm_data(self, tr, rn, i, item): return self.dynamicCall("GetCommData(QString, QString, int, QString)", tr, rn, i, item).strip()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    collector = UniversalCollector()
    collector.login()
    QTimer.singleShot(1000, collector.start_collection)
    sys.exit(app.exec_())
