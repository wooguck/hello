"""DB 계층 (SQLite)

핵심 테이블:
- strategies        : 전략(=파라미터 세트) 하나당 한 행. 세대/부모/상태 추적
- virtual_positions : 가상(내부 시뮬레이션) 보유 포지션 - 10개 전략 병행용
- trades            : 모든 매매 기록 (virtual / mock_real 구분)
- daily_performance : 전략별 일일 성과 스냅샷 (승률, 손익비, MDD 등)
- backtest_scores   : 대량 백테스트 결과
"""
import sqlite3
import json
from contextlib import contextmanager
from datetime import datetime, date, timedelta, timezone

# ── 한국시간(KST) 통일 ─────────────────────────────
try:
    from zoneinfo import ZoneInfo
    KST_TZ = ZoneInfo("Asia/Seoul")
except Exception:
    KST_TZ = timezone(timedelta(hours=9))


def now_kst() -> datetime:
    """현재 시각을 한국시간(KST)으로 반환"""
    return datetime.now(KST_TZ)


def now_kst_iso() -> str:
    return now_kst().isoformat()


DB_PATH = "trading.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS strategies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    generation INTEGER NOT NULL,
    parent_ids TEXT,
    params_json TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'candidate',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS virtual_positions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    strategy_id INTEGER NOT NULL,
    symbol TEXT NOT NULL,
    entry_price REAL NOT NULL,
    qty INTEGER NOT NULL,
    entry_time TEXT NOT NULL,
    exit_price REAL,
    exit_time TEXT,
    status TEXT NOT NULL DEFAULT 'open',
    kind TEXT NOT NULL DEFAULT 'virtual',
    FOREIGN KEY(strategy_id) REFERENCES strategies(id)
);

CREATE TABLE IF NOT EXISTS trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    strategy_id INTEGER NOT NULL,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL,
    price REAL NOT NULL,
    qty INTEGER NOT NULL,
    executed_at TEXT NOT NULL,
    kind TEXT NOT NULL,
    FOREIGN KEY(strategy_id) REFERENCES strategies(id)
);

CREATE TABLE IF NOT EXISTS daily_performance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    strategy_id INTEGER NOT NULL,
    date TEXT NOT NULL,
    trade_count INTEGER NOT NULL,
    win_rate REAL,
    avg_return REAL,
    cumulative_return REAL,
    max_drawdown REAL,
    fitness_score REAL,
    FOREIGN KEY(strategy_id) REFERENCES strategies(id)
);

CREATE TABLE IF NOT EXISTS backtest_scores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    strategy_id INTEGER NOT NULL,
    run_at TEXT NOT NULL,
    sample_size INTEGER NOT NULL,
    is_out_of_sample INTEGER NOT NULL,
    win_rate REAL,
    avg_return REAL,
    score REAL,
    FOREIGN KEY(strategy_id) REFERENCES strategies(id)
);

CREATE TABLE IF NOT EXISTS market_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    price REAL NOT NULL,
    volume REAL,
    chegyul REAL,
    rsi REAL,
    ema_fast REAL,
    ema_slow REAL,
    volume_ratio REAL,
    snapshot_time TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS backtest_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_at TEXT NOT NULL,
    params_json TEXT NOT NULL,
    symbol TEXT NOT NULL,
    period_days INTEGER NOT NULL,
    trade_count INTEGER NOT NULL,
    win_rate REAL,
    total_return REAL,
    max_drawdown REAL,
    avg_return REAL,
    note TEXT
);

CREATE TABLE IF NOT EXISTS stock_names (
    symbol TEXT PRIMARY KEY,
    name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS judgments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    judged_at TEXT NOT NULL,
    symbol TEXT NOT NULL,
    kind TEXT NOT NULL,            -- buy | sell
    decision TEXT NOT NULL,        -- 매수 | 매수금지 | 수익청산 | 손절 | 보유
    engine TEXT NOT NULL,          -- rule | gemini | gpt | params
    score REAL,
    reason TEXT,
    profile TEXT                   -- ★ 매수 시점 지표 스냅샷 (JSON) - 학습용
);

CREATE TABLE IF NOT EXISTS universe (
    symbol TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    market TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS scan_state (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    pointer INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT
);

CREATE TABLE IF NOT EXISTS market_indices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    index_name TEXT NOT NULL,
    value REAL NOT NULL,
    change_pct REAL,
    snapshot_time TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS screener_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    params_json TEXT,
    note TEXT
);

CREATE TABLE IF NOT EXISTS screener_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL,
    cond_key TEXT NOT NULL,
    cond_txt TEXT NOT NULL,
    slots_json TEXT,
    signal_count INTEGER NOT NULL,
    win_rate REAL,
    avg_ret REAL,
    total_return REAL,
    pf REAL,
    bench_diff REAL,
    oos_pass INTEGER,
    oos_win_rate REAL,
    oos_avg REAL,
    FOREIGN KEY(run_id) REFERENCES screener_runs(id)
);

CREATE TABLE IF NOT EXISTS screener_ai_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    round_no INTEGER NOT NULL,
    provider TEXT,
    directive_json TEXT,
    result_json TEXT,
    bench_avg REAL,
    note TEXT
);

CREATE TABLE IF NOT EXISTS hall_of_fame (
    cond_key TEXT PRIMARY KEY,
    cond_txt TEXT NOT NULL,
    slots_json TEXT,
    first_entered TEXT NOT NULL,
    last_updated TEXT NOT NULL,
    best_win_rate REAL,
    best_pf REAL,
    best_oos_win REAL,
    best_oos_avg REAL,
    sample_count INTEGER NOT NULL DEFAULT 0,
    pass_count INTEGER NOT NULL DEFAULT 0,
    fail_count INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'active'   -- active | retired
);

CREATE TABLE IF NOT EXISTS value_watch (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    name TEXT,
    watch_date TEXT NOT NULL,          -- 관찰 시작일
    per REAL, pbr REAL, roe REAL, div_yield REAL,
    price_at_watch REAL,               -- 관찰 시작 시점 가격
    status TEXT DEFAULT 'watching',    -- watching | up | down | removed
    peak_return REAL,                  -- 관찰 후 최고 수익률 %
    last_check TEXT,
    note TEXT
);

CREATE TABLE IF NOT EXISTS paper_schedule (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cond_key TEXT NOT NULL,
    cond_txt TEXT NOT NULL,
    tf TEXT DEFAULT 'day',
    slots_json TEXT,
    grade TEXT NOT NULL,
    scheduled_date TEXT NOT NULL,     -- 다음날(YYYY-MM-DD) 모의매매 적용일
    created_at TEXT NOT NULL,
    used INTEGER DEFAULT 0            -- 1=해당일 사용됨
);

CREATE TABLE IF NOT EXISTS retired_conditions (
    cond_key TEXT PRIMARY KEY,
    cond_txt TEXT NOT NULL,
    slots_json TEXT,
    retired_at TEXT NOT NULL,
    last_win_rate REAL,
    last_pf REAL,
    reason TEXT
);

-- ★ 조건식 등록부 (원형 1,2,3... + 변형 1-1, 1-2, 1-1-1...) - 모의 매매 성적표 기준
CREATE TABLE IF NOT EXISTS conditions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cond_no TEXT UNIQUE NOT NULL,        -- "1", "2", "1-1", "1-1-1" ...
    parent_no TEXT,                      -- 원형/부모 번호
    cond_txt TEXT NOT NULL,
    slots_json TEXT NOT NULL,
    source TEXT NOT NULL DEFAULT 'photo', -- photo | gemini | rule
    status TEXT NOT NULL DEFAULT 'active', -- active | backlog(뒤로 뺌) | retired
    rounds_tested INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    last_tested_at TEXT,
    tf TEXT DEFAULT 'day'                 -- ★ 봉 기준: day|week|month|min1|min3|min15
);

CREATE TABLE IF NOT EXISTS paper_positions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cond_key TEXT NOT NULL,
    cond_txt TEXT NOT NULL,
    symbol TEXT NOT NULL,
    entry_price REAL NOT NULL,
    entry_time TEXT NOT NULL,
    qty INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'open',
    exit_price REAL,
    exit_time TEXT,
    ret_pct REAL
);
"""


@contextmanager
def get_conn():
    """DB 연결 (WAL + busy_timeout - OneDrive/동기화 잠금 방어)
    - WAL 모드: 읽기와 쓰기 동시 허용, 파일 잠금 최소화
    - busy_timeout 30초: 다른 프로세스가 쓰는 중이면 대기 후 재시도
    """
    conn = sqlite3.connect(DB_PATH, timeout=30.0)
    conn.row_factory = sqlite3.Row
    try:
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA busy_timeout=30000")
            conn.execute("PRAGMA synchronous=NORMAL")
        except Exception:
            pass
        yield conn
        try:
            conn.commit()
        except Exception as _ce:
            log_io_error("commit", _ce)
    finally:
        try:
            conn.close()
        except Exception:
            pass


def log_io_error(where, e):
    """DB I/O 오류 로그 - OneDrive 잠금/디스크 문제 대응 (앱 종료 없이 안내)"""
    import logging
    logging.getLogger("db").error(
        f"DB {where} 실패: {e} | 폴더가 동기화 중(OneDrive)이면 잠시 후 재시도 "
        f"또는 DB를 C:\\stock_data 같은 로컬 폴더로 이동 권장")


def init_db():
    with get_conn() as conn:
        conn.executescript(SCHEMA)
        # 기존 DB 마이그레이션: virtual_positions에 kind 컬럼이 없으면 추가
        try:
            cols = [r["name"] for r in conn.execute("PRAGMA table_info(virtual_positions)").fetchall()]
            if "kind" not in cols:
                conn.execute("ALTER TABLE virtual_positions ADD COLUMN kind TEXT NOT NULL DEFAULT 'virtual'")
                print("[DB] virtual_positions.kind 컬럼 추가 (마이그레이션)")
        except Exception:
            pass
        # ★ 마이그레이션 (2026-08-28): 환상수익 검증기록 무효화
        #   avg_ret > 310%(물리한계: 10일×31%)는 데이터 접합 점프 오염 - 등급 '무효'로
        try:
            n = conn.execute("UPDATE validation_results SET grade='무효(데이터오류)' "
                             "WHERE avg_ret > 310 AND grade != '무효(데이터오류)'").rowcount
            if n:
                print(f"[DB] 환상수익 검증기록 {n}건 무효화 (avg_ret>310% = 접합 오류)")
        except Exception:
            pass
        # ★ 마이그레이션: paper_positions.order_kind (2026-08-27 사용자: '가상/실제모의 헷갈림')
        #   real  = 키움 모의계좌에 실제 주문 나간 것 (진짜 체결)
        #   virtual = 주문 없이 기록만 (DRY_RUN/장외 신호 등)
        try:
            pcols = [r["name"] for r in conn.execute("PRAGMA table_info(paper_positions)").fetchall()]
            if "order_kind" not in pcols:
                conn.execute("ALTER TABLE paper_positions ADD COLUMN order_kind TEXT NOT NULL DEFAULT 'virtual'")
                print("[DB] paper_positions.order_kind 컬럼 추가 (실제모의/가상 구분)")
        except Exception:
            pass
        # 마이그레이션: judgments.profile 컬럼 (매수 시점 스냅샷 - 학습용)
        try:
            jcols = [r["name"] for r in conn.execute("PRAGMA table_info(judgments)").fetchall()]
            if "profile" not in jcols:
                conn.execute("ALTER TABLE judgments ADD COLUMN profile TEXT")
                print("[DB] judgments.profile 컬럼 추가 (마이그레이션)")
        except Exception:
            pass
        # ★ 마이그레이션: hall_of_fame signature/score/ranked 컬럼 (명예의 전당 순위 관리)
        try:
            hcols = [r["name"] for r in conn.execute("PRAGMA table_info(hall_of_fame)").fetchall()]
            added = []
            if "signature" not in hcols:
                conn.execute("ALTER TABLE hall_of_fame ADD COLUMN signature TEXT")
                added.append("signature")
            if "score" not in hcols:
                conn.execute("ALTER TABLE hall_of_fame ADD COLUMN score REAL DEFAULT 0")
                added.append("score")
            if "ranked" not in hcols:
                conn.execute("ALTER TABLE hall_of_fame ADD COLUMN ranked INTEGER DEFAULT 0")
                added.append("ranked")
            if added:
                print(f"[DB] hall_of_fame {','.join(added)} 컬럼 추가 (명예의 전당 순위)")
        except Exception:
            pass
        # ★ 마이그레이션: conditions.tf (봉 기준 - 사진 조건식)
        try:
            ccols = [r["name"] for r in conn.execute("PRAGMA table_info(conditions)").fetchall()]
            if "tf" not in ccols:
                conn.execute("ALTER TABLE conditions ADD COLUMN tf TEXT DEFAULT 'day'")
                print("[DB] conditions.tf 컬럼 추가 (봉 기준)")
        except Exception:
            pass
        # ★ 마이그레이션: paper_positions.highest_return (보유 중 최고 수익률 - AI 매도/트레일링스탑용)
        try:
            pcols = [r["name"] for r in conn.execute("PRAGMA table_info(paper_positions)").fetchall()]
            if "highest_return" not in pcols:
                conn.execute("ALTER TABLE paper_positions ADD COLUMN highest_return REAL DEFAULT 0")
                print("[DB] paper_positions.highest_return 컬럼 추가 (AI 매도 판단용)")
            if "entry_index_pct" not in pcols:
                conn.execute("ALTER TABLE paper_positions ADD COLUMN entry_index_pct REAL")
                print("[DB] paper_positions.entry_index_pct 컬럼 추가 (진입 시점 지수 등락률)")
            if "exit_index_pct" not in pcols:
                conn.execute("ALTER TABLE paper_positions ADD COLUMN exit_index_pct REAL")
                print("[DB] paper_positions.exit_index_pct 컬럼 추가 (청산 시점 지수 등락률)")
            if "lowest_return" not in pcols:
                conn.execute("ALTER TABLE paper_positions ADD COLUMN lowest_return REAL DEFAULT 0")
                print("[DB] paper_positions.lowest_return 컬럼 추가 (매수후최저수익률)")
            # ★ 매수 시점 매도 지침 (사용자: '매수되면 평가해서 어느 선에 매도하겠다 지침을 만들고 유동적으로 매도')
            if "target_price" not in pcols:
                conn.execute("ALTER TABLE paper_positions ADD COLUMN target_price REAL")
                print("[DB] paper_positions.target_price 컬럼 추가 (매도 지침 - 목표가)")
            if "stop_price" not in pcols:
                conn.execute("ALTER TABLE paper_positions ADD COLUMN stop_price REAL")
                print("[DB] paper_positions.stop_price 컬럼 추가 (매도 지침 - 손절가)")
            if "sell_plan" not in pcols:
                conn.execute("ALTER TABLE paper_positions ADD COLUMN sell_plan TEXT")
                print("[DB] paper_positions.sell_plan 컬럼 추가 (매도 지침 문구)")
            if "plan_provider" not in pcols:
                conn.execute("ALTER TABLE paper_positions ADD COLUMN plan_provider TEXT DEFAULT 'rule'")
                print("[DB] paper_positions.plan_provider 컬럼 추가 (지침 출처: gemini/rule)")
            if "exit_reason" not in pcols:
                conn.execute("ALTER TABLE paper_positions ADD COLUMN exit_reason TEXT")
                print("[DB] paper_positions.exit_reason 컬럼 추가 (청산 사유 - 주간 리포트 AIvs규칙 비교용)")
        except Exception:
            pass
    print(f"[DB] {DB_PATH} 초기화 완료")
    # ★ 구버전 날짜별 스냅샷 파일에 source 컬럼 추가 (백필/실시간 구분용)
    try:
        migrated = migrate_daily_files()
        if migrated:
            print(f"[DB] 데이터 파일 {migrated}개 source 컬럼 마이그레이션 완료")
    except Exception:
        pass


def create_strategy(generation, params, parent_ids=None, status="candidate"):
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO strategies (generation, parent_ids, params_json, status, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (generation, json.dumps(parent_ids or []), json.dumps(params), status,
             now_kst_iso()),
        )
        return cur.lastrowid


def get_active_strategies():
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM strategies WHERE status IN ('active','survivor','candidate')"
        ).fetchall()
        return [dict(r) for r in rows]


def record_trade(strategy_id, symbol, side, price, qty, kind):
    if price is None:
        price = 0
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO trades (strategy_id, symbol, side, price, qty, executed_at, kind) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (strategy_id, symbol, side, price, qty, now_kst_iso(), kind),
        )


def record_daily_performance(strategy_id, date, trade_count, win_rate, avg_return,
                             cumulative_return, max_drawdown, fitness_score):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO daily_performance "
            "(strategy_id, date, trade_count, win_rate, avg_return, cumulative_return, "
            "max_drawdown, fitness_score) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (strategy_id, date, trade_count, win_rate, avg_return, cumulative_return,
             max_drawdown, fitness_score),
        )


def get_recent_performance(strategy_id, limit=30):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM daily_performance WHERE strategy_id=? ORDER BY date DESC LIMIT ?",
            (strategy_id, limit),
        ).fetchall()
        return [dict(r) for r in rows]


def set_strategy_status(strategy_id, status):
    with get_conn() as conn:
        conn.execute("UPDATE strategies SET status=? WHERE id=?", (status, strategy_id))


def get_open_positions(strategy_id=None):
    with get_conn() as conn:
        if strategy_id:
            rows = conn.execute(
                "SELECT * FROM virtual_positions WHERE status='open' AND strategy_id=?",
                (strategy_id,),
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM virtual_positions WHERE status='open'").fetchall()
        return [dict(r) for r in rows]


def get_open_positions_with_pl(symbol_prices=None):
    """오픈 포지션 + 현재가 기반 수익률% 계산 (실제 매매 현황 표시용)
    symbol_prices: {symbol: price} 캐시. 없으면 수익률 None(가격 미확인)
    """
    positions = get_open_positions()
    out = []
    for p in positions:
        price = (symbol_prices or {}).get(p["symbol"])
        ret = None
        if price and p["entry_price"]:
            ret = round((price - p["entry_price"]) / p["entry_price"] * 100, 2)
        out.append({**p, "current_price": price, "return_pct": ret})
    return out


def get_positions_aggregated(kind_filter=None, symbol_prices=None, account_positions=None,
                             account_only=False):
    """
    ★ 종목별 합산 포지션 (UI 1행 표시용) - 같은 종목 여러 전략이 매수해도 1행으로 합산
    kind_filter: None=전체 / 'real'(모의+실전) / 'virtual'
    symbol_prices: {symbol: price} 현재가 캐시
    account_positions: 키움 계좌 실제 보유 종목 리스트 (get_account_overview()['positions'])
                       → 내부 DB에 없어도 표시 (구분 "계좌")
    account_only=True: 내부 DB 무시하고 계좌 실제 보유만 (💼 계좌 탭용 - 자동매매 가상 기록 제외)
    반환: [{symbol, name, kind, qty, avg_price, cur_price, eval_amt, pnl, pnl_pct, entries:[...]}, ...]
    """
    if account_only:
        # 계좌 실제 보유만 (내부 DB 포지션 완전 제외)
        rows = []
    else:
        rows = get_open_positions()
    if kind_filter == "real":
        rows = [r for r in rows if r.get("kind") in ("mock_real", "live_real")]
    elif kind_filter == "virtual":
        rows = [r for r in rows if r.get("kind") == "virtual"]
    prices = symbol_prices or {}
    agg = {}
    for r in rows:
        sym = r["symbol"]
        kind = r.get("kind", "virtual")
        a = agg.setdefault(sym, {"symbol": sym, "name": get_symbol_name(sym),
                                 "kinds": set(), "qty": 0, "cost": 0.0,
                                 "entries": []})
        a["kinds"].add(kind)
        a["qty"] += r["qty"]
        a["cost"] += r["entry_price"] * r["qty"]
        a["entries"].append(r)

    # ── 키움 계좌 실제 보유 종목 병합 (내부 DB에 없어도 표시) ──
    # kind_filter='virtual' 일 때는 계좌 종목 제외 (가상만 볼 때)
    if account_positions and kind_filter != "virtual":
        for p in account_positions:
            sym = p.get("symbol", "")
            if not sym:
                continue
            qty = p.get("qty", 0) or 0
            if qty <= 0:
                continue
            avg = p.get("avg_price", 0) or 0
            a = agg.setdefault(sym, {"symbol": sym, "name": p.get("name") or get_symbol_name(sym),
                                     "kinds": set(), "qty": 0, "cost": 0.0,
                                     "entries": []})
            a["kinds"].add("account")  # 계좌 보유 표시
            a["qty"] += qty
            a["cost"] += avg * qty

    out = []
    for sym, a in agg.items():
        avg = a["cost"] / a["qty"] if a["qty"] else 0
        cur = prices.get(sym)
        eval_amt = cur * a["qty"] if cur else a["cost"]
        pnl = eval_amt - a["cost"]
        pnl_pct = pnl / a["cost"] * 100 if a["cost"] else 0
        if len(a["kinds"]) == 1:
            k = next(iter(a["kinds"]))
            kind_label = {"virtual": "가상", "mock_real": "모의", "live_real": "실전",
                          "account": "계좌"}.get(k, k)
        else:
            kind_label = "혼합"
        out.append({"symbol": sym, "name": a["name"], "kind": kind_label,
                    "qty": a["qty"], "avg_price": round(avg, 2),
                    "cur_price": cur, "eval_amt": round(eval_amt), "pnl": round(pnl),
                    "pnl_pct": round(pnl_pct, 2), "entries": a["entries"]})
    # 실제(계좌/모의/실전) 우선 → 수익률 높은 순
    priority = {"계좌": 0, "모의": 0, "실전": 0, "혼합": 0, "가상": 1}
    out.sort(key=lambda x: (priority.get(x["kind"], 1), -x["pnl_pct"]))
    return out


def get_real_positions_summary(symbol_prices=None):
    """실제 매매(모의/실전) 포지션 실적 요약
    - 청산: 승률/총손익/평균수익률
    - 오픈: 현재 수익률 리스트
    """
    with get_conn() as conn:
        closed = conn.execute(
            "SELECT * FROM virtual_positions WHERE status='closed' AND kind IN ('mock_real','live_real')"
        ).fetchall()
        closed = [dict(r) for r in closed]
        opened = conn.execute(
            "SELECT * FROM virtual_positions WHERE status='open' AND kind IN ('mock_real','live_real')"
        ).fetchall()
        opened = [dict(r) for r in opened]

    closed_rets = []
    for c in closed:
        try:
            closed_rets.append((c["exit_price"] - c["entry_price"]) / c["entry_price"] * 100)
        except Exception:
            continue
    win_rate = len([r for r in closed_rets if r > 0]) / len(closed_rets) * 100 if closed_rets else 0
    avg_ret = sum(closed_rets) / len(closed_rets) if closed_rets else 0
    total_pnl = sum((c["exit_price"] - c["entry_price"]) * c["qty"] for c in closed if c["exit_price"])

    open_list = []
    for o in opened:
        price = (symbol_prices or {}).get(o["symbol"])
        ret = None
        if price and o["entry_price"]:
            ret = round((price - o["entry_price"]) / o["entry_price"] * 100, 2)
        open_list.append({**o, "current_price": price, "return_pct": ret})

    # ★ 평가손익 수정: 실현손익(청산) + 미실현평가손익(오픈) 둘 다 합산해야 "평가손익"
    unrealized_pnl = 0.0
    open_pnl_list = []
    for o in opened:
        price = (symbol_prices or {}).get(o["symbol"])
        if price and o["entry_price"]:
            pnl = (price - o["entry_price"]) * o["qty"]
            unrealized_pnl += pnl
            open_pnl_list.append(pnl)
        else:
            open_pnl_list.append(None)

    total_eval_pnl = round(total_pnl + unrealized_pnl)

    return {
        "closed_count": len(closed_rets),
        "win_rate": round(win_rate, 2),
        "avg_return": round(avg_ret, 2),
        "total_pnl": round(total_pnl),          # 실현손익 (청산만)
        "unrealized_pnl": round(unrealized_pnl), # 미실현 평가손익 (오픈)
        "total_eval_pnl": total_eval_pnl,        # ★ 평가손익 = 실현 + 미실현
        "open": open_list,
    }


def get_real_trades(limit=30):
    """실제 주문(모의/실전)만 최근순 조회"""
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM trades WHERE kind IN ('mock_real','live_real') "
            "ORDER BY id DESC LIMIT ?", (limit,),
        ).fetchall()
        return [dict(r) for r in rows]


def get_latest_price(symbol: str):
    """종목의 마지막 가격 (없으면 None) - 캐시/잔고용 빠른 조회
    1) 메인 DB 실시간 스냅샷 우선
    2) ★ 종목별 저장(data/stocks/{symbol}.db) 최신 일봉 종가 폴백
       (전 종목 스캔 히트 종목은 감시 풀 밖일 수 있어 반드시 필요 - 가격 0으로 진입 스킵 방지)
    """
    try:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT price FROM market_snapshots WHERE symbol=? ORDER BY id DESC LIMIT 1",
                (symbol,),
            ).fetchone()
            if row and row["price"]:
                return row["price"]
    except Exception:
        pass
    if STOCK_DIR_SAVE:
        try:
            path = _stock_db_path(symbol)
            if _os.path.exists(path):
                conn = _daily_conn(path)
                try:
                    row = conn.execute(
                        "SELECT close_price FROM daily_bars ORDER BY bar_date DESC LIMIT 1"
                    ).fetchone()
                finally:
                    conn.close()
                if row and row["close_price"]:
                    return float(row["close_price"])
        except Exception:
            pass
    return None


def get_account_summary():
    """계좌 잔고 요약 (예수금/평가금액/평가손익/보유종목) - 키움 통합 조회
    실패 시 None 반환 (대시보드에서 숨김 처리)
    """
    try:
        from kiwoom_client import client
        ov = client.get_account_overview()
        if not isinstance(ov, dict) or ov.get("mock"):
            return ov if isinstance(ov, dict) else None
        # 오류만 있는 경우도 그대로 반환 (대시보드에서 표시)
        return ov
    except Exception:
        return None


def get_today_realized_pnl():
    """당일 실현 손익 (KST 기준 오늘 청산된 모의/실전 포지션)"""
    today = now_kst().strftime("%Y-%m-%d")
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT entry_price, exit_price, qty FROM virtual_positions "
                "WHERE status='closed' AND kind IN ('mock_real','live_real') "
                "AND date(exit_time)=?",
                (today,),
            ).fetchall()
        pnl = 0.0
        for r in rows:
            pnl += (r["exit_price"] - r["entry_price"]) * r["qty"]
        return round(pnl)
    except Exception:
        return 0


def open_virtual_position(strategy_id, symbol, entry_price, qty, kind="virtual"):
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO virtual_positions (strategy_id, symbol, entry_price, qty, entry_time, status, kind) "
            "VALUES (?, ?, ?, ?, ?, 'open', ?)",
            (strategy_id, symbol, entry_price, qty, now_kst_iso(), kind),
        )
        return cur.lastrowid


def close_virtual_position(position_id, exit_price):
    with get_conn() as conn:
        conn.execute(
            "UPDATE virtual_positions SET exit_price=?, exit_time=?, status='closed' WHERE id=?",
            (exit_price, now_kst_iso(), position_id),
        )


def get_trades(strategy_id=None, limit=100):
    with get_conn() as conn:
        if strategy_id:
            rows = conn.execute(
                "SELECT * FROM trades WHERE strategy_id=? ORDER BY id DESC LIMIT ?",
                (strategy_id, limit),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM trades ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(r) for r in rows]


def get_trade_stats():
    """요약 통계: 총 거래, 총 매수/매도, 종류별 건수"""
    with get_conn() as conn:
        total = conn.execute("SELECT COUNT(*) c FROM trades").fetchone()["c"]
        buys = conn.execute("SELECT COUNT(*) c FROM trades WHERE side='buy'").fetchone()["c"]
        sells = conn.execute("SELECT COUNT(*) c FROM trades WHERE side='sell'").fetchone()["c"]
        mock = conn.execute("SELECT COUNT(*) c FROM trades WHERE kind='mock_real'").fetchone()["c"]
        virt = conn.execute("SELECT COUNT(*) c FROM trades WHERE kind='virtual'").fetchone()["c"]
        live = conn.execute("SELECT COUNT(*) c FROM trades WHERE kind='live_real'").fetchone()["c"]
        open_pos = conn.execute(
            "SELECT COUNT(*) c FROM virtual_positions WHERE status='open'"
        ).fetchone()["c"]
        closed_pos = conn.execute(
            "SELECT COUNT(*) c FROM virtual_positions WHERE status='closed'"
        ).fetchone()["c"]
        return {
            "total_trades": total, "buys": buys, "sells": sells,
            "mock_real": mock, "virtual": virt, "live_real": live,
            "open_positions": open_pos, "closed_positions": closed_pos,
        }


def latest_fitness(strategy_id):
    perf = get_recent_performance(strategy_id, limit=1)
    return perf[0]["fitness_score"] if perf else -999.0


# ── 시세 스냅샷 (★ 날짜별 파일 분리 - trading.db 무거워짐 방지) ──
# 시세/지수 같은 대용량 수집 데이터는 data/snapshots_YYYY-MM-DD.db, data/indices_YYYY-MM-DD.db
# 에 날짜별로 저장. trading.db는 전략/거래/성과 등 핵심만 가볍게 유지.
import os as _os
from config import CFG as _CFG

# ★ 데이터 폴더: config.DATA_DIR (기본 "data", Windows 고정 가능: DATA_DIR=C:/stock_data)
DATA_DIR = getattr(_CFG, "DATA_DIR", "data") or "data"
STOCK_DIR_SAVE = getattr(_CFG, "STOCK_DIR_SAVE", True)


def _stock_db_path(symbol):
    """★ 종목별 데이터 파일: data/stocks/{symbol}.db (일봉+분봉 통합)"""
    try:
        _os.makedirs(_os.path.join(DATA_DIR, "stocks"), exist_ok=True)
    except Exception:
        pass
    return _os.path.join(DATA_DIR, "stocks", f"{symbol}.db")


def _init_stock_schema(conn):
    """종목별 파일 스키마: daily_bars(일봉) + minute_bars(분봉)"""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS daily_bars (
            bar_date TEXT PRIMARY KEY,
            open_price REAL, high_price REAL, low_price REAL, close_price REAL,
            volume REAL, amount REAL, source TEXT, updated_at TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS minute_bars (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            bar_time TEXT NOT NULL,
            price REAL NOT NULL,
            volume REAL,
            cum_volume REAL,
            UNIQUE(bar_time)
        )
    """)
    conn.commit()


def _ensure_data_dir():
    _os.makedirs(DATA_DIR, exist_ok=True)


def _snapshot_db_path(d=None):
    """날짜별 스냅샷 DB 파일 경로: data/snapshots_YYYY-MM-DD.db"""
    if d is None:
        d = now_kst().date()
    if isinstance(d, str):
        d = date.fromisoformat(d)
    return _os.path.join(DATA_DIR, f"snapshots_{d.isoformat()}.db")


def _index_db_path(d=None):
    """날짜별 지수 DB 파일 경로: data/indices_YYYY-MM-DD.db"""
    if d is None:
        d = now_kst().date()
    if isinstance(d, str):
        d = date.fromisoformat(d)
    return _os.path.join(DATA_DIR, f"indices_{d.isoformat()}.db")


def _daily_conn(db_path):
    _ensure_data_dir()
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


# ── ★ 종목별 저장 (STOCK_DIR_SAVE=true) - 일봉/분봉 종목별 누적 ──

def record_stock_daily(symbol, bar_date, open_price, high_price, low_price,
                       close_price, volume, amount, source="backfill"):
    """종목별 일봉 1개 저장/갱신 (bar_date 기준 upsert)
    ★ 2026-08-28 자동 보정: 소스(네이버/다음)가 주는 봉 자체에 종가>고가 같은
      오류가 있으면 재수신해도 같은 불량이 반복됨 (사용자: "아무리 해도 안 채워짐")
      → 저장 시점에 고가=max(시가,고가,저가,종가) / 저가=min(...)으로 정합화"""
    try:
        _vals = [v for v in (open_price, high_price, low_price, close_price) if v and v > 0]
        if _vals:
            high_price = max(_vals)
            low_price = min(_vals)
        path = _stock_db_path(symbol)
        conn = _daily_conn(path)
        _init_stock_schema(conn)
        conn.execute(
            "INSERT OR REPLACE INTO daily_bars (bar_date, open_price, high_price, low_price, "
            "close_price, volume, amount, source, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (bar_date, open_price, high_price, low_price, close_price, volume, amount,
             source, now_kst_iso()))
        conn.commit()
        conn.close()
        return True
    except Exception:
        return False


def record_stock_minute(symbol, bar_time, price, volume, cum_volume):
    """종목별 분봉 1개 저장 (bar_time upsert)"""
    try:
        path = _stock_db_path(symbol)
        conn = _daily_conn(path)
        _init_stock_schema(conn)
        conn.execute(
            "INSERT OR REPLACE INTO minute_bars (bar_time, price, volume, cum_volume) "
            "VALUES (?, ?, ?, ?)",
            (bar_time, price, volume, cum_volume))
        conn.commit()
        conn.close()
        return True
    except Exception:
        return False


def get_stock_daily(symbol, max_days=120):
    """종목별 일봉 조회 (오래된순) - 파일 1개만 열면 끝 (차트/검증 최적화)"""
    try:
        path = _stock_db_path(symbol)
        if not _os.path.exists(path):
            return []
        conn = _daily_conn(path)
        try:
            rows = conn.execute(
                "SELECT bar_date, open_price, high_price, low_price, close_price, volume, amount "
                "FROM daily_bars ORDER BY bar_date DESC LIMIT ?", (max_days,)).fetchall()
        except Exception:
            rows = []
        conn.close()
        out = []
        for r in rows:
            out.append({"date": r["bar_date"], "open": r["open_price"] or 0,
                        "high": r["high_price"] or 0, "low": r["low_price"] or 0,
                        "close": r["close_price"] or 0, "volume": r["volume"] or 0,
                        "amount": r["amount"] or 0})
        out.reverse()
        return out
    except Exception:
        return []


def get_stock_minute(symbol, limit=20000):
    """종목별 분봉 조회 (오래된순)"""
    try:
        path = _stock_db_path(symbol)
        if not _os.path.exists(path):
            return []
        conn = _daily_conn(path)
        try:
            rows = conn.execute(
                "SELECT bar_time, price, volume, cum_volume FROM minute_bars "
                "ORDER BY bar_time DESC LIMIT ?", (limit,)).fetchall()
        except Exception:
            rows = []
        conn.close()
        out = [{"bar_time": r["bar_time"], "price": r["price"],
                "volume": r["volume"] or 0, "cum_volume": r["cum_volume"] or 0}
               for r in rows]
        out.reverse()
        return out
    except Exception:
        return []


def get_stock_minute_dates(symbol):
    """★ 종목별 분봉 보유 날짜 목록 (중복 없이, 오름차순) - 이미 받은 날짜 확인용
    반환: ["YYYY-MM-DD", ...] (없으면 [])
    """
    try:
        path = _stock_db_path(symbol)
        if not _os.path.exists(path):
            return []
        conn = _daily_conn(path)
        try:
            rows = conn.execute(
                "SELECT DISTINCT substr(bar_time,1,10) d FROM minute_bars ORDER BY d").fetchall()
        except Exception:
            rows = []
        conn.close()
        return [r["d"] for r in rows]
    except Exception:
        return []


def stock_files_count():
    """종목별 파일 개수 (UI 표시용)"""
    try:
        d = _os.path.join(DATA_DIR, "stocks")
        if not _os.path.isdir(d):
            return 0
        return len([f for f in _os.listdir(d) if f.endswith(".db")])
    except Exception:
        return 0


def data_collection_stats():
    """★ 데이터 수집 현황 요약 (UI 표시용 - 실제 받아지는지 눈으로)
    반환: {stock_files, universe, daily_bars, minute_bars, minute_days, minute_range,
           total_mb, last_backfill}
    """
    import json
    out = {"stock_files": 0, "universe": 0, "daily_bars": 0, "minute_bars": 0,
           "minute_days": 0, "minute_range": "", "total_mb": 0.0, "last_backfill": ""}
    try:
        out["universe"] = count_universe()
    except Exception:
        pass
    try:
        out["last_backfill"] = ""
        with open(_os.path.join("strategy", "backfill_state.json"), encoding="utf-8") as f:
            st = json.load(f)
            out["last_backfill"] = (st.get("last_backfill_at") or "")[:16].replace("T", " ")
    except Exception:
        pass
    sd = _os.path.join(DATA_DIR, "stocks")
    if not _os.path.isdir(sd):
        return out
    files = [f for f in _os.listdir(sd) if f.endswith(".db")]
    out["stock_files"] = len(files)
    min_dates = []
    for f in files[:4000]:
        p = _os.path.join(sd, f)
        try:
            out["total_mb"] += _os.path.getsize(p) / 1024 / 1024
            c = _daily_conn(p)
            try:
                r = c.execute("SELECT COUNT(*) FROM daily_bars").fetchone()
                out["daily_bars"] += r[0] if r else 0
            except Exception:
                pass
            try:
                r = c.execute("SELECT COUNT(DISTINCT substr(bar_time,1,10)) d, "
                              "MIN(substr(bar_time,1,10)) mn, MAX(substr(bar_time,1,10)) mx "
                              "FROM minute_bars").fetchone()
                if r and r["d"]:
                    out["minute_bars"] += c.execute("SELECT COUNT(*) FROM minute_bars").fetchone()[0]
                    out["minute_days"] = max(out["minute_days"], r["d"])
                    if r["mn"]:
                        min_dates.append((r["mn"], r["mx"]))
            except Exception:
                pass
            c.close()
        except Exception:
            continue
    if min_dates:
        mn = min(x[0] for x in min_dates)
        mx = max(x[1] for x in min_dates)
        out["minute_range"] = f"{mn}~{mx}"
    out["total_mb"] = round(out["total_mb"], 1)
    return out


def _init_daily_schema(conn, kind="snapshot"):
    if kind == "snapshot":
        conn.execute("""
            CREATE TABLE IF NOT EXISTS market_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                price REAL NOT NULL,
                open_price REAL,
                high_price REAL,
                low_price REAL,
                volume REAL,
                amount REAL,
                chegyul REAL,
                rsi REAL,
                ema_fast REAL,
                ema_slow REAL,
                volume_ratio REAL,
                snapshot_time TEXT NOT NULL,
                source TEXT
            )
        """)
        # 기존 파일 마이그레이션: source 컬럼 없으면 추가 (과거 실시간 수집 데이터는 source=NULL)
        try:
            cols = [r["name"] for r in conn.execute("PRAGMA table_info(market_snapshots)")]
            if "source" not in cols:
                conn.execute("ALTER TABLE market_snapshots ADD COLUMN source TEXT")
        except Exception:
            pass
    else:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS market_indices (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                index_name TEXT NOT NULL,
                value REAL NOT NULL,
                change_pct REAL,
                snapshot_time TEXT NOT NULL
            )
        """)
    conn.commit()


def record_snapshot(symbol, price, volume=None, chegyul=None, rsi=None,
                    ema_fast=None, ema_slow=None, volume_ratio=None,
                    open_price=None, high_price=None, low_price=None, amount=None,
                    source="live", bar_date=None):
    """매 사이클마다 시세 스냅샷 저장 - ★ 날짜별 파일(data/snapshots_날짜.db)에 저장
    source: 'live'(장중 실시간 수집) | 'backfill'(네이버 과거 일봉 백필) | None(기존 데이터)
    bar_date: 'YYYY-MM-DD' — 백필 봉의 실제 날짜. 주면 그 날짜 파일에 그 날짜 시각으로 저장
              (차트 날짜/날짜검산 정확성 확보)
    """
    try:
        if bar_date:
            path = _snapshot_db_path(date.fromisoformat(bar_date))
            snap_time = f"{bar_date}T15:30:00+09:00"  # 봉 종가 기준 시각
        else:
            path = _snapshot_db_path()
            snap_time = now_kst_iso()
        conn = _daily_conn(path)
        _init_daily_schema(conn, "snapshot")
        try:
            conn.execute(
                "INSERT INTO market_snapshots "
                "(symbol, price, open_price, high_price, low_price, volume, amount, chegyul, rsi, "
                "ema_fast, ema_slow, volume_ratio, snapshot_time, source) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (symbol, price, open_price, high_price, low_price, volume, amount, chegyul, rsi,
                 ema_fast, ema_slow, volume_ratio, snap_time, source),
            )
        except Exception:
            # source 컬럼이 없는 (마이그레이션 전) 파일이면 예전 컬럼으로 저장
            conn.execute(
                "INSERT INTO market_snapshots "
                "(symbol, price, open_price, high_price, low_price, volume, amount, chegyul, rsi, "
                "ema_fast, ema_slow, volume_ratio, snapshot_time) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (symbol, price, open_price, high_price, low_price, volume, amount, chegyul, rsi,
                 ema_fast, ema_slow, volume_ratio, snap_time),
            )
        conn.commit()
        conn.close()
        return True
    except Exception:
        return False


def get_snapshots(symbol=None, hours=720, limit=100000, start_date=None, end_date=None):
    """최근 N시간/특정 기간 스냅샷 조회 - 날짜별 파일을 순회하며 수집
    (기본 720h = 30일, 과거 날짜 파일에서도 자동으로 읽음)
    """
    _ensure_data_dir()
    since = (now_kst() - timedelta(hours=hours)).isoformat()
    # 조회 대상 날짜 파일 목록
    sd = date.fromisoformat(since[:10]) if start_date is None else (
        start_date if isinstance(start_date, date) else date.fromisoformat(start_date))
    ed = now_kst().date() if end_date is None else (
        end_date if isinstance(end_date, date) else date.fromisoformat(end_date))
    d = ed
    target_dates = []
    while d >= sd:
        target_dates.append(d)
        d = d - timedelta(days=1)
        if len(target_dates) > 400:
            break

    all_rows = []
    for dd in target_dates:
        path = _snapshot_db_path(dd)
        if not _os.path.exists(path):
            continue
        try:
            conn = _daily_conn(path)
            if symbol:
                rows = conn.execute(
                    "SELECT * FROM market_snapshots WHERE symbol=? "
                    "AND snapshot_time>=? ORDER BY id DESC LIMIT ?",
                    (symbol, since, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM market_snapshots WHERE snapshot_time>=? "
                    "ORDER BY id DESC LIMIT ?",
                    (since, limit),
                ).fetchall()
            conn.close()
            all_rows.extend([dict(r) for r in rows])
        except Exception:
            continue
        if len(all_rows) >= limit:
            break
    all_rows.sort(key=lambda r: r["snapshot_time"])
    return all_rows[:limit]


def get_snapshot_summary(hours=720):
    """최근 N시간 스냅샷 통계: 종목별 샘플수/최신가/변화율 (기본 30일) - 날짜별 파일에서"""
    rows = get_snapshots(hours=hours, limit=100000)
    per = {}
    for r in rows:
        sym = r["symbol"]
        b = per.setdefault(sym, {"symbol": sym, "cnt": 0, "low": None, "high": None, "last_price": None})
        b["cnt"] += 1
        p = r["price"]
        b["low"] = p if b["low"] is None else min(b["low"], p)
        b["high"] = p if b["high"] is None else max(b["high"], p)
        b["last_price"] = p
    return sorted(per.values(), key=lambda x: x["symbol"])


def build_weekly_report(hours=720):
    """기간별 시세 아카이브 리포트 생성 (기본 720h = 30일) - 날짜별 파일에서
    반환: {"period": "...", "symbols": [...], "summary": {...}, "text": "..."}
    """
    from datetime import timedelta
    since_dt = now_kst() - timedelta(hours=hours)
    since = since_dt.isoformat()
    rows = get_snapshots(hours=hours, limit=100000)
    rows = [dict(r) for r in rows]

    if not rows:
        return {"period": f"최근 {hours}시간", "symbols": [], "summary": {"samples": 0},
                "text": f"📭 최근 {hours}시간 동안 쌓인 시세 스냅샷이 없습니다.\n"
                        "장중에 상시 실행(python main.py)을 켜두면 2분마다 자동 저장됩니다."}

    per_symbol = {}
    for r in rows:
        sym = r["symbol"]
        b = per_symbol.setdefault(sym, {"prices": [], "chegyuls": [], "volumes": [],
                                        "times": [], "rsis": []})
        if r["price"]:
            b["prices"].append(r["price"])
            b["times"].append(r["snapshot_time"])
        if r["chegyul"]:
            b["chegyuls"].append(r["chegyul"])
        if r["volume"]:
            b["volumes"].append(r["volume"])
        if r["rsi"]:
            b["rsis"].append(r["rsi"])

    symbols_out = []
    for sym, b in per_symbol.items():
        prices = b["prices"]
        if not prices:
            continue
        first, last = prices[0], prices[-1]
        change_pct = (last - first) / first * 100 if first else 0
        chegyul_avg = sum(b["chegyuls"]) / len(b["chegyuls"]) if b["chegyuls"] else 0
        chegyul_last = b["chegyuls"][-1] if b["chegyuls"] else 0
        vol_avg = sum(b["volumes"]) / len(b["volumes"]) if b["volumes"] else 0
        rsi_last = b["rsis"][-1] if b["rsis"] else None
        symbols_out.append({
            "symbol": sym,
            "samples": len(prices),
            "first": first, "last": last,
            "change_pct": round(change_pct, 2),
            "high": max(prices), "low": min(prices),
            "chegyul_avg": round(chegyul_avg, 1),
            "chegyul_last": round(chegyul_last, 1),
            "vol_avg": round(vol_avg),
            "rsi_last": round(rsi_last, 1) if rsi_last is not None else None,
            "start": b["times"][0][:16] if b["times"] else "",
            "end": b["times"][-1][:16] if b["times"] else "",
        })

    symbols_out.sort(key=lambda x: -x["change_pct"])

    lines = [f"📈 시세 아카이브 리포트 (최근 {hours}시간 = {round(hours/24,1)}일)",
             "=" * 50]
    if symbols_out:
        for s in symbols_out:
            arrow = "▲" if s["change_pct"] >= 0 else "▼"
            lines.append(f"\n[{s['symbol']}] {s['samples']}개 샘플 ({s['start']} ~ {s['end']})")
            lines.append(f"  가격: {s['first']:,.0f} → {s['last']:,.0f} ({arrow} {abs(s['change_pct']):.2f}%)")
            lines.append(f"  고가 {s['high']:,.0f} / 저가 {s['low']:,.0f}")
            lines.append(f"  체결강도: 평균 {s['chegyul_avg']:.0f} / 최신 {s['chegyul_last']:.0f}"
                         + (f" / RSI {s['rsi_last']}" if s["rsi_last"] is not None else ""))
    else:
        lines.append("종목별 데이터 없음")

    return {
        "period": f"최근 {hours}시간",
        "symbols": symbols_out,
        "summary": {"samples": len(rows), "symbol_count": len(symbols_out)},
        "text": "\n".join(lines),
    }


# ── 손익 분석 (PnL) ─────────────────────────

def get_daily_pnl_detail(target_date=None):
    """
    ★ 특정 날짜의 매수/매도 상세 (손익분석 일별 클릭용)
    반환: {"date":..., "trades":[{symbol,name,side,price,qty,kind,time,pnl,ret_pct}...],
           "summary":{...}}
    """
    if target_date is None:
        target_date = now_kst().strftime("%Y-%m-%d")
    with get_conn() as conn:
        trades = conn.execute(
            "SELECT * FROM trades WHERE date(executed_at)=? ORDER BY executed_at",
            (target_date,),
        ).fetchall()
        trades = [dict(r) for r in trades]
        # 청산 포지션 (그날 청산된 것)
        closed = conn.execute(
            "SELECT * FROM virtual_positions WHERE status='closed' AND date(exit_time)=?",
            (target_date,),
        ).fetchall()
        closed = [dict(r) for r in closed]
    out_trades = []
    for t in trades:
        out_trades.append({
            "time": t["executed_at"][11:19] if t["executed_at"] else "",
            "symbol": t["symbol"], "name": get_symbol_name(t["symbol"]),
            "side": t["side"], "price": t["price"], "qty": t["qty"],
            "kind": t["kind"],
            "amount": round(t["price"] * t["qty"]),
        })
    # 청산 결과 요약 (손익/수익률)
    closed_out = []
    wins = losses = 0
    total_pnl = 0.0
    for c in closed:
        try:
            ret = (c["exit_price"] - c["entry_price"]) / c["entry_price"] * 100
            pnl = (c["exit_price"] - c["entry_price"]) * c["qty"]
        except Exception:
            continue
        if ret > 0:
            wins += 1
        else:
            losses += 1
        total_pnl += pnl
        closed_out.append({
            "symbol": c["symbol"], "name": get_symbol_name(c["symbol"]),
            "entry": c["entry_price"], "exit": c["exit_price"], "qty": c["qty"],
            "ret_pct": round(ret, 2), "pnl": round(pnl),
            "kind": c.get("kind", "virtual"),
        })
    n = wins + losses
    return {
        "date": target_date,
        "trades": out_trades,
        "closed": closed_out,
        "summary": {
            "trades": len(out_trades), "closed": n,
            "wins": wins, "losses": losses,
            "win_rate": round(wins / n * 100, 1) if n else 0,
            "total_pnl": round(total_pnl),
        },
    }


def get_profit_factor(strategy_id=None, days=30):
    """
    ★ 손익비(Profit Factor) = 총이익 / 총손실
    PF ≥ 1 이어야 수익. 이게 자동매매 수익의 핵심 지표.
    """
    with get_conn() as conn:
        if strategy_id:
            rows = conn.execute(
                "SELECT entry_price, exit_price, qty FROM virtual_positions "
                "WHERE status='closed' AND strategy_id=?", (strategy_id,),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT entry_price, exit_price, qty FROM virtual_positions "
                "WHERE status='closed' AND date(exit_time)>=?",
                ((now_kst() - timedelta(days=days)).strftime("%Y-%m-%d"),),
            ).fetchall()
    gross_profit = gross_loss = 0.0
    n_wins = n_losses = 0
    for r in rows:
        try:
            pnl = (r["exit_price"] - r["entry_price"]) * r["qty"]
        except Exception:
            continue
        if pnl > 0:
            gross_profit += pnl
            n_wins += 1
        else:
            gross_loss += abs(pnl)
            n_losses += 1
    pf = gross_profit / gross_loss if gross_loss > 0 else (999.0 if gross_profit > 0 else 0)
    return {
        "profit_factor": round(pf, 2),
        "gross_profit": round(gross_profit),
        "gross_loss": round(gross_loss),
        "wins": n_wins, "losses": n_losses,
        "avg_win": round(gross_profit / n_wins, 0) if n_wins else 0,
        "avg_loss": round(gross_loss / n_losses, 0) if n_losses else 0,
        "expectancy": round((gross_profit - gross_loss) / max(1, n_wins + n_losses), 0),
    }


def analyze_pnl(strategy_id=None, days=7):
    """청산 포지션 기반 손익 분석
    반환: {summary, per_strategy, per_day, per_symbol}
    """
    from datetime import timedelta
    since = (date.today() - timedelta(days=days)).isoformat()
    with get_conn() as conn:
        if strategy_id:
            rows = conn.execute(
                "SELECT * FROM virtual_positions WHERE status='closed' AND strategy_id=?",
                (strategy_id,),
            ).fetchall()
        elif since:
            rows = conn.execute(
                "SELECT * FROM virtual_positions WHERE status='closed' AND date(exit_time)>=?",
                (since,),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM virtual_positions WHERE status='closed'"
            ).fetchall()
        rows = [dict(r) for r in rows]

    per_strategy, per_day, per_symbol = {}, {}, {}
    for r in rows:
        try:
            ret = (r["exit_price"] - r["entry_price"]) / r["entry_price"] * 100
            pnl = (r["exit_price"] - r["entry_price"]) * r["qty"]
        except Exception:
            continue
        sid = r["strategy_id"]
        d = (r["exit_time"] or "")[:10]
        sym = r["symbol"]
        for bucket, key in ((per_strategy, sid), (per_day, d), (per_symbol, sym)):
            b = bucket.setdefault(key, {"trades": 0, "wins": 0, "total_return": 0.0,
                                        "pnl": 0.0, "avg_return": 0.0, "returns": []})
            b["trades"] += 1
            b["returns"].append(ret)
            b["total_return"] += ret
            b["pnl"] += pnl
            if ret > 0:
                b["wins"] += 1
    for bucket in (per_strategy, per_day, per_symbol):
        for b in bucket.values():
            b["win_rate"] = b["wins"] / b["trades"] * 100 if b["trades"] else 0
            b["avg_return"] = b["total_return"] / b["trades"] if b["trades"] else 0

    total_trades = len(rows)
    total_wins = sum(1 for r in rows if r["exit_price"] > r["entry_price"])
    total_pnl = sum((r["exit_price"] - r["entry_price"]) * r["qty"] for r in rows if r["exit_price"])
    returns = []
    for r in rows:
        try:
            returns.append((r["exit_price"] - r["entry_price"]) / r["entry_price"] * 100)
        except Exception:
            continue
    avg_ret = sum(returns) / len(returns) if returns else 0
    win_rate = total_wins / total_trades * 100 if total_trades else 0

    # 종목명 추가 (per_symbol)
    per_symbol_named = {}
    for sym, b in per_symbol.items():
        per_symbol_named[f"{sym} {get_symbol_name(sym)}"] = b
    # 손익비 계산
    pf = get_profit_factor(strategy_id=strategy_id, days=days if days else 365)

    return {
        "summary": {
            "trades": total_trades, "wins": total_wins, "win_rate": round(win_rate, 2),
            "total_pnl": round(total_pnl), "avg_return": round(avg_ret, 2),
            "period_days": days, "profit_factor": pf["profit_factor"],
            "avg_win": pf["avg_win"], "avg_loss": pf["avg_loss"],
            "expectancy": pf["expectancy"],
        },
        "per_strategy": per_strategy,
        "per_day": per_day,
        "per_symbol": per_symbol_named,
    }


# ── 백테스트 결과 저장/조회 ─────────────────────

def save_backtest_result(params, symbol, period_days, trade_count, win_rate,
                         total_return, max_drawdown, avg_return, note=""):
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO backtest_results "
            "(run_at, params_json, symbol, period_days, trade_count, win_rate, "
            "total_return, max_drawdown, avg_return, note) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (now_kst_iso(), json.dumps(params), symbol, period_days,
             trade_count, win_rate, total_return, max_drawdown, avg_return, note),
        )
        return cur.lastrowid


def get_backtest_results(limit=30):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM backtest_results ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]


# ── 조건식 스크리너 결과 저장/조회 ─────────────

def save_screener_run(params: dict) -> int:
    """스크리너 실행 기록 1건 → run_id 반환"""
    import json as _json
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO screener_runs (created_at, params_json, note) VALUES (?, ?, ?)",
            (now_kst_iso(), _json.dumps(params, ensure_ascii=False), params.get("note", "")),
        )
        return cur.lastrowid


def save_screener_result(run_id, cond_key, cond_txt, slots, signal_count,
                         win_rate, avg_ret, total_return, pf, bench_diff,
                         oos_pass=None, oos_win_rate=None, oos_avg=None):
    try:
        import json as _json
        with get_conn() as conn:
            try:
                conn.execute(
                    "INSERT INTO screener_results "
                    "(run_id, cond_key, cond_txt, slots_json, signal_count, win_rate, "
                    "avg_ret, total_return, pf, bench_diff, oos_pass, oos_win_rate, oos_avg) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (run_id, cond_key, cond_txt, _json.dumps(slots, ensure_ascii=False),
                     signal_count, win_rate, avg_ret, total_return, pf, bench_diff,
                     1 if oos_pass else 0, oos_win_rate, oos_avg),
                )
            except Exception:
                conn.execute(
                    "INSERT INTO screener_results "
                    "(run_id, cond_key, cond_txt, slots_json, signal_count, win_rate, "
                    "avg_ret, total_return, pf, bench_diff) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (run_id, cond_key, cond_txt, _json.dumps(slots, ensure_ascii=False),
                     signal_count, win_rate, avg_ret, total_return, pf, bench_diff),
                )
    except Exception:
        pass


def get_screener_runs(limit=10):
    """최근 스크리너 실행 기록 (벤치마크 등 파라미터 포함)"""
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT * FROM screener_runs ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


def save_ai_screener_session(round_no, provider, directive, result, bench_avg):
    """AI 스크리너 라운드 기록"""
    import json as _json
    try:
        with get_conn() as conn:
            conn.execute(
                "INSERT INTO screener_ai_sessions "
                "(created_at, round_no, provider, directive_json, result_json, bench_avg, note) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (now_kst_iso(), round_no, provider,
                 _json.dumps(directive, ensure_ascii=False)[:500],
                 _json.dumps(result, ensure_ascii=False)[:1000],
                 bench_avg, (result.get("note") or "")[:200]),
            )
    except Exception:
        pass


def get_screener_results(limit=30, min_signals=30, top_only=True):
    """최근 스크리너 결과 (신호 30+ 승률 높은 순) - 진화/UI용"""
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT * FROM screener_results WHERE signal_count >= ? "
                "ORDER BY id DESC LIMIT ?", (min_signals, max(100, limit * 5)),
            ).fetchall()
        rows = [dict(r) for r in rows]
        rows.sort(key=lambda r: -(r["win_rate"] or 0) * max(min(r["avg_ret"] or 0, 0.1), -0.2)
                  * min(1, (r["signal_count"] or 0) / 100))
        return rows[:limit]
    except Exception:
        return []


# ── 상위 조건식 모의 실전 테스트 (paper_positions) ─────────

def open_paper_position(cond_key, cond_txt, symbol, entry_price, qty, entry_index_pct=None,
                        target_price=None, stop_price=None, sell_plan=None, plan_provider="rule",
                        order_kind="virtual"):
    """모의 포지션 진입.
    entry_index_pct: 진입 시점 지수(코스피) 등락률 - 국면 점수제용
    target_price/stop_price/sell_plan: ★ 매수 시점 평가로 만든 매도 지침 (목표가/손절가/지침 문구)
    order_kind: 'real'=키움 모의계좌 실제 주문 체결 / 'virtual'=기록만 (2026-08-27 구분 추가)
    """
    try:
        with get_conn() as conn:
            cur = conn.execute(
                "INSERT INTO paper_positions (cond_key, cond_txt, symbol, entry_price, "
                "entry_time, qty, highest_return, entry_index_pct, "
                "target_price, stop_price, sell_plan, plan_provider, order_kind) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (cond_key, cond_txt, symbol, entry_price, now_kst_iso(), qty, 0.0,
                 entry_index_pct, target_price, stop_price, sell_plan, plan_provider,
                 order_kind if order_kind in ("real", "virtual") else "virtual"),
            )
            return cur.lastrowid   # ★ 2026-09-01: 포지션 id 반환 (추적/테스트용)
    except Exception:
        return None


def update_paper_highest(pos_id, highest_return):
    """보유 중 최고 수익률(%) 갱신 - AI 매도 판단(트레일링 스탑)용"""
    try:
        with get_conn() as conn:
            conn.execute(
                "UPDATE paper_positions SET highest_return=? WHERE id=?",
                (highest_return, pos_id))
    except Exception:
        pass


def update_paper_lowest(pos_id, lowest_return):
    """보유 중 최저 수익률(%) 갱신 - 매수후 최저가/최저수익률 추적 (AI 매도 판단용)"""
    try:
        with get_conn() as conn:
            conn.execute(
                "UPDATE paper_positions SET lowest_return=? WHERE id=?",
                (lowest_return, pos_id))
    except Exception:
        pass


def close_paper_position(pos_id, exit_price, ret_pct, exit_index_pct=None, reason=None):
    """모의 포지션 청산.
    exit_index_pct: 청산 시점 지수(코스피) 등락률 - 국면 점수제용
    reason: 청산 사유 ([AI매도]/[하드손절]/[매도지침] 등 - 주간 리포트 AIvs규칙 비교용)
    """
    try:
        with get_conn() as conn:
            conn.execute(
                "UPDATE paper_positions SET status='closed', exit_price=?, exit_time=?, "
                "ret_pct=?, exit_index_pct=?, exit_reason=? WHERE id=?",
                (exit_price, now_kst_iso(), ret_pct, exit_index_pct, reason, pos_id),
            )
    except Exception:
        pass


def get_paper_open():
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT * FROM paper_positions WHERE status='open' ORDER BY id DESC").fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


def get_paper_closed(limit=50):
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT * FROM paper_positions WHERE status='closed' "
                "ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


def count_paper_open():
    try:
        with get_conn() as conn:
            r = conn.execute("SELECT COUNT(*) c FROM paper_positions WHERE status='open'").fetchone()
            return r["c"] if r else 0
    except Exception:
        return 0


def paper_has_open(symbol, cond_key=None):
    try:
        with get_conn() as conn:
            if cond_key:
                r = conn.execute(
                    "SELECT COUNT(*) c FROM paper_positions "
                    "WHERE status='open' AND symbol=? AND cond_key=?",
                    (symbol, cond_key)).fetchone()
            else:
                r = conn.execute(
                    "SELECT COUNT(*) c FROM paper_positions WHERE status='open' AND symbol=?",
                    (symbol,)).fetchone()
            return (r["c"] if r else 0) > 0
    except Exception:
        return False


# ── 명예의 전당 (Hall of Fame) ───────────────────────
# ★ 검증 통과(OOS) 조건식의 영구 명예의 전당. 매 라운드 재검증해 갱신되고,
#   실패가 쌓이면 자동 퇴출(폐기)됩니다. "계속 올라가고, 싹수없는 건 없어진다."

def normalize_slots(slots):
    """★ 조건식 정규화 시그니처 — 중복 판정의 핵심
    - 슬롯 (키, 파라미터) 쌍을 정렬 → 순서만 바뀐 조건식은 동일 취급
    - 파라미터 양자화: x(배수)는 0.5 단위, n(기간)은 5 단위로 반올림
      → 미세 수치만 다른 조건식(예: vol 1.5 vs 1.6, MA 20 vs 21)도 동일 취급
    반환: 시그니처 문자열 (같으면 '같은 조건식')
    """
    norm = []
    for k, p in (slots or []):
        q = {}
        for pk, pv in sorted((p or {}).items()):
            if isinstance(pv, (int, float)) and not isinstance(pv, bool):
                if pk == "x":
                    q[pk] = round(float(pv) * 2) / 2          # 0.5 단위
                elif pk == "n":
                    q[pk] = max(1, int(round(float(pv) / 5)) * 5)  # 5 단위
                else:
                    q[pk] = round(float(pv), 1)
            else:
                q[pk] = pv
        norm.append((str(k), tuple(sorted(q.items()))))
    norm.sort()
    return json.dumps(norm, ensure_ascii=False)


def _ensure_hof_columns():
    """hall_of_fame 컬럼 확장 (signature/score/ranked) - 구버전 DB 호환"""
    try:
        with get_conn() as conn:
            cols = [r["name"] for r in conn.execute("PRAGMA table_info(hall_of_fame)")]
            if "signature" not in cols:
                conn.execute("ALTER TABLE hall_of_fame ADD COLUMN signature TEXT")
            if "score" not in cols:
                conn.execute("ALTER TABLE hall_of_fame ADD COLUMN score REAL DEFAULT 0")
            if "ranked" not in cols:
                conn.execute("ALTER TABLE hall_of_fame ADD COLUMN ranked INTEGER DEFAULT 0")
    except Exception:
        pass


def hof_score(win_rate, pf, sells):
    """명예의 전당 순위 점수 = 승률 × 손익비(최대 3 캡) × 표본가중치
    - 최소 3건 이상 + 승률 50% 이상부터 점수 부여 (기존 입성 기준 유지)
    - 표본가중치 sells/(sells+20): 3건→0.13, 30건→0.6, 100건→0.83
      → 건수 적으면 아무리 좋아도 상위에 못 올라감 (샘플 부족 방지)
    """
    try:
        if sells < 3 or win_rate < 50:
            return 0.0
        return float(win_rate) * min(max(float(pf), 0.0), 3.0) * (sells / (sells + 20))
    except Exception:
        return 0.0


def hof_rank(limit=50):
    """★ 명예의 전당 순위 관리 — 상위 N개만 ranked=1(활성), 나머지는 ranked=0
    - ★ 삭제 없음: 전부 hall_of_fame에 계속 누적 (나중에 재진입/활용 가능)
    - ★ 중복 방지: 같은 정규화 시그니처(순서만 다름/미세 수치만 다름)는
      그룹에서 점수 최고 1개만 ranked, 나머지는 ranked=0 → 상위 도배 방지
    반환: {"ranked": 상위 수, "total": 전체 누적, "deduped": 중복으로 제외된 수}
    """
    _ensure_hof_columns()
    try:
        stats = paper_stats_per_condition()
    except Exception:
        stats = {}
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM hall_of_fame").fetchall()
        scored = []
        for r in rows:
            r = dict(r)
            sig = r.get("signature")
            if not sig:
                try:
                    sig = normalize_slots(json.loads(r.get("slots_json") or "[]"))
                except Exception:
                    sig = r["cond_key"]
            st = stats.get(r["cond_key"], {})
            sells = st.get("sells", 0)
            wr = st.get("win_rate", 0)
            pf = (st.get("profit") or 0) / max(1, (st.get("loss") or 0) or 1)
            score = hof_score(wr, pf, sells)
            try:
                conn.execute(
                    "UPDATE hall_of_fame SET signature=?, score=? WHERE cond_key=?",
                    (sig, score, r["cond_key"]))
            except Exception:
                pass
            scored.append((r["cond_key"], sig, score, sells))
        # 점수 DESC → 표본 수 DESC → cond_key ASC (동률이어도 순위가 매번 안 바뀌도록 안정 정렬)
        scored.sort(key=lambda x: (-x[2], -x[3], x[0]))
        ranked_keys, seen_sig, deduped = [], set(), 0
        for key, sig, score, _sells in scored:
            if score <= 0:
                continue
            if sig in seen_sig:
                deduped += 1
                continue
            if len(ranked_keys) >= limit:
                break
            seen_sig.add(sig)
            ranked_keys.append(key)
        for key, _sig, _sc, _sl in scored:
            try:
                conn.execute(
                    "UPDATE hall_of_fame SET ranked=? WHERE cond_key=?",
                    (1 if key in ranked_keys else 0, key))
            except Exception:
                pass
    return {"ranked": len(ranked_keys), "total": len(scored), "deduped": deduped}


def hof_upsert(cond_key, cond_txt, slots, win_rate, pf, oos_win=None, oos_avg=None, passed=True):
    """명예의 전당 등록/갱신 (cond_key 기준)
    passed=True면 pass_count++, False면 fail_count++ (연속 실패 시 퇴출 판단용)
    """
    import json as _json
    now = now_kst_iso()
    try:
        sig = normalize_slots(slots)
    except Exception:
        sig = cond_key
    try:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT * FROM hall_of_fame WHERE cond_key=?", (cond_key,)).fetchone()
            if row:
                row = dict(row)
                conn.execute(
                    "UPDATE hall_of_fame SET cond_txt=?, slots_json=?, last_updated=?, "
                    "best_win_rate=MAX(best_win_rate, ?), best_pf=MAX(best_pf, ?), "
                    "best_oos_win=MAX(best_oos_win, COALESCE(?, 0)), "
                    "best_oos_avg=MAX(best_oos_avg, COALESCE(?, 0)), "
                    "sample_count=sample_count+1, signature=?, "
                    "pass_count=pass_count+?, fail_count=fail_count+? "
                    "WHERE cond_key=?",
                    (cond_txt, _json.dumps(slots, ensure_ascii=False), now,
                     win_rate, pf, oos_win, oos_avg, sig,
                     1 if passed else 0, 0 if passed else 1, cond_key))
            else:
                conn.execute(
                    "INSERT INTO hall_of_fame (cond_key, cond_txt, slots_json, first_entered, "
                    "last_updated, best_win_rate, best_pf, best_oos_win, best_oos_avg, "
                    "sample_count, pass_count, fail_count, signature) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)",
                    (cond_key, cond_txt, _json.dumps(slots, ensure_ascii=False), now, now,
                     win_rate, pf, oos_win, oos_avg,
                     1 if passed else 0, 0 if passed else 1, sig))
    except Exception:
        pass


def hof_list(limit=50, ranked_only=True):
    """명예의 전당 목록 (순위 점수순)
    ranked_only=True : 상위 랭킹만 (기본 - 모의실전/UI 사용)
    ranked_only=False: 전체 누적 이력 (활용·분석용 - 삭제된 것 없음)
    """
    try:
        _ensure_hof_columns()
        with get_conn() as conn:
            if ranked_only:
                rows = conn.execute(
                    "SELECT * FROM hall_of_fame WHERE status='active' AND ranked=1 "
                    "ORDER BY score DESC LIMIT ?", (limit,)).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM hall_of_fame WHERE status='active' "
                    "ORDER BY score DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


def hof_retire_bad(min_pass=2, fail_ratio=0.6):
    """★ 싹수없는 조건식 자동 퇴출: 2회 이상 테스트됐고 실패 비율 60% 이상이면 폐기
    반환: 퇴출된 cond_key 리스트
    """
    import json as _json
    retired = []
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT * FROM hall_of_fame WHERE status='active' AND sample_count >= ?",
                (min_pass,)).fetchall()
            for r in rows:
                r = dict(r)
                total = r["pass_count"] + r["fail_count"]
                if total <= 0:
                    continue
                if r["fail_count"] / total >= fail_ratio:
                    conn.execute("UPDATE hall_of_fame SET status='retired' WHERE cond_key=?",
                                 (r["cond_key"],))
                    try:
                        conn.execute(
                            "INSERT OR REPLACE INTO retired_conditions "
                            "(cond_key, cond_txt, slots_json, retired_at, last_win_rate, last_pf, reason) "
                            "VALUES (?, ?, ?, ?, ?, ?, ?)",
                            (r["cond_key"], r["cond_txt"], r["slots_json"], now_kst_iso(),
                             r["best_win_rate"], r["best_pf"], f"실패율 {r['fail_count']/total*100:.0f}%"))
                    except Exception:
                        pass
                    retired.append(r["cond_key"])
    except Exception:
        pass
    return retired


def retired_list(limit=50):
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT * FROM retired_conditions ORDER BY retired_at DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


# ── 조건식 등록부 (원형/변형 - 모의 매매 성적표) ───────────────

def create_condition(cond_no, cond_txt, slots, source="photo", parent_no=None, tf="day"):
    """조건식 등록 (cond_no 중복 시 무시). 반환: id
    tf: 봉 기준 (day|week|month|min1|min3|min15) - 사진 조건식의 [일]/[주]/[월]/[3분] 등
    """
    import json as _json
    try:
        with get_conn() as conn:
            exists = conn.execute("SELECT id FROM conditions WHERE cond_no=?", (cond_no,)).fetchone()
            if exists:
                return exists["id"]
            cur = conn.execute(
                "INSERT INTO conditions (cond_no, parent_no, cond_txt, slots_json, source, created_at, tf) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (cond_no, parent_no, cond_txt, _json.dumps(slots, ensure_ascii=False),
                 source, now_kst_iso(), tf))
            return cur.lastrowid
    except Exception:
        return None


def get_conditions(status="active"):
    """조건식 목록 (cond_no 오름차순)"""
    try:
        with get_conn() as conn:
            if status:
                rows = conn.execute(
                    "SELECT * FROM conditions WHERE status=? ORDER BY cond_no", (status,)).fetchall()
            else:
                rows = conn.execute("SELECT * FROM conditions ORDER BY cond_no").fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


def get_condition_by_id(cid):
    try:
        with get_conn() as conn:
            r = conn.execute("SELECT * FROM conditions WHERE id=?", (cid,)).fetchone()
            return dict(r) if r else None
    except Exception:
        return None


def next_cond_no(parent_no=None):
    """다음 조건식 번호: 원형 "N" / 변형 "N-M" / "N-M-K"...
    예) 기존 1,2,3 → 새 원형 "4" · 1의 자식이 1-1,1-2 → 다음 "1-3" · 1-1의 자식 → "1-1-1"
    """
    try:
        with get_conn() as conn:
            if parent_no:
                prefix = parent_no + "-"
                rows = conn.execute(
                    "SELECT cond_no FROM conditions WHERE cond_no LIKE ?", (prefix + "%",)).fetchall()
                kids = [r["cond_no"] for r in rows]
                max_k = 0
                for k in kids:
                    try:
                        max_k = max(max_k, int(k.rsplit("-", 1)[1]))
                    except Exception:
                        pass
                return f"{parent_no}-{max_k + 1}"
            else:
                rows = conn.execute("SELECT cond_no FROM conditions").fetchall()
                nums = []
                for r in rows:
                    try:
                        nums.append(int(r["cond_no"]))
                    except Exception:
                        pass
                return str(max(nums) + 1 if nums else 1)
    except Exception:
        return None


def set_condition_status(cid, status):
    try:
        with get_conn() as conn:
            conn.execute("UPDATE conditions SET status=? WHERE id=?", (status, cid))
    except Exception:
        pass


def touch_condition_tested(cid):
    try:
        with get_conn() as conn:
            conn.execute(
                "UPDATE conditions SET rounds_tested=rounds_tested+1, last_tested_at=? WHERE id=?",
                (now_kst_iso(), cid))
    except Exception:
        pass


def paper_stats_per_condition():
    """★ 조건식별 모의 매매 성적표
    반환: {cond_key: {buys, sells, profit, loss, net, win_rate, open, symbols:[...]}}
    cond_key = conditions.id (str)
    """
    import json as _json
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT * FROM paper_positions ORDER BY id").fetchall()
    except Exception:
        return {}
    per = {}
    for r in rows:
        ck = str(r["cond_key"])
        st = per.setdefault(ck, {"buys": 0, "sells": 0, "profit": 0.0, "loss": 0.0,
                                 "net": 0.0, "wins": 0, "losses": 0, "open": 0,
                                 "symbols": [], "rets": []})
        st["buys"] += 1
        if r["symbol"] not in st["symbols"]:
            st["symbols"].append(r["symbol"])
        if r["status"] == "open":
            st["open"] += 1
            continue
        ret = r["ret_pct"] or 0
        pnl = (ret / 100.0) * (r["entry_price"] or 0) * (r["qty"] or 0)
        st["sells"] += 1
        st["rets"].append(ret)
        st["net"] += pnl
        if ret > 0:
            st["profit"] += pnl
            st["wins"] += 1
        else:
            st["loss"] += abs(pnl)
            st["losses"] += 1
    for st in per.values():
        closed = st["wins"] + st["losses"]
        st["win_rate"] = round(st["wins"] / closed * 100, 1) if closed else 0.0
        st["net"] = round(st["net"])
        st["profit"] = round(st["profit"])
        st["loss"] = round(st["loss"])
    return per


def index_condition_stats(min_sells=1):
    """★ 조건식 × 지수 국면 성적 집계 (국면 점수제의 데이터)
    국면 = 진입 시점 지수(코스피) 등락률 기준:
      crash(≤-2%) / weak(-2~-1%) / normal(-1~+1%) / strong(≥+1%)
    반환: {cond_key: {"crash"/"weak"/"normal"/"strong": {sells, win_rate, avg_ret, pf},
                       "down": 하락(crash+weak) 합산, ...}}
    """
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT cond_key, entry_index_pct, ret_pct FROM paper_positions "
                "WHERE status='closed' AND entry_index_pct IS NOT NULL "
                "AND ret_pct IS NOT NULL").fetchall()
    except Exception:
        return {}
    def _regime(p):
        if p <= -2.0:
            return "crash"
        if p <= -1.0:
            return "weak"
        if p >= 1.0:
            return "strong"
        return "normal"
    per = {}
    for r in rows:
        ck = str(r["cond_key"])
        rg = _regime(r["entry_index_pct"])
        per.setdefault(ck, {}).setdefault(rg, []).append(r["ret_pct"] or 0)
    out = {}
    for ck, regimes in per.items():
        c_out, down_rets = {}, []
        for rg in ("crash", "weak", "normal", "strong"):
            rets = regimes.get(rg, [])
            if not rets:
                c_out[rg] = {"sells": 0, "win_rate": 0, "avg_ret": 0, "pf": 0}
                continue
            wins = [x for x in rets if x > 0]
            gp = sum(wins)
            gl = abs(sum(x for x in rets if x <= 0))
            c_out[rg] = {"sells": len(rets), "win_rate": round(len(wins) / len(rets) * 100, 1),
                         "avg_ret": round(sum(rets) / len(rets), 2),
                         "pf": round(gp / gl, 2) if gl else (999.0 if gp else 0)}
            if rg in ("crash", "weak"):
                down_rets += rets
        c_out["down"] = {
            "sells": len(down_rets),
            "win_rate": round(len([x for x in down_rets if x > 0]) / len(down_rets) * 100, 1)
                        if down_rets else 0,
            "avg_ret": round(sum(down_rets) / len(down_rets), 2) if down_rets else 0}
        out[ck] = c_out
    return out


def regime_rule_score(cond_stats, min_sells=None):
    """조건식의 하락장 국면 점수 (규칙 기반) - 표본 부족이면 None(미평가 → 제한 없음)
    점수 범위: -50 ~ +70 (높을수록 하락장에서도 잘 버는 조건식)
    기준: 하락(crash+weak) 국면 승률·평균수익
    """
    if min_sells is None:
        try:
            min_sells = int(getattr(_CFG, "INDEX_COND_MIN_SELLS", 5))
        except Exception:
            min_sells = 5
    down = (cond_stats or {}).get("down") or {}
    sells = down.get("sells", 0)
    if sells < min_sells:
        return None  # ★ 데이터 부족 - 미평가 (진입 제한 없음)
    wr = down.get("win_rate", 0)
    ar = down.get("avg_ret", 0)
    score = 0
    if wr >= 55:
        score += 50
    elif wr >= 45:
        score += 25
    else:
        score -= 30
    if ar >= 1.0:
        score += 20
    elif ar <= -1.0:
        score -= 20
    return score


def condition_ledger(cid):
    """조건식의 매수 종목 내역 (종목별 진입/청산/수익률) - UI 클릭 시"""
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT * FROM paper_positions WHERE cond_key=? ORDER BY id DESC",
                (str(cid),)).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


# ── 종목명 (코드 → 이름) ─────────────────────────

# 기본 종목명 (API 호출 전에도 표시 가능하도록 대표 종목들)
DEFAULT_STOCK_NAMES = {
    "005930": "삼성전자", "000660": "SK하이닉스", "035420": "NAVER",
    "005380": "현대차", "051910": "LG화학", "006400": "삼성SDI",
    "035720": "카카오", "000270": "기아", "068270": "셀트리온",
    "207940": "삼성바이오로직스", "028260": "삼성물산", "012330": "현대모비스",
    "066570": "LG전자", "105560": "KB금융", "055550": "신한지주",
    "034730": "SK", "003550": "LG", "033780": "KT&G", "086790": "하나금융지주",
    "015760": "한국전력", "005490": "POSCO홀딩스", "017670": "SK텔레콤",
    "096770": "SK이노베이션", "009540": "HD한국조선해양", "011200": "HMM",
    "000030": "우리은행", "032830": "삼성생명", "030200": "KT",
    "036570": "엔씨소프트", "042700": "한미반도체", "247540": "에코프로비엠",
    "086520": "에코프로", "352820": "하이브", "010130": "고려아연",
    "034220": "LG디스플레이", "011070": "LG이노텍", "028050": "삼성엔지니어링",
}


def save_symbol_name(symbol: str, name: str):
    """API에서 받은 종목명을 DB에 저장 (재호출 없이 사용)"""
    if not symbol or not name or name == symbol:
        return
    try:
        with get_conn() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO stock_names (symbol, name) VALUES (?, ?)",
                (symbol, name),
            )
    except Exception:
        pass


def get_symbol_name(symbol: str) -> str:
    """종목 코드 → 이름. DB → 기본맵 순서로 조회, 없으면 코드 그대로"""
    try:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT name FROM stock_names WHERE symbol=?", (symbol,)
            ).fetchone()
            if row:
                return row["name"]
    except Exception:
        pass
    return DEFAULT_STOCK_NAMES.get(symbol, symbol)


def paper_kind_label(cond_key: str, cond_txt: str = "") -> str:
    """★ 거래 기록 유형 구분 (실제 매매 vs 검증이 화면에서 섞이지 않게)
    - MANUAL           → 수동매수 (사용자가 손으로 산 종목 - AI 매도 관리 대상)
    - 📅예약           → 검증예약 (엄밀 검증 통과 → 다음날 예약된 매수)
    - 🏆/✅검증통과    → 검증통과 (엄밀 검증 채택 조건식의 매수)
    - 그 외            → 신호     (운영 조건식 신호 매수)
    """
    try:
        ck = (cond_key or "").strip().upper()
        if ck == "MANUAL":
            return "수동매수"
        txt = cond_txt or ""
        if "📅예약" in txt:
            return "검증예약"
        if "🏆검증통과" in txt or "✅검증통과" in txt:
            return "검증통과"
        if "🏆" in txt or "✅" in txt:
            return "검증통과"
        return "신호"
    except Exception:
        return "신호"


def get_market_status() -> dict:
    """시세 수신 상태 요약 (대시보드용) - 날짜별 파일 기준
    반환: {last_fetch, snapshot_count, symbols, source}
    """
    try:
        _ensure_data_dir()
        last_fetch = None
        count = 0
        syms = set()
        # 오늘 파일 우선, 없으면 최근 파일들
        today_path = _snapshot_db_path()
        files = [today_path] if _os.path.exists(today_path) else []
        if not files:
            snap_files = sorted(f for f in _os.listdir(DATA_DIR) if f.startswith("snapshots_"))
            files = [_os.path.join(DATA_DIR, f) for f in snap_files[-3:]]
        for path in files:
            try:
                c = _daily_conn(path)
                r = c.execute("SELECT MAX(snapshot_time) t, COUNT(*) c FROM market_snapshots").fetchone()
                last_fetch = r["t"] if r and r["t"] else last_fetch
                count += r["c"] if r else 0
                for srow in c.execute("SELECT DISTINCT symbol FROM market_snapshots"):
                    syms.add(srow["symbol"])
                c.close()
            except Exception:
                continue
        return {
            "last_fetch": last_fetch,
            "snapshot_count": count,
            "symbols": list(syms),
            "source": "실시간 수신 중" if count > 0 else "미수신 (사이클 실행 필요)",
        }
    except Exception as e:
        return {"last_fetch": None, "snapshot_count": 0, "symbols": [],
                "source": f"오류: {e}"}


# ── 판단 기록 (매수/매도 결정 로그 - 대시보드 메인 표시용) ────

def record_judgment(symbol, kind, decision, engine, score=None, reason="", profile=None):
    """매수/매도 판단 결과 저장
    profile: 매수 시점 지표 스냅샷 dict (학습용) - {체결강도, RSI, 1분대금, 3분대금, 등락률, 점수, ...}
    """
    import json as _json
    try:
        with get_conn() as conn:
            # 구버전 DB(profile 컬럼 없음) 대응
            try:
                conn.execute(
                    "INSERT INTO judgments (judged_at, symbol, kind, decision, engine, score, reason, profile) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (now_kst_iso(), symbol, kind, decision, engine,
                     score, (reason or "")[:400],
                     _json.dumps(profile, ensure_ascii=False)[:600] if profile else None),
                )
            except Exception:
                conn.execute(
                    "INSERT INTO judgments (judged_at, symbol, kind, decision, engine, score, reason) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (now_kst_iso(), symbol, kind, decision, engine,
                     score, (reason or "")[:400]),
                )
    except Exception:
        pass


def get_recent_judgments(kind=None, limit=12):
    """최근 판단 기록 조회"""
    try:
        with get_conn() as conn:
            if kind:
                rows = conn.execute(
                    "SELECT * FROM judgments WHERE kind=? ORDER BY id DESC LIMIT ?",
                    (kind, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM judgments ORDER BY id DESC LIMIT ?", (limit,)
                ).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


def get_buy_history_for_ai(limit=30):
    """★ AI 피드백용: 매수한 종목의 판단 당시 상세 (이유/엔진/점수) + 그 후 결과"""
    try:
        with get_conn() as conn:
            buys = conn.execute(
                "SELECT * FROM judgments WHERE kind='buy' AND decision='매수' "
                "ORDER BY id DESC LIMIT ?", (limit,),
            ).fetchall()
            buys = [dict(b) for b in buys]
            out = []
            for b in buys:
                sym = b["symbol"]
                # 그 종목의 이후 포지션 결과 (청산 여부/수익) - 같은 커넥션 내에서 조회
                pos = None
                pr = conn.execute(
                    "SELECT * FROM virtual_positions WHERE symbol=? AND status='closed' "
                    "ORDER BY id DESC LIMIT 1", (sym,),
                ).fetchone()
                if pr:
                    try:
                        ret = (pr["exit_price"] - pr["entry_price"]) / pr["entry_price"] * 100
                    except Exception:
                        ret = None
                    pos = {"entry": pr["entry_price"], "exit": pr["exit_price"],
                           "ret_pct": round(ret, 2) if ret is not None else None,
                           "exit_time": pr["exit_time"]}
                out.append({"judged_at": b["judged_at"], "symbol": sym,
                            "name": get_symbol_name(sym), "engine": b["engine"],
                            "score": b["score"], "reason": b["reason"], "result": pos})
            return out
    except Exception:
        return []


def save_universe(symbol, name, market):
    """전체 종목 목록에 저장 (코드+이름+시장)"""
    try:
        with get_conn() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO universe (symbol, name, market, updated_at) "
                "VALUES (?, ?, ?, ?)",
                (symbol, name, market, now_kst_iso()),
            )
    except Exception as e:
        # 조용히 무시하지 않고 로그 (전체 종목 저장 실패 감지용)
        import logging
        logging.getLogger("db").warning(f"save_universe 실패 {symbol}: {e}")


def log_gate_reject(cond_key, symbol, price, reason):
    """★ AI 매수 게이트 거부 기록 (2026-08-28 그림자 추적)
    'AI가 안 샀던 그 시점'을 저장 → 나중에 그냥 샀으면 어땠는지 전방 성적 비교
    → AI 게이트가 수익에 기여하는지 데이터로 판정하는 근거"""
    try:
        with get_conn() as conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS gate_shadow (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                at TEXT NOT NULL, cond_key TEXT, symbol TEXT NOT NULL,
                price REAL, reason TEXT)""")
            conn.execute("INSERT INTO gate_shadow (at, cond_key, symbol, price, reason) "
                         "VALUES (?,?,?,?,?)",
                         (now_kst_iso(), str(cond_key), symbol, price, (reason or "")[:80]))
    except Exception:
        pass


_AUTO_PARAMS_CACHE = {"t": 0.0, "data": None}


def auto_param(key, default):
    """★ 자동 튜닝 파라미터 조회 (2026-08-28 사용자: '.env에 무조건 기록되는 건 아닌지')
    우선순위: strategy/auto_params.json (시스템 자동) > .env (사용자 수동) > 기본값
    - 시스템이 찾은 최적값은 auto_params.json에만 기록 - 사용자의 .env는 건드리지 않음
    - AUTO_OPT_APPLY=false면 자동값 무시 (.env/기본값만 사용)
    """
    import time as _t
    import os as _os
    if _os.getenv("AUTO_OPT_APPLY", "true").lower() == "true":
        try:
            now = _t.time()
            if _AUTO_PARAMS_CACHE["data"] is None or now - _AUTO_PARAMS_CACHE["t"] > 60:
                import json as _j
                _AUTO_PARAMS_CACHE["data"] = _j.load(
                    open(_os.path.join("strategy", "auto_params.json"), encoding="utf-8"))
                _AUTO_PARAMS_CACHE["t"] = now
            v = (_AUTO_PARAMS_CACHE["data"] or {}).get(key)
            if v is not None:
                return str(v)
        except Exception:
            pass
    return _os.getenv(key, str(default))


def name_map():
    """★ 공용 종목명 맵 {symbol: name} (2026-08-28 중복 제거)
    14개 파일에 복붙돼 있던 'for u in get_universe(): names[...]=...' 패턴의 원형.
    새 코드는 이걸 쓰세요: names = db.name_map()
    """
    try:
        return {u.get("symbol"): (u.get("name") or "") for u in get_universe()}
    except Exception:
        return {}


def get_universe(market=None):
    """전체 종목 목록 (코드+이름+시장)"""
    with get_conn() as conn:
        if market:
            rows = conn.execute(
                "SELECT symbol, name, market FROM universe WHERE market=? ORDER BY symbol", (market,)
            ).fetchall()
        else:
            rows = conn.execute("SELECT symbol, name, market FROM universe ORDER BY symbol").fetchall()
    return [dict(r) for r in rows]


def count_universe() -> int:
    try:
        with get_conn() as conn:
            return conn.execute("SELECT COUNT(*) c FROM universe").fetchone()["c"]
    except Exception:
        return 0


def get_scan_pointer() -> int:
    try:
        with get_conn() as conn:
            row = conn.execute("SELECT pointer FROM scan_state WHERE id=1").fetchone()
            return row["pointer"] if row else 0
    except Exception:
        return 0


def set_scan_pointer(pointer: int):
    try:
        with get_conn() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO scan_state (id, pointer, updated_at) VALUES (1, ?, ?)",
                (pointer, now_kst_iso()),
            )
    except Exception:
        pass


# ── 데이터 파일 관리 (날짜별 파일은 자산 - 삭제 안 함) ──

def get_data_files_info():
    """날짜별 데이터 파일 현황 (용량/개수 - UI 표시용)"""
    _ensure_data_dir()
    files = []
    total = 0
    for f in sorted(_os.listdir(DATA_DIR)):
        if f.startswith("snapshots_") or f.startswith("indices_"):
            p = _os.path.join(DATA_DIR, f)
            size = _os.path.getsize(p)
            total += size
            files.append({"name": f, "size": size})
    return {"files": files, "count": len(files), "total_bytes": total}


def migrate_daily_files():
    """모든 날짜별 스냅샷 파일에 source 컬럼 추가 (구버전 데이터 마이그레이션)
    - 구버전(실시간 수집) 행은 source=NULL → 백필 대상으로 인정되지 않음
    - 백필이 다시 돌면 그 종목들을 source='backfill' 로 채워 넣습니다
    """
    if not _os.path.isdir(DATA_DIR):
        return 0
    n = 0
    for f in _os.listdir(DATA_DIR):
        if not f.startswith("snapshots_"):
            continue
        path = _os.path.join(DATA_DIR, f)
        try:
            conn = _daily_conn(path)
            cols = [r["name"] for r in conn.execute("PRAGMA table_info(market_snapshots)")]
            if "source" not in cols:
                conn.execute("ALTER TABLE market_snapshots ADD COLUMN source TEXT")
                conn.commit()
                n += 1
            conn.close()
        except Exception:
            continue
    return n


def backfill_coverage(min_days=30, max_scan_files=40):
    """★ 백필(네이버 과거 일봉) 커버리지 - 종목별 일봉 수 집계
    ★ 종목별 저장(STOCK_DIR_SAVE=true)이면 data/stocks/*.db 의 daily_bars 행 수를 셉니다.
    (날짜별 저장이면 source='backfill' 인 행만 집계)
    반환: {"symbols": {sym: 일봉수}, "ready": min_days 이상 종목 수,
           "total": 전체 종목 수(universe), "min_days": min_days}
    """
    _ensure_data_dir()
    per = {}
    # ★ 종목별 저장 우선 (전 종목 스캔의 핵심 - 이게 없으면 빈 목록으로 돌았던 버그)
    if STOCK_DIR_SAVE:
        sd = _os.path.join(DATA_DIR, "stocks")
        if _os.path.isdir(sd):
            for f in _os.listdir(sd):
                if not f.endswith(".db"):
                    continue
                sym = f[:-3]
                try:
                    conn = _daily_conn(_os.path.join(sd, f))
                    r = conn.execute("SELECT COUNT(*) FROM daily_bars").fetchone()
                    conn.close()
                    per[sym] = r[0] if r else 0
                except Exception:
                    continue
        ready = sum(1 for v in per.values() if v >= min_days)
        total = 0
        try:
            total = count_universe()
        except Exception:
            pass
        return {"symbols": per, "ready": ready, "total": total, "min_days": min_days}
    # 날짜별 저장 폴백 (기존)
    files = sorted(f for f in _os.listdir(DATA_DIR) if f.startswith("snapshots_"))
    for f in files[:max_scan_files]:
        path = _os.path.join(DATA_DIR, f)
        try:
            conn = _daily_conn(path)
            cols = [r["name"] for r in conn.execute("PRAGMA table_info(market_snapshots)")]
            if "source" in cols:
                rows = conn.execute(
                    "SELECT symbol, COUNT(*) c FROM market_snapshots "
                    "WHERE source='backfill' GROUP BY symbol").fetchall()
            else:
                # source 컬럼 없는 구버전 파일: 전부 백필로 간주
                rows = conn.execute(
                    "SELECT symbol, COUNT(*) c FROM market_snapshots GROUP BY symbol").fetchall()
            conn.close()
            for r in rows:
                per[r["symbol"]] = per.get(r["symbol"], 0) + r["c"]
        except Exception:
            continue
    ready = sum(1 for v in per.values() if v >= min_days)
    total = 0
    try:
        total = count_universe()
    except Exception:
        pass
    return {"symbols": per, "ready": ready, "total": total, "min_days": min_days}


def get_latest_backfill_bars(limit_symbols=6000, max_scan_files=60, include_live=True):
    """★ 각 종목의 최신 백필 일봉 (거래대금/거래량 순위·스캔 대상 선정용)
    ★ 종목별 저장(STOCK_DIR_SAVE=true)이면 data/stocks/*.db 의 최신 daily_bars
    (날짜별 저장이면 snapshots_* 파일 폴백)
    반환: {symbol: {"close": float, "volume": float, "amount": float}}
    """
    # 종목별 저장 우선 (전 종목 스캔 대상 - 핵심)
    if STOCK_DIR_SAVE:
        sd = _os.path.join(DATA_DIR, "stocks")
        if _os.path.isdir(sd):
            result = {}
            for f in sorted(_os.listdir(sd)):
                if not f.endswith(".db"):
                    continue
                sym = f[:-3]
                try:
                    conn = _daily_conn(_os.path.join(sd, f))
                    r = conn.execute(
                        "SELECT close_price, volume, amount FROM daily_bars "
                        "ORDER BY bar_date DESC LIMIT 1").fetchone()
                    conn.close()
                    if r:
                        result[sym] = {"close": r["close_price"] or 0,
                                       "volume": r["volume"] or 0,
                                       "amount": r["amount"] or 0}
                except Exception:
                    continue
                if len(result) >= limit_symbols:
                    return result
            return result
    _ensure_data_dir()

    """★ 각 종목의 최신 백필 일봉 (거래대금/거래량 순위 계산용)
    - data/snapshots_*.db 를 최신 파일부터 순회해 종목별 마지막 봉(종가/거래량/거래대금) 수집
    - source='backfill'(네이버 일봉) 우선, 부족하면 source='live'(장중 실시간) 보강
    반환: {symbol: {"close": float, "volume": float, "amount": float}}
    """
    _ensure_data_dir()
    files = sorted(f for f in _os.listdir(DATA_DIR) if f.startswith("snapshots_"))
    result = {}

    for f in reversed(files[-max_scan_files:]):
        path = _os.path.join(DATA_DIR, f)
        try:
            conn = _daily_conn(path)
            cols = [r["name"] for r in conn.execute("PRAGMA table_info(market_snapshots)")]
            if "source" in cols:
                q = ("SELECT symbol, price, volume, amount, source "
                     "FROM market_snapshots ORDER BY id DESC")
            else:
                q = ("SELECT symbol, price, volume, amount, 'backfill' AS source "
                     "FROM market_snapshots ORDER BY id DESC")
            rows = conn.execute(q).fetchall()
            conn.close()
            for r in rows:
                sym = r["symbol"]
                if not sym or sym in result:
                    continue
                if not include_live and r["source"] != "backfill":
                    continue
                result[sym] = {
                    "close": float(r["price"] or 0),
                    "volume": float(r["volume"] or 0),
                    "amount": float(r["amount"] or ((r["price"] or 0) * (r["volume"] or 0))),
                }
                if len(result) >= limit_symbols:
                    return result
        except Exception:
            continue
    return result


# ── 분봉 데이터 (네이버 분봉: 최근 약 1주일, 분당 종가+누적거래량) ──
# data/minutes_YYYY-MM-DD.db (봉 날짜 기준 파일 분리)
# - 장중 60초 실시간 스냅샷과 별개로, 과거 분봉을 한꺼번에 저장
# - 같은 (symbol, bar_time) 은 INSERT OR REPLACE 로 재백필 안전

def _minute_db_path(d=None):
    if d is None:
        d = now_kst().date()
    if isinstance(d, str):
        d = date.fromisoformat(d)
    return _os.path.join(DATA_DIR, f"minutes_{d.isoformat()}.db")


def _init_minute_schema(conn):
    conn.execute("""
        CREATE TABLE IF NOT EXISTS minute_bars (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol TEXT NOT NULL,
            bar_time TEXT NOT NULL,
            price REAL NOT NULL,
            volume REAL,
            cum_volume REAL,
            amount REAL,
            snapshot_time TEXT NOT NULL,
            UNIQUE(symbol, bar_time)
        )
    """)
    try:
        conn.execute("CREATE INDEX IF NOT EXISTS idx_minute_sym ON minute_bars(symbol)")
    except Exception:
        pass
    conn.commit()


def record_minute_bar(symbol, bar_time_dt, price, volume, cum_volume, amount=None):
    """분봉 1개 저장 (봉 날짜 파일). 같은 시각 봉은 덮어씀 (재백필 안전)"""
    try:
        d = bar_time_dt.date() if hasattr(bar_time_dt, "date") else now_kst().date()
        path = _minute_db_path(d)
        conn = _daily_conn(path)
        _init_minute_schema(conn)
        ts = bar_time_dt.isoformat() if hasattr(bar_time_dt, "isoformat") else str(bar_time_dt)
        if amount is None:
            amount = price * (volume or 0)
        conn.execute(
            "INSERT OR REPLACE INTO minute_bars "
            "(symbol, bar_time, price, volume, cum_volume, amount, snapshot_time) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (symbol, ts, float(price), float(volume or 0), float(cum_volume or 0),
             float(amount), now_kst_iso()),
        )
        conn.commit()
        conn.close()
        return True
    except Exception:
        return False


def get_minute_bars(symbol, days=8, start=None, end=None, limit=20000):
    """분봉 조회 (bar_time 오름차순)
    ★ 종목별 저장 우선(data/stocks/{symbol}.db) - 없으면 봉 날짜 파일 순회
    """
    # 1) 종목별 파일 (최적)
    if STOCK_DIR_SAVE:
        try:
            bars = get_stock_minute(symbol, limit=limit)
            if bars:
                return bars
        except Exception:
            pass
    _ensure_data_dir()
    out = []
    sd = start or (now_kst() - timedelta(days=days)).date()
    ed = end or now_kst().date()
    if isinstance(sd, str):
        sd = date.fromisoformat(sd)
    if isinstance(ed, str):
        ed = date.fromisoformat(ed)
    d = ed
    while d >= sd and len(out) < limit:
        path = _minute_db_path(d)
        if _os.path.exists(path):
            try:
                conn = _daily_conn(path)
                rows = conn.execute(
                    "SELECT symbol, bar_time, price, volume, cum_volume, amount "
                    "FROM minute_bars WHERE symbol=? ORDER BY bar_time", (symbol,)).fetchall()
                conn.close()
                for r in rows:
                    out.append({"symbol": r["symbol"], "bar_time": r["bar_time"],
                                "price": r["price"], "volume": r["volume"],
                                "cum_volume": r["cum_volume"], "amount": r["amount"]})
            except Exception:
                pass
        d = d - timedelta(days=1)
        if len(out) >= limit:
            break
    out.sort(key=lambda r: r["bar_time"])
    return out


def get_minute_summary(days=8, limit=5000):
    """분봉 종목별 요약 (시세 데이터 탭 표시용)
    반환: [{symbol, name, bars, start, end, high, low, last_price, volume_sum}...]
    """
    _ensure_data_dir()
    per = {}
    sd = (now_kst() - timedelta(days=days)).date()
    ed = now_kst().date()
    d = ed
    while d >= sd:
        path = _minute_db_path(d)
        if _os.path.exists(path):
            try:
                conn = _daily_conn(path)
                rows = conn.execute(
                    "SELECT symbol, bar_time, price, volume FROM minute_bars").fetchall()
                conn.close()
                for r in rows:
                    b = per.setdefault(r["symbol"], {"rows": [], "vol": 0.0})
                    b["rows"].append((r["bar_time"], r["price"]))
                    b["vol"] += r["volume"] or 0
            except Exception:
                pass
        d = d - timedelta(days=1)
    out = []
    for sym, b in per.items():
        if not b["rows"]:
            continue
        b["rows"].sort()  # bar_time 오름차순 → 마지막이 최신
        prices = [p for _t, p in b["rows"]]
        out.append({
            "symbol": sym, "name": get_symbol_name(sym), "bars": len(b["rows"]),
            "start": b["rows"][0][0][:16], "end": b["rows"][-1][0][:16],
            "high": max(prices), "low": min(prices),
            "last_price": b["rows"][-1][1],
            "volume_sum": round(b["vol"]),
        })
    out.sort(key=lambda x: -x["bars"])
    return out[:limit]


def get_minute_symbols(days=8):
    """분봉 데이터가 있는 종목 목록 (최근 N일 파일 기준)"""
    _ensure_data_dir()
    syms = set()
    sd = (now_kst() - timedelta(days=days)).date()
    ed = now_kst().date()
    d = ed
    while d >= sd:
        path = _minute_db_path(d)
        if _os.path.exists(path):
            try:
                conn = _daily_conn(path)
                for r in conn.execute("SELECT DISTINCT symbol FROM minute_bars"):
                    syms.add(r["symbol"])
                conn.close()
            except Exception:
                pass
        d = d - timedelta(days=1)
    return sorted(syms)


def get_minute_coverage(days=8):
    """분봉 수집 현황 (대시보드): 종목 수 / 총 봉 수 / 첫~최근 봉 시각"""
    _ensure_data_dir()
    syms = set()
    total = 0
    times = []
    sd = (now_kst() - timedelta(days=days)).date()
    ed = now_kst().date()
    d = ed
    while d >= sd:
        path = _minute_db_path(d)
        if _os.path.exists(path):
            try:
                conn = _daily_conn(path)
                r = conn.execute(
                    "SELECT COUNT(*) c, MIN(bar_time) mn, MAX(bar_time) mx "
                    "FROM minute_bars").fetchone()
                if r and r["c"]:
                    total += r["c"]
                    if r["mn"]:
                        times.append(r["mn"])
                    if r["mx"]:
                        times.append(r["mx"])
                    for rr in conn.execute("SELECT DISTINCT symbol FROM minute_bars"):
                        syms.add(rr["symbol"])
                conn.close()
            except Exception:
                pass
        d = d - timedelta(days=1)
    return {
        "symbols": len(syms),
        "bars": total,
        "start": min(times)[:16] if times else None,
        "end": max(times)[:16] if times else None,
    }


# ── 지수 수집 (코스피/코스닥 등 - ★ 날짜별 파일 분리) ──

def record_index(index_name: str, value: float, change_pct: float = None):
    """지수(코스피/코스닥 등) 스냅샷 저장 - ★ data/indices_날짜.db"""
    try:
        path = _index_db_path()
        conn = _daily_conn(path)
        _init_daily_schema(conn, "index")
        conn.execute(
            "INSERT INTO market_indices (index_name, value, change_pct, snapshot_time) "
            "VALUES (?, ?, ?, ?)",
            (index_name, value, change_pct, now_kst_iso()),
        )
        conn.commit()
        conn.close()
    except Exception:
        pass


def get_index_summary():
    """지수 요약 (UI용): 오늘 파일 기준 지수별 최신값/변화율/샘플수"""
    try:
        path = _index_db_path()
        if not _os.path.exists(path):
            return []
        conn = _daily_conn(path)
        rows = conn.execute(
            "SELECT index_name, COUNT(*) cnt, MAX(value) last_value, "
            "MAX(snapshot_time) last_time FROM market_indices GROUP BY index_name"
        ).fetchall()
        out = []
        for r in rows:
            lr = conn.execute(
                "SELECT change_pct FROM market_indices WHERE index_name=? "
                "ORDER BY id DESC LIMIT 1", (r["index_name"],)
            ).fetchone()
            out.append({"index_name": r["index_name"], "count": r["cnt"],
                        "last_value": r["last_value"], "last_time": r["last_time"],
                        "change_pct": lr["change_pct"] if lr else None})
        conn.close()
        return out
    except Exception:
        return []


# ── 데이터 수집 기간 (언제부터 언제까지 쌓였는지) ──────

def get_data_collection_period():
    """자료 수집 기간: 날짜별 파일 기준 스냅샷/지수 최초~최근 + 건수"""
    try:
        _ensure_data_dir()
        snap_files = sorted(f for f in _os.listdir(DATA_DIR) if f.startswith("snapshots_"))
        idx_files = sorted(f for f in _os.listdir(DATA_DIR) if f.startswith("indices_"))
        snap_count = idx_count = 0
        snap_times = []
        idx_times = []
        for f in snap_files:
            try:
                c = _daily_conn(_os.path.join(DATA_DIR, f))
                r = c.execute("SELECT MIN(snapshot_time) s, MAX(snapshot_time) e, COUNT(*) c "
                              "FROM market_snapshots").fetchone()
                c.close()
                snap_count += r["c"]
                if r["s"]:
                    snap_times.append(r["s"])
                if r["e"]:
                    snap_times.append(r["e"])
            except Exception:
                continue
        for f in idx_files:
            try:
                c = _daily_conn(_os.path.join(DATA_DIR, f))
                r = c.execute("SELECT MIN(snapshot_time) s, MAX(snapshot_time) e, COUNT(*) c "
                              "FROM market_indices").fetchone()
                c.close()
                idx_count += r["c"]
                if r["s"]:
                    idx_times.append(r["s"])
                if r["e"]:
                    idx_times.append(r["e"])
            except Exception:
                continue
        with get_conn() as conn:
            trades = conn.execute("SELECT COUNT(*) c FROM trades").fetchone()["c"]
        all_t = snap_times + idx_times
        return {
            "start": min(all_t)[:19].replace("T", " ") if all_t else None,
            "end": max(all_t)[:19].replace("T", " ") if all_t else None,
            "snapshot_count": snap_count,
            "index_count": idx_count,
            "trade_count": trades,
            "data_files": len(snap_files) + len(idx_files),
            "now": now_kst().strftime("%Y-%m-%d %H:%M:%S"),
        }
    except Exception:
        return {"start": None, "end": None, "snapshot_count": 0,
                "index_count": 0, "trade_count": 0, "data_files": 0,
                "now": now_kst().strftime("%Y-%m-%d %H:%M:%S")}


# ── KRX 거래일 (주말/공휴일 제외 - 특정 날짜 검산용) ──

# 대한민국 공휴일 (KRX 휴장일) - 매년 갱신 필요
KRX_HOLIDAYS = {
    "2025-01-01", "2025-01-28", "2025-01-29", "2025-01-30",  # 설
    "2025-03-03",  # 삼일절 대체
    "2025-05-05", "2025-05-06",  # 어린이날 대체
    "2025-06-06",
    "2025-08-15",
    "2025-10-03", "2025-10-05", "2025-10-06", "2025-10-07",  # 추석
    "2025-10-09",
    "2025-12-25",
    "2026-01-01",
    "2026-02-16", "2026-02-17", "2026-02-18",  # 설(2/17~19, 2/18 대체)
    "2026-03-02",  # 3/1 대체
    "2026-05-05",
    "2026-06-06",
    "2026-08-15",
    "2026-09-24", "2026-09-25", "2026-09-26", "2026-09-27", "2026-09-28",  # 추석 9/25~27
    "2026-10-09",
    "2026-12-25",
}


def is_trading_day(d=None) -> bool:
    """주말(토/일) + 공휴일 제외, KRX 거래일이면 True"""
    if d is None:
        d = now_kst().date()
    if isinstance(d, str):
        d = date.fromisoformat(d)
    if d.weekday() >= 5:  # 토/일
        return False
    if d.isoformat() in KRX_HOLIDAYS:
        return False
    return True


def prev_trading_day(d=None):
    """지정일(기본 오늘) 이전의 가장 가까운 거래일"""
    if d is None:
        d = now_kst().date()
    if isinstance(d, str):
        d = date.fromisoformat(d)
    d = d - timedelta(days=1)
    while not is_trading_day(d):
        d = d - timedelta(days=1)
    return d


def next_trading_day(d=None):
    """지정일 이후의 가장 가까운 거래일"""
    if d is None:
        d = now_kst().date()
    if isinstance(d, str):
        d = date.fromisoformat(d)
    d = d + timedelta(days=1)
    while not is_trading_day(d):
        d = d + timedelta(days=1)
    return d


# ── 전략 연구 데이터 (별도 시트/파일로 저장 - 가상·모의 완전 분리) ──
# research/ 폴더에 날짜별 CSV로 매수/매도 신호 기록
#   - research/signals_YYYY-MM-DD.csv  : 매수 신호 (당일 모든 판단)
#   - research/trades_YYYY-MM-DD.csv   : 실제 체결 (모의/실전만)
#   - research/virtual_YYYY-MM-DD.csv  : 가상 시뮬레이션만
RESEARCH_DIR = "research"


def _ensure_research_dir():
    _os.makedirs(RESEARCH_DIR, exist_ok=True)


def _research_csv_path(kind: str, d=None):
    """research/{kind}_YYYY-MM-DD.csv 경로"""
    if d is None:
        d = now_kst().date()
    if isinstance(d, str):
        d = date.fromisoformat(d)
    return _os.path.join(RESEARCH_DIR, f"{kind}_{d.isoformat()}.csv")


def _append_csv(path, headers, row):
    """CSV에 한 행 추가 (파일 없으면 헤더 포함 생성)"""
    _ensure_research_dir()
    new_file = not _os.path.exists(path)
    with open(path, "a", encoding="utf-8-sig") as f:
        if new_file:
            f.write(",".join(headers) + "\n")
        f.write(",".join(str(x) for x in row) + "\n")


def record_signal_to_research(symbol, decision, engine, score, reason, price=None,
                              kind="signal"):
    """
    ★ 전략 연구용 신호 기록 (시트별 CSV)
    kind: signal(모든 판단) | real(모의/실전) | virtual(가상)
    """
    try:
        t = now_kst().strftime("%H:%M:%S")
        name = get_symbol_name(symbol)
        if kind == "virtual":
            path = _research_csv_path("virtual")
            _append_csv(path, ["시간", "종목", "이름", "결정", "엔진", "점수", "가격", "이유"],
                        [t, symbol, name, decision, engine, score, price, (reason or "")[:150]])
        elif kind == "real":
            path = _research_csv_path("trades")
            _append_csv(path, ["시간", "종목", "이름", "결정", "엔진", "점수", "가격", "이유"],
                        [t, symbol, name, decision, engine, score, price, (reason or "")[:150]])
        else:
            path = _research_csv_path("signals")
            _append_csv(path, ["시간", "종목", "이름", "결정", "엔진", "점수", "가격", "이유"],
                        [t, symbol, name, decision, engine, score, price, (reason or "")[:150]])
        return True
    except Exception:
        return False


def get_research_files():
    """research/ 폴더의 시트 목록 (UI 표시용)"""
    _ensure_research_dir()
    files = []
    for f in sorted(_os.listdir(RESEARCH_DIR)):
        if f.endswith(".csv"):
            files.append({"name": f, "size": _os.path.getsize(_os.path.join(RESEARCH_DIR, f))})
    return files


# ── 자체 테스트 (self test) ───────────────────

def self_test():
    """시스템 전체 자체 점검 - 문제 있으면 False 반환"""
    problems = []
    checks = []
    try:
        init_db()
        checks.append(("DB 초기화", True))
    except Exception as e:
        checks.append(("DB 초기화", False))
        problems.append(f"DB 초기화 실패: {e}")

    with get_conn() as conn:
        cnt = conn.execute("SELECT COUNT(*) c FROM strategies").fetchone()["c"]
    checks.append(("전략 테이블", cnt >= 0))
    if cnt == 0:
        problems.append("전략이 없습니다 - bootstrap 필요")

    with get_conn() as conn:
        conn.execute("SELECT COUNT(*) FROM trades")
    checks.append(("trades 테이블", True))

    with get_conn() as conn:
        conn.execute("SELECT COUNT(*) FROM market_snapshots")
    checks.append(("market_snapshots 테이블", True))

    with get_conn() as conn:
        conn.execute("SELECT COUNT(*) FROM backtest_results")
    checks.append(("backtest_results 테이블", True))

    return {"ok": not problems, "checks": checks, "problems": problems}


# ── ★ 검증 통과 → 다음날 실제 모의투자 예약 (paper_schedule) ──

def schedule_validation_to_paper(grades=("채택 후보", "조건부")):
    """검증(validation_results)에서 '채택 후보/조건부'인 조건식을
    다음 거래일에 모의매매 풀로 예약. (원본 조건식은 그대로 - 예약만 추가)
    반환: {"scheduled": n, "list": [...], "date": ...}
    """
    nxt = next_trading_day(now_kst().date())
    nxt_s = nxt.isoformat()
    try:
        rows = []
        with get_conn() as conn:
            r = conn.execute(
                "SELECT cond_key, grade FROM validation_results "
                "WHERE id IN (SELECT MAX(id) FROM validation_results GROUP BY cond_key) "
                "AND grade IN (%s)" % ",".join("?" * len(grades)),
                (*grades,)).fetchall()
        passed = {str(x["cond_key"]): x["grade"] for x in r}
        scheduled = []
        for c in get_conditions(status="active"):
            ck = str(c["id"])
            if ck not in passed:
                continue
            with get_conn() as conn:
                ex = conn.execute(
                    "SELECT id FROM paper_schedule WHERE cond_key=? AND scheduled_date=?",
                    (ck, nxt_s)).fetchone()
            if ex:
                continue
            with get_conn() as conn:
                conn.execute(
                    "INSERT INTO paper_schedule (cond_key, cond_txt, tf, slots_json, grade, "
                    "scheduled_date, created_at) VALUES (?,?,?,?,?,?,?)",
                    (ck, c["cond_txt"], c.get("tf") or "day", c.get("slots_json") or "",
                     passed[ck], nxt_s, now_kst_iso()))
            scheduled.append({"cond_key": ck, "grade": passed[ck], "date": nxt_s})
        return {"scheduled": len(scheduled), "list": scheduled, "date": nxt_s}
    except Exception:
        return {"scheduled": 0, "list": [], "date": nxt_s}


def get_scheduled_paper(date_str=None, mark_used=False):
    """예약된 다음날 모의매매 풀 조회 (조건식 slots 포함)
    date_str: None=오늘 / mark_used=True면 사용 표시
    """
    if date_str is None:
        date_str = now_kst().strftime("%Y-%m-%d")
    import json as _json
    out = []
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT * FROM paper_schedule WHERE scheduled_date=? AND used=0",
                (date_str,)).fetchall()
            if mark_used:
                conn.execute(
                    "UPDATE paper_schedule SET used=1 WHERE scheduled_date=? AND used=0",
                    (date_str,))
        for r in rows:
            d = dict(r)
            try:
                d["slots"] = _json.loads(d.get("slots_json") or "[]")
            except Exception:
                d["slots"] = []
            out.append(d)
    except Exception:
        pass
    return out


# ── ★ 시간대 분석 (지수 국면 × 진입 시간대 - "지수와 어떤 시간대에도") ──

TIME_BUCKETS = [
    ("09:00-09:30", "개장초"), ("09:30-10:30", "오전1"), ("10:30-11:30", "오전2"),
    ("11:30-12:30", "점심"), ("12:30-13:30", "오후1"), ("13:30-14:30", "오후2"),
    ("14:30-15:30", "마감"),
]


def _time_bucket(hhmm):
    """진입 시각(09:00~15:30) → 구간 키. 장외면 None"""
    try:
        h, m = int(hhmm[:2]), int(hhmm[3:5])
        t = h * 60 + m
        if 9 * 60 <= t < 9 * 60 + 30:
            return "09:00-09:30"
        if 9 * 60 + 30 <= t < 10 * 60 + 30:
            return "09:30-10:30"
        if 10 * 60 + 30 <= t < 11 * 60 + 30:
            return "10:30-11:30"
        if 11 * 60 + 30 <= t < 12 * 60 + 30:
            return "11:30-12:30"
        if 12 * 60 + 30 <= t < 13 * 60 + 30:
            return "12:30-13:30"
        if 13 * 60 + 30 <= t < 14 * 60 + 30:
            return "13:30-14:30"
        if 14 * 60 + 30 <= t < 15 * 60 + 31:
            return "14:30-15:30"
        return None
    except Exception:
        return None


def time_zone_stats(min_sells=1):
    """★ 조건식 × 시간대 성적 (진입 시각 기준)
    반환: {cond_key: {구간키: {sells, win_rate, avg_ret, pf}}}
    """
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT cond_key, entry_time, ret_pct FROM paper_positions "
                "WHERE status='closed' AND ret_pct IS NOT NULL AND entry_time IS NOT NULL"
            ).fetchall()
    except Exception:
        return {}
    per = {}
    for r in rows:
        bucket = _time_bucket(r["entry_time"][11:16] if len(r["entry_time"]) > 15 else "")
        if not bucket:
            continue
        ck = str(r["cond_key"])
        per.setdefault(ck, {}).setdefault(bucket, []).append(r["ret_pct"] or 0)
    out = {}
    for ck, buckets in per.items():
        c_out = {}
        for b, rets in buckets.items():
            wins = [x for x in rets if x > 0]
            gp = sum(wins)
            gl = abs(sum(x for x in rets if x <= 0))
            c_out[b] = {"sells": len(rets), "win_rate": round(len(wins) / len(rets) * 100, 1),
                        "avg_ret": round(sum(rets) / len(rets), 2),
                        "pf": round(gp / gl, 2) if gl else (999.0 if gp else 0)}
        out[ck] = c_out
    return out


def index_time_stats(min_sells=1):
    """★ 지수 국면 × 시간대 교차 분석 (시장 전체 - '어느 지수대에 어느 시간대가 좋은지')
    반환: {"rows": [{regime, bucket, sells, win_rate, avg_ret}...], "best": [...]}
    regime: crash(≤-2%) / weak(-2~-1%) / normal / strong(≥+1%)
    """
    def _regime(p):
        if p <= -2.0:
            return "crash"
        if p <= -1.0:
            return "weak"
        if p >= 1.0:
            return "strong"
        return "normal"
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT entry_time, entry_index_pct, ret_pct FROM paper_positions "
                "WHERE status='closed' AND entry_index_pct IS NOT NULL AND ret_pct IS NOT NULL"
            ).fetchall()
    except Exception:
        return {"rows": [], "best": []}
    grid = {}
    for r in rows:
        bucket = _time_bucket(r["entry_time"][11:16] if len(r["entry_time"]) > 15 else "")
        if not bucket:
            continue
        rg = _regime(r["entry_index_pct"])
        grid.setdefault(rg, {}).setdefault(bucket, []).append(r["ret_pct"] or 0)
    rows_out = []
    for rg in ("crash", "weak", "normal", "strong"):
        for bucket, rets in grid.get(rg, {}).items():
            wins = [x for x in rets if x > 0]
            rows_out.append({"regime": rg, "bucket": bucket, "sells": len(rets),
                             "win_rate": round(len(wins) / len(rets) * 100, 1),
                             "avg_ret": round(sum(rets) / len(rets), 2)})
    rows_out.sort(key=lambda x: -x["sells"])
    best = sorted([r for r in rows_out if r["sells"] >= min_sells],
                  key=lambda x: (-x["win_rate"], -x["avg_ret"]))[:5]
    return {"rows": rows_out, "best": best}


# ── ★ 저평가 주식 추적 (버핏 관점 - 저PER/고ROE 종목이 실제로 어떻게 올랐나) ──

def add_value_watch(symbol, name, per, pbr, roe, div_yield, price):
    """저평가 종목 관찰 등록 (같은 종목 중복 방지)"""
    try:
        today = now_kst().strftime("%Y-%m-%d")
        with get_conn() as conn:
            ex = conn.execute("SELECT id FROM value_watch WHERE symbol=? AND status='watching'",
                              (symbol,)).fetchone()
            if ex:
                return ex["id"]
            cur = conn.execute(
                "INSERT INTO value_watch (symbol, name, watch_date, per, pbr, roe, div_yield, "
                "price_at_watch, status, last_check) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (symbol, name, today, per, pbr, roe, div_yield, price, "watching", today))
            return cur.lastrowid
    except Exception:
        return None


def update_value_watch(symbol, price, peak=None):
    """관찰 종목 현재가/최고수익률 갱신 (매일 호출 - '저평가가 올랐나' 추적)"""
    try:
        today = now_kst().strftime("%Y-%m-%d")
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT * FROM value_watch WHERE symbol=? AND status='watching'", (symbol,)).fetchall()
            for r in rows:
                entry = r["price_at_watch"] or price
                ret = (price - entry) / entry * 100 if entry else 0
                peak = max(r["peak_return"] or 0, ret)
                # +15% 이상 오르면 'up' (저평가 회복 관찰 완료)
                new_status = "up" if ret >= 15 else "watching"
                conn.execute(
                    "UPDATE value_watch SET last_check=?, peak_return=?, status=? WHERE id=?",
                    (today, round(peak, 2), new_status, r["id"]))
    except Exception:
        pass


def value_watch_list(limit=50):
    """관찰 중인 저평가 종목 목록"""
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT * FROM value_watch WHERE status IN ('watching','up') "
                "ORDER BY watch_date DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


def value_watch_stats():
    """저평가 추적 요약: 관찰 중 / +15% 회복 / 평균 수익률"""
    try:
        with get_conn() as conn:
            watching = conn.execute("SELECT COUNT(*) FROM value_watch WHERE status='watching'").fetchone()[0]
            up = conn.execute("SELECT COUNT(*) FROM value_watch WHERE status='up'").fetchone()[0]
            rets = conn.execute(
                "SELECT peak_return FROM value_watch WHERE status='up'").fetchall()
        avg_peak = round(sum(r["peak_return"] for r in rets) / len(rets), 2) if rets else 0
        return {"watching": watching, "up": up, "avg_peak_return": avg_peak}
    except Exception:
        return {"watching": 0, "up": 0, "avg_peak_return": 0}
