# -*- coding: utf-8 -*-
"""
🔐 키움 REST API 키 진단 (kiwoom_key_diag.py)
=============================================
현재 .env의 키가 '모의용'인지 '실전용'인지, 서버 설정과 맞는지 판별.
8030(투자구분 불일치) 문제를 5초 만에 진단.

실행:
  python kiwoom_key_diag.py

판별 결과:
  ✅ OK   = 키가 현재 서버(모의/실전)와 정상 매칭 - 주문 가능
  ⚠️ 8030 = 키가 다른 투자구분용 - 모의용/실전용 키를 다시 발급
"""
import logging
import os

logging.basicConfig(level=logging.WARNING)
from config import CFG

MOCK = "https://mockapi.kiwoom.com"
REAL = "https://api.kiwoom.com"


def mask(s, head=6, tail=2):
    s = s or ""
    if len(s) <= head + tail:
        return "*" * len(s)
    return s[:head] + "*" * 8 + s[-tail:]


def diagnose():
    print("=" * 62)
    print("🔐 키움 REST API 키 진단")
    print("=" * 62)

    # 1) 현재 설정
    use_mock = CFG.USE_MOCK
    base = CFG.base_url
    key = CFG.APP_KEY or ""
    secret = CFG.APP_SECRET or ""
    acct = CFG.ACCOUNT_NO or ""
    print(f"\n[1] 현재 .env 설정")
    print(f"  KIWOOM_USE_MOCK : {use_mock}  ({'모의' if use_mock else '실전'})")
    print(f"  접속 서버        : {base}")
    print(f"  APP_KEY          : {mask(key)}  (길이 {len(key)})")
    print(f"  APP_SECRET       : {mask(secret)}  (길이 {len(secret)})")
    print(f"  ACCOUNT_NO       : {mask(acct)}")

    if not key or not secret:
        print("\n  ❌ APP_KEY/APP_SECRET이 비어 있습니다. .env 확인 필요")
        return

    # 2) 실제 토큰 발급 시도
    print(f"\n[2] 토큰 발급 시도 → {base}/oauth2/token")
    import requests
    try:
        resp = requests.post(
            f"{base}/oauth2/token",
            json={"grant_type": "client_credentials", "appkey": key, "secretkey": secret},
            headers={"Content-Type": "application/json;charset=UTF-8"},
            timeout=10,
        )
        print(f"  HTTP {resp.status_code}")
        data = resp.json()
        msg = data.get("return_msg", "")
        code = data.get("return_code", "")
        if resp.status_code == 200 and data.get("token"):
            print("  ✅ 토큰 발급 성공! → 이 키는 현재 서버와 정상 매칭됨")
            print("  → 주문/계좌/조회 모두 사용 가능. 문제 해결됨.")
            return
        print(f"  응답: {msg} (return_code={code})")

        # 8030 판별
        if "8030" in str(code) or "8030" in msg or "투자구분" in msg:
            print()
            print("  ⚠️ 8030 = 키와 서버의 투자구분 불일치")
            print(f"     현재 서버: {'모의(mockapi)' if use_mock else '실전(api)'}")
            print(f"     넣은 키:   실전용(운영) 키로 보임" if use_mock else f"     넣은 키:   모의용 키로 보임")
            print()
            print("  [해결] 키움 개발자 센터(openapi.kiwoom.com)에서")
            print(f"     {'모의투자' if use_mock else '실전투자'}용 앱을 **새로 등록**해서")
            print(f"     그 앱의 App Key / Secret Key를 .env에 넣으세요.")
            print("     (실전용 키와 모의용 키는 서로 다릅니다 - 반드시 별도 발급)")
            return

        # 기타 오류
        print(f"  ⚠️ 기타 오류: {msg} (코드 {code})")
        print("  → 위 메시지를 복사해서 문의해 주세요")
        return
    except Exception as e:
        print(f"  ❌ 요청 실패: {e}")
        print("  → 인터넷/방화벽 확인. 위 메시지를 복사해서 문의해 주세요")
        return

    # 3) 실제 계좌 보유 종목 조회 (손매수 종목이 왜 안 보이는지 확인)
    print(f"\n[3] 실제 계좌 보유 종목 조회 (kt00004+kt00005)")
    try:
        from kiwoom_client import client
        ov = client.get_account_overview()
        if not isinstance(ov, dict):
            print("  ❌ 계좌 응답 이상 (dict 아님)")
            return
        if ov.get("mock"):
            print("  ⚠️ 계좌 응답이 mock(키 없음/DRY_RUN 기본값) - 실제 보유를 못 봅니다.")
            print(f"     DRY_RUN={CFG.DRY_RUN} · 키={'있음' if CFG.APP_KEY else '없음'}")
            return
        pos = ov.get("positions") or []
        if ov.get("errors"):
            print(f"  ⚠️ 조회 오류: {' | '.join(str(e) for e in ov['errors'][:3])}")
        if not pos:
            print("  ⚠️ 계좌 보유 종목 0개 (응답은 성공했으나 보유 내역 없음)")
            print("     → 계좌에 실제로 종목이 없는지, 아니면 응답 구조가 다른지 확인 필요")
        for p in pos:
            print(f"  ✅ {p.get('symbol','')} {p.get('name','')} "
                  f"{p.get('qty',0)}주 · 평균 {p.get('avg_price',0):,}원")
        print(f"  → 보유 {len(pos)}종목 · 예수금 {ov.get('entr',0):,}원")
        if pos:
            print("  → 앱의 💼 계좌 탭 / 수동 매수 동기화가 이 종목들을 표시합니다 (거짓 없음)")
    except Exception as e:
        print(f"  ❌ 계좌 조회 실패: {e}")

    # 4) 키움 일봉 차트 조회 (네이버 차단 시 백필 폴백용 - ka10081)
    print(f"\n[4] 키움 일봉 차트 1개 조회 (ka10081 - 네이버 차단 시 대체 수집용)")
    try:
        from backfill_history import fetch_daily_kiwoom
        rows = fetch_daily_kiwoom("005930", days=90)
        if not rows:
            print("  ⚠️ 일봉 데이터 0개 - 키/서버(모의·실전) 확인 필요")
            print("     (모의 서버엔 모의용 키, 실전 서버엔 실전용 키가 있어야 합니다)")
        else:
            print(f"  ✅ 삼성전자 일봉 {len(rows)}봉 수신")
            for r in rows[-3:]:
                print(f"     {r['date']} 시{r['open']:,} 고{r['high']:,} 저{r['low']:,} "
                      f"종{r['close']:,} 거래량{r['volume']:,}")
            print("  → 네이버가 막혀도 키움으로 전 종목 일봉 수집 가능 (1종목/초)")
    except Exception as e:
        print(f"  ❌ 키움 일봉 조회 실패: {e}")


if __name__ == "__main__":
    diagnose()
