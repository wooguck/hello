# -*- coding: utf-8 -*-
"""
🏛 자동 거버너 (governor.py) - 종합판정 자동 반영 + AI 조정 + 롤백
====================================================================
사용자 요청: "종합 판정(WF/MC 등)이 자동으로 유기적으로 반영되고,
무료 AI가 조정하며, 문제 생기면 되돌릴 방법도 있어야"

구조 (3중 안전):
  [1] 스냅샷: 어떤 변경이든 실행 전에 현재 상태를 통째로 저장
      (조건식 상태 전부 + 핵심 파라미터 + 명전 랭킹) → 언제든 복원
  [2] 판정 자동 반영 (규칙 - AI 아님, 결정적):
      · robust_check 자동 실행 (검증통과 조건식 대상, 라운드 순환)
      · WF 🔴(검증구간 플러스 <50%) → 자동 강등 (시기의존 전략 퇴출)
      · MC 파산확률 5%+ → 자동 강등
  [3] AI 조정 (Gemini 무료 - 가드레일 안에서만):
      · AI는 "화이트리스트 행동"만 선택 가능:
        demote(강등) / promote(승격) / trail_adjust(1.0~3.0 범위) / noop
      · 하드손절/게이트/예산은 AI가 절대 못 건드림 (하드코딩 차단)
      · 하루 최대 3개 행동 · 모든 결정은 governor_log에 근거와 함께 기록

롤백:
  python governor.py --snapshots        # 스냅샷 목록
  python governor.py --rollback <ID>    # 해당 시점으로 복원
실행:
  python governor.py                    # 1회 실행 (판정→반영→AI조정)
자동: 라운드에서 10라운드마다 호출 (AUTO_GOVERN=true, 기본 true)
"""
import argparse
import json
import os
import sys
from datetime import datetime

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

SNAP_DIR = os.path.join("strategy", "snapshots")
GOV_LOG = os.path.join("strategy", "governor_log.json")

# ★ AI 가드레일: 이 목록 밖의 행동은 무조건 거부
ALLOWED_ACTIONS = ("demote", "promote", "trail_adjust", "noop")
TRAIL_MIN, TRAIL_MAX = 1.0, 3.0        # AI가 조정 가능한 트레일링 범위
MAX_ACTIONS_PER_RUN = 3                # 1회 실행당 최대 행동 수
# AI가 절대 못 건드리는 것: HARD_STOP_LOSS_PCT, VALIDATE_GATE_ENABLED, 예산, DRY_RUN


def _log(msg):
    print(msg, flush=True)


def _gov_log(entry):
    try:
        log = {"entries": []}
        if os.path.exists(GOV_LOG):
            log = json.load(open(GOV_LOG, encoding="utf-8"))
        entry["at"] = db.now_kst_iso()
        log["entries"].append(entry)
        log["entries"] = log["entries"][-500:]
        os.makedirs("strategy", exist_ok=True)
        json.dump(log, open(GOV_LOG, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    except Exception:
        pass


# ── [1] 스냅샷 / 롤백 ────────────────────────────────────
def take_snapshot(reason=""):
    """현재 상태 저장: 조건식 상태 + 핵심 env + 명전 랭킹"""
    os.makedirs(SNAP_DIR, exist_ok=True)
    # ★ 마이크로초 포함 (같은 초에 2개 생성 시 덮어쓰기 방지 - 롤백 자동백업 충돌 버그 수정)
    snap_id = db.now_kst().strftime("%Y%m%d_%H%M%S_%f")[:22]
    conds = []
    try:
        with db.get_conn() as conn:
            for r in conn.execute("SELECT id, cond_no, status FROM conditions").fetchall():
                conds.append({"id": r["id"], "no": r["cond_no"], "status": r["status"]})
    except Exception:
        pass
    hof = []
    try:
        with db.get_conn() as conn:
            for r in conn.execute("SELECT cond_key, ranked FROM hall_of_fame").fetchall():
                hof.append({"cond_key": r["cond_key"], "ranked": r["ranked"]})
    except Exception:
        pass
    env_keys = ("VALIDATE_TP_PCT", "VALIDATE_SL_PCT", "VALIDATE_TRAIL_PCT",
                "VALIDATE_MAX_HOLD", "PAPER_HOLD_DAYS")
    env = {}
    if os.path.exists(".env"):
        for ln in open(".env", encoding="utf-8").read().splitlines():
            for k in env_keys:
                if ln.strip().startswith(k + "="):
                    env[k] = ln.split("=", 1)[1].strip()
    snap = {"id": snap_id, "reason": reason, "at": db.now_kst_iso(),
            "conditions": conds, "hof": hof, "env": env}
    path = os.path.join(SNAP_DIR, f"snap_{snap_id}.json")
    json.dump(snap, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return snap_id


def list_snapshots():
    if not os.path.isdir(SNAP_DIR):
        print("스냅샷 없음")
        return []
    files = sorted(os.listdir(SNAP_DIR))
    for f in files:
        try:
            s = json.load(open(os.path.join(SNAP_DIR, f), encoding="utf-8"))
            n_active = sum(1 for c in s["conditions"] if c["status"] == "active")
            print(f"  {s['id']}  활성 {n_active}개 · {s.get('reason','')[:40]}")
        except Exception:
            continue
    return files


def rollback(snap_id):
    """스냅샷 시점으로 복원 (조건식 상태 + env 파라미터)
    ★ snap_id는 '20260827_174545_608649' / 'snap_...json' / 경로 어느 형태든 허용"""
    snap_id = os.path.basename(str(snap_id).strip())
    if snap_id.startswith("snap_"):
        snap_id = snap_id[5:]
    if snap_id.endswith(".json"):
        snap_id = snap_id[:-5]
    path = os.path.join(SNAP_DIR, f"snap_{snap_id}.json")
    if not os.path.exists(path):
        print(f"❌ 스냅샷 {snap_id} 없음 (--snapshots로 확인)")
        return False
    # 복원 전에 '지금' 상태도 스냅샷 (롤백의 롤백 가능)
    take_snapshot(reason=f"rollback 직전 자동백업 (→{snap_id})")
    s = json.load(open(path, encoding="utf-8"))
    n = 0
    with db.get_conn() as conn:
        for c in s["conditions"]:
            conn.execute("UPDATE conditions SET status=? WHERE id=?", (c["status"], c["id"]))
            n += 1
        for h in s.get("hof", []):
            conn.execute("UPDATE hall_of_fame SET ranked=? WHERE cond_key=?",
                         (h["ranked"], h["cond_key"]))
    # env 복원
    if s.get("env") and os.path.exists(".env"):
        lines = open(".env", encoding="utf-8").read().splitlines()
        out = []
        for ln in lines:
            key = ln.split("=", 1)[0].strip() if "=" in ln else ""
            out.append(f"{key}={s['env'][key]}" if key in s["env"] else ln)
        open(".env", "w", encoding="utf-8").write("\n".join(out) + "\n")
    _gov_log({"action": "rollback", "to": snap_id, "restored_conds": n})
    print(f"✅ 롤백 완료: {snap_id} 시점으로 조건식 {n}개 상태 + 파라미터 복원")
    print("   ⚠️ 실행 중인 앱은 재시작해야 env 반영")
    return True


# ── [2] 판정 자동 반영 (결정적 규칙) ─────────────────────
def apply_verdicts(max_checks=2, log_fn=None):
    """검증통과(채택/조건부) 조건식을 순환하며 robust_check → 🔴이면 강등"""
    def _l(m):
        _log(m)
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    from robust_check import walk_forward, monte_carlo
    import validation as V
    # 대상: 최신 등급이 채택/조건부인 활성 조건식 (robust 검사 오래된 순)
    cands = []
    try:
        with db.get_conn() as conn:
            rows = conn.execute(
                "SELECT cond_key, grade FROM validation_results WHERE id IN "
                "(SELECT MAX(id) FROM validation_results GROUP BY cond_key) "
                "AND grade IN ('채택 후보','조건부')").fetchall()
        passed = {str(r["cond_key"]) for r in rows}
        for c in db.get_conditions(status="active"):
            if str(c["id"]) in passed:
                rp = os.path.join("strategy", f"robust_auto_{c['id']}.json")
                age = os.path.getmtime(rp) if os.path.exists(rp) else 0
                cands.append((age, c))
    except Exception:
        return {"checked": 0, "demoted": []}
    cands.sort(key=lambda x: x[0])
    demoted = []
    checked = 0
    for _age, c in cands[:max_checks]:
        try:
            slots = [tuple(s) for s in json.loads(c.get("slots_json") or "[]")]
            if not slots:
                continue
            wf = walk_forward(slots, windows=3, max_symbols=200)
            full = V.run_backtest_detail(
                sorted(s for s, n in db.backfill_coverage(min_days=120)["symbols"].items()
                       if n >= 120)[:200], slots, max_symbols=200)
            mc = monte_carlo(full["trades"], runs=500)
            checked += 1
            res = {"cond": c["cond_no"], "wf": wf.get("verdict"), 
                   "ruin": mc.get("ruin_pct")}
            json.dump({"at": db.now_kst_iso(), **res},
                      open(os.path.join("strategy", f"robust_auto_{c['id']}.json"), "w",
                           encoding="utf-8"))
            bad_wf = wf.get("verdict") == "🔴 실패"
            bad_mc = isinstance(mc.get("ruin_pct"), (int, float)) and mc["ruin_pct"] >= 5.0
            if bad_wf or bad_mc:
                snap = take_snapshot(reason=f"강등 전: {c['cond_no']}번 (WF={wf.get('verdict')} ruin={mc.get('ruin_pct')}%)")
                db.set_condition_status(c["id"], "backlog")
                demoted.append(c["cond_no"])
                why = "WF 시기의존" if bad_wf else f"파산확률 {mc['ruin_pct']}%"
                _l(f"🏛 [거버너] {c['cond_no']}번 자동 강등 ({why}) · 스냅샷 {snap} - "
                   f"복원: python governor.py --rollback {snap}")
                _gov_log({"action": "auto_demote", "cond_no": c["cond_no"],
                          "why": why, "snapshot": snap, **res})
            else:
                _l(f"🏛 [거버너] {c['cond_no']}번 강건성 통과 (WF {wf.get('test_positive','-')} · "
                   f"파산 {mc.get('ruin_pct','-')}%)")
                _gov_log({"action": "robust_pass", "cond_no": c["cond_no"], **res})
        except Exception as e:
            _l(f"🏛 검사 실패 {c.get('cond_no')}: {str(e)[:50]}")
    return {"checked": checked, "demoted": demoted}


# ── [3] AI 조정 (가드레일) ───────────────────────────────
def ai_adjust(log_fn=None):
    """Gemini가 채널/조건식 성적을 보고 화이트리스트 행동 선택 (한도·범위 강제)"""
    def _l(m):
        _log(m)
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass
    try:
        from ai_judge import call_llm, AI_ENABLED, GEMINI_API_KEY, OPENAI_API_KEY
        if not (AI_ENABLED and (GEMINI_API_KEY or OPENAI_API_KEY)):
            return {"actions": 0, "note": "AI 미연결 - 규칙 판정만 적용됨"}
    except Exception:
        return {"actions": 0, "note": "AI 모듈 없음"}
    # 성적 요약
    try:
        with db.get_conn() as conn:
            rows = conn.execute(
                "SELECT cond_key, cond_txt, COUNT(*) n, "
                "SUM(CASE WHEN ret_pct>0 THEN 1 ELSE 0 END)*100.0/COUNT(*) wr, "
                "AVG(ret_pct) avg FROM paper_positions WHERE status='closed' "
                "AND exit_time > datetime('now','-14 days') "
                "GROUP BY cond_key HAVING n >= 5").fetchall()
    except Exception:
        return {"actions": 0}
    if not rows:
        return {"actions": 0, "note": "표본 부족"}
    lines = [f"{r['cond_key']}|{(r['cond_txt'] or '')[:30]}|{r['n']}건|승률{r['wr']:.0f}%|평균{r['avg']:+.2f}%"
             for r in rows]
    prompt = ("최근 14일 채널/조건식 성적:\n" + "\n".join(lines) +
              "\n\n허용 행동만 선택 (최대 3개, 한 줄에 하나):\n"
              "demote|<cond_key>|<이유>   (부진 조건식 대기 이동)\n"
              "trail_adjust|<1.0~3.0 값>|<이유>   (트레일링 % 조정)\n"
              "noop|없음|<이유>\n"
              "주의: 표본 10건 미만으로 성급히 판단하지 말 것. 확신 없으면 noop.")
    res = call_llm("당신은 보수적인 트레이딩 시스템 관리자입니다. 근거 없는 변경을 싫어합니다.", prompt)
    if not res:
        return {"actions": 0}
    applied = 0
    for ln in res.splitlines():
        if applied >= MAX_ACTIONS_PER_RUN:
            break
        parts = [p.strip() for p in ln.split("|")]
        if len(parts) < 3 or parts[0] not in ALLOWED_ACTIONS:
            continue
        act, arg, why = parts[0], parts[1], parts[2][:80]
        if act == "noop":
            _gov_log({"action": "ai_noop", "why": why})
            continue
        snap = take_snapshot(reason=f"AI조정 전: {act} {arg}")
        if act == "demote":
            try:
                db.set_condition_status(int(arg), "backlog")
                _l(f"🏛🤖 AI 강등: {arg} ({why}) · 복원: --rollback {snap}")
                _gov_log({"action": "ai_demote", "cond_key": arg, "why": why, "snapshot": snap})
                applied += 1
            except Exception:
                continue
        elif act == "trail_adjust":
            try:
                v = max(TRAIL_MIN, min(TRAIL_MAX, float(arg)))   # ★ 범위 강제
                from visual_lab import apply_env
                from config import CFG
                apply_env({"tp": float(os.getenv("VALIDATE_TP_PCT", 5)),
                           "sl": float(os.getenv("VALIDATE_SL_PCT", 3)),
                           "trail": v,
                           "hold": int(os.getenv("VALIDATE_MAX_HOLD", 10))})
                _l(f"🏛🤖 AI 트레일링 조정: {v}% ({why}) · 복원: --rollback {snap}")
                _gov_log({"action": "ai_trail", "value": v, "why": why, "snapshot": snap})
                applied += 1
            except Exception:
                continue
    return {"actions": applied}


def run_governor(log_fn=None):
    """1회 실행: 판정 반영 → AI 조정"""
    r1 = apply_verdicts(log_fn=log_fn)
    r2 = ai_adjust(log_fn=log_fn)
    return {"verdicts": r1, "ai": r2}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--snapshots", action="store_true")
    ap.add_argument("--rollback", default="")
    ap.add_argument("--log", action="store_true", help="거버너 결정 이력")
    args = ap.parse_args()
    if args.snapshots:
        list_snapshots()
        return
    if args.rollback:
        rollback(args.rollback)
        return
    if args.log:
        try:
            log = json.load(open(GOV_LOG, encoding="utf-8"))
            for e in log["entries"][-20:]:
                print(f"  {e.get('at','')[:16]} {e.get('action')} "
                      f"{e.get('cond_no') or e.get('cond_key') or ''} {e.get('why','')[:50]}")
        except Exception:
            print("이력 없음")
        return
    print("🏛 거버너 1회 실행 (판정 자동반영 → AI 조정)")
    r = run_governor()
    print("결과:", r)


if __name__ == "__main__":
    main()
