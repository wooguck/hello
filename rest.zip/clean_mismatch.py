# -*- coding: utf-8 -*-
"""
🧹 어긋남(mismatch) 종목 정리 v2 (clean_mismatch.py)
====================================================
mismatch_symbols.json에 있는 종목(액면분할/수정주가 어긋남)의
★ 일봉(daily_bars)만 비웁니다 - 분봉(minute_bars)은 보존! ★

v1은 DB 파일을 통째로 지워서 분봉까지 날아가는 문제가 있었음 → v2에서 수정.
- 일봉: 어긋난 혼합 데이터라 비우고 새로 받아야 함 (다음/Yahoo가 일관된 값 제공)
- 분봉: 그날 안에서만 비교(익절/손절 순서 판정)에 쓰여 어긋남 영향이 작고,
        다시 구할 수 없는 데이터라 보존

실행:
  python clean_mismatch.py            # 일봉만 비우기 실행
  python clean_mismatch.py --dry      # 뭘 정리할지 보기만
  → 이후 python collect_data.py --once 로 일봉 재수신
"""
import argparse
import json
import os
import sqlite3
import sys

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry", action="store_true", help="정리하지 않고 목록만 표시")
    args = ap.parse_args()

    if not os.path.exists("mismatch_symbols.json"):
        print("❌ mismatch_symbols.json 이 없습니다 (import_bydate.py 실행 폴더에서 실행하세요)")
        return

    with open("mismatch_symbols.json", encoding="utf-8") as f:
        mismatch = json.load(f)
    syms = sorted(mismatch.keys())
    print(f"📋 어긋남 종목: {len(syms)}개 (일봉만 비움 - 분봉은 보존)")

    stocks_dir = os.path.join("data", "stocks")
    cleaned, missing = [], []
    kept_minutes = 0
    for s in syms:
        p = os.path.join(stocks_dir, f"{s}.db")
        if not os.path.exists(p):
            missing.append(s)
            continue
        if args.dry:
            cleaned.append(s)
            continue
        try:
            conn = sqlite3.connect(p, timeout=10)
            # ★ 일봉만 비움 (분봉 minute_bars는 그대로)
            conn.execute("DELETE FROM daily_bars")
            try:
                m = conn.execute("SELECT COUNT(*) FROM minute_bars").fetchone()
                kept_minutes += (m[0] if m else 0)
            except Exception:
                pass
            conn.commit()
            conn.execute("VACUUM")
            conn.close()
            cleaned.append(s)
        except Exception as e:
            print(f"  ⚠️ {s} 정리 실패: {e}")

    if args.dry:
        print(f"🔍 (미리보기) 일봉 비울 대상 {len(cleaned)}개 · 파일 없음 {len(missing)}개")
        print("   실제 실행: python clean_mismatch.py")
        return

    print(f"🧹 정리 완료: {len(cleaned)}종목 일봉 비움 · 분봉 {kept_minutes:,}봉 보존 · "
          f"파일 없음 {len(missing)}개")

    # 기록 남기기 + mismatch 파일은 cleaned로 이름 변경 (재사용 방지)
    with open("mismatch_cleaned.json", "w", encoding="utf-8") as f:
        json.dump({"cleaned": cleaned, "detail": mismatch}, f, ensure_ascii=False, indent=2)
    try:
        os.remove("mismatch_symbols.json")
    except Exception:
        pass
    print("📄 기록: mismatch_cleaned.json")
    print()
    print("👉 다음 단계: python collect_data.py --once")
    print(f"   → {len(cleaned)}종목 일봉을 다음(카카오)/Yahoo에서 현재 수정주가 기준으로 새로 받습니다")
    print(f"   → 다음 500봉(약 2년) 기준 {len(cleaned)}종목 ≈ {max(1, int(len(cleaned) * 0.8 / 60))}분 내외")


if __name__ == "__main__":
    main()
