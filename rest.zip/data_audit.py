# -*- coding: utf-8 -*-
"""
🩺 데이터 무결성 종합 검사 (data_audit.py)
============================================
수집된 일봉/분봉이 "중간에 빠진 것 없이" 제대로 있는지 전 종목 검사합니다.

검사 항목:
  [1] 일봉 커버리지  : 종목별 봉 수 / 시작~끝 날짜 / 최신인지(7일 이내)
  [2] 일봉 중간 갭   : 거래일 달력(전 종목 날짜 합집합) 기준으로 빠진 날짜 탐지
                       ★ 거래일 달력 = "그날 봉이 있는 종목이 30%+" 인 날짜
                       (공휴일/주말은 자동으로 달력에서 빠짐 - 거래정지와 구분)
  [3] 일봉 값 오류   : 고가<저가 · 종가≤0 · 고저 범위 밖 종가 · 거래량<0 · 중복날짜
  [4] 분봉 커버리지  : 종목별 분봉 수 / 며칠치 / 하루 평균 봉 수(<200이면 부분수신)
  [5] 파일 상태     : 열리지 않는 DB / 테이블 없음 / 0바이트 / 용량 통계
  [6] 유니버스 대조  : 목록엔 있는데 파일 없는 종목 (폐지 등록분 제외)

출력:
  - 콘솔 요약 + 문제 종목 상위 목록
  - data_audit_report.json  (전체 상세 - 프로그램용)
  - data_audit_report.md    (읽기 좋은 보고서)

실행:
  python data_audit.py              # 전체 검사
  python data_audit.py --fix-list   # 문제 종목을 재수집 대상으로 표시
                                    # (strategy/audit_refill.json - collect_data가 다음 실행 때 참고 가능)
  python data_audit.py --symbol 005930   # 한 종목 상세
"""
import argparse
import json
import os
import sqlite3
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

STOCKS_DIR = os.path.join(db.DATA_DIR, "stocks")
DEAD_PATH = os.path.join("strategy", "dead_symbols.json")


def _log(msg=""):
    print(msg, flush=True)


def _load_dead():
    try:
        if os.path.exists(DEAD_PATH):
            with open(DEAD_PATH, encoding="utf-8") as f:
                return set(json.load(f))
    except Exception:
        pass
    return set()


def scan_all():
    """전 종목 파일 스캔 → 종목별 요약 + 거래일 달력 구축"""
    per = {}          # sym -> dict
    date_count = Counter()   # 날짜 -> 그날 봉 보유 종목 수
    broken = []       # 열리지 않는 파일
    if not os.path.isdir(STOCKS_DIR):
        return per, [], broken

    files = [f for f in os.listdir(STOCKS_DIR) if f.endswith(".db")]
    n = len(files)
    for i, f in enumerate(files):
        sym = f[:-3]
        path = os.path.join(STOCKS_DIR, f)
        size = os.path.getsize(path)
        info = {"size": size, "daily": 0, "d_first": "", "d_last": "",
                "dates": None, "bad_ohlc": 0, "bad_dup": 0,
                "minute": 0, "m_days": 0, "m_per_day": 0.0}
        try:
            conn = sqlite3.connect(path, timeout=10)
            # 일봉
            try:
                rows = conn.execute(
                    "SELECT bar_date, open_price, high_price, low_price, close_price, "
                    "volume FROM daily_bars ORDER BY bar_date").fetchall()
            except Exception:
                rows = []
            dates = []
            bad = 0
            seen = set()
            dup = 0
            for (d, o, h, l, c, v) in rows:
                if d in seen:
                    dup += 1
                seen.add(d)
                dates.append(d)
                date_count[d] += 1
                # 값 오류 검사
                try:
                    o = float(o or 0); h = float(h or 0)
                    l = float(l or 0); c = float(c or 0); v = float(v or 0)
                    if c <= 0 or h < l or v < 0 or (h > 0 and (c > h * 1.001 or c < l * 0.999)):
                        bad += 1
                except Exception:
                    bad += 1
            info["daily"] = len(rows)
            info["bad_ohlc"] = bad
            info["bad_dup"] = dup
            if dates:
                info["d_first"] = dates[0]
                info["d_last"] = dates[-1]
                info["dates"] = set(dates)
            # 분봉
            try:
                m = conn.execute("SELECT COUNT(*), COUNT(DISTINCT substr(bar_time,1,10)) "
                                 "FROM minute_bars").fetchone()
                info["minute"] = m[0] or 0
                info["m_days"] = m[1] or 0
                if info["m_days"]:
                    info["m_per_day"] = info["minute"] / info["m_days"]
            except Exception:
                pass
            conn.close()
        except Exception as e:
            broken.append((sym, str(e)[:60]))
        per[sym] = info
        if (i + 1) % 300 == 0 or i == n - 1:
            sys.stdout.write(f"\r  🔍 스캔 {i+1}/{n} 종목   ")
            sys.stdout.flush()
    print()

    # ★ 거래일 달력: 그날 봉을 가진 종목이 전체의 30%+ 인 날 = 거래일
    #   (개별 거래정지와 공휴일을 구분하는 통계적 방법)
    n_syms = max(1, len(per))
    calendar = sorted(d for d, c in date_count.items() if c >= n_syms * 0.30)
    return per, calendar, broken


def find_gaps(info, calendar):
    """종목의 보유 날짜 vs 거래일 달력 → 중간에 빠진 날짜 목록
    (종목의 첫 봉 ~ 마지막 봉 사이만 - 상장 전/폐지 후는 갭 아님)
    """
    if not info.get("dates") or not calendar:
        return []
    first, last = info["d_first"], info["d_last"]
    have = info["dates"]
    return [d for d in calendar if first <= d <= last and d not in have]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fix-list", action="store_true",
                    help="문제 종목을 strategy/audit_refill.json 으로 저장")
    ap.add_argument("--symbol", default="", help="한 종목만 상세 보기")
    ap.add_argument("--gap-limit", type=int, default=3,
                    help="중간 갭 N개 이상만 문제로 분류 (기본 3 - 거래정지 1~2일은 정상)")
    args = ap.parse_args()

    _log("=" * 64)
    _log("🩺 데이터 무결성 종합 검사")
    _log("=" * 64)

    per, calendar, broken = scan_all()
    dead = _load_dead()

    if args.symbol:
        s = args.symbol
        info = per.get(s)
        if not info:
            _log(f"❌ {s}: 파일 없음")
            return
        gaps = find_gaps(info, calendar)
        _log(f"\n📄 {s} 상세")
        _log(f"  일봉 {info['daily']}봉 ({info['d_first']} ~ {info['d_last']})")
        _log(f"  값 오류 {info['bad_ohlc']} · 중복 {info['bad_dup']}")
        _log(f"  분봉 {info['minute']:,}봉 · {info['m_days']}일 · 하루평균 {info['m_per_day']:.0f}봉")
        _log(f"  중간 갭 {len(gaps)}일: {gaps[:20]}{' ...' if len(gaps) > 20 else ''}")
        return

    # 유니버스 대조
    try:
        univ = [u["symbol"] for u in db.get_universe()
                if (u.get("market") or "").upper() != "KONEX" and u.get("symbol")]
    except Exception:
        univ = []
    univ_set = set(univ)
    have_set = set(per.keys())
    missing = sorted((univ_set - have_set) - dead)   # 목록엔 있는데 파일 없음 (폐지 제외)
    extra = sorted(have_set - univ_set)               # 파일은 있는데 목록에 없음 (참고용)

    # 분류
    fresh_cut = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
    few_bars, stale, gap_syms, bad_syms, no_minute = [], [], {}, [], []
    total_daily = total_minute = total_size = 0
    for sym, info in per.items():
        total_daily += info["daily"]
        total_minute += info["minute"]
        total_size += info["size"]
        if sym in dead:
            continue
        if info["daily"] < 30:
            few_bars.append((sym, info["daily"]))
        elif info["d_last"] < fresh_cut:
            stale.append((sym, info["d_last"]))
        gaps = find_gaps(info, calendar)
        if len(gaps) >= args.gap_limit:
            gap_syms[sym] = gaps
        if info["bad_ohlc"] or info["bad_dup"]:
            bad_syms.append((sym, info["bad_ohlc"], info["bad_dup"]))
        if info["minute"] == 0:
            no_minute.append(sym)

    # ── 요약 출력 ──
    _log(f"\n📊 [전체 현황]")
    _log(f"  종목 파일 {len(per):,}개 · 일봉 {total_daily:,}봉 · 분봉 {total_minute:,}봉 "
         f"· 용량 {total_size / 1024 / 1024:.1f}MB")
    _log(f"  거래일 달력: {len(calendar)}일 ({calendar[0] if calendar else '-'} ~ "
         f"{calendar[-1] if calendar else '-'})")
    _log(f"  유니버스 {len(univ)}종목 · 폐지 등록 {len(dead)}종목")

    _log(f"\n🔎 [문제 분류]  (폐지 {len(dead)}종목은 제외하고 집계)")
    _log(f"  ① 파일 자체 없음        : {len(missing)}종목")
    _log(f"  ② 일봉 30봉 미만        : {len(few_bars)}종목")
    _log(f"  ③ 최신 아님(7일+)       : {len(stale)}종목")
    _log(f"  ④ 중간 갭 {args.gap_limit}일 이상     : {len(gap_syms)}종목")
    _log(f"  ⑤ 값 오류/중복 날짜     : {len(bad_syms)}종목")
    _log(f"  ⑥ 분봉 없음            : {len(no_minute)}종목 (분봉은 매일 자동 누적 - 참고용)")
    _log(f"  ⑦ 열리지 않는 파일      : {len(broken)}개")

    def _show(title, items, fmt):
        if items:
            _log(f"\n  {title} (상위 10):")
            for it in items[:10]:
                _log(f"    {fmt(it)}")
            if len(items) > 10:
                _log(f"    ... 외 {len(items) - 10}개")

    _show("① 파일 없음", missing, lambda s: s)
    _show("② 봉 부족", sorted(few_bars, key=lambda x: x[1]), lambda x: f"{x[0]}: {x[1]}봉")
    _show("③ 오래됨", sorted(stale, key=lambda x: x[1]), lambda x: f"{x[0]}: 마지막 {x[1]}")
    _show("④ 중간 갭", sorted(gap_syms.items(), key=lambda x: -len(x[1])),
          lambda x: f"{x[0]}: {len(x[1])}일 빠짐 (예: {x[1][:3]})")
    _show("⑤ 값 오류", sorted(bad_syms, key=lambda x: -(x[1] + x[2])),
          lambda x: f"{x[0]}: 오류 {x[1]} · 중복 {x[2]}")
    _show("⑦ 파일 손상", broken, lambda x: f"{x[0]}: {x[1]}")

    # ── 판정 ──
    n_problem = len(missing) + len(few_bars) + len(stale) + len(gap_syms) + len(broken)
    _log("\n" + "=" * 64)
    if n_problem == 0:
        _log("✅ 판정: 일봉 데이터 완전 - 빠진 것 없음! 검증/전략 생성 진행 가능")
    elif n_problem <= 50:
        _log(f"🟡 판정: 경미한 문제 {n_problem}종목 - 아래 재수집 목록으로 채우면 완료")
    else:
        _log(f"🔴 판정: 문제 {n_problem}종목 - 재수집 필요")

    # ── 보고서 저장 ──
    report = {
        "checked_at": datetime.now().isoformat(),
        "totals": {"files": len(per), "daily_bars": total_daily,
                   "minute_bars": total_minute, "size_mb": round(total_size / 1048576, 1),
                   "calendar_days": len(calendar), "universe": len(univ), "dead": len(dead)},
        "missing_files": missing,
        "few_bars": dict(few_bars),
        "stale": dict(stale),
        "gaps": {s: g for s, g in gap_syms.items()},
        "bad_values": [{"symbol": s, "bad_ohlc": b, "dup": d} for s, b, d in bad_syms],
        "no_minute": no_minute[:500],
        "broken_files": [{"symbol": s, "error": e} for s, e in broken],
    }
    with open("data_audit_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=1)

    md = ["# 🩺 데이터 무결성 검사 보고서",
          f"검사 시각: {report['checked_at']}", "",
          f"- 종목 파일: {len(per):,}개 / 일봉 {total_daily:,}봉 / 분봉 {total_minute:,}봉 / "
          f"{report['totals']['size_mb']}MB",
          f"- 거래일 달력: {len(calendar)}일", "",
          "| 검사 | 결과 |", "|---|---|",
          f"| 파일 없음 | {len(missing)} |",
          f"| 봉 부족(<30) | {len(few_bars)} |",
          f"| 오래됨(7일+) | {len(stale)} |",
          f"| 중간 갭({args.gap_limit}일+) | {len(gap_syms)} |",
          f"| 값 오류/중복 | {len(bad_syms)} |",
          f"| 분봉 없음 | {len(no_minute)} |",
          f"| 파일 손상 | {len(broken)} |"]
    with open("data_audit_report.md", "w", encoding="utf-8") as f:
        f.write("\n".join(md))
    _log("📄 저장: data_audit_report.json · data_audit_report.md")

    # ── 재수집 목록 (--fix-list) ──
    refill = sorted(set(missing) | {s for s, _ in few_bars} | {s for s, _ in stale}
                    | set(gap_syms.keys()) | {s for s, _ in broken})
    if args.fix_list and refill:
        os.makedirs("strategy", exist_ok=True)
        with open(os.path.join("strategy", "audit_refill.json"), "w", encoding="utf-8") as f:
            json.dump(refill, f, ensure_ascii=False, indent=1)
        _log(f"🔧 재수집 대상 {len(refill)}종목 저장: strategy/audit_refill.json")
        _log("   → 해당 종목 data/stocks/{종목}.db 지우고 collect_data.py --once 하면 다시 받습니다")
        _log("   (갭만 있는 종목은 지우지 않아도 collect_data가 갭을 자동 보충)")


if __name__ == "__main__":
    main()
