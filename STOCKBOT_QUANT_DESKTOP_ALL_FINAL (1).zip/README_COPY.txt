StockBot Quant 전체 종목 화면 통합본

이번 압축파일 하나만 사용합니다. 이전 run_quant_research 파일이나 개별 파일을 섞지 않습니다.

1. 실행 중인 새 API/새 코어 창을 닫습니다. 기존 자동매매 프로그램도 실행하지 않은 상태로 둡니다.

2. 기존 quant_platform 폴더가 있으면 삭제하지 말고 이름만 바꿉니다.
   C:\Users\wowman\Desktop\StockBot\quant_platform
   -> quant_platform_mixed_old

3. 이 압축파일의 내용을 정확히 다음 프로젝트 루트에 풉니다.
   C:\Users\wowman\Desktop\StockBot\

   정상 경로:
   C:\Users\wowman\Desktop\StockBot\quant_platform\gui.py
   C:\Users\wowman\Desktop\StockBot\quant_platform\orchestrator.py
   C:\Users\wowman\Desktop\StockBot\quant_platform\all_runner.py
   C:\Users\wowman\Desktop\StockBot\quant_platform\order_gateway.py
   C:\Users\wowman\Desktop\StockBot\quant_platform\audit.py
   C:\Users\wowman\Desktop\StockBot\run_stockbot_gui.bat
   C:\Users\wowman\Desktop\StockBot\build_stockbot_quant.bat

   잘못된 경로:
   C:\Users\wowman\Desktop\StockBot\quant_platform\quant_platform\gui.py

4. 다음 항목은 보존합니다.
   trading.db
   data\stocks\
   data\quant_platform.sqlite3
   .env
   .venv\
   teams.py
   auto_pilot.py
   collect_data.py
   desktop_app.py

5. 화면 실행

   PowerShell:
   cd C:\Users\wowman\Desktop\StockBot
   .\run_stockbot_gui.bat

   창에서:
   - 선택 종목 실행: 입력한 종목 하나 실행
   - 전체 종목 실행: data\stocks\*.db와 canonical-only 종목 전체를 resumable batch로 처리
   - 전체 오류·안전 점검: 기존 DB·자료·주문 경로·환경 안전장치 감사
   - 중지: 현재 종목 완료 후 안전 중지

   전체 실행은 reports\all_run_state.json에 상태를 저장해
   다음 실행에서 완료된 종목을 건너뛰고 이어갑니다.

6. 리포트와 오류

   reports\RUN-*.json
   reports\ALL-*.json
   reports\all_run_state.json
   reports\integration_audit.json
   errors\latest.json
   errors\E-*.json

   오류번호 E-...와 errors\latest.json을 전달하면 발생 단계와 원인을 확인합니다.

7. EXE 빌드

   새 64비트 .venv에서:
   .\build_stockbot_quant.bat

   PyInstaller가 .venv에 없으면 자동 설치합니다.
   완료 후 StockBotQuant.exe가 프로젝트 루트에 생성됩니다.
   이후 StockBotQuant.exe를 더블클릭합니다.

현재 통합 실행기는 READ_ONLY_RESEARCH_ALL 모드이며 주문을 제출하지 않습니다.
주문 게이트웨이는 기본 OFF입니다. DRY_RUN/PAPER도 외부 주문 API를 호출하지 않습니다.
키움 원격 다운로드와 PAPER/SHADOW/실거래는 공식 API 및 별도 검증 후 연결합니다.
