"""
과거 일봉 데이터 백필(backfill) - 네이버 금융 공개 API
=====================================================
키움 계좌/키 불필요. 공개 API로 전 종목 과거 일봉(OHLCV)을 받아
data/ 날짜별 스냅샷 형식으로 저장합니다.

사용법:
    python backfill_history.py            # 전 종목 90일치 (약 15~30분)
    python backfill_history.py --days 30  # 30일치만 (빠름)
    python backfill_history.py --symbol 005930  # 삼성전자만

저장: data/snapshots_YYYY-MM-DD.db (가격/시고저/거래량/거래대금)
    -> 기존 검증 도구(프롬프트 전략 검증/날짜 검산)가 자동으로 사용
"""
import argparse
import os
from config import _env_int as _cfg_env_int
import re
import logging
import sys
import time
from datetime import datetime

import requests
import db
from config import CFG

logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger("backfill")

NAVER_URL = "https://fchart.stock.naver.com/sise.nhn"
HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

# ★ 실패 원인 집계 (네이버 차단/네트워크 진단용) - backfill() 결과에 포함
_FAIL_STATS = {"dns": 0, "http": {}, "timeout": 0, "other": 0}

# ★ 네이버 차단(빈 응답) 감지 → 이후 종목은 네이버 건너뛰고 키움 일봉으로만 수집
#   (차단 상태에서 네이버에 계속 요청하는 낭비 방지 - 배치마다 초기화돼 차단 풀리면 자동 복귀)
_NAVER_BLOCKED = {"count": 0, "mode": False}

# ★ 다음(카카오) 금융 폴백 상태 (2026-08-23 실측: 500봉/회, 코스피+코스닥 OK)
#   - 간격 없이 연속 호출하면 403 차단 (약 20~30초 후 자동 해제) → 0.7초 간격 필수
#   - 403 연속 8회면 이 배치에서 다음은 건너뜀 (배치마다 리셋)
#   - session: 브라우저처럼 쿠키를 먼저 받아두면 403 회피에 도움 (첫 호출 때 워밍업)
_DAUM_STATE = {"last_call": 0.0, "b403": 0, "skip": False,
               "session": None, "warmed": False, "cooldown_until": 0.0,
               "canary": None}

# ★ 죽은 종목(폐지/합병 - 어느 소스에서도 못 받음) 자동 등록 → 다음 배치부터 제외
#   파일: strategy/dead_symbols.json (수동 삭제하면 다시 시도)
_DEAD_PATH = "strategy/dead_symbols.json"


def _load_dead():
    try:
        import json, os
        if os.path.exists(_DEAD_PATH):
            with open(_DEAD_PATH, encoding="utf-8") as f:
                return set(json.load(f))
    except Exception:
        pass
    return set()


def _mark_dead(symbol, reason=""):
    """폐지/미지원 확정 종목 기록 - get_unfilled_symbols가 제외"""
    try:
        import json, os
        dead = _load_dead()
        if symbol in dead:
            return
        dead.add(symbol)
        os.makedirs("strategy", exist_ok=True)
        with open(_DEAD_PATH, "w", encoding="utf-8") as f:
            json.dump(sorted(dead), f, ensure_ascii=False, indent=1)
        log.info(f"💀 {symbol}: 폐지/미지원 종목으로 등록 ({reason}) - 이후 수집 제외")
    except Exception:
        pass


def prune_dead_list():
    """★ 폐지 목록 자기치유: 일봉 30봉+ 있는 종목은 폐지가 아님 → 목록에서 제거
    (순간 403 버스트로 멀쩡한 종목이 오등록된 경우 복구 - 107% 진행률 버그 원인)
    반환: 제거한 종목 수
    """
    import json, os, sqlite3
    dead = _load_dead()
    if not dead:
        return 0
    stocks_dir = os.path.join(db.DATA_DIR, "stocks")
    revived = []
    for sym in list(dead):
        p = os.path.join(stocks_dir, f"{sym}.db")
        if not os.path.exists(p):
            continue
        try:
            c = sqlite3.connect(p)
            r = c.execute("SELECT COUNT(*) FROM daily_bars").fetchone()
            c.close()
            if r and r[0] and r[0] >= 30:
                dead.discard(sym)
                revived.append(sym)
        except Exception:
            continue
    if revived:
        try:
            with open(_DEAD_PATH, "w", encoding="utf-8") as f:
                json.dump(sorted(dead), f, ensure_ascii=False, indent=1)
            log.info(f"♻️ 폐지 목록 정리: {len(revived)}종목은 데이터가 있어 복구 "
                     f"(순간 403 오등록이었음) - 남은 폐지 {len(dead)}종목")
        except Exception:
            pass
    return len(revived)


def _daum_canary():
    """★ 403이 IP 차단인지 '종목이 없어서'인지 구분 (다음은 폐지 종목에 403을 줌!)
    삼성전자(005930) 조회 → 200이면 IP는 정상 = 그 403은 종목 문제
    결과는 배치 동안 캐시 (canary: True=IP정상 / False=IP차단)
    """
    if _DAUM_STATE["canary"] is not None:
        return _DAUM_STATE["canary"]
    try:
        s = _daum_session()
        r = s.get("https://finance.daum.net/api/charts/A005930/days",
                  params={"limit": 2, "adjusted": "true"},
                  headers={"Referer": "https://finance.daum.net/quotes/A005930"},
                  timeout=10)
        ok = r.status_code == 200 and bool((r.json() or {}).get("data"))
    except Exception:
        ok = False
    _DAUM_STATE["canary"] = ok
    if ok:
        log.info("🐤 다음 카나리아(005930) 정상 - 403은 IP 차단이 아니라 '없는 종목' 응답임")
    else:
        log.warning("🐤 다음 카나리아(005930)도 실패 - IP 차단 상태")
    return ok


def _daum_session():
    """★ 다음 금융용 세션 - 첫 사용 시 메인 페이지에 들러 쿠키 획득 (브라우저 흉내)
    403(IP 평판 차단)은 쿠키 없는 '기계식 요청'일 때 잘 걸림 → 쿠키+세션 유지로 완화
    """
    if _DAUM_STATE["session"] is None:
        s = requests.Session()
        s.headers.update({
            "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                           "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"),
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "ko-KR,ko;q=0.9,en-US;q=0.8",
        })
        _DAUM_STATE["session"] = s
    if not _DAUM_STATE["warmed"]:
        try:
            # 메인 → 종목 페이지 순서로 방문 (쿠키 수집) - 실패해도 진행
            _DAUM_STATE["session"].get("https://finance.daum.net/", timeout=8)
            time.sleep(0.5)
        except Exception:
            pass
        _DAUM_STATE["warmed"] = True
    return _DAUM_STATE["session"]

# ★ 키움 폴백 실패 원인 로그 1회만 (같은 원인이 250개 반복 도배되지 않게)
_KW_FALLBACK_LOG = {}


def _fail_count(kind, detail=""):
    if kind == "dns":
        _FAIL_STATS["dns"] += 1
    elif kind == "http":
        _FAIL_STATS["http"][detail] = _FAIL_STATS["http"].get(detail, 0) + 1
    elif kind == "timeout":
        _FAIL_STATS["timeout"] += 1
    else:
        _FAIL_STATS["other"] += 1


def _http_get(url, params=None, tries=4, base_wait=1.5):
    """네이버 조회 헬퍼 - DNS/네트워크 일시 오류 대비 지수 백오프 재시도
    ★ 실패 원인을 _FAIL_STATS에 집계 (HTTP 4xx=차단, DNS=네트워크 문제 구분)
    """
    import time as _t
    last = None
    for attempt in range(tries):
        try:
            r = requests.get(url, params=params, headers=HEADERS, timeout=15)
            if r.status_code == 200:
                return r
            last = f"HTTP {r.status_code}"
            _fail_count("http", f"HTTP {r.status_code}")
        except requests.exceptions.Timeout:
            last = "타임아웃"
            _fail_count("timeout")
        except requests.exceptions.RequestException as e:
            last = str(e)[:80]
            # DNS 실패(11001)/연결 실패 구분 - 네이버 차단 vs 네트워크 문제
            _fail_count("dns" if ("Name or service" in str(e) or "getaddrinfo" in str(e)
                                 or "11001" in str(e)) else "other")
        wait = base_wait * (2 ** attempt)
        if attempt < tries - 1:
            _t.sleep(wait)
    log.warning(f"네이버 조회 실패({tries}회): {last}")
    return None


def fetch_daily(symbol: str, days: int = 90) -> list:
    """
    네이버 금융에서 일봉 조회 (DNS/네트워크 재시도 내장)
    반환: [{date, open, high, low, close, volume}, ...] 오래된순
    """
    r = _http_get(NAVER_URL, params={
        "symbol": symbol, "timeframe": "day",
        "count": str(days), "requestType": "0",
    })
    if r is None:
        return []
    items = re.findall(r'<item data="([^"]+)"', r.text)
    out = []
    for it in items:
        parts = it.split("|")
        if len(parts) < 6:
            continue
        try:
            d = parts[0]           # YYYYMMDD
            o = int(parts[1])
            h = int(parts[2])
            l = int(parts[3])
            c = int(parts[4])
            v = int(parts[5])
            out.append({"date": d, "open": o, "high": h, "low": l,
                        "close": c, "volume": v})
        except Exception:
            continue
    # 오래된순 정렬
    out.sort(key=lambda x: x["date"])
    # ★ HTTP 200인데 데이터가 없으면 = 네이버가 내용을 안 주는 차단(레이트리밋) 의심
    #   (403/429이 아니라 200 + 빈 응답으로 차단하는 경우가 많음 - 이번 사용자 사례)
    if not out and r.status_code == 200:
        _fail_count("http", "HTTP 200 빈응답(차단)")
        _NAVER_BLOCKED["count"] += 1
        if _NAVER_BLOCKED["count"] >= 10 and not _NAVER_BLOCKED["mode"]:
            _NAVER_BLOCKED["mode"] = True
            log.warning("🔴 네이버 연속 빈 응답 10회 - 이후 종목은 네이버 건너뛰고 키움 일봉(ka10081)으로만 수집 "
                        "(배치 끝나면 네이버 다시 확인)")
    return out

def fetch_daily_kiwoom(symbol: str, days: int = 90) -> list:
    """★ 키움 일봉 폴백 (ka10081) - 네이버 차단 시 사용자 PC에서 대체 수집
    - 키/계좌가 있어야 동작 (없으면 [] → 네이버 유지)
    - ⛔ mock 차트(가짜 랜덤)는 절대 사용하지 않음 (실제 데이터만 저장 - 거짓 없는 원칙)
    - ★ 파라미터 변형 재시도: 모의 서버가 특정 조합에만 데이터를 주는 경우 대응
      (base_dt/tic_cnt/upd_stkpc_tp 조합을 여러 개 시도 - 첫 성공 시 반환)
    - ★ 진단 로그: return_code/배열 길이/유효 항목 수 (그래도 0봉이면 원인 확정용)
    반환: [{date, open, high, low, close, volume, amount}, ...] 오래된순 / [] (불가)
    """
    from kiwoom_client import client as _kc
    # 1) 키/계좌 상태 확인 (왜 폴백이 안 되는지 - 같은 원인은 1번만 로그)
    def _once(kind, msg):
        if kind not in _KW_FALLBACK_LOG:
            _KW_FALLBACK_LOG[kind] = True
            log.warning(msg)
    if getattr(_kc, "_is_dry_mock_no_key", lambda: True)():
        _once("dry_mock_no_key",
              "🔸 키움 폴백 불가: DRY_RUN=true + 키 미설정 상태 → 가짜 데이터 방지 위해 스킵 "
              "(.env에 APP_KEY/APP_SECRET 넣거나 DRY_RUN=false로)")
        return []
    if getattr(_kc, "_is_mock_token", False):
        _once("mock_token",
              "🔸 키움 폴백 불가: mock 토큰 상태 (키 인증 실패 - 키/서버 확인 필요)")
        return []
    if not getattr(CFG, "APP_KEY", None) or not getattr(CFG, "APP_SECRET", None):
        _once("no_key", "🔸 키움 폴백 불가: APP_KEY/SECRET 미설정 (네이버가 풀릴 때까지 대기)")
        return []

    # 2) 파라미터 변형 조합 시도 (모의 서버 대응)
    #    (오늘/직전거래일, tic_cnt 500/100/30, 수정주가 1/0)
    combos = []
    try:
        from db import now_kst as _nk
        today = _nk().strftime("%Y%m%d")
        from datetime import timedelta as _td
        prev = (_nk() - _td(days=1)).strftime("%Y%m%d")
    except Exception:
        from datetime import datetime, timedelta
        today = datetime.now().strftime("%Y%m%d")
        prev = (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    combos = [
        {"date": "", "tic_cnt": 500, "upd": 1, "raw": False},   # 기본 (주말 보정+500)
        {"date": today, "tic_cnt": 100, "upd": 1, "raw": True}, # 오늘+100 (보정 없음)
        {"date": prev, "tic_cnt": 100, "upd": 1, "raw": True},  # 전날+100
        {"date": today, "tic_cnt": 30, "upd": 0, "raw": True},  # 오늘+30+원주가
        {"date": prev, "tic_cnt": 500, "upd": 1, "raw": True},  # 전날+500
    ]

    last_chart = None
    last_diag = ""
    for ci, c in enumerate(combos):
        try:
            chart = _kc.get_chart_daily(symbol, date=c["date"], tic_cnt=c["tic_cnt"],
                                        upd_stkpc_tp=c["upd"], raw_base_dt=c["raw"])
        except Exception as e:
            _once("exc", f"🔸 키움 일봉 조회 예외: {str(e)[:80]} (키/서버/계좌 확인)")
            return []
        if not isinstance(chart, dict):
            continue
        last_chart = chart
        # ⛔ mock 차트(가짜 랜덤) 방어 - 절대 저장 금지
        if chart.get("mock"):
            _once("mock_chart", "🔸 키움 일봉이 mock 응답(가짜) - 저장 안 함 (키 인증이 안 되는 상태)")
            return []
        # ★ 에러 응답이면 다음 조합으로 (로그는 1번만)
        rc = chart.get("return_code")
        rm = chart.get("return_msg")
        if rc not in (0, None):
            if ci == 0:
                _once("rc", f"🔸 키움 일봉 조회 에러: return_code={rc} {rm} "
                            f"(모의 서버엔 모의용 키 · dmst_stex_tp 포함 확인)")
            continue
        # 3) 배열 찾기 (output2/output/stk_dt_pole_chart_qry/... + 중첩 재귀)
        lst = None
        for k in ("output2", "output", "stk_dt_pole_chart_qry", "output1", "rs", "data", "list"):
            v = chart.get(k)
            if isinstance(v, list) and v:
                lst = v
                break
        if lst is None:
            def _find_list(obj, depth=0):
                if depth > 4:
                    return None
                if isinstance(obj, dict):
                    for v in obj.values():
                        r = _find_list(v, depth + 1)
                        if r:
                            return r
                elif isinstance(obj, list) and obj and all(isinstance(x, dict) for x in obj):
                    return obj
                return None
            lst = _find_list(chart)
        if not lst:
            if ci == 0:
                _once("parse", f"🔸 키움 일봉 응답 파싱 실패 (응답 키: {list(chart.keys())[:8]}) - "
                               f"키움 응답 구조 확인 필요")
            continue
        # 4) 관대한 필드 자동 탐지 파싱 (키움/한투/영문/한글 어떤 응답이든 대응)
        out = _parse_kiwoom_candles(lst)
        # 5) 첫 조합 + 0봉이면 진단 로그 (return_code/배열 길이/유효 항목)
        if ci == 0 and not out and not _KW_FALLBACK_LOG.get("_diag_done"):
            _KW_FALLBACK_LOG["_diag_done"] = True
            n_empty = sum(1 for x in lst if isinstance(x, dict) and not any(
                str(v).strip() for v in x.values()))
            log.warning(f"🔍 [키움응답 진단] {symbol} 응답 키: {list(chart.keys())[:10]} "
                        f"· return_code={rc} · 배열 {len(lst)}개 · 빈 항목 {n_empty}개")
            if lst and isinstance(lst[0], dict):
                log.warning(f"🔍 [키움응답 진단] 첫 항목 키: {list(lst[0].keys())[:15]}")
                log.warning(f"🔍 [키움응답 진단] 첫 항목: {str(lst[0])[:250]}")
            log.warning(f"🔍 [키움응답 진단] 조합 {len(combos)}개 모두 시도 - 전부 0봉이면 "
                        f"모의 서버가 일봉을 안 주는 것 (실전 서버/네이버 대기 필요)")
        if out:
            return out
    # 6) 모든 조합 실패 - 마지막 응답 기준 진단
    if not _KW_FALLBACK_LOG.get("_diag_all"):
        _KW_FALLBACK_LOG["_diag_all"] = True
        log.warning(f"🔸 키움 일봉 {symbol}: 파라미터 {len(combos)}개 조합 모두 0봉 - "
                    f"모의 서버가 일봉 데이터를 제공하지 않는 것으로 보임. "
                    f"네이버 차단이 풀리면(공유기 재부팅) 다시 받거나, 실전 서버 조회 필요")
    return []


def _parse_kiwoom_candles(lst):
    """키움 응답 항목 배열 → 일봉 dict 목록 (관대한 필드 자동 탐지)
    반환: [{date, open, high, low, close, volume, amount}, ...] 오래된순 / []
    """
    import re as _re
    def _pick(c, *keys):
        for k in keys:
            v = c.get(k)
            if v not in (None, ""):
                return str(v)
        low = {str(k).lower().replace("_", ""): v for k, v in c.items()}
        for k in keys:
            key = k.lower().replace("_", "")
            if key in low and low[key] not in (None, ""):
                return str(low[key])
        return ""
    def _num(c, *keys):
        s = _pick(c, *keys).replace(",", "").replace("+", "").strip()
        if not s:
            return 0
        try:
            return int(float(s))
        except Exception:
            m = _re.search(r"-?\d+", s)
            return int(m.group()) if m else 0
    out = []
    for c in lst:
        if not isinstance(c, dict):
            continue
        date = _pick(c, "stck_bsop_date", "stk_bsop_date", "bsop_date", "date",
                     "trade_date", "ymd", "dt", "day", "일자")
        d_digits = "".join(ch for ch in date if ch.isdigit())
        if len(d_digits) != 8:
            continue
        date = d_digits
        cl = _num(c, "stck_clpr", "stk_clpr", "close_prc", "cur_prc", "close",
                  "현재가", "종가", "price")
        if cl <= 0:
            continue
        o = _num(c, "stck_oprc", "stk_oprc", "open_prc", "open_pric", "open", "시가")
        h = _num(c, "stck_hgpr", "stk_hgpr", "high_prc", "high_pric", "high", "고가")
        l = _num(c, "stck_lwpr", "stk_lwpr", "low_prc", "low_pric", "low", "저가")
        v = _num(c, "cntg_vol", "acml_vol", "stck_vol", "trde_qty", "volume",
                 "vol", "거래량")
        amt = _num(c, "acml_tr_pbmn", "trd_amt", "trde_prica", "amount", "거래대금")
        out.append({"date": date, "open": o or cl, "high": h or cl,
                    "low": l or cl, "close": cl, "volume": v,
                    "amount": amt, "source": "kiwoom"})
    out.sort(key=lambda x: x["date"])
    return out


def fetch_daily_yahoo(symbol: str, days: int = 90) -> list:
    """★ Yahoo Finance 일봉 폴백 - 네이버/키움 실패 시 (키 없음, 전 세계 무료)
    - 코스피: {code}.KS, 코스닥: {code}.KQ (market 자동 판별)
    - range: days에 따라 자동 (최대 8년치) - 네이버보다 긴 기간 가능
    - 날짜: KST 기준 (UTC 00:00 → KST 09:00 당일 = 한국 거래일)
    - 반환: [{date, open, high, low, close, volume, amount}, ...] 오래된순 / [] (불가)
    """
    try:
        import requests as _req
        from datetime import timezone, timedelta as _td, datetime as _dt
        # 시장 판별 (코스피 .KS / 코스닥 .KQ)
        market = "KS"
        try:
            for u in db.get_universe():
                if u.get("symbol") == symbol:
                    mk = (u.get("market") or "").upper()
                    if mk == "KOSDAQ":
                        market = "KQ"
                    elif mk in ("KOSPI", "KRX"):
                        market = "KS"
                    break
        except Exception:
            pass
        ticker = f"{symbol}.{market}"
        # days → range 문자열 (Yahoo 규격)
        rng = "max"
        if days and 0 < days <= 30:
            rng = "1mo"
        elif days and days <= 90:
            rng = "3mo"
        elif days and days <= 180:
            rng = "6mo"
        elif days and days <= 400:
            rng = "1y"
        elif days and days <= 800:
            rng = "2y"
        r = _req.get(f"https://query1.finance.yahoo.com/v8/finance/chart/{ticker}",
                     params={"range": rng, "interval": "1d"}, headers=HEADERS, timeout=15)
        if r.status_code != 200:
            _fail_count("http", f"HTTP {r.status_code}")
            return []
        j = r.json()
        res = (j.get("chart", {}) or {}).get("result")
        if not res:
            return []  # 상장폐지/미지원 종목
        r0 = res[0]
        ts = r0.get("timestamp") or []
        q = (r0.get("indicators", {}) or {}).get("quote", [{}])[0]
        kst = timezone(_td(hours=9))
        closes = q.get("close") or []
        opens = q.get("open") or []
        highs = q.get("high") or []
        lows = q.get("low") or []
        vols = q.get("volume") or []
        out = []
        for i, t in enumerate(ts):
            if i >= len(closes):
                break
            close = closes[i]
            if close in (None, 0):
                continue
            d = _dt.fromtimestamp(t, tz=timezone.utc).astimezone(kst).strftime("%Y%m%d")
            open_ = opens[i] if i < len(opens) and opens[i] else close
            high = highs[i] if i < len(highs) and highs[i] else close
            low = lows[i] if i < len(lows) and lows[i] else close
            vol = int(vols[i]) if i < len(vols) and vols[i] else 0
            out.append({"date": d, "open": int(open_), "high": int(high),
                        "low": int(low), "close": int(close), "volume": vol,
                        "amount": int(close * vol), "source": "yahoo"})
        out.sort(key=lambda x: x["date"])
        return out[-days:] if days and days > 0 else out
    except Exception as e:
        log.warning(f"Yahoo 일봉 실패({symbol}): {str(e)[:80]}")
        return []


def fetch_daily_daum(symbol: str, days: int = 90) -> list:
    """★ 다음(카카오) 금융 일봉 폴백 - 네이버 차단 시 1순위 대체 (키 없음)
    - 2026-08-23 실측: 1회 최대 500봉 (limit>500은 403) · 코스피+코스닥 전부 OK
    - ⚠️ 간격 없이 연속 호출하면 403 (약 20~30초 뒤 자동 해제) → 호출 간 0.7초 강제
    - 403 연속 8회면 이 배치에서 다음은 건너뜀 (_DAUM_STATE.skip - 배치마다 리셋)
    반환: [{date, open, high, low, close, volume, amount}, ...] 오래된순 / []
    """
    import time as _t
    # ★ 쿨다운 중이면 대기 후 재개 (403 다발 시 60초 쉬면 풀리는 경우 많음)
    if _DAUM_STATE["skip"]:
        if _t.time() < _DAUM_STATE["cooldown_until"]:
            return []
        # 쿨다운 종료 → 재시도 모드 (세션도 새로 - 쿠키 갱신)
        _DAUM_STATE["skip"] = False
        _DAUM_STATE["b403"] = 0
        _DAUM_STATE["session"] = None
        _DAUM_STATE["warmed"] = False
        log.warning("🟡 다음 금융 쿨다운 종료 - 새 세션으로 재시도")
    # ★ 최소 호출 간격 0.7초 (다음은 버스트에 민감 - 실측으로 확인)
    gap = _t.time() - _DAUM_STATE["last_call"]
    if gap < 0.7:
        _t.sleep(0.7 - gap)
    try:
        s = _daum_session()
        h = {"Referer": f"https://finance.daum.net/quotes/A{symbol}"}
        limit = max(1, min(days, 500))  # 1회 최대 500봉 (그 이상은 403)
        url = f"https://finance.daum.net/api/charts/A{symbol}/days"
        params = {"limit": limit, "adjusted": "true"}
        r = s.get(url, params=params, headers=h, timeout=12)
        _DAUM_STATE["last_call"] = _t.time()
        if r.status_code == 403:
            # ★★ 중요 발견(2026-08-23 실측): 다음은 폐지/합병/없는 종목에 404가 아니라
            #    403을 반환함! (999999도 403) → 카나리아(005930)로 IP 차단과 구분
            # ★ 오등록 방지: 순간 버스트 403일 수도 있으므로 3초 후 같은 종목 재확인,
            #   두 번 다 403 + 카나리아 정상일 때만 폐지 처리
            if _daum_canary():
                _t.sleep(3.0)
                r2 = s.get(url, params=params, headers=h, timeout=12)
                _DAUM_STATE["last_call"] = _t.time()
                if r2.status_code == 200:
                    r = r2   # 순간 차단이었음 - 정상 진행
                else:
                    # IP 정상 + 2회 연속 403 = 이 종목이 다음에 없는 것 (폐지/합병)
                    _fail_count("http", "403=폐지/미지원(다음)")
                    _mark_dead(symbol, "다음 403 2회 + 카나리아 정상")
                    return []
            else:
                # 진짜 IP 차단 → 10초 쉬고 + 종목 페이지 방문(쿠키 재획득) 후 1회 재시도
                _t.sleep(10.0)
                try:
                    s.get(f"https://finance.daum.net/quotes/A{symbol}", timeout=8)
                    _t.sleep(1.0)
                except Exception:
                    pass
                r = s.get(url, params=params, headers=h, timeout=12)
                _DAUM_STATE["last_call"] = _t.time()
        if r.status_code == 403:
            _DAUM_STATE["b403"] += 1
            _fail_count("http", "HTTP 403(다음)")
            if _DAUM_STATE["b403"] >= 8 and not _DAUM_STATE["skip"]:
                # ★ 60초 쿨다운 후 자동 재시도 (배치 끝까지 포기하지 않음)
                _DAUM_STATE["skip"] = True
                _DAUM_STATE["cooldown_until"] = _t.time() + 60.0
                log.warning("🔴 다음 금융 403 연속 8회 - 60초 쿨다운 후 새 세션으로 자동 재시도")
            else:
                _t.sleep(2.0)
            return []
        if r.status_code != 200:
            _fail_count("http", f"HTTP {r.status_code}(다음)")  # 404 = 상장폐지 등
            return []
        _DAUM_STATE["b403"] = 0
        data = (r.json() or {}).get("data") or []
        out = []
        for c in data:
            d = str(c.get("date") or "")[:10].replace("-", "")
            if len(d) != 8:
                continue
            cl = c.get("tradePrice") or 0
            if not cl:
                continue
            cl = int(cl)
            o = int(c.get("openingPrice") or 0) or cl
            hi = int(c.get("highPrice") or 0) or cl
            lo = int(c.get("lowPrice") or 0) or cl
            v = int(c.get("candleAccTradeVolume") or 0)
            amt = int(c.get("candleAccTradePrice") or 0) or cl * v
            out.append({"date": d, "open": o, "high": hi, "low": lo,
                        "close": cl, "volume": v, "amount": amt, "source": "daum"})
        out.sort(key=lambda x: x["date"])
        return out
    except Exception as e:
        log.warning(f"다음 일봉 실패({symbol}): {str(e)[:80]}")
        return []


def fetch_daily_retry(symbol, days=90, tries=2):
    """일봉 fetch + 실패 시 재시도.
    ★ 폴백 체인: 네이버 → 다음(카카오, 500봉) → Yahoo(최대 8년) → 키움(ka10081)
    ★ 네이버 차단 모드(빈 응답 10회+)면 네이버를 건너뛰고 바로 다음/Yahoo/키움으로
    """
    daum_on = getattr(CFG, "BACKFILL_FALLBACK_DAUM", True)
    yahoo_on = getattr(CFG, "BACKFILL_FALLBACK_YAHOO", True)
    kiwoom_on = getattr(CFG, "BACKFILL_FALLBACK_KIWOOM", True)
    # 네이버 차단 모드 → 네이버 요청 생략, 바로 다음(카카오) → Yahoo
    if _NAVER_BLOCKED["mode"]:
        if daum_on:
            dm = fetch_daily_daum(symbol, days=days)
            if dm:
                if not _KW_FALLBACK_LOG.get("_daum_note"):
                    _KW_FALLBACK_LOG["_daum_note"] = True
                    log.warning(f"🔄 네이버 차단 → 다음(카카오) 일봉 폴백으로 수집 중 (첫 종목 {symbol}: {len(dm)}봉)")
                return dm
        if yahoo_on:
            yh = fetch_daily_yahoo(symbol, days=days)
            if yh:
                log.warning(f"🔄 {symbol}: 네이버 차단 → Yahoo 일봉 폴백 {len(yh)}봉")
                return yh
        if kiwoom_on:
            kw = fetch_daily_kiwoom(symbol, days=days)
            if kw:
                return kw
        return []
    for attempt in range(1, tries + 1):
        rows = fetch_daily(symbol, days=days)
        if rows:
            return rows
        if attempt < tries:
            time.sleep(1.0)
    # ★ 네이버 차단/빈 응답 → 다음(카카오) 폴백 (키 없음, 500봉)
    if daum_on:
        dm = fetch_daily_daum(symbol, days=days)
        if dm:
            log.warning(f"🔄 {symbol}: 네이버 실패 → 다음(카카오) 일봉 폴백 {len(dm)}봉")
            return dm
    # ★ 그다음 Yahoo (키 없음, 8년치 - 단, 당일봉 지연 가능)
    if yahoo_on:
        yh = fetch_daily_yahoo(symbol, days=days)
        if yh:
            log.warning(f"🔄 {symbol}: 네이버/다음 실패 → Yahoo 일봉 폴백 {len(yh)}봉")
            return yh
    # ★ 마지막 키움 (실전 키가 있으면 실제 데이터, mock이면 빈 값 → 무시)
    if kiwoom_on:
        kw = fetch_daily_kiwoom(symbol, days=days)
        if kw:
            log.warning(f"🔄 {symbol}: 네이버/다음/Yahoo 실패 → 키움 일봉 폴백 {len(kw)}봉")
            return kw
    return []


def save_daily_to_snapshots(symbol: str, days_list: list):
    """일봉 데이터를 날짜별 스냅샷 파일에 저장 (우리 형식으로)"""
    saved = 0
    for row in days_list:
        d = row["date"]  # YYYYMMDD
        date_iso = f"{d[:4]}-{d[4:6]}-{d[6:8]}"
        # ★ 종목별 저장(기본): data/stocks/{symbol}.db 에 일봉 누적 (조회/차트/검증 최적화)
        #   false면 날짜별 스냅샷 파일 유지 (기존 방식)
        if getattr(db, "STOCK_DIR_SAVE", True):
            db.record_stock_daily(symbol, date_iso, row["open"], row["high"], row["low"],
                                  row["close"], row["volume"], row["close"] * row["volume"],
                                  source="backfill")
        else:
            db.record_snapshot(
                symbol,
                row["close"],
                open_price=row["open"],
                high_price=row["high"],
                low_price=row["low"],
                volume=row["volume"],
                amount=row["close"] * row["volume"],
                source="backfill",
                bar_date=date_iso,
            )
        saved += 1
    return saved


def backfill(symbols=None, days=90, max_symbols=None, sleep_sec=None):
    """전 종목 백필 실행
    sleep_sec: 종목 간 대기(초) - 기본 0.3 (네이버 차단 방지, 천천히 안정적으로)
    ★ 실패 원인 집계 포함 (HTTP 4xx=네이버 차단 / DNS=네트워크 문제)
    """
    global _FAIL_STATS, _NAVER_BLOCKED, _KW_FALLBACK_LOG, _DAUM_STATE
    _FAIL_STATS = {"dns": 0, "http": {}, "timeout": 0, "other": 0}
    # ★ 배치마다 네이버 차단 카운터 리셋 → 차단이 풀렸으면 이 배치에서 다시 네이버 사용
    _NAVER_BLOCKED = {"count": 0, "mode": False}
    _KW_FALLBACK_LOG = {}
    # ★ 다음(카카오) 폴백 상태도 배치마다 리셋 (403 스킵 해제 + 새 세션 - 다시 시도)
    _DAUM_STATE = {"last_call": 0.0, "b403": 0, "skip": False,
                   "session": None, "warmed": False, "cooldown_until": 0.0,
                   "canary": None}
    if symbols is None:
        univ = db.get_universe(market="KOSPI") + db.get_universe(market="KOSDAQ")
        symbols = [u["symbol"] for u in univ]
    if max_symbols:
        symbols = symbols[:max_symbols]
    # ★ 기본 간격 0.5초 (0.3초로 1300종목쯤에서 IP 차단된 사례 - 예방적으로 상향, env로 조절)
    if sleep_sec is None:
        sleep_sec = float(getattr(CFG, "BACKFILL_SLEEP_SEC", 0.5))

    total_saved = 0
    ok_cnt = 0
    fail_cnt = 0
    t0 = time.time()
    log.info(f"=== 과거 일봉 백필 시작: {len(symbols)}종목 × {days}일 (간격 {sleep_sec}s) ===")
    log.info(f"출처: 네이버 금융 공개 API (키움 계좌 불필요) - 범위: 제일 뒷날 ~ 오늘")
    range_logged = False
    # ★ 개장 자동 중단: 수집 중 09:00이 되면 멈추고 매매에 양보 (BACKFILL_STOP_AT_OPEN)
    #   사용자 사고: 밤새 라운드가 아침까지 이어져 9시에 매수가 안 돌던 문제의 원인
    stop_at_open = os.getenv("BACKFILL_STOP_AT_OPEN", "true").lower() == "true"

    def _market_open_now():
        try:
            from db import is_trading_day
            now = db.now_kst()
            return (is_trading_day(now.date())
                    and (9 <= now.hour < 15 or (now.hour == 15 and now.minute <= 20)))
        except Exception:
            return False

    for i, sym in enumerate(symbols):
        # 50종목마다 개장 여부 확인 → 개장했으면 수집 중단 (받은 것은 저장됨)
        if stop_at_open and i % 50 == 0 and i > 0 and _market_open_now():
            log.info(f"⏰ 장 시작 감지 - 수집 중단({i}/{len(symbols)}) → 매매 우선 "
                     f"(나머지는 장마감 후 자동 이어받기)")
            break
        days_list = fetch_daily_retry(sym, days, tries=2)  # 실패 시 1회 재시도 (빈 곳 없이)
        if days_list:
            if not range_logged and days_list:
                range_logged = True
                log.info(f"  📅 일봉 범위: {days_list[0]['date']} ~ {days_list[-1]['date']} "
                         f"({len(days_list)}봉 = 받을 수 있는 최대)")
            n = save_daily_to_snapshots(sym, days_list)
            total_saved += n
            ok_cnt += 1
        else:
            fail_cnt += 1
        # ★ 실시간 한 줄 진행 표시 (남은 시간 포함) - '진짜 진행 중인지' 보이게
        #   ★ exe(--noconsole)에서는 sys.stdout이 None → write 시 크래시 방지 (자동 파일럿 오류 원인)
        el = time.time() - t0
        eta = ""
        if i >= 4 and el > 2:
            per = el / (i + 1)
            eta = f" · 남은 {int(per * (len(symbols) - i - 1) // 60)}분"
        src = days_list[0].get("source", "naver") if days_list else "-"
        if sys.stdout is not None:
            try:
                sys.stdout.write(f"\r  ⏳ {i+1}/{len(symbols)} {sym}({src}) · 성공 {ok_cnt} · "
                                 f"실패 {fail_cnt} · {total_saved:,}봉 · {el:.0f}초{eta}   ")
                sys.stdout.flush()
                if (i + 1) % 200 == 0 or i == len(symbols) - 1:
                    print()   # 200개마다 줄 고정 (스크롤 기록용)
            except Exception:
                pass
        elif (i + 1) % 200 == 0 or i == len(symbols) - 1:
            # 콘솔 없는 환경(exe): 200개마다 로그로만
            log.info(f"진행 {i+1}/{len(symbols)} · 성공 {ok_cnt} · 실패 {fail_cnt} · {total_saved:,}봉")
        time.sleep(sleep_sec)  # 네이버 과부하/레이트리밋 방지 (실패 줄이기)

    el = time.time() - t0
    log.info(f"=== 완료: {ok_cnt}종목 성공 / {fail_cnt} 실패 / {total_saved}봉 저장 "
             f"({el/60:.1f}분) ===")
    # 실패 원인 요약 (진단용)
    fs = _FAIL_STATS
    parts = []
    if fs["dns"]:
        parts.append(f"DNS/네트워크 {fs['dns']}")
    if fs["timeout"]:
        parts.append(f"타임아웃 {fs['timeout']}")
    if fs["http"]:
        for code, n in sorted(fs["http"].items()):
            parts.append(f"{code} {n}")
    if fs["other"]:
        parts.append(f"기타 {fs['other']}")
    if fail_cnt:
        log.info(f"⚠️ 실패 원인: {' · '.join(parts) if parts else '알 수 없음'}")
        if any(c.startswith("HTTP 4") for c in fs["http"]):
            log.info("⚠️ HTTP 4xx 다수 = 네이버가 요청을 차단(레이트리밋) 중 → 잠시 멈췄다 다시 시도하세요")
        if fs["dns"] > fail_cnt * 0.5:
            log.info("⚠️ DNS 실패 다수 = 네이버 도메인 해석 불가 → 인터넷/DNS 확인 (브라우저에서 fchart.stock.naver.com 접속 확인)")
    return {"symbols_ok": ok_cnt, "fail": fail_cnt, "bars": total_saved}


def get_unfilled_symbols(max_n=None):
    """
    ★ 받아야 할 종목: (미수신 종목 + 날짜 갭 있는 종목) 합집합 - 중복 방지
    - 미수신: 종목별 파일(data/stocks/*.db)이 없으면 아직 1회도 안 받음
    - 날짜 갭: 종목별 파일은 있는데 최근 BACKFILL_DAYS 중 빠진 날짜가 있으면
      (오류/중단으로 빈 곳) → 다시 받아서 채움 (REPLACE라 안전, 이미 있는 날짜는 유지)
    - 분봉은 bar_time UNIQUE로 자연 누적 (매일 7일치가 밀려 쌓임, 삭제 안 함)
    """
    import sqlite3, os
    # ★ market 라벨(KOSPI/KOSDAQ/KRX/빈값)과 무관하게 전 종목을 대상으로 함
    #   (키움 ka10099로 유니버스가 market='KRX'로 덮이면 KOSPI/KOSDAQ 조회가 빈 목록이
    #    되어 "받을 종목 0개"로 오판 → 일봉 완료 처리되는 버그 방지)
    univ = [u for u in db.get_universe() if (u.get("market") or "").upper() != "KONEX"]
    all_syms = [u["symbol"] for u in univ if u.get("symbol")]

    stocks_dir = os.path.join(db.DATA_DIR, "stocks")
    have = set()
    gaps = set()
    if db.STOCK_DIR_SAVE and os.path.isdir(stocks_dir):
        for f in os.listdir(stocks_dir):
            if not f.endswith(".db"):
                continue
            sym = f[:-3]
            have.add(sym)
            # 빈 곳/갭 확인: 일봉이 30봉 미만이면 (오류·중단으로 일부만 받음) → 다시 받기
            #   (정상 완료 시 90일치가 한 번에 들어옴 - 30봉 미만은 비정상)
            try:
                c = sqlite3.connect(os.path.join(stocks_dir, f))
                try:
                    r = c.execute("SELECT COUNT(*), MAX(bar_date) FROM daily_bars").fetchone()
                except Exception:
                    r = None
                c.close()
                cnt = (r[0] or 0) if r else 0
                last = (r[1] or "") if r else ""
                # ★ 최신성 검사: 마지막 봉이 오래됐으면 갱신 필요
                #   2026-09-02: 7일→3일로 강화 (사용자: "예전 자료만 있음" -
                #   7일 기준이면 일주일 묵은 일봉도 '최신' 오판 → 매일 갱신 안 됨)
                #   주말+공휴일 여유 3일 (금요일봉이 월요일에도 유효)
                from datetime import datetime as _dt, timedelta as _td
                _fresh_days = _cfg_env_int("BACKFILL_FRESH_DAYS", 3)
                fresh_cut = (_dt.now() - _td(days=_fresh_days)).strftime("%Y-%m-%d")
                if cnt >= 30 and last >= fresh_cut:
                    have.add(sym)  # 충분 + 최신
                else:
                    gaps.add(sym)  # 부족하거나 오래됨 → 다시 받기 (갭/최신 보충)
            except Exception:
                continue
    else:
        # 날짜별 파일 폴백 (기존 방식)
        data_dir = db.DATA_DIR
        if os.path.exists(data_dir):
            for f in os.listdir(data_dir):
                if f.startswith("snapshots_") and f.endswith(".db"):
                    try:
                        c = sqlite3.connect(os.path.join(data_dir, f))
                        cols = [r[1] for r in c.execute("PRAGMA table_info(market_snapshots)")]
                        if "source" in cols:
                            rows = c.execute(
                                "SELECT DISTINCT symbol FROM market_snapshots WHERE source='backfill'").fetchall()
                        else:
                            rows = c.execute("SELECT DISTINCT symbol FROM market_snapshots").fetchall()
                        for r in rows:
                            have.add(r[0])
                        c.close()
                    except Exception:
                        continue

    # ★ 죽은 종목(폐지/합병 - 다음 403+카나리아 정상으로 확정) 제외
    #   (strategy/dead_symbols.json 삭제하면 다시 시도)
    prune_dead_list()   # ★ 오등록 자기치유 (데이터 있는 종목은 폐지 목록에서 제거)
    dead = _load_dead()
    unfilled = []
    for s in all_syms:
        if s in dead:
            continue
        if s not in have or s in gaps:
            unfilled.append(s)
    if max_n:
        unfilled = unfilled[:max_n]
    return unfilled


def auto_backfill(days=None, per_run=None):
    """★ 프로그램 자동 백필: 받아야 할 종목(미수신+갭)만 최대 per_run개 받기
    - 매일 호출하면 그날치 1일씩 계속 누적 (bar_date PK REPLACE라 기존 보존)
    - 오류/중단으로 빈 곳은 다음 호출에서 자동 메움 (get_unfilled_symbols가 갭도 대상)
    - 분봉도 같은 방식으로 매일 누적 (bar_time UNIQUE)
    """
    if days is None:
        days = CFG.BACKFILL_DAYS
    if per_run is None:
        per_run = CFG.BACKFILL_PER_RUN
    symbols = get_unfilled_symbols(max_n=per_run)
    if not symbols:
        result = {"symbols_ok": 0, "fail": 0, "bars": 0, "note": "이미 전 종목 백필 완료"}
    else:
        result = backfill(symbols=symbols, days=days)
    # ── 분봉 백필 (관심/보유 종목 위주 - 전 종목은 용량 초과) ──
    try:
        if getattr(CFG, "AUTO_BACKFILL_MINUTES", True):
            mres = backfill_minutes()
            result["minutes"] = (f"📈 분봉 백필: {mres.get('symbols_ok', 0)}종목 "
                                 f"{mres.get('bars', 0)}봉")
    except Exception as e:
        result["minutes"] = f"분봉 백필 오류: {e}"
    # ★ 마지막 백필 시각 기록 (상태/재시작 이어받기용)
    try:
        import json, os
        st_dir = "strategy"
        os.makedirs(st_dir, exist_ok=True)
        st = {}
        try:
            with open(os.path.join(st_dir, "backfill_state.json"), encoding="utf-8") as f:
                st = json.load(f)
        except Exception:
            pass
        st["last_backfill_at"] = db.now_kst_iso()
        st["last_symbols_ok"] = result.get("symbols_ok", 0)
        with open(os.path.join(st_dir, "backfill_state.json"), "w", encoding="utf-8") as f:
            json.dump(st, f, ensure_ascii=False, indent=2)
        # ★ 2026-09-02: 라운드 수집도 collect_data.log에 한 줄 기록
        #   (사용자: "collect_data.log 놀고 있음" - 실제 수집은 앱 라운드가 하는데
        #    일지는 옛 별도 수집기 것만 남아 '논다'고 보임 → 일지 통일)
        try:
            os.makedirs("logs", exist_ok=True)
            with open(os.path.join("logs", "collect_data.log"), "a", encoding="utf-8") as f:
                f.write(f"{db.now_kst_iso()} [앱 라운드 수집] "
                        f"일봉 {result.get('symbols_ok', 0)}종목 {result.get('bars', 0)}봉 "
                        f"{result.get('note', '')}\n")
        except Exception:
            pass
    except Exception:
        pass
    # ── ★ 자동 전략 생성: 30일+ 일봉이 충분한 종목 수가 모이면 자동 분석 → 프롬프트 갱신 ──
    try:
        if getattr(CFG, "AUTO_STRATEGY_GEN", True):
            from strategy_auto import maybe_auto_generate
            sr = maybe_auto_generate()
            if sr and sr.get("applied"):
                result["strategy"] = (f"🧠 자동 전략 생성·적용 완료: v{sr.get('version')} "
                                      f"'{sr.get('rule', {}).get('name', '')}' "
                                      f"(승률 {sr.get('rule', {}).get('win_rate', 0):.1f}% "
                                      f"· 손익비 {sr.get('rule', {}).get('pf', 0):.2f})")
            elif sr and sr.get("skipped"):
                result["strategy"] = f"전략 생성 대기: {sr.get('skipped')}"
            elif sr and not sr.get("ready"):
                result["strategy"] = (f"전략 생성 대기: 일봉 ≥{sr.get('min_days')}일 종목 "
                                      f"{sr.get('ready_count')}/{sr.get('target')}개")
    except Exception as e:
        result["strategy"] = f"전략 생성 오류: {e}"
    return result


# ── 분봉 백필 (네이버 분봉: 최근 약 1주일, 분당 종가+누적거래량) ──────────

def fetch_minutes(symbol: str, max_bars: int = 6000) -> list:
    r = _http_get(NAVER_URL, params={
        "symbol": symbol, "timeframe": "minute",
        "count": "500", "requestType": "0",
    })
    if r is None:
        return []
    items = re.findall(r'<item data="([^"]+)"', r.text)
    out = []
    prev_date = None
    prev_cum = 0
    for it in items:
        parts = it.split("|")
        if len(parts) < 6:
            continue
        dt_s = parts[0]  # YYYYMMDDHHMM
        if len(dt_s) != 12:
            continue
        try:
            price = int(parts[4])
            cum = int(parts[5])
            bar = datetime.strptime(dt_s, "%Y%m%d%H%M")
        except Exception:
            continue
        date_key = dt_s[:8]
        vol = max(0, cum - prev_cum) if date_key == prev_date else max(0, cum)
        prev_date = date_key
        prev_cum = cum
        out.append({"bar_time": bar, "price": price,
                    "cum_volume": cum, "volume": vol})
    out.sort(key=lambda x: x["bar_time"])
    return out[-max_bars:]

def fetch_minutes_kiwoom(symbol: str, minutes: int = 2000) -> list:
    """
    ★ 키움 분봉 보충 (ka10080) - 네이버가 안 주는 7일 이전 분봉
    - 사용자 PC에서 키움 키(모의/실전)가 있어야 동작 (없으면 mock/실패 → [] 반환, 자동 스킵)
    - 1회 최대 500봉, 페이지네이션으로 과거로 더 (req_cnt 500씩, 반복)
    - 네이버(7일)와 병합되어 1개월+ 분봉 확보 목적
    반환: [{bar_time(datetime), price, volume, cum_volume}...] 오래된순 (가능한 만큼)
    """
    from datetime import datetime as _dt
    from kiwoom_client import client as _kc
    # 키 없음(개발환경/mock) → 실제 데이터 아님, 스킵
    if getattr(_kc, "_is_dry_mock_no_key", lambda: True)() or getattr(_kc, "_is_mock_token", False):
        return []
    out = []
    seen = set()
    req = min(max(minutes, 1), 500)
    for _page in range(8):  # 최대 4000봉 (8페이지) - 과도한 요청 방지
        try:
            candles = _kc.get_minute_chart(symbol, minutes=req)
        except Exception as e:
            log.warning(f"키움 분봉 실패({symbol}): {e}")
            break
        if not candles:
            break
        added = 0
        for c in candles:
            t = c.get("time") or ""
            if len(t) != 12 or not t.isdigit():
                continue  # 시간 없으면 저장 불가 - 스킵
            try:
                bar = _dt.strptime(t, "%Y%m%d%H%M")
            except Exception:
                continue
            key = bar.isoformat()
            if key in seen:
                continue
            seen.add(key)
            price = c.get("price") or 0
            qty = c.get("qty") or 0
            amount = c.get("amount") or 0
            # 분당 거래량: qty 있으면 그대로, 없으면 amount/price
            vol = qty if qty else (amount / price if price > 0 else 0)
            out.append({"bar_time": bar, "price": price, "volume": vol, "cum_volume": 0})
            added += 1
        if added == 0:
            break
        # 페이지네이션: 가장 오래된 봉 이전부터 다시 요청하려면 date 기반 필요 - 여기선 1회로 한정
        break  # ★ 1회 요청(최대 500봉 ≈ 1거래일+)으로 제한 - 키움 레이트리밋 고려
    out.sort(key=lambda x: x["bar_time"])
    return out


def get_minute_symbols(max_n=None):
    """분봉 백필 대상 선정
    MINUTE_ALL=true  → 코스피+코스닥 전 종목 (KONEX 제외) - ★ 전 종목 분봉
    MINUTE_ALL=false → 설정(MINUTE_SYMBOLS) + 기본 유니버스 + 계좌 보유 종목
    반환: (uniq, source) — uniq: 종목코드 리스트, source: 대상 설명
    """
    from collections import OrderedDict
    uniq = OrderedDict()
    source_note = []

    # ★ 전 종목 모드: universe 전체 (코스피+코스닥, KONEX 제외)
    if getattr(CFG, "MINUTE_ALL", True):
        try:
            rows = db.get_universe()
            all_syms = [u["symbol"] for u in rows if u.get("market") != "KONEX"]
            if all_syms:
                for s in all_syms:
                    s = (s or "").strip().lstrip("A")
                    if s.isdigit() and len(s) == 6:
                        uniq[s] = "전체종목"
                return list(uniq.keys()), f"전체종목 {len(uniq)}종목 (MINUTE_ALL=true)"
        except Exception:
            pass
        # 종목 목록이 없으면 아래(유니버스+계좌)로 폴백

    def _add(s, src):
        s = (s or "").strip()
        # 'A' 접두어 제거 (계좌는 A005930, 시세는 005930)
        s = s.lstrip("A")
        if s.isdigit() and len(s) == 6 and s not in uniq:
            uniq[s] = src

    # 1) 설정 (MINUTE_SYMBOLS) - 최우선
    env_list = getattr(CFG, "MINUTE_SYMBOLS", "") or ""
    if env_list:
        for s in env_list.split(","):
            _add(s, "설정")
        if uniq:
            source_note.append(f"설정 {len(uniq)}종목")

    # 2) 기본 유니버스
    univ = list(getattr(CFG, "UNIVERSE", None) or [])
    for s in univ:
        _add(s, "유니버스")
    if univ:
        source_note.append(f"유니버스 {len(uniq)}종목")

    # 3) 계좌 실제 보유 종목 (실패 시 스킵 - 장외/DRY_RUN 무관)
    acc_syms = []
    try:
        from kiwoom_client import client
        ov = client.get_account_overview()
        if isinstance(ov, dict) and ov.get("positions"):
            acc_syms = [p.get("symbol", "") for p in ov["positions"][:20]]
    except Exception:
        pass
    if acc_syms:
        before = len(uniq)
        for s in acc_syms:
            _add(s, "계좌")
        source_note.append(f"계좌 보유 {len(uniq) - before}종목")

    # 4) ★ 매수 감시 풀 (급등/반등/저평가 후보) - 매일 장마감 후 그날 후보 분봉을 쌓아둠
    #    → 1개월 누적하면 "상위 후보 50종목의 분봉 1개월치" 테스트 데이터 확보
    try:
        import engine as _eng
        watch_syms = _eng.get_watch_candidates(limit=50)
        before = len(uniq)
        for c in watch_syms:
            _add(c.get("symbol", ""), "감시풀")
        if len(uniq) > before:
            source_note.append(f"감시풀 {len(uniq) - before}종목")
    except Exception:
        pass

    out = list(uniq.keys())
    if max_n:
        out = out[:max_n]
    return out, " + ".join(source_note) if source_note else "대상 없음"


def backfill_minutes(symbols=None, max_n=None):
    """분봉 백필 (네이버 공개 API) - 받을 수 있는 최대(7거래일, 제일 뒷날~오늘) 전부 저장
    반환: {"symbols_ok": n, "fail": n, "bars": n, "range": "..."}
    """
    if symbols is None:
        max_n = max_n or getattr(CFG, "MINUTE_MAX_SYMBOLS", 30)
        symbols, source_note = get_minute_symbols(max_n=max_n)
    else:
        source_note = "수동 지정"
    if not symbols:
        return {"symbols_ok": 0, "fail": 0, "bars": 0, "note": "분봉 대상 종목 없음"}
    ok = fail = total = 0
    t0 = time.time()
    log.info(f"=== 분봉 백필 시작: {len(symbols)}종목 ({source_note}) - 범위: 제일 뒷날~오늘(최대 7거래일) ===")
    log.info(f"   대상: {','.join(symbols)}")
    min_dt = max_dt = None
    target_days = int(getattr(CFG, "MINUTE_TARGET_DAYS", 22))
    for i, sym in enumerate(symbols):
        # ★ 이미 받은 분봉 날짜 (중복 방지 - 받은 건 더 받지 않음)
        have_dates = set(db.get_stock_minute_dates(sym)) if getattr(db, "STOCK_DIR_SAVE", True) else set()
        # ★ 한 달치(목표 거래일) 채워졌으면 그 종목은 스킵 (더 받을 필요 없음)
        if getattr(db, "STOCK_DIR_SAVE", True) and len(have_dates) >= target_days:
            ok += 1  # 이미 완료로 간주 (카운트만)
            continue
        rows = fetch_minutes(sym)
        # ★ 키움 보충: 네이버(7일) 이전 분봉 (키 있고 설정 on이면) - 한 달치 목표
        kw_rows = (fetch_minutes_kiwoom(sym, minutes=500)
                   if getattr(CFG, "KIWOOM_MINUTE_SUPPLEMENT", True) else [])
        if kw_rows:
            # 네이버 7일과 겹치는 시간 제외 + 이미 받은 날짜 제외 + 한 달치만
            nav_keys = set()
            for r in rows:
                nav_keys.add(r["bar_time"].strftime("%Y%m%d%H%M"))
            added_kw = 0
            for r in kw_rows:
                key = r["bar_time"].strftime("%Y%m%d%H%M")
                if key in nav_keys:
                    continue  # 네이버가 이미 가진 시간은 스킵
                if r["bar_time"].strftime("%Y-%m-%d") in have_dates:
                    continue  # ★ 이미 받은 날짜는 스킵 (받은 건 더 받지 않음)
                if getattr(db, "STOCK_DIR_SAVE", True):
                    db.record_stock_minute(sym, r["bar_time"].isoformat(), r["price"],
                                           r["volume"], r["cum_volume"])
                else:
                    db.record_minute_bar(sym, r["bar_time"], r["price"],
                                         r["volume"], r["cum_volume"])
                added_kw += 1
                total += 1
            if added_kw:
                log.info(f"  {sym}: 키움 보충 {added_kw}봉 (이전 분봉, 이미 받은 날짜 제외)")
        if rows:
            for r in rows:
                if getattr(db, "STOCK_DIR_SAVE", True):
                    db.record_stock_minute(sym, r["bar_time"].isoformat(), r["price"],
                                           r["volume"], r["cum_volume"])
                else:
                    db.record_minute_bar(sym, r["bar_time"], r["price"],
                                         r["volume"], r["cum_volume"])
                dt = r["bar_time"].strftime("%Y-%m-%d")
                if min_dt is None or dt < min_dt:
                    min_dt = dt
                if max_dt is None or dt > max_dt:
                    max_dt = dt
            ok += 1
            total += len(rows)
        else:
            fail += 1
        if (i + 1) % 10 == 0 or i == len(symbols) - 1:
            log.info(f"  진행 {i+1}/{len(symbols)} · 성공 {ok} · 실패 {fail} · "
                     f"저장 {total}봉 · {time.time()-t0:.0f}초")
        time.sleep(0.05)
    rng_txt = f" · 범위 {min_dt}~{max_dt}" if min_dt else ""
    log.info(f"=== 분봉 완료: {ok}종목 / {fail} 실패 / {total}봉{rng_txt} ({time.time()-t0:.0f}초) ===")
    return {"symbols_ok": ok, "fail": fail, "bars": total,
            "range": f"{min_dt}~{max_dt}" if min_dt else ""}


def fetch_index(name: str = "KOSPI"):
    """★ 네이버 실시간 지수 (코스피/코스닥) - 키 없이 동작
    반환: {"name": "코스피", "symbol": "KOSPI", "value": 6920.51,
           "change_pct": -0.82, "traded_at": "..."} / None (실패)
    """
    import requests as _req
    url = f"https://m.stock.naver.com/api/index/{name}/basic"
    try:
        r = _req.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
        if r.status_code != 200:
            return None
        d = r.json()
        return {
            "name": d.get("stockName") or name,
            "symbol": name,
            "value": float(d.get("closePrice") or 0),
            "change_pct": float(d.get("fluctuationsRatio") or 0),
            "traded_at": d.get("localTradedAt") or "",
        }
    except Exception:
        return None


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="과거 일봉 백필 (네이버 공개 API)")
    parser.add_argument("--days", type=int, default=90, help="받을 일 수 (기본 90일)")
    parser.add_argument("--symbol", default=None, help="특정 종목만 (예: 005930)")
    parser.add_argument("--max", type=int, default=None, help="최대 종목 수 (테스트용)")
    args = parser.parse_args()

    db.init_db()
    # universe 없으면 로드
    if db.count_universe() < 100:
        log.info("전 종목 목록 없음 - GitHub CSV에서 로드...")
        import universe
        universe.refresh_universe()

    symbols = [args.symbol] if args.symbol else None
    backfill(symbols=symbols, days=args.days, max_symbols=args.max)
