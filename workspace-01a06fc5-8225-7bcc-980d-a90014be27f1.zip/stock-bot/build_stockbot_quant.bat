@echo off
setlocal
cd /d "%~dp0"

set "PYTHON=%CD%\.venv\Scripts\python.exe"

if not exist "%PYTHON%" (
    echo [ERROR] New 64-bit Python environment not found:
    echo %PYTHON%
    pause
    exit /b 1
)
if not exist ".\stockbot_quant_gui_entry.py" (
    echo [ERROR] GUI entry file is missing:
    echo %CD%\stockbot_quant_gui_entry.py
    echo Extract the clean integration package at the project root.
    pause
    exit /b 1
)
if not exist ".\quant_platform\gui.py" (
    echo [ERROR] GUI module is missing:
    echo %CD%\quant_platform\gui.py
    echo Extract the clean integration package at the project root.
    pause
    exit /b 1
)

"%PYTHON%" -c "import PyInstaller" >nul 2>nul
if errorlevel 1 (
    echo [BUILD] PyInstaller is not installed in the new environment.
    echo [BUILD] Installing PyInstaller into .venv...
    "%PYTHON%" -m pip install pyinstaller
    if errorlevel 1 (
        echo [ERROR] Could not install PyInstaller into .venv.
        echo Try: "%PYTHON%" -m pip install pyinstaller
        pause
        exit /b 1
    )
)

"%PYTHON%" -c "import PyInstaller; print('[BUILD] PyInstaller', PyInstaller.__version__)"
if errorlevel 1 (
    echo [ERROR] PyInstaller cannot be imported from .venv.
    pause
    exit /b 1
)

if exist "build" rmdir /s /q "build"
if exist "dist\StockBotQuant.exe" del /q "dist\StockBotQuant.exe"

 echo [BUILD] Building StockBotQuant.exe with the new 64-bit environment...
"%PYTHON%" -m PyInstaller --noconfirm --clean --onefile --noconsole --name StockBotQuant --paths "%CD%" --collect-submodules quant_platform stockbot_quant_gui_entry.py
if errorlevel 1 (
    echo [ERROR] Windows executable build failed.
    pause
    exit /b 1
)

copy /Y "dist\StockBotQuant.exe" ".\StockBotQuant.exe" >nul
if errorlevel 1 (
    echo [ERROR] Could not copy the executable to the project root.
    pause
    exit /b 1
)

echo.
echo [DONE] Built:
echo %CD%\StockBotQuant.exe
echo.
echo The executable uses external data, reports, errors, and .env files in this folder.
pause
