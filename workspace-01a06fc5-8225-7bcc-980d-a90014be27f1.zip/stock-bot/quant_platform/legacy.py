"""기존 stock-bot SQLite 일봉을 새 canonical 코어로 연결하는 bridge."""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Sequence

from .backtest import BacktestConfig, BacktestEngine, BacktestResult
from .conditions import DslSignal
from .data import MarketDataStore
from .domain import Bar, DataSource, KST


@dataclass(frozen=True)
class LegacyRowIssue:
    row_number: int
    code: str
    detail: str
    raw: dict

    def as_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class LegacyLoadReport:
    symbol: str
    path: str
    raw_rows: int
    accepted_rows: int
    rejected_rows: int
    bars: tuple[Bar, ...]
    issues: tuple[LegacyRowIssue, ...]

    def as_dict(self) -> dict:
        return {
            "symbol": self.symbol,
            "path": self.path,
            "raw_rows": self.raw_rows,
            "accepted_rows": self.accepted_rows,
            "rejected_rows": self.rejected_rows,
            "issues": [item.as_dict() for item in self.issues],
        }


class LegacyDataError(ValueError):
    """원천 DB 행을 파싱하지 못했음을 알리는 오류입니다."""

    def __init__(self, report: LegacyLoadReport):
        self.report = report
        first = report.issues[0].detail if report.issues else "unknown source data error"
        super().__init__(f"{report.path}: rejected {report.rejected_rows}/{report.raw_rows} source rows; first={first}")


def load_legacy_daily_with_report(symbol: str, stock_dir: str | Path = "data/stocks") -> LegacyLoadReport:
    path = Path(stock_dir) / f"{symbol}.db"
    if not path.exists():
        raise FileNotFoundError(f"legacy stock database not found: {path}")
    connection = sqlite3.connect(path)
    try:
        rows = connection.execute(
            "SELECT rowid, bar_date, open_price, high_price, low_price, close_price, volume, amount, source "
            "FROM daily_bars ORDER BY bar_date, rowid"
        ).fetchall()
    finally:
        connection.close()
    result: list[Bar] = []
    issues: list[LegacyRowIssue] = []
    for row_number, (rowid, bar_date, open_price, high_price, low_price, close_price, volume, amount, source) in enumerate(rows, start=1):
        raw = {"rowid": rowid, "bar_date": bar_date, "open_price": open_price, "high_price": high_price,
               "low_price": low_price, "close_price": close_price, "volume": volume, "amount": amount, "source": source}
        try:
            text = str(bar_date).strip()
            if len(text) == 8 and text.isdigit():
                text = f"{text[:4]}-{text[4:6]}-{text[6:]}"
            timestamp = datetime.fromisoformat(text).replace(tzinfo=KST) if "T" not in text else datetime.fromisoformat(text)
            result.append(Bar(symbol, "1d", timestamp, float(open_price), float(high_price), float(low_price),
                              float(close_price), float(volume or 0), float(amount) if amount is not None else None,
                              source or DataSource.IMPORTED))
        except (TypeError, ValueError, OverflowError) as exc:
            # 이전에는 이 행을 조용히 버렸습니다. 이제 원본 행과 이유를 보존합니다.
            issues.append(LegacyRowIssue(row_number, "SOURCE_ROW_REJECTED", f"{type(exc).__name__}: {exc}", raw))
    return LegacyLoadReport(symbol, str(path.resolve()), len(rows), len(result), len(issues), tuple(result), tuple(issues))


def load_legacy_daily(symbol: str, stock_dir: str | Path = "data/stocks") -> list[Bar]:
    report = load_legacy_daily_with_report(symbol, stock_dir)
    if report.issues:
        raise LegacyDataError(report)
    return list(report.bars)


def import_legacy_daily(symbols: Sequence[str], *, stock_dir: str | Path = "data/stocks",
                        database_path: str | Path = "data/quant_platform.sqlite3") -> dict:
    imported = 0
    skipped = []
    with MarketDataStore(database_path) as store:
        for symbol in symbols:
            try:
                loaded = load_legacy_daily_with_report(symbol, stock_dir)
                if loaded.issues:
                    skipped.append({"symbol": symbol, "reason": "source rows rejected", "load_report": loaded.as_dict()})
                    continue
                imported += store.upsert_bars(loaded.bars)
            except (FileNotFoundError, ValueError) as exc:
                skipped.append({"symbol": symbol, "reason": str(exc)})
        report = store.integrity_report()
        return {"imported": imported, "skipped": skipped, "quality_ok": report.ok,
                "quality_issues": [issue.message for issue in report.issues], "coverage": store.coverage()}


def run_legacy_dsl_backtest(symbol: str, *, stock_dir: str | Path = "data/stocks",
                            database_path: str | Path = "data/quant_platform.sqlite3") -> BacktestResult:
    rows = load_legacy_daily(symbol, stock_dir)
    with MarketDataStore(database_path) as store:
        store.upsert_bars(rows)
    buy = {"indicator": "close", "comparison": ">", "value": {"indicator": "sma_20"}}
    sell = {"indicator": "close", "comparison": "<", "value": {"indicator": "ema_20"}}
    return BacktestEngine(BacktestConfig(initial_capital=1_000_000, commission_pct=0.1, slippage_pct=0.05)).run(
        rows, DslSignal(buy=buy, sell=sell))
