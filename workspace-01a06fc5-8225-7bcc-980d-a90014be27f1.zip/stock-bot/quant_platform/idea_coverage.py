"""기존 아이디어/프롬프트가 실제 코어에 연결되었는지 추적합니다.

파일 이름만 보고 구현됐다고 간주하지 않습니다. 연결 증거가 없는 항목은
UNWIRED_UNVERIFIED로 남기며, 자동으로 전략에 몰래 넣지 않습니다.
"""
from __future__ import annotations

import hashlib
from datetime import datetime
from pathlib import Path
from typing import Iterable


CORE_IDEAS = (
    ("core.close_above_sma20", "종가가 SMA20 상향", "orchestrator.DEFAULT_BUY", "tested by pipeline and orchestrator"),
    ("core.rsi_between_45_75", "RSI 45~75", "orchestrator._atoms", "candidate generation tested"),
    ("core.volume_above_sma20", "거래량 SMA20 대비 증가", "orchestrator._atoms", "candidate generation tested"),
    ("core.cross_above_ema20", "EMA20 상향돌파", "orchestrator._atoms", "candidate generation tested"),
)


def _digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _source_files(root: Path) -> list[Path]:
    files: list[Path] = []
    prompts = root / "prompts"
    if prompts.exists():
        files.extend(path for path in prompts.rglob("*") if path.is_file() and path.suffix.lower() in {".txt", ".md", ".json"})
    strategy = root / "strategy"
    if strategy.exists():
        files.extend(path for path in strategy.rglob("*") if path.is_file() and path.suffix.lower() in {".json", ".txt", ".md"})
    # 실행 상태 파일은 아이디어가 아니므로 제외합니다.
    ignored = {"backfill_state.json", "control_state.json", "round_progress.json", "doctor_report.json"}
    return sorted({path for path in files if path.name not in ignored})


def build_idea_coverage(root: str | Path = ".") -> dict:
    root = Path(root).resolve()
    sources = _source_files(root)
    items = []
    for path in sources:
        try:
            size = path.stat().st_size
            digest = _digest(path)
        except OSError as exc:
            items.append({"path": str(path), "status": "READ_ERROR", "detail": str(exc)})
            continue
        items.append({
            "path": str(path),
            "kind": path.suffix.lower().lstrip("."),
            "bytes": size,
            "sha256": digest,
            "status": "UNWIRED_UNVERIFIED",
            "detail": "기존 아이디어 자료이지만 새 코어의 전략 ID/테스트 증거가 없습니다.",
            "action": "아이디어를 후보 DSL로 명시적으로 등록하고 독립 검증·Shadow를 통과시킨 뒤 사용하세요.",
        })
    return {
        "generated_at": datetime.now().astimezone().isoformat(),
        "root": str(root),
        "policy": "아이디어는 연결 증거가 없으면 자동 사용하지 않음",
        "core_ideas": [
            {"id": idea_id, "title": title, "implementation": implementation,
             "status": "IMPLEMENTED_TESTED", "evidence": evidence}
            for idea_id, title, implementation, evidence in CORE_IDEAS
        ],
        "legacy_sources": items,
        "counts": {
            "core_implemented_tested": len(CORE_IDEAS),
            "legacy_sources": len(items),
            "unwired_unverified": sum(item.get("status") == "UNWIRED_UNVERIFIED" for item in items),
            "read_errors": sum(item.get("status") == "READ_ERROR" for item in items),
        },
        "safe_to_use_unverified_ideas": False,
    }
