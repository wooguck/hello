"""데이터 출처·합성/의심 데이터 감사를 위한 모듈.

숫자만 그럴듯하다고 실제 시장 데이터라고 가정하지 않습니다. 출처가 mock/test이거나
과도하게 평평한 시계열, 미래 시각, 거래량 부재를 별도 경고로 표시합니다.
의심 데이터는 삭제하지 않고 분석 승인에서 제외할 수 있도록 증거를 남깁니다.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from math import isfinite
from typing import Iterable

from .domain import Bar


_SYNTHETIC_SOURCES = {"mock", "test", "demo", "synthetic", "generated", "fixture"}


@dataclass(frozen=True)
class ProvenanceFinding:
    code: str
    severity: str  # WARN | FAIL
    detail: str
    symbol: str | None = None
    timestamp: str | None = None
    action: str = ""

    def as_dict(self) -> dict:
        return asdict(self)


def inspect_provenance(bars: Iterable[Bar], *, now: datetime | None = None,
                       allow_synthetic: bool = False) -> dict:
    rows = list(bars)
    findings: list[ProvenanceFinding] = []
    current = now or datetime.now(timezone.utc)
    if current.tzinfo is None:
        current = current.replace(tzinfo=timezone.utc)
    source_values = {str(row.source).strip().lower() for row in rows}
    synthetic = sorted(source_values & _SYNTHETIC_SOURCES)
    if synthetic and not allow_synthetic:
        findings.append(ProvenanceFinding(
            "SYNTHETIC_SOURCE", "FAIL", f"합성/테스트 출처가 포함됨: {', '.join(synthetic)}",
            action="실제 브로커/공식 원천 자료로 교체하거나 데모 검증으로만 분리하세요.",
        ))
    elif synthetic:
        findings.append(ProvenanceFinding(
            "SYNTHETIC_SOURCE_ALLOWED", "WARN", f"합성/테스트 출처를 허용한 데모 실행: {', '.join(synthetic)}",
            action="실제 운영 승인에는 사용할 수 없습니다.",
        ))
    if not rows:
        findings.append(ProvenanceFinding("NO_ROWS", "FAIL", "검사할 봉 데이터가 없습니다.", action="데이터 수집/경로를 확인하세요."))
        return {"status": "FAIL", "rows": 0, "sources": [], "findings": [item.as_dict() for item in findings]}

    unverified = sorted(source_values - {"kiwoom", "naver", "daum", "yahoo", "imported"} - _SYNTHETIC_SOURCES)
    if unverified:
        findings.append(ProvenanceFinding(
            "UNVERIFIED_SOURCE", "WARN", f"검증되지 않은 출처 표기: {', '.join(unverified)}",
            action="원천 API 응답 또는 파일 checksum을 연결하세요.",
        ))
    future_limit = current + timedelta(days=1)
    future_rows = [row for row in rows if row.timestamp > future_limit]
    if future_rows:
        findings.append(ProvenanceFinding(
            "FUTURE_DATA", "FAIL", f"현재 시각보다 1일 이상 미래인 봉 {len(future_rows)}개",
            future_rows[0].symbol, future_rows[0].timestamp.isoformat(),
            "미래 봉은 분석에서 제외하고 시스템 시각/원천 파서를 확인하세요.",
        ))
    zero_volume = sum(row.volume == 0 for row in rows)
    if zero_volume / len(rows) >= 0.9:
        findings.append(ProvenanceFinding(
            "MISSING_VOLUME", "WARN", f"거래량 0인 봉이 {zero_volume}/{len(rows)}개",
            action="거래량 없는 가격 데이터는 신호 검증에서 별도 취급하세요.",
        ))
    close_values = [row.close for row in rows if isfinite(row.close)]
    if len(close_values) >= 20 and len(set(close_values)) == 1:
        findings.append(ProvenanceFinding(
            "FLAT_SERIES", "FAIL", "20개 이상 종가가 완전히 동일합니다.",
            rows[0].symbol, action="더미 데이터·파싱 오류·거래정지 여부를 확인하세요.",
        ))
    elif len(close_values) >= 20:
        unique_ratio = len(set(close_values)) / len(close_values)
        if unique_ratio < 0.05:
            findings.append(ProvenanceFinding(
                "LOW_VARIATION", "WARN", f"종가 고유값 비율이 {unique_ratio:.1%}로 과도하게 낮습니다.",
                rows[0].symbol, action="합성/복제 데이터인지 원천 checksum과 대조하세요.",
            ))
    hard_fail = any(item.severity == "FAIL" for item in findings)
    return {
        "status": "FAIL" if hard_fail else ("WARN" if findings else "PASS"),
        "rows": len(rows),
        "sources": sorted(source_values),
        "findings": [item.as_dict() for item in findings],
        "analysis_eligible": not hard_fail,
    }
