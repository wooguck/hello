"""하루 동안 계속 실행되는 안전한 연구·모의운용 감독자.

원칙:
- 실제 브로커/API를 절대 호출하지 않습니다.
- 연구는 run_all의 resumable batch로 실행합니다.
- PAPER 주문은 로컬 원장에만 기록합니다.
- 종목 단위 오류는 오류센터에 기록하고 다음 종목으로 진행합니다.
- 자동 복구는 디렉터리·임시파일·상태파일 같은 안전한 런타임 복구만 수행합니다.
  전략 코드나 주문 코드를 몰래 수정하지 않습니다.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sqlite3
import time
import traceback
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from .all_runner import discover_symbols, run_all
from .backtest import BacktestConfig
from .conditions import DslSignal
from .data import MarketDataStore
from .error_center import ErrorCenter
from .legacy import load_legacy_daily
from .order_gateway import OrderGateway, OrderIntent, OrderMode
from .paper import PaperTradingEngine
from .orchestrator import DEFAULT_BUY, DEFAULT_SELL
from .review import review_file


SCHEMA = """
CREATE TABLE IF NOT EXISTS paper_cycles (
    cycle_id TEXT PRIMARY KEY,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    status TEXT NOT NULL,
    source_symbol_count INTEGER NOT NULL DEFAULT 0,
    completed_count INTEGER NOT NULL DEFAULT 0,
    failed_count INTEGER NOT NULL DEFAULT 0,
    new_bar_count INTEGER NOT NULL DEFAULT 0,
    paper_order_count INTEGER NOT NULL DEFAULT 0,
    summary_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS paper_orders (
    client_order_id TEXT PRIMARY KEY,
    cycle_id TEXT NOT NULL,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    price REAL NOT NULL,
    timestamp TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_paper_orders_symbol_time ON paper_orders(symbol, timestamp);
"""


def _now() -> str:
    return datetime.now().astimezone().isoformat()


def _atomic_write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def _safe_load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    if not path.exists():
        return default
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            return default
        if not isinstance(value.get("fingerprints", {}), dict):
            value["fingerprints"] = {}
        if not isinstance(value.get("cycles", []), list):
            value["cycles"] = []
        return value
    except (OSError, json.JSONDecodeError):
        backup = path.with_name(path.name + f".corrupt-{datetime.now().strftime('%Y%m%d-%H%M%S')}")
        try:
            shutil.copy2(path, backup)
        except OSError:
            pass
        return default


def _repair_runtime(root: Path) -> list[str]:
    """실행을 막는 안전한 런타임 문제만 자동 복구합니다."""
    actions: list[str] = []
    for name in ("reports", "errors", "data"):
        path = root / name
        if not path.exists():
            path.mkdir(parents=True, exist_ok=True)
            actions.append(f"created {name}")
    for path in (root / "reports" / "all_run_state.json.tmp", root / "reports" / "overnight_state.json.tmp"):
        if path.exists():
            try:
                path.unlink()
                actions.append(f"removed stale temporary file {path.name}")
            except OSError:
                pass
    # 잘못된 package가 섞였으면 자동 수정하지 않고 명시적으로 중단·기록합니다.
    required = [root / "quant_platform" / "__init__.py", root / "quant_platform" / "gui.py", root / "quant_platform" / "all_runner.py"]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise RuntimeError("clean package is incomplete: " + ", ".join(missing))
    return actions


def _init_db(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path, timeout=30)
    connection.executescript(SCHEMA)
    connection.commit()
    return connection


def _rows_for_symbol(symbol: str, source_dir: Path, database_path: Path):
    with MarketDataStore(database_path) as store:
        rows = store.get_bars(symbol, "1d")
    if len(rows) < 2:
        try:
            rows = load_legacy_daily(symbol, stock_dir=source_dir)
        except Exception:
            rows = []
    return rows


def _fingerprint(rows) -> str:
    if not rows:
        return "empty"
    return f"{len(rows)}:{rows[-1].timestamp.isoformat()}:{rows[-1].close}"


def _paper_replay(symbol: str, rows, cycle_id: str, gateway: OrderGateway, connection: sqlite3.Connection) -> dict[str, Any]:
    if len(rows) < 2:
        return {"symbol": symbol, "status": "NO_DATA", "new_orders": 0, "final_equity": None}
    signal = DslSignal(buy=DEFAULT_BUY, sell=DEFAULT_SELL)
    result = PaperTradingEngine(BacktestConfig(initial_capital=1_000_000)).run(rows, signal)
    inserted = 0
    for index, order in enumerate(result.orders):
        client_order_id = f"PAPER-{cycle_id}-{symbol}-{index:04d}"
        gateway_result = gateway.submit(OrderIntent(
            symbol=symbol,
            side=order.side,
            quantity=order.quantity,
            price=order.price,
            strategy_id="overnight-default-signal",
            signal_time=order.timestamp,
            client_order_id=client_order_id,
            reason="historical paper replay only",
        ))
        connection.execute(
            "INSERT OR IGNORE INTO paper_orders(client_order_id, cycle_id, symbol, side, quantity, price, timestamp, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (client_order_id, cycle_id, symbol, order.side, order.quantity, order.price, order.timestamp,
             gateway_result.status, _now()),
        )
        if gateway_result.status in {"PAPER_PENDING", "SIMULATED"}:
            inserted += 1
    connection.commit()
    return {
        "symbol": symbol,
        "status": "PAPER_REPLAYED",
        "new_orders": inserted,
        "historical_orders": len(result.orders),
        "final_equity": result.final_equity,
        "realized_pnl": result.realized_pnl,
        "last_bar": rows[-1].timestamp.isoformat(),
    }


def run_cycle(root: Path, *, state: dict[str, Any]) -> dict[str, Any]:
    actions = _repair_runtime(root)
    reports = root / "reports"
    errors = root / "errors"
    source_dir = root / "data" / "stocks"
    database_path = root / "data" / "quant_platform.sqlite3"
    trading_db = root / "trading.db"
    cycle_id = f"PAPER-{datetime.now().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:6].upper()}"
    status_path = reports / "overnight_status.json"
    status = {
        "cycle_id": cycle_id,
        "mode": "PAPER_LOCAL_ONLY",
        "started_at": _now(),
        "status": "RUNNING",
        "auto_repair_actions": actions,
        "orders_submitted_to_broker": 0,
    }
    _atomic_write(status_path, status)

    def progress(event: dict[str, Any]) -> None:
        status.update({"last_event": event, "heartbeat_at": _now()})
        _atomic_write(status_path, status)

    run_summary = run_all(
        source_dir=source_dir,
        database_path=database_path,
        trading_db=trading_db,
        reports_dir=reports,
        errors_dir=errors,
        resume=True,
        progress=progress,
    )
    status.update({"research_run_id": run_summary.get("all_run_id"), "research_status": run_summary.get("status")})

    ledger_path = root / "data" / "paper_overnight.sqlite3"
    connection = _init_db(ledger_path)
    connection.execute(
        "INSERT OR REPLACE INTO paper_cycles(cycle_id, started_at, status, source_symbol_count, completed_count, failed_count, summary_json) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (cycle_id, status["started_at"], "RUNNING", run_summary.get("source_symbol_count", 0),
         run_summary.get("completed_count", 0), run_summary.get("failed_count", 0),
         json.dumps(run_summary, ensure_ascii=False)),
    )
    connection.commit()
    paper_results: list[dict[str, Any]] = []
    new_bar_count = 0
    fingerprints = state.setdefault("fingerprints", {})
    with OrderGateway(root / "data" / "quant_orders.sqlite3", mode=OrderMode.PAPER) as gateway:
        # all_runner는 이미 완료된 종목을 skipped로 반환할 수 있습니다. PAPER ledger가
        # 아직 없는 종목을 놓치지 않도록 이번 summary가 아닌 현재 전체 universe를 봅니다.
        source_symbols, canonical_only = discover_symbols(source_dir, database_path)
        symbols = sorted(set(source_symbols) | set(canonical_only))
        for symbol in symbols:
            try:
                rows = _rows_for_symbol(symbol, source_dir, database_path)
                current = _fingerprint(rows)
                if fingerprints.get(symbol) == current:
                    paper_results.append({"symbol": symbol, "status": "NO_NEW_BAR", "new_orders": 0, "last_bar": rows[-1].timestamp.isoformat() if rows else None})
                    continue
                fingerprints[symbol] = current
                new_bar_count += 1
                paper_results.append(_paper_replay(symbol, rows, cycle_id, gateway, connection))
            except Exception as exc:
                ErrorCenter(errors).record(
                    cycle_id,
                    "PAPER_REPLAY",
                    exc,
                    context={"symbol": symbol, "traceback": traceback.format_exc()},
                    recoverable=True,
                    recommended_action="해당 종목을 건너뛰고 다음 cycle에서 재시도합니다.",
                    impact="해당 종목 paper replay만 보류했습니다. 브로커 주문은 없습니다.",
                )
                paper_results.append({"symbol": symbol, "status": "ERROR_SKIPPED", "error": f"{type(exc).__name__}: {exc}", "new_orders": 0})
    status.update({
        "finished_at": _now(),
        "status": "COMPLETED",
        "new_bar_count": new_bar_count,
        "paper_results": paper_results,
        "paper_order_count": sum(item.get("new_orders", 0) for item in paper_results),
        "research_summary": {
            "source_symbol_count": run_summary.get("source_symbol_count", 0),
            "completed_count": run_summary.get("completed_count", 0),
            "failed_count": run_summary.get("failed_count", 0),
            "skipped_count": run_summary.get("skipped_count", 0),
        },
        "orders_submitted_to_broker": 0,
        "ledger_path": str(ledger_path.resolve()),
    })
    connection.execute(
        "UPDATE paper_cycles SET finished_at=?, status=?, new_bar_count=?, paper_order_count=?, summary_json=? WHERE cycle_id=?",
        (status["finished_at"], status["status"], status["new_bar_count"], status["paper_order_count"],
         json.dumps(status, ensure_ascii=False), cycle_id),
    )
    connection.commit()
    connection.close()
    _atomic_write(status_path, status)
    _atomic_write(reports / f"{cycle_id}.json", status)

    # 최근 RUN 리포트가 있으면 결과 검수 파일도 자동으로 갱신합니다.
    run_reports = sorted(reports.glob("RUN-*.json"), reverse=True)
    if run_reports:
        try:
            review_file(run_reports[0], run_reports[0].with_name(run_reports[0].stem + "_review.json"))
        except Exception as exc:
            ErrorCenter(errors).record(
                cycle_id,
                "RESULT_REVIEW",
                exc,
                context={"report": str(run_reports[0]), "traceback": traceback.format_exc()},
                recoverable=True,
                recommended_action="다음 cycle에서 결과 검수를 재시도합니다.",
                impact="paper replay는 완료되었지만 review 파일 갱신을 보류했습니다.",
            )
    return status


def supervisor(root: Path, *, hours: float = 24.0, interval_seconds: int = 900, once: bool = False) -> int:
    root = root.resolve()
    reports = root / "reports"
    errors = root / "errors"
    state_path = reports / "overnight_state.json"
    state = _safe_load(state_path, {"version": 1, "started_at": _now(), "cycles": []})
    deadline = datetime.now(timezone.utc) + timedelta(hours=max(0.01, hours))
    cycle = 0
    print(f"[OVERNIGHT] PAPER_LOCAL_ONLY started root={root} until={deadline.astimezone().isoformat()}", flush=True)
    while True:
        cycle += 1
        try:
            result = run_cycle(root, state=state)
            state.setdefault("cycles", []).append({
                "cycle_id": result.get("cycle_id"),
                "status": result.get("status"),
                "finished_at": result.get("finished_at"),
                "new_bar_count": result.get("new_bar_count", 0),
                "paper_order_count": result.get("paper_order_count", 0),
            })
            state["last_cycle"] = result.get("cycle_id")
            state["last_status"] = result.get("status")
            _atomic_write(state_path, state)
            print(
                f"[CYCLE {cycle}] research={result.get('research_status')} "
                f"new_bars={result.get('new_bar_count', 0)} "
                f"paper_orders={result.get('paper_order_count', 0)} broker_orders=0",
                flush=True,
            )
        except Exception as exc:
            # 감독자 자체 오류도 기록하고 잠시 후 재시작합니다.
            errors.mkdir(parents=True, exist_ok=True)
            ErrorCenter(errors).record(
                f"SUP-{datetime.now().strftime('%Y%m%d-%H%M%S')}",
                "OVERNIGHT_SUPERVISOR",
                exc,
                context={"traceback": traceback.format_exc(), "cycle": cycle},
                recoverable=True,
                recommended_action="런타임 복구 후 다음 cycle에서 재시도합니다.",
                impact="이번 cycle만 실패했으며 주문은 제출되지 않았습니다.",
            )
            print(f"[RECOVERED] cycle error={type(exc).__name__}: {exc}; retrying", flush=True)
        if once or datetime.now(timezone.utc) >= deadline:
            print("[OVERNIGHT] finished; broker_orders=0", flush=True)
            return 0
        time.sleep(max(10, int(interval_seconds)))


def main() -> int:
    parser = argparse.ArgumentParser(description="24시간 안전 PAPER 연구 감독자")
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--hours", type=float, default=24.0)
    parser.add_argument("--interval", type=int, default=900, help="cycle 간격(초), 기본 15분")
    parser.add_argument("--once", action="store_true", help="한 cycle만 실행하고 종료")
    args = parser.parse_args()
    return supervisor(args.root, hours=args.hours, interval_seconds=args.interval, once=args.once)


if __name__ == "__main__":
    raise SystemExit(main())
