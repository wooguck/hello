"""이전 배포본 호환 shim. 새 구현은 quant_platform.validation.walk_forward에 있습니다."""
from .validation.walk_forward import WalkForwardSplit, run_walk_forward, walk_forward_splits

__all__ = ["WalkForwardSplit", "run_walk_forward", "walk_forward_splits"]
