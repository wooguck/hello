"""사람이 읽을 수 있는 조건식·돌파 이벤트 수익 분석.

조건식 자체와 미래 수익을 분리합니다. 조건은 신호 시점까지의 정보만 보고,
수익은 다음 봉 시가 진입 이후에만 계산합니다. 결과는 보장 수익이 아니라
표본·분포·OOS를 포함한 조건 검색 카드입니다.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from statistics import median
from typing import Sequence

from .domain import Bar
from .indicators import feature_rows


@dataclass(frozen=True)
class BreakoutRule:
    ma_period: int = 20
    rsi_low: float = 50.0
    rsi_high: float = 70.0
    breakout_lookback: int = 20
    volume_multiplier: float = 1.5
    target_pct: float = 8.0
    stop_pct: float = 4.0
    horizons: tuple[int, ...] = (1, 3, 5, 10)
    commission_pct: float = 0.2
    slippage_pct: float = 0.1

    def __post_init__(self) -> None:
        if self.ma_period <= 0 or self.breakout_lookback <= 0:
            raise ValueError("periods must be positive")
        if self.rsi_low < 0 or self.rsi_high > 100 or self.rsi_low > self.rsi_high:
            raise ValueError("invalid RSI range")
        if self.volume_multiplier <= 0 or self.target_pct <= 0 or self.stop_pct <= 0:
            raise ValueError("volume multiplier and target/stop must be positive")
        if not self.horizons or any(int(value) <= 0 for value in self.horizons):
            raise ValueError("horizons must contain positive days")
        if self.commission_pct < 0 or self.slippage_pct < 0:
            raise ValueError("costs cannot be negative")

    def as_dict(self) -> dict:
        return asdict(self)

    def as_text(self) -> list[str]:
        return [
            f"종가 > SMA({self.ma_period})",
            f"RSI(14) {self.rsi_low:g}~{self.rsi_high:g}",
            f"종가 > 직전 {self.breakout_lookback}일 고가",
            f"거래량 > 거래량 SMA({self.ma_period}) × {self.volume_multiplier:g}",
            f"다음 봉 시가 진입 · 목표 +{self.target_pct:g}% · 손절 -{self.stop_pct:g}%",
        ]


def _percentile(values: Sequence[float], percentile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    position = (len(ordered) - 1) * percentile
    low = int(position)
    high = min(low + 1, len(ordered) - 1)
    weight = position - low
    return ordered[low] * (1 - weight) + ordered[high] * weight


def _signals(rows: Sequence[Bar], rule: BreakoutRule) -> list[int]:
    features = feature_rows(rows, ma_period=rule.ma_period, volume_period=rule.ma_period)
    output: list[int] = []
    for index, current in enumerate(features):
        # 신호 시점에는 현재 봉의 OHLCV까지만 사용합니다. 직전 고가 범위에
        # 현재 봉을 넣지 않아 돌파 조건에 look-ahead가 생기지 않습니다.
        if index + 1 >= len(rows):
            continue
        previous_highs = [row.high for row in rows[max(0, index - rule.breakout_lookback):index]]
        if not previous_highs:
            continue
        ma = current.get(f"sma_{rule.ma_period}")
        rsi = current.get("rsi_14")
        volume_ma = current.get(f"volume_sma_{rule.ma_period}")
        if ma is None or rsi is None or volume_ma is None:
            continue
        if (current["close"] > ma and rule.rsi_low <= rsi <= rule.rsi_high
                and current["close"] > max(previous_highs)
                and current["volume"] > volume_ma * rule.volume_multiplier):
            output.append(index)
    return output


def _event_metrics(rows: Sequence[Bar], signals: Sequence[int], rule: BreakoutRule, horizon: int) -> dict:
    returns: list[float] = []
    target_hits = 0
    stop_hits = 0
    days_to_target: list[int] = []
    for signal_index in signals:
        entry_index = signal_index + 1
        end_index = min(len(rows) - 1, entry_index + horizon)
        entry = rows[entry_index].open * (1 + rule.slippage_pct / 100)
        exit_price = rows[end_index].close * (1 - rule.slippage_pct / 100)
        result = (exit_price / entry - 1) * 100 - rule.commission_pct
        returns.append(result)
        target = entry * (1 + rule.target_pct / 100)
        stop = entry * (1 - rule.stop_pct / 100)
        target_day = None
        target_hit = False
        stop_hit = False
        for day, row in enumerate(rows[entry_index:end_index + 1]):
            if row.high >= target and target_day is None:
                target_day = day
                target_hit = True
            if row.low <= stop:
                stop_hit = True
        target_hits += target_hit
        stop_hits += stop_hit
        if target_day is not None:
            days_to_target.append(target_day)
    count = len(returns)
    return {
        "horizon_days": horizon,
        "signal_count": count,
        "average_return_pct": sum(returns) / count if count else None,
        "median_return_pct": median(returns) if returns else None,
        "p25_return_pct": _percentile(returns, 0.25),
        "p75_return_pct": _percentile(returns, 0.75),
        "positive_rate_pct": sum(value > 0 for value in returns) / count * 100 if count else None,
        "target_hit_rate_pct": target_hits / count * 100 if count else None,
        "stop_hit_rate_pct": stop_hits / count * 100 if count else None,
        "median_days_to_target": median(days_to_target) if days_to_target else None,
        "cost_model": {"commission_pct": rule.commission_pct, "slippage_pct": rule.slippage_pct},
    }


def run_breakout_event_study(rows: Sequence[Bar], rule: BreakoutRule | None = None, *, min_signals: int = 10) -> dict:
    rule = rule or BreakoutRule()
    values = list(rows)
    signals = _signals(values, rule)
    usable = [index for index in signals if index + 1 + max(rule.horizons) < len(values)]
    split = int(len(values) * 0.7)
    train_signals = [index for index in usable if index < split]
    test_signals = [index for index in usable if index >= split]
    all_metrics = [_event_metrics(values, usable, rule, horizon) for horizon in rule.horizons]
    test_metrics = [_event_metrics(values, test_signals, rule, horizon) for horizon in rule.horizons]
    status = "PASS" if len(train_signals) >= min_signals and len(test_signals) >= min_signals else "INSUFFICIENT_SAMPLE"
    return {
        "status": status,
        "eligible_for_strategy_selection": status == "PASS",
        "rule": rule.as_dict(),
        "rule_text": rule.as_text(),
        "signal_count": len(usable),
        "train_signal_count": len(train_signals),
        "test_signal_count": len(test_signals),
        "lookahead_policy": "signal uses current/previous data; entry is next bar open",
        "all_periods": all_metrics,
        "oos_periods": test_metrics,
        "interpretation": "조건 검색 통계이며 미래 수익을 보장하지 않습니다.",
    }
