"""일봉 관심종목과 분봉 진입·보유·청산을 연결하는 안전한 상태머신."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum


class WatchState(str, Enum):
    NOT_ELIGIBLE = "NOT_ELIGIBLE"
    WATCHLIST = "WATCHLIST"
    ARMED = "ARMED"
    ENTERED = "ENTERED"
    HOLD_TRAILING = "HOLD_TRAILING"
    PARTIAL_EXIT = "PARTIAL_EXIT"
    EXITED = "EXITED"
    BLOCKED = "BLOCKED"


class DecisionAction(str, Enum):
    REMOVE = "REMOVE"
    WATCH = "WATCH"
    BUY = "BUY"
    HOLD = "HOLD"
    PARTIAL_SELL = "PARTIAL_SELL"
    SELL = "SELL"
    BLOCK = "BLOCK"


@dataclass(frozen=True)
class DailyContext:
    symbol: str
    as_of: datetime
    close: float
    sma20: float | None
    rsi14: float | None
    prior_20d_high: float | None
    trend_strength: str = "NORMAL"  # STRONG | NORMAL | WEAK
    data_ok: bool = True

    def qualifies(self) -> bool:
        return bool(
            self.data_ok
            and self.sma20 is not None
            and self.rsi14 is not None
            and self.prior_20d_high is not None
            and self.close > self.sma20
            and 50 <= self.rsi14 <= 70
            and self.close > self.prior_20d_high
        )


@dataclass(frozen=True)
class IntradayObservation:
    symbol: str
    timestamp: datetime
    buy_signal: bool = False
    sell_signal: bool = False
    trend_strength: str = "NORMAL"
    price: float | None = None
    stop_broken: bool = False
    target_reached: bool = False
    data_ok: bool = True


@dataclass(frozen=True)
class PositionState:
    symbol: str
    quantity: int
    entry_price: float
    stop_price: float
    target_price: float
    partial_exit_done: bool = False

    @property
    def active(self) -> bool:
        return self.quantity > 0


@dataclass(frozen=True)
class TradeDecision:
    action: DecisionAction
    state: WatchState
    symbol: str
    reason: str
    quantity: int = 0
    partial_quantity: int = 0
    daily_context_as_of: str | None = None
    intraday_timestamp: str | None = None
    lookahead_check: str = "PASS"

    def as_dict(self) -> dict:
        return {
            "action": self.action.value,
            "state": self.state.value,
            "symbol": self.symbol,
            "reason": self.reason,
            "quantity": self.quantity,
            "partial_quantity": self.partial_quantity,
            "daily_context_as_of": self.daily_context_as_of,
            "intraday_timestamp": self.intraday_timestamp,
            "lookahead_check": self.lookahead_check,
        }


class MultiTimeframePolicy:
    """일봉 context는 T-1 또는 그 이전, 분봉은 현재 시각까지의 정보만 사용합니다."""

    def __init__(self, *, partial_exit_pct: float = 50.0):
        if not 0 < partial_exit_pct <= 100:
            raise ValueError("partial_exit_pct must be in (0, 100]")
        self.partial_exit_pct = float(partial_exit_pct)

    def decide(self, daily: DailyContext, intraday: IntradayObservation,
               position: PositionState | None = None) -> TradeDecision:
        if daily.symbol != intraday.symbol:
            raise ValueError("daily and intraday symbols must match")
        if daily.as_of > intraday.timestamp:
            raise ValueError("daily context cannot be newer than intraday observation")
        daily_time = daily.as_of.isoformat()
        intraday_time = intraday.timestamp.isoformat()
        common = {"daily_context_as_of": daily_time, "intraday_timestamp": intraday_time, "lookahead_check": "PASS"}
        if not daily.data_ok or not intraday.data_ok:
            return TradeDecision(DecisionAction.BLOCK, WatchState.BLOCKED, daily.symbol,
                                  "data quality/provenance gate blocked the decision", **common)
        if not daily.qualifies():
            if position and position.active:
                return TradeDecision(DecisionAction.SELL, WatchState.EXITED, daily.symbol,
                                      "daily context is no longer eligible", quantity=position.quantity, **common)
            return TradeDecision(DecisionAction.REMOVE, WatchState.NOT_ELIGIBLE, daily.symbol,
                                  "daily context did not qualify", **common)
        if position is None or not position.active:
            if intraday.buy_signal:
                return TradeDecision(DecisionAction.BUY, WatchState.ENTERED, daily.symbol,
                                      "daily watchlist qualified and confirmed intraday buy signal", **common)
            return TradeDecision(DecisionAction.WATCH, WatchState.ARMED, daily.symbol,
                                  "daily context qualified; waiting for confirmed intraday entry", **common)
        if intraday.stop_broken:
            return TradeDecision(DecisionAction.SELL, WatchState.EXITED, daily.symbol,
                                  "intraday stop was broken", quantity=position.quantity, **common)
        if intraday.sell_signal and intraday.trend_strength != "STRONG":
            return TradeDecision(DecisionAction.SELL, WatchState.EXITED, daily.symbol,
                                  "confirmed intraday sell signal while trend is not strong", quantity=position.quantity, **common)
        if intraday.target_reached and not position.partial_exit_done and intraday.trend_strength == "STRONG":
            partial = max(1, int(position.quantity * self.partial_exit_pct / 100))
            return TradeDecision(DecisionAction.PARTIAL_SELL, WatchState.PARTIAL_EXIT, daily.symbol,
                                  "target reached but trend remains strong; take partial profit and trail remainder",
                                  quantity=position.quantity, partial_quantity=min(partial, position.quantity), **common)
        if intraday.target_reached and intraday.trend_strength != "STRONG":
            return TradeDecision(DecisionAction.SELL, WatchState.EXITED, daily.symbol,
                                  "target reached and trend is not strong", quantity=position.quantity, **common)
        return TradeDecision(DecisionAction.HOLD, WatchState.HOLD_TRAILING, daily.symbol,
                              "trend/risk gate allows holding; protect with trailing stop", quantity=position.quantity, **common)
