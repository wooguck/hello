"""기존 StockBot과 새 quant_platform을 한 번에 연결하는 안전한 실행기.

기본 모드는 READ_ONLY_RESEARCH입니다.
- 기존 data/stocks를 원천으로 읽고 canonical DB에 idempotent upsert
- 원천과 일치하는 분석용 행만 분리하고 canonical에 남은 추가 행은 보존
- 후보 생성, 백테스트, OOS/랜덤/Monte Carlo/재검증을 실행
- 기존 trading.db와 주문 API는 호출하지 않음
- 실패 시 구조화된 오류번호와 실행 리포트를 남김
"""
from __future__ import annotations

import argparse
import json
import sqlite3
import sys
import uuid
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Sequence

from .backtest import BacktestConfig, BacktestEngine
from .conditions import DslSignal
from .data import MarketDataStore
from .error_center import ErrorCenter
from .event_study import run_breakout_event_study
from .legacy import load_legacy_daily_with_report
from .provenance import inspect_provenance
from .review import review_report
from .strategies import CandidateStrategy, generate_candidates
from .survivors import StrategyEvaluation, score_evaluation, select_survivors
from .validation import monte_carlo_returns, revalidate_strategy, validate_random_periods, walk_forward_splits
from .data.quality import validate_bars


VERSION = "0.2.0"
DEFAULT_SYMBOL = "005930"
DEFAULT_BUY = {"indicator": "close", "comparison": ">", "value": {"indicator": "sma_20"}}
DEFAULT_SELL = {"indicator": "close", "comparison": "<", "value": {"indicator": "ema_20"}}


def _atoms() -> list[dict]:
    return [
        DEFAULT_BUY,
        {"indicator": "rsi_14", "comparison": "BETWEEN", "value": [45, 75]},
        {"indicator": "volume", "comparison": ">", "value": {"indicator": "volume_sma_20", "multiplier": 1.1}},
        {"operator": "CROSS_ABOVE", "left": {"indicator": "close"}, "right": {"indicator": "ema_20"}},
    ]


def _backtest_config() -> BacktestConfig:
    return BacktestConfig(initial_capital=1_000_000, commission_pct=0.1, slippage_pct=0.05)


def _summary(result) -> dict[str, Any]:
    return {
        "initial_capital": result.initial_capital,
        "final_equity": result.final_equity,
        "total_return_pct": result.total_return_pct,
        "trade_count": result.trade_count,
        "win_rate_pct": result.win_rate_pct,
        "average_trade_return_pct": result.average_trade_return_pct,
        "profit_factor": result.profit_factor if result.profit_factor != float("inf") else None,
        "max_drawdown_pct": result.max_drawdown_pct,
    }


def _evaluate_candidate(candidate: CandidateStrategy, rows: Sequence, config: BacktestConfig) -> tuple[StrategyEvaluation, dict]:
    signal_factory = lambda: DslSignal(buy=candidate.condition, sell=DEFAULT_SELL)
    backtest = BacktestEngine(config).run(rows, signal_factory())
    random_result = validate_random_periods(
        rows,
        signal_factory,
        runs=min(20, max(5, len(rows) // 100)),
        min_bars=min(90, len(rows)),
        max_bars=min(300, len(rows)),
        seed=123,
        config=config,
    )
    if len(rows) >= 160:
        test_size = min(100, max(30, len(rows) // 6))
        train_size = min(700, max(90, len(rows) - test_size * 3))
        splits = walk_forward_splits(rows, train_size=train_size, test_size=test_size, step=test_size)
    else:
        splits = tuple()
    wf_results = tuple(BacktestEngine(config).run(split.test, signal_factory()) for split in splits)
    wf_positive = (sum(item.total_return_pct > 0 for item in wf_results) / len(wf_results) * 100) if wf_results else 0.0
    trade_returns = [trade.return_pct or 0.0 for trade in backtest.trades if trade.side == "SELL"]
    monte_carlo = monte_carlo_returns(trade_returns, runs=200, seed=123)
    revalidation = None
    if len(rows) >= 1000:
        revalidation = asdict(revalidate_strategy(
            candidate.strategy_id,
            candidate.condition,
            rows,
            baseline_bars=700,
            recent_bars=300,
        ))
    score = score_evaluation(
        total_return_pct=backtest.total_return_pct,
        win_rate_pct=backtest.win_rate_pct,
        profit_factor=backtest.profit_factor,
        max_drawdown_pct=backtest.max_drawdown_pct,
        trade_count=backtest.trade_count,
        random_positive_rate_pct=random_result.positive_rate_pct,
        walk_forward_positive_rate_pct=wf_positive,
        monte_carlo_loss_probability_pct=monte_carlo["loss_probability_pct"],
    )
    evaluation = StrategyEvaluation(
        strategy_id=candidate.strategy_id,
        strategy_hash=candidate.strategy_hash,
        total_return_pct=round(backtest.total_return_pct, 4),
        win_rate_pct=round(backtest.win_rate_pct, 4),
        profit_factor=round(backtest.profit_factor, 4) if backtest.profit_factor != float("inf") else 999.0,
        max_drawdown_pct=round(backtest.max_drawdown_pct, 4),
        trade_count=backtest.trade_count,
        random_positive_rate_pct=round(random_result.positive_rate_pct, 4),
        walk_forward_positive_rate_pct=round(wf_positive, 4),
        monte_carlo_loss_probability_pct=round(monte_carlo["loss_probability_pct"], 4),
        score=round(score, 4),
    )
    detail = {
        "candidate": {"strategy_id": candidate.strategy_id, "strategy_hash": candidate.strategy_hash,
                      "condition_count": candidate.condition_count, "condition": candidate.condition},
        "backtest": _summary(backtest),
        "random_validation": {
            "runs": random_result.runs,
            "positive_rate_pct": random_result.positive_rate_pct,
            "median_return_pct": random_result.median_return_pct,
            "worst_return_pct": random_result.worst_return_pct,
            "best_return_pct": random_result.best_return_pct,
            "max_drawdown_pct": random_result.max_drawdown_pct,
        },
        "walk_forward": {"split_count": len(wf_results), "positive_rate_pct": wf_positive},
        "monte_carlo": monte_carlo,
        "revalidation": revalidation,
        "evaluation": asdict(evaluation),
    }
    return evaluation, detail


def _legacy_universe_status(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"available": False, "path": str(path.resolve()), "reason": "trading.db not found"}
    try:
        with sqlite3.connect(path) as db:
            db.row_factory = sqlite3.Row
            row = db.execute("SELECT COUNT(*) AS count, MAX(updated_at) AS updated_at FROM universe").fetchone()
        updated_at = row["updated_at"] if row else None
        age_hours = None
        if updated_at:
            text = str(updated_at).replace("Z", "+00:00")
            updated = datetime.fromisoformat(text)
            if updated.tzinfo is None:
                updated = updated.replace(tzinfo=timezone.utc)
            age_hours = max(0.0, (datetime.now(timezone.utc) - updated.astimezone(timezone.utc)).total_seconds() / 3600)
        return {"available": True, "path": str(path.resolve()), "count": row["count"] if row else 0,
                "updated_at": updated_at, "age_hours": age_hours,
                "refresh_required": age_hours is None or age_hours > 24}
    except Exception as exc:
        return {"available": False, "path": str(path.resolve()), "error": str(exc)}


def run_pipeline(*, symbol: str = DEFAULT_SYMBOL, source_dir: str | Path = "data/stocks",
                 database_path: str | Path = "data/quant_platform.sqlite3",
                 trading_db: str | Path = "trading.db", reports_dir: str | Path = "reports",
                 errors_dir: str | Path = "errors", progress: Callable[[dict[str, Any]], None] | None = None) -> dict[str, Any]:
    run_id = f"RUN-{datetime.now().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:6].upper()}"
    project_root = Path.cwd().resolve()
    source_dir = Path(source_dir)
    database_path = Path(database_path)
    reports_dir = Path(reports_dir)
    reports_dir.mkdir(parents=True, exist_ok=True)
    errors = ErrorCenter(errors_dir)
    report_path = reports_dir / f"{run_id}.json"
    stages: list[dict[str, Any]] = []

    def mark(stage: str, status: str, **details: Any) -> None:
        event = {"stage": stage, "status": status, "at": datetime.now().astimezone().isoformat(), **details}
        stages.append(event)
        if progress is not None:
            try:
                progress(event)
            except Exception:
                # UI progress callback must never break the actual research run.
                pass

    report: dict[str, Any] = {
        "version": VERSION,
        "run_id": run_id,
        "mode": "READ_ONLY_RESEARCH",
        "safe_mode": True,
        "symbol": symbol,
        "project_root": str(project_root),
        "python_executable": sys.executable,
        "orders_submitted": 0,
        "stages": stages,
    }
    try:
        source_path = source_dir / f"{symbol}.db"
        source_mode = "legacy_file"
        source_quality: dict[str, Any] | None = None
        if source_path.exists():
            mark("PRECHECK", "OK", source_path=str(source_path.resolve()), canonical_path=str(database_path.resolve()))
            loaded = load_legacy_daily_with_report(symbol, stock_dir=source_dir)
            source_quality = loaded.as_dict()
            if loaded.issues:
                raise ValueError(f"source data rejected {loaded.rejected_rows}/{loaded.raw_rows} rows: "
                                 f"{loaded.issues[0].detail}")
            source_rows = list(loaded.bars)
        else:
            # data/stocks 원본이 없는 종목도 canonical DB에 이미 보존된
            # historical 데이터가 있으면 백테스트 대상으로 처리합니다.
            source_mode = "canonical_only"
            with MarketDataStore(database_path) as store:
                source_rows = store.get_bars(symbol, "1d")
            mark("PRECHECK", "OK", source_path=None, canonical_path=str(database_path.resolve()),
                 source_mode=source_mode)
        if len(source_rows) < 2:
            raise ValueError(f"not enough valid {source_mode} bars: {len(source_rows)}")
        source_keys = [row.key for row in source_rows]
        if len(set(source_keys)) != len(source_keys):
            raise ValueError(f"{source_mode} contains duplicate symbol/timeframe/timestamp keys")
        mark("SOURCE_READ", "OK", source_mode=source_mode, source_rows=len(source_rows),
             source_rejected_rows=source_quality.get("rejected_rows", 0) if source_quality else 0,
             first_bar=source_rows[0].timestamp.isoformat(), last_bar=source_rows[-1].timestamp.isoformat())

        with MarketDataStore(database_path) as store:
            before_rows = store.get_bars(symbol, "1d")
            before_count = len(before_rows)
            upserted = store.upsert_bars(source_rows)
            after_rows = store.get_bars(symbol, "1d")
            after_by_key = {row.key: row for row in after_rows}
            missing = [key for key in source_keys if key not in after_by_key]
            if missing:
                raise RuntimeError(f"canonical import incomplete: missing={len(missing)}")
            analysis_rows = tuple(after_by_key[key] for key in source_keys)
            extra_rows = [row for row in after_rows if row.key not in set(source_keys)]
            mismatches = []
            for source_row, canonical_row in zip(source_rows, analysis_rows):
                if any(getattr(source_row, field) != getattr(canonical_row, field)
                       for field in ("open", "high", "low", "close", "volume")):
                    mismatches.append(source_row.timestamp.isoformat())
            quality = validate_bars(analysis_rows, expected_timeframe="1d")
            if not quality.ok:
                raise ValueError(f"analysis data quality failed: {quality.by_code()}")
            provenance = inspect_provenance(analysis_rows)
            if provenance["status"] == "FAIL":
                raise ValueError(f"data provenance gate failed: {provenance['findings'][:3]}")
            canonical_coverage = store.coverage(symbol)
        mark("CANONICAL_RECONCILE", "OK", source_rows=len(source_rows), canonical_before=before_count,
             canonical_after=len(after_rows), upserted=upserted, analysis_rows=len(analysis_rows),
             preserved_extra_rows=len(extra_rows), value_mismatches=len(mismatches),
             quality_ok=quality.ok)

        universe = _legacy_universe_status(Path(trading_db))
        mark("UNIVERSE_AUDIT", "OK", **universe)

        candidates = generate_candidates(_atoms(), max_conditions=3, max_combinations=100, seed=123)
        config = _backtest_config()
        evaluations: list[StrategyEvaluation] = []
        details: list[dict[str, Any]] = []
        for index, candidate in enumerate(candidates, start=1):
            if progress is not None:
                try:
                    progress({"stage": "STRATEGY_RESEARCH", "status": "RUNNING",
                              "candidate_index": index, "candidate_total": len(candidates),
                              "candidate_id": candidate.strategy_id})
                except Exception:
                    pass
            evaluation, detail = _evaluate_candidate(candidate, analysis_rows, config)
            evaluations.append(evaluation)
            details.append(detail)
        rule_search = run_breakout_event_study(analysis_rows)
        survivors = select_survivors(
            evaluations,
            min_score=55.0,
            max_drawdown_pct=25.0,
            min_trades=5,
            min_random_positive_rate_pct=60.0,
            min_walk_forward_positive_rate_pct=50.0,
            max_monte_carlo_loss_probability_pct=50.0,
            limit=10,
        )
        mark("STRATEGY_RESEARCH", "OK", candidate_count=len(candidates), survivor_count=len(survivors))

        report.update({
            "source": {"mode": source_mode,
                       "path": str(source_path.resolve()) if source_path else None,
                       "rows": len(source_rows),
                       "quality": source_quality or {"raw_rows": len(source_rows), "accepted_rows": len(source_rows), "rejected_rows": 0, "issues": []},
                       "first_bar": source_rows[0].timestamp.isoformat(),
                       "last_bar": source_rows[-1].timestamp.isoformat()},
            "canonical": {"path": str(database_path.resolve()), "before_rows": before_count,
                          "after_rows": len(after_rows), "coverage": canonical_coverage,
                          "preserved_extra_rows": len(extra_rows),
                          "value_mismatches": mismatches[:20]},
            "analysis": {"rows": len(analysis_rows), "first_bar": analysis_rows[0].timestamp.isoformat(),
                         "last_bar": analysis_rows[-1].timestamp.isoformat(), "quality_ok": quality.ok,
                         "quality_issues": [asdict(issue) for issue in quality.issues]},
            "provenance": provenance,
            "universe": universe,
            "candidates": {"count": len(candidates)},
            "rule_search": rule_search,
            "evaluations": details,
            "survivors": [asdict(item) for item in survivors],
            "next_stage": "SHADOW_REQUIRED" if survivors else "NO_SURVIVOR",
            "report_path": str(report_path.resolve()),
        })
        report["review"] = review_report(report)
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        return report
    except Exception as exc:
        error = errors.record(
            run_id,
            stages[-1]["stage"] if stages else "PRECHECK",
            exc,
            context={"symbol": symbol, "source_dir": source_dir, "database_path": database_path,
                     "stages_completed": [item["stage"] for item in stages]},
            recoverable=False,
            recommended_action="오류 JSON과 마지막 성공 단계를 확인한 뒤 오류번호를 전달하세요.",
            impact="현재 통합 실행을 중단했습니다. 주문은 제출되지 않았습니다.",
        )
        mark("FAILED", "ERROR", error_id=error.error_id, error_type=error.error_type)
        report.update({"status": "FAILED", "error_id": error.error_id,
                       "error_report": str((errors.root / f"{error.error_id}.json").resolve()),
                       "report_path": str(report_path.resolve())})
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        raise RuntimeError(f"{error.error_id}: {type(exc).__name__}: {exc}") from exc


def main() -> int:
    parser = argparse.ArgumentParser(description="기존 StockBot + 새 quant_platform 통합 실행기")
    parser.add_argument("--symbol", default=DEFAULT_SYMBOL)
    parser.add_argument("--source-dir", type=Path, default=Path("data/stocks"))
    parser.add_argument("--db", type=Path, default=Path("data/quant_platform.sqlite3"))
    parser.add_argument("--trading-db", type=Path, default=Path("trading.db"))
    parser.add_argument("--reports-dir", type=Path, default=Path("reports"))
    parser.add_argument("--errors-dir", type=Path, default=Path("errors"))
    args = parser.parse_args()
    try:
        report = run_pipeline(symbol=args.symbol, source_dir=args.source_dir, database_path=args.db,
                              trading_db=args.trading_db, reports_dir=args.reports_dir, errors_dir=args.errors_dir)
        print("status = COMPLETED")
        print("mode =", report["mode"])
        print("symbol =", report["symbol"])
        print("source_rows =", report["source"]["rows"])
        print("canonical_rows =", report["canonical"]["after_rows"])
        print("analysis_rows =", report["analysis"]["rows"])
        print("candidate_count =", report["candidates"]["count"])
        print("survivor_count =", len(report["survivors"]))
        print("orders_submitted =", report["orders_submitted"])
        print("report =", report["report_path"])
        return 0
    except Exception as exc:
        print("status = FAILED")
        print("error =", type(exc).__name__, str(exc))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
