"""키움 조건검색 결과와 로컬 조건의 대조 계약.

키움 OpenAPI의 실제 메서드·버전·응답을 확인하기 전에는 원격 호출을 구현하지
않습니다. 이 모듈은 worker가 실제로 수집한 결과와 로컬 결과를 비교합니다.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Iterable


@dataclass(frozen=True)
class ConditionSnapshot:
    provider: str
    condition_id: str
    condition_version: str
    captured_at: str
    symbols: tuple[str, ...]

    def __post_init__(self) -> None:
        if not str(self.condition_id).strip() or not str(self.condition_version).strip():
            raise ValueError("condition_id and condition_version are required")
        normalized = sorted({str(symbol).strip() for symbol in self.symbols if str(symbol).strip()})
        if any(len(symbol) != 6 or not symbol.isdigit() for symbol in normalized):
            raise ValueError("condition symbols must be six-digit codes")
        # 실제 worker가 공급한 캡처 시각만 받으며, 빈 문자열은 허용하지 않습니다.
        if not str(self.captured_at).strip():
            raise ValueError("captured_at is required")
        object.__setattr__(self, "provider", str(self.provider).strip())
        object.__setattr__(self, "condition_id", str(self.condition_id).strip())
        object.__setattr__(self, "condition_version", str(self.condition_version).strip())
        object.__setattr__(self, "symbols", tuple(normalized))


@dataclass(frozen=True)
class ConditionComparison:
    condition_id: str
    condition_version: str
    captured_at: str
    kiwoom_count: int
    local_count: int
    intersection_count: int
    kiwoom_only: tuple[str, ...]
    local_only: tuple[str, ...]
    precision_pct: float | None
    recall_pct: float | None
    jaccard_pct: float | None
    status: str

    def as_dict(self) -> dict:
        return {
            "condition_id": self.condition_id,
            "condition_version": self.condition_version,
            "captured_at": self.captured_at,
            "kiwoom_count": self.kiwoom_count,
            "local_count": self.local_count,
            "intersection_count": self.intersection_count,
            "kiwoom_only": list(self.kiwoom_only),
            "local_only": list(self.local_only),
            "precision_pct": self.precision_pct,
            "recall_pct": self.recall_pct,
            "jaccard_pct": self.jaccard_pct,
            "status": self.status,
        }


def compare_condition_snapshots(kiwoom: ConditionSnapshot, local: ConditionSnapshot, *, min_match_pct: float = 95.0) -> ConditionComparison:
    if kiwoom.provider.lower() != "kiwoom":
        raise ValueError("first snapshot must have provider=kiwoom")
    if local.condition_id != kiwoom.condition_id or local.condition_version != kiwoom.condition_version:
        return ConditionComparison(
            kiwoom.condition_id, kiwoom.condition_version, kiwoom.captured_at,
            len(kiwoom.symbols), len(local.symbols), 0, kiwoom.symbols, local.symbols,
            0.0, 0.0, 0.0, "CONDITION_VERSION_MISMATCH",
        )
    if kiwoom.captured_at != local.captured_at:
        return ConditionComparison(
            kiwoom.condition_id, kiwoom.condition_version, kiwoom.captured_at,
            len(kiwoom.symbols), len(local.symbols), 0, kiwoom.symbols, local.symbols,
            0.0, 0.0, 0.0, "CAPTURE_TIME_MISMATCH",
        )
    left, right = set(kiwoom.symbols), set(local.symbols)
    intersection = left & right
    union = left | right
    precision = len(intersection) / len(right) * 100 if right else None
    recall = len(intersection) / len(left) * 100 if left else None
    jaccard = len(intersection) / len(union) * 100 if union else 100.0
    status = "KIWOOM_MATCH" if precision is not None and recall is not None and min(precision, recall) >= min_match_pct else "CONDITION_MISMATCH"
    return ConditionComparison(
        kiwoom.condition_id, kiwoom.condition_version, kiwoom.captured_at,
        len(left), len(right), len(intersection), tuple(sorted(left - right)), tuple(sorted(right - left)),
        precision, recall, jaccard, status,
    )
