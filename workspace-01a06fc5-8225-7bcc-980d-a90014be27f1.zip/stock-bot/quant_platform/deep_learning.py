"""딥러닝 검증 경계.

이 모듈은 딥러닝 모델을 자동으로 전략에 편입하지 않습니다. 먼저 시간순 분할,
미래정보 누수, 표본 수, 라이브러리 설치 상태를 검사합니다. PyTorch가 없으면
NOT_INSTALLED로 명시하고 통과로 위장하지 않습니다.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Sequence

from .domain import Bar


@dataclass(frozen=True)
class DeepLearningResult:
    status: str
    eligible: bool
    rows: int
    train_rows: int
    test_rows: int
    train_test_overlap: int
    test_accuracy: float | None = None
    baseline_accuracy: float | None = None
    epochs: int = 0
    detail: str = ""

    def as_dict(self) -> dict:
        return asdict(self)


def _features(rows: Sequence[Bar]):
    # row t의 feature는 t까지, label은 t+1의 방향만 사용합니다.
    values = []
    labels = []
    for index in range(1, len(rows) - 1):
        previous = rows[index - 1]
        current = rows[index]
        next_row = rows[index + 1]
        values.append([
            current.close / previous.close - 1.0,
            (current.high - current.low) / current.close,
            current.volume / max(previous.volume, 1.0),
        ])
        labels.append(1.0 if next_row.close > current.close else 0.0)
    return values, labels


def run_deep_learning_probe(rows: Sequence[Bar], *, min_rows: int = 120, epochs: int = 12,
                            seed: int = 123) -> dict:
    values = list(rows)
    if len(values) < min_rows:
        return DeepLearningResult("INSUFFICIENT_DATA", False, len(values), 0, 0, 0,
                                  detail=f"at least {min_rows} chronological bars are required").as_dict()
    features, labels = _features(values)
    split = int(len(features) * 0.8)
    train_rows = split
    test_rows = len(features) - split
    if split <= 0 or test_rows <= 0:
        return DeepLearningResult("INSUFFICIENT_SPLIT", False, len(values), train_rows, test_rows, 0,
                                  detail="chronological train/test split is empty").as_dict()
    overlap = 0
    try:
        import torch
        from torch import nn
    except ImportError:
        return DeepLearningResult("NOT_INSTALLED", False, len(values), train_rows, test_rows, overlap,
                                  detail="PyTorch is not installed; no deep model was trained").as_dict()

    torch.manual_seed(seed)
    x_train = torch.tensor(features[:split], dtype=torch.float32)
    y_train = torch.tensor(labels[:split], dtype=torch.float32).reshape(-1, 1)
    x_test = torch.tensor(features[split:], dtype=torch.float32)
    y_test = torch.tensor(labels[split:], dtype=torch.float32).reshape(-1, 1)
    model = nn.Sequential(nn.Linear(3, 8), nn.ReLU(), nn.Linear(8, 1))
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
    loss_fn = nn.BCEWithLogitsLoss()
    for _ in range(max(1, int(epochs))):
        optimizer.zero_grad()
        loss = loss_fn(model(x_train), y_train)
        loss.backward()
        optimizer.step()
    with torch.no_grad():
        predictions = (torch.sigmoid(model(x_test)) >= 0.5).float()
        accuracy = float((predictions == y_test).float().mean().item() * 100)
    positive_rate = sum(labels[split:]) / len(labels[split:])
    baseline = max(positive_rate, 1 - positive_rate) * 100
    return DeepLearningResult(
        "PROBED", True, len(values), train_rows, test_rows, overlap,
        test_accuracy=round(accuracy, 4), baseline_accuracy=round(baseline, 4),
        epochs=max(1, int(epochs)), detail="chronological holdout probe only; not approved for trading",
    ).as_dict()
