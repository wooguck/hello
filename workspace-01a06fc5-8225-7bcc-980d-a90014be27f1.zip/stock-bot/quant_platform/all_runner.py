"""전체 기존 종목을 resumable batch로 통합·검증하는 실행기."""
from __future__ import annotations

import json
import shutil
import sqlite3
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from .error_center import ErrorCenter
from .orchestrator import run_pipeline


class RunCancelled(Exception):
    pass


def _now() -> str:
    return datetime.now().astimezone().isoformat()


def _universe_audit(trading_db: Path) -> dict[str, Any]:
    """기존 universe를 읽기 전용으로 감사합니다.

    GitHub historical master를 current로 승격하지 않습니다. 공식 현재 목록이
    별도로 연결되기 전까지는 legacy_unverified로만 표시합니다.
    """
    if not trading_db.exists():
        return {"available": False, "path": str(trading_db.resolve()), "reason": "trading.db not found"}
    try:
        with sqlite3.connect(trading_db) as db:
            db.row_factory = sqlite3.Row
            total = db.execute("SELECT COUNT(*) AS n FROM universe").fetchone()["n"]
            latest = db.execute("SELECT MAX(updated_at) AS value FROM universe").fetchone()["value"]
            markets = [dict(row) for row in db.execute(
                "SELECT market, COUNT(*) AS n FROM universe GROUP BY market ORDER BY market"
            ).fetchall()]
        age_hours = None
        if latest:
            value = datetime.fromisoformat(str(latest).replace("Z", "+00:00"))
            if value.tzinfo is None:
                value = value.replace(tzinfo=timezone.utc)
            age_hours = max(0.0, (datetime.now(timezone.utc) - value.astimezone(timezone.utc)).total_seconds() / 3600)
        return {
            "available": True,
            "path": str(trading_db.resolve()),
            "count": total,
            "updated_at": latest,
            "age_hours": age_hours,
            "refresh_required": age_hours is None or age_hours > 24,
            "classification": "legacy_unverified",
            "markets": markets,
        }
    except Exception as exc:
        return {"available": False, "path": str(trading_db.resolve()), "error": str(exc)}


def discover_symbols(source_dir: Path, canonical_db: Path) -> tuple[list[str], list[str]]:
    source_symbols = sorted(path.stem for path in source_dir.glob("*.db") if path.stem.isdigit() and len(path.stem) == 6)
    canonical_symbols: list[str] = []
    if canonical_db.exists():
        try:
            with sqlite3.connect(canonical_db) as db:
                canonical_symbols = [row[0] for row in db.execute("SELECT DISTINCT symbol FROM bars ORDER BY symbol")]
        except sqlite3.Error:
            canonical_symbols = []
    return sorted(set(source_symbols)), sorted(set(canonical_symbols) - set(source_symbols))


def _canonical_fingerprint(database_path: Path, symbol: str) -> str:
    if not database_path.exists():
        return "canonical:missing"
    try:
        with sqlite3.connect(database_path) as db:
            row = db.execute(
                "SELECT COUNT(*), MAX(bar_time) FROM bars WHERE symbol=? AND timeframe='1d'",
                (symbol,),
            ).fetchone()
        return f"canonical:{row[0]}:{row[1]}"
    except sqlite3.Error:
        return "canonical:unreadable"


def _load_state(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"version": 1, "completed": {}, "failed": {}}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            return {"version": 1, "completed": {}, "failed": {}}
        # 손상되었거나 이전 버전에서 리스트로 저장된 상태도 안전한 빈 맵으로 정규화합니다.
        if not isinstance(value.get("completed"), dict):
            value["completed"] = {}
        if not isinstance(value.get("failed"), dict):
            value["failed"] = {}
        return value
    except (OSError, json.JSONDecodeError):
        backup = path.with_name(path.name + f".corrupt-{datetime.now().strftime('%Y%m%d-%H%M%S')}")
        try:
            shutil.copy2(path, backup)
        except OSError:
            pass
        return {"version": 1, "completed": {}, "failed": {}}


def _save_state(path: Path, state: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def run_all(*, source_dir: str | Path = "data/stocks", database_path: str | Path = "data/quant_platform.sqlite3",
            trading_db: str | Path = "trading.db", reports_dir: str | Path = "reports",
            errors_dir: str | Path = "errors", resume: bool = True,
            progress: Callable[[dict[str, Any]], None] | None = None,
            stop_event: threading.Event | None = None) -> dict[str, Any]:
    source_dir = Path(source_dir)
    database_path = Path(database_path)
    reports_dir = Path(reports_dir)
    reports_dir.mkdir(parents=True, exist_ok=True)
    all_run_id = f"ALL-{datetime.now().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:6].upper()}"
    state_path = reports_dir / "all_run_state.json"
    state = _load_state(state_path) if resume else {"version": 1, "completed": {}, "failed": {}}
    source_symbols, canonical_only = discover_symbols(source_dir, database_path)
    # 원본 종목과 canonical-only 종목을 합쳐 전체 실행 대상 universe를 만듭니다.
    # 이전 버전은 이 변수를 만들기 전에 참조해 전체 실행 시작 즉시 실패했습니다.
    symbols = sorted(set(source_symbols) | set(canonical_only))
    summary = {
        "all_run_id": all_run_id,
        "mode": "READ_ONLY_RESEARCH_ALL",
        "started_at": _now(),
        "source_dir": str(source_dir.resolve()),
        "database_path": str(database_path.resolve()),
        "trading_db": str(Path(trading_db).resolve()),
        "source_symbol_count": len(source_symbols),
        "canonical_only_symbol_count": len(canonical_only),
        "canonical_only_symbols": canonical_only[:100],
        "total_symbol_count": len(symbols),
        "completed": [],
        "failed": [],
        "skipped": [],
        "orders_submitted": 0,
        "status": "RUNNING",
    }
    universe = _universe_audit(Path(trading_db))
    total = len(symbols)
    for index, symbol in enumerate(symbols, start=1):
        if stop_event is not None and stop_event.is_set():
            summary["status"] = "STOPPED"
            break
        source_path = source_dir / f"{symbol}.db"
        fingerprint = (f"{source_path.stat().st_size}:{source_path.stat().st_mtime_ns}"
                       if source_path.exists() else _canonical_fingerprint(database_path, symbol))
        previous = state.get("completed", {}).get(symbol)
        if resume and previous and previous.get("fingerprint") == fingerprint:
            summary["skipped"].append(symbol)
            if progress:
                progress({"stage": "ALL_RUN", "status": "SKIPPED", "index": index, "total": total, "symbol": symbol})
            continue
        if progress:
            progress({"stage": "ALL_RUN", "status": "RUNNING", "index": index, "total": total, "symbol": symbol})
        try:
            report = run_pipeline(symbol=symbol, source_dir=source_dir, database_path=database_path,
                                  trading_db=trading_db, reports_dir=reports_dir, errors_dir=errors_dir,
                                  progress=progress)
            state.setdefault("completed", {})[symbol] = {
                "fingerprint": fingerprint,
                "completed_at": _now(),
                "report_path": report.get("report_path"),
                "analysis_rows": report.get("analysis", {}).get("rows", 0),
                "survivor_count": len(report.get("survivors", [])),
            }
            state.get("failed", {}).pop(symbol, None)
            summary["completed"].append({
                "symbol": symbol,
                "source_rows": report.get("source", {}).get("rows", 0),
                "canonical_rows": report.get("canonical", {}).get("after_rows", 0),
                "analysis_rows": report.get("analysis", {}).get("rows", 0),
                "survivor_count": len(report.get("survivors", [])),
                "report_path": report.get("report_path"),
            })
        except Exception as exc:
            error_id = None
            latest = Path(errors_dir) / "latest.json"
            if latest.exists():
                try:
                    error_id = json.loads(latest.read_text(encoding="utf-8")).get("error_id")
                except (OSError, json.JSONDecodeError):
                    pass
            state.setdefault("failed", {})[symbol] = {"failed_at": _now(), "error": str(exc), "error_id": error_id}
            summary["failed"].append({"symbol": symbol, "error": str(exc), "error_id": error_id})
        _save_state(state_path, state)
        if progress:
            progress({"stage": "ALL_RUN", "status": "PROGRESS", "index": index, "total": total,
                      "completed": len(summary["completed"]), "failed": len(summary["failed"]),
                      "skipped": len(summary["skipped"]), "symbol": symbol})

    if summary["status"] == "RUNNING":
        summary["status"] = "COMPLETED"
    summary["finished_at"] = _now()
    summary["universe"] = universe
    summary["state_path"] = str(state_path.resolve())
    summary["completed_count"] = len(summary["completed"])
    summary["failed_count"] = len(summary["failed"])
    summary["skipped_count"] = len(summary["skipped"])
    output = reports_dir / f"{all_run_id}.json"
    output.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    summary["report_path"] = str(output.resolve())
    output.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary
