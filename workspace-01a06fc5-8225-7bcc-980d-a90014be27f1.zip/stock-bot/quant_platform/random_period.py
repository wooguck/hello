"""이전 배포본 호환 shim. 새 구현은 quant_platform.validation.random_period에 있습니다."""
from .validation.random_period import RandomValidationResult, random_windows, validate_random_periods

__all__ = ["RandomValidationResult", "random_windows", "validate_random_periods"]
