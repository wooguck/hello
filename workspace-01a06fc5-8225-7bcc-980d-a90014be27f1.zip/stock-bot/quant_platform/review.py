"""실행 결과 검수·교차검증·요약·소크라테스 질문 생성."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class ReviewFinding:
    code: str
    severity: str  # PASS | WARN | FAIL
    title: str
    detail: str
    action: str = ""

    def as_dict(self) -> dict[str, str]:
        return asdict(self)


def _finding(code: str, severity: str, title: str, detail: str, action: str = "") -> ReviewFinding:
    return ReviewFinding(code, severity, title, detail, action)


def socratic_questions(report: dict[str, Any]) -> list[dict[str, str]]:
    """결과가 자동 결론으로 굳어지지 않도록 사용자 판단 질문을 만듭니다."""
    questions = [
        {"id": "risk_limit", "question": "허용 가능한 최대낙폭(MDD)은 몇 퍼센트인가요?", "reason": "수익률만으로 전략을 채택하지 않기 위해 필요합니다."},
        {"id": "universe_scope", "question": "상장폐지 종목을 백테스트에 포함할 것인가요? 현재 매매 universe에는 포함하지 않습니다.", "reason": "historical과 current universe를 분리해야 합니다."},
        {"id": "out_of_sample", "question": "최근 구간 성과가 과거보다 나빠져도 Shadow를 허용할 것인가요?", "reason": "재검증 KEEP만으로 실거래를 승인하지 않기 위해 필요합니다."},
    ]
    provenance = report.get("provenance", {})
    if provenance.get("status") in {"FAIL", "WARN"}:
        questions.append({"id": "data_authenticity", "question": "이 자료의 원천·checksum을 확인했나요? 합성·복제·미래 봉이면 연구를 폐기할까요?", "reason": "수익률보다 데이터 진위가 우선입니다."})
    analysis = report.get("analysis", {})
    if analysis.get("rows", 0) < 300:
        questions.append({"id": "sample_size", "question": "현재 표본 수가 적은데 이 결과를 보류하고 데이터를 더 모을까요?", "reason": "표본 부족은 과적합 위험을 높입니다."})
    if report.get("canonical", {}).get("preserved_extra_rows", 0):
        questions.append({"id": "extra_rows", "question": "원본에 없는 canonical 추가 봉을 보존하되 분석에서 제외하는 정책을 유지할까요?", "reason": "데이터 출처가 섞이면 성과가 달라질 수 있습니다."})
    return questions


def _rule_review(report: dict[str, Any]) -> list[ReviewFinding]:
    findings: list[ReviewFinding] = []
    if report.get("mode") not in {"READ_ONLY_RESEARCH", "READ_ONLY_RESEARCH_ALL"}:
        findings.append(_finding("MODE_UNSAFE", "FAIL", "실행 모드", "읽기 전용 연구 모드가 아닙니다.", "주문 게이트웨이를 OFF로 두고 다시 실행하세요."))
    if report.get("orders_submitted", 0) != 0:
        findings.append(_finding("ORDERS_NONZERO", "FAIL", "주문 제출", "연구 실행에서 주문 제출 수가 0이 아닙니다.", "즉시 주문 게이트웨이를 중지하고 ledger를 확인하세요."))
    else:
        findings.append(_finding("ORDERS_ZERO", "PASS", "주문 제출", "연구 실행에서 주문이 제출되지 않았습니다."))

    analysis = report.get("analysis", {})
    canonical = report.get("canonical", {})
    source = report.get("source", {})
    if analysis.get("quality_ok") is True:
        findings.append(_finding("DATA_QUALITY", "PASS", "분석 데이터 품질", "구조적 품질 검사를 통과했습니다."))
    else:
        findings.append(_finding("DATA_QUALITY", "FAIL", "분석 데이터 품질", "분석 데이터 품질 검사 실패", "백테스트를 중지하고 원본 데이터를 확인하세요."))
    if canonical.get("preserved_extra_rows", 0) == 0:
        findings.append(_finding("SOURCE_ALIGNMENT", "PASS", "원본·canonical 정렬", "추가 canonical 행 없이 분석했습니다."))
    else:
        findings.append(_finding("SOURCE_ALIGNMENT", "WARN", "원본·canonical 정렬", f"canonical 추가 행 {canonical.get('preserved_extra_rows')}개를 보존하고 분석에서 제외했습니다.", "추가 행의 출처와 가격조정 기준을 확인하세요."))
    if source.get("rows", 0) == analysis.get("rows", 0) and source.get("rows", 0) > 0:
        findings.append(_finding("ROW_ALIGNMENT", "PASS", "분석 행 수", f"원본 {source.get('rows')}개와 분석 {analysis.get('rows')}개가 일치합니다."))
    else:
        findings.append(_finding("ROW_ALIGNMENT", "FAIL", "분석 행 수", f"원본 {source.get('rows', 0)}개와 분석 {analysis.get('rows', 0)}개가 다릅니다.", "분석을 보류하고 import를 확인하세요."))

    provenance = report.get("provenance", {})
    provenance_status = provenance.get("status")
    if provenance_status == "FAIL":
        findings.append(_finding("PROVENANCE_GATE", "FAIL", "데이터 출처·진위", "합성·미래·의심 데이터가 분석 승인에서 차단되었습니다.", "provenance.findings의 원인 행을 확인하고 실제 원천으로 교체하세요."))
    elif provenance_status == "WARN":
        findings.append(_finding("PROVENANCE_GATE", "WARN", "데이터 출처·진위", "출처 또는 거래량 검증 경고가 있습니다.", "실제 원천 응답·checksum을 확인하세요."))
    elif provenance_status == "PASS":
        findings.append(_finding("PROVENANCE_GATE", "PASS", "데이터 출처·진위", "출처·미래 시각·합성 데이터 검사를 통과했습니다."))
    else:
        findings.append(_finding("PROVENANCE_MISSING", "WARN", "데이터 출처·진위", "이 리포트에는 provenance 검수 결과가 없습니다.", "새 통합 실행기로 리포트를 다시 생성하세요."))

    universe = report.get("universe", {})
    if universe.get("classification") == "legacy_unverified":
        findings.append(_finding("UNIVERSE_UNVERIFIED", "WARN", "현재 universe", "기존 universe는 historical fallback 가능성이 있어 current 운영용으로 승인하지 않았습니다.", "공식 현재 종목 목록을 연결한 뒤 current로 승격하세요."))
    else:
        findings.append(_finding("UNIVERSE_STATUS", "PASS", "현재 universe", "current universe 출처가 확인되었습니다."))

    rule_search = report.get("rule_search", {})
    if rule_search.get("status") == "PASS":
        findings.append(_finding("RULE_SEARCH", "PASS", "돌파 조건 검색", f"학습 신호 {rule_search.get('train_signal_count', 0)}개·OOS 신호 {rule_search.get('test_signal_count', 0)}개를 확보했습니다."))
    else:
        findings.append(_finding("RULE_SEARCH", "WARN", "돌파 조건 검색", f"OOS까지 검증할 신호 표본이 부족합니다: {rule_search.get('test_signal_count', 0)}개", "수익률을 주장하지 말고 데이터를 더 모으세요."))

    evaluations = report.get("evaluations", [])
    if not evaluations:
        findings.append(_finding("NO_EVALUATION", "FAIL", "전략 평가", "전략 평가 결과가 없습니다.", "전략 연구를 다시 실행하세요."))
    else:
        bad_risk = [item for item in evaluations if item.get("backtest", {}).get("max_drawdown_pct", 0) > 25]
        if bad_risk:
            findings.append(_finding("RISK_GATE", "FAIL", "위험도 gate", f"MDD 25% 초과 전략 {len(bad_risk)}개가 있습니다.", "SURVIVOR로 승격하지 말고 Shadow 전환을 보류하세요."))
        else:
            findings.append(_finding("RISK_GATE", "PASS", "위험도 gate", "평가 전략의 MDD가 기본 한도 이내입니다."))

    dl = report.get("deep_learning", {})
    if dl.get("status") == "PROBED":
        findings.append(_finding("MODEL_CROSSCHECK", "WARN", "모델 교차검증", "규칙 모델과 딥러닝 probe 결과를 나란히 생성했지만 자동 채택하지 않았습니다.", "시간순 OOS 성능·기준모델 대비 개선·과적합을 별도로 검토하세요."))
    else:
        findings.append(_finding("MODEL_CROSSCHECK", "WARN", "모델 교차검증", "현재는 결정론적 RULE 검수만 수행했습니다.", "딥러닝 probe 또는 독립 외부 모델 검토를 통과하기 전에는 전략을 채택하지 마세요."))
    return findings


def review_report(report: dict[str, Any]) -> dict[str, Any]:
    findings = _rule_review(report)
    fail_count = sum(item.severity == "FAIL" for item in findings)
    warn_count = sum(item.severity == "WARN" for item in findings)
    if fail_count:
        status = "REJECTED"
    elif warn_count:
        status = "HOLD_FOR_REVIEW"
    else:
        status = "APPROVE_FOR_SHADOW"
    key = []
    for item in findings:
        if item.severity != "PASS":
            key.append(f"{item.title}: {item.detail}")
    summary = "정상 항목은 생략했습니다. " + ("; ".join(key) if key else "추가 보류 사유가 없습니다.")
    return {
        "reviewed_at": datetime.now(timezone.utc).astimezone().isoformat(),
        "status": status,
        "counts": {"PASS": len(findings) - fail_count - warn_count, "WARN": warn_count, "FAIL": fail_count},
        "safe_to_order": False,
        "summary": summary,
        "findings": [item.as_dict() for item in findings],
        "socratic_questions": socratic_questions(report),
        "model_crosscheck": {"mode": "RULE_ONLY", "providers": ["rule"], "independent_model_agreement": None},
    }


def review_file(report_path: str | Path, output_path: str | Path | None = None) -> Path:
    report_path = Path(report_path)
    report = json.loads(report_path.read_text(encoding="utf-8"))
    review = review_report(report)
    output = Path(output_path) if output_path else report_path.with_name(report_path.stem + "_review.json")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(review, ensure_ascii=False, indent=2), encoding="utf-8")
    return output
