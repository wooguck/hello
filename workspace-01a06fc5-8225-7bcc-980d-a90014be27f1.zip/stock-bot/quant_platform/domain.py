"""공통 도메인 모델.

모든 모듈이 동일한 Bar/Timeframe을 사용해야 백테스트와 실시간 모의투자의
의미가 달라지는 문제를 줄일 수 있습니다.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from enum import Enum
from math import isfinite
from zoneinfo import ZoneInfo

KST = ZoneInfo("Asia/Seoul")


class Timeframe(str, Enum):
    MINUTE_1 = "1m"
    MINUTE_5 = "5m"
    MINUTE_15 = "15m"
    DAILY = "1d"


class DataSource(str, Enum):
    KIWOOM = "kiwoom"
    NAVER = "naver"
    DAUM = "daum"
    YAHOO = "yahoo"
    MOCK = "mock"
    IMPORTED = "imported"
    UNKNOWN = "unknown"


def to_kst(value: datetime | date | str) -> datetime:
    """입력 시각을 timezone-aware Asia/Seoul datetime으로 변환합니다.

    naive datetime은 프로젝트의 기존 정책과 호환되도록 KST로 간주합니다.
    문자열은 ISO-8601 형식만 허용해 모호한 날짜 파싱을 막습니다.
    """
    if isinstance(value, str):
        text = value.strip()
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        value = datetime.fromisoformat(text)
    if isinstance(value, date) and not isinstance(value, datetime):
        value = datetime.combine(value, time.min)
    if not isinstance(value, datetime):
        raise TypeError("timestamp must be datetime, date, or ISO-8601 string")
    if value.tzinfo is None:
        return value.replace(tzinfo=KST)
    return value.astimezone(KST)


@dataclass(frozen=True, slots=True)
class Bar:
    symbol: str
    timeframe: Timeframe | str
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0
    trading_value: float | None = None
    source: DataSource | str = DataSource.UNKNOWN
    adjusted: bool = False

    def __post_init__(self) -> None:
        symbol = str(self.symbol).strip()
        if not symbol:
            raise ValueError("symbol is required")
        timeframe = self.timeframe.value if isinstance(self.timeframe, Timeframe) else str(self.timeframe)
        if timeframe not in {item.value for item in Timeframe}:
            raise ValueError(f"unsupported timeframe: {timeframe}")
        values = (self.open, self.high, self.low, self.close)
        if any(not isfinite(float(v)) for v in values):
            raise ValueError("OHLC values must be finite")
        if any(float(v) <= 0 for v in values):
            raise ValueError("OHLC values must be positive")
        if not isfinite(float(self.volume)) or (self.trading_value is not None and not isfinite(float(self.trading_value))):
            raise ValueError("volume/trading_value must be finite")
        if float(self.high) < max(float(self.open), float(self.close)):
            raise ValueError("high must be >= open and close")
        if float(self.low) > min(float(self.open), float(self.close)):
            raise ValueError("low must be <= open and close")
        if float(self.volume) < 0:
            raise ValueError("volume cannot be negative")
        if self.trading_value is not None and float(self.trading_value) < 0:
            raise ValueError("trading_value cannot be negative")
        object.__setattr__(self, "symbol", symbol)
        object.__setattr__(self, "timeframe", timeframe)
        object.__setattr__(self, "timestamp", to_kst(self.timestamp))
        object.__setattr__(self, "source", self.source.value if isinstance(self.source, DataSource) else str(self.source))
        for field in ("open", "high", "low", "close", "volume"):
            object.__setattr__(self, field, float(getattr(self, field)))
        if self.trading_value is not None:
            object.__setattr__(self, "trading_value", float(self.trading_value))

    @property
    def key(self) -> tuple[str, str, str]:
        return self.symbol, str(self.timeframe), self.timestamp.isoformat()

    def as_dict(self) -> dict:
        return {
            "symbol": self.symbol,
            "timeframe": str(self.timeframe),
            "timestamp": self.timestamp.isoformat(),
            "open": self.open,
            "high": self.high,
            "low": self.low,
            "close": self.close,
            "volume": self.volume,
            "trading_value": self.trading_value,
            "source": self.source,
            "adjusted": self.adjusted,
        }


@dataclass(frozen=True, slots=True)
class Quote:
    symbol: str
    price: float
    timestamp: datetime
    change_pct: float | None = None
    volume: float | None = None

    def __post_init__(self) -> None:
        if not isfinite(float(self.price)):
            raise ValueError("quote price must be finite")
        if float(self.price) <= 0:
            raise ValueError("quote price must be positive")
        object.__setattr__(self, "symbol", str(self.symbol).strip())
        object.__setattr__(self, "price", float(self.price))
        object.__setattr__(self, "timestamp", to_kst(self.timestamp))
        if self.change_pct is not None:
            if not isfinite(float(self.change_pct)):
                raise ValueError("quote change_pct must be finite")
            object.__setattr__(self, "change_pct", float(self.change_pct))
        if self.volume is not None:
            if not isfinite(float(self.volume)) or float(self.volume) < 0:
                raise ValueError("quote volume must be finite and non-negative")
            object.__setattr__(self, "volume", float(self.volume))
