"""선택적 FastAPI API.

실제 주문 API는 노출하지 않습니다. 백테스트와 상태조회는 job 기반으로 실행하고,
나중에 Redis/Celery queue로 교체할 수 있도록 LocalJobQueue 뒤에 둡니다.
"""
import json
from pathlib import Path

from .conditions import canonicalize, strategy_hash, validate
from .config import load_settings
from .error_center import ErrorCenter
from .jobs import LocalJobQueue
from .pipeline import PipelineConfig, run_demo
from .strategies import generate_candidates


def create_app(*, queue: LocalJobQueue | None = None):
    try:
        from fastapi import FastAPI, HTTPException
        from pydantic import BaseModel, Field
    except ImportError as exc:
        raise RuntimeError("FastAPI API requires optional dependencies: fastapi and uvicorn") from exc

    class DemoRequest(BaseModel):
        bars: int = Field(default=180, ge=40, le=5000)
        candidates: int = Field(default=24, ge=1, le=5000)

    class ConditionRequest(BaseModel):
        condition: dict

    class AtomsRequest(BaseModel):
        atoms: list[dict]
        max_conditions: int = Field(default=3, ge=1, le=6)
        max_combinations: int = Field(default=100, ge=1, le=10000)

    app = FastAPI(title="Kiwoom Quant Research API", version="0.1.0")
    job_queue = queue or LocalJobQueue(max_workers=2)

    @app.get("/api/system-status")
    def system_status():
        settings = load_settings(base_dir=Path.cwd())
        latest_error = ErrorCenter("errors").list_recent(limit=1)
        return {"ok": True, "settings": settings.safe_summary(), "live_orders": False,
                "latest_error": latest_error[0] if latest_error else None}

    @app.get("/api/errors")
    def list_errors(limit: int = 20):
        limit = max(1, min(int(limit), 100))
        return {"errors": ErrorCenter("errors").list_recent(limit=limit)}

    @app.get("/api/errors/{error_id}")
    def get_error(error_id: str):
        path = Path("errors") / f"{error_id}.json"
        if not path.exists():
            raise HTTPException(status_code=404, detail="error not found")
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=500, detail="error report is invalid JSON") from exc

    @app.post("/api/backtests")
    def create_backtest(request: DemoRequest):
        job_id = job_queue.submit(run_demo, PipelineConfig(bars_per_symbol=request.bars, candidate_limit=request.candidates))
        return {"job_id": job_id, "status": "QUEUED"}

    @app.get("/api/backtests/{job_id}")
    def get_backtest(job_id: str):
        job = job_queue.get(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="job not found")
        return {"job_id": job.job_id, "status": job.status.value, "created_at": job.created_at,
                "result": job.result, "error": job.error}

    @app.post("/api/conditions/validate")
    def validate_condition(request: ConditionRequest):
        try:
            canonical = canonicalize(request.condition)
            return {"valid": True, "strategy_hash": strategy_hash(canonical), "condition": canonical}
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @app.post("/api/strategies/generate")
    def generate_strategy_candidates(request: AtomsRequest):
        try:
            candidates = generate_candidates(request.atoms, max_conditions=request.max_conditions,
                                             max_combinations=request.max_combinations)
            return {"count": len(candidates), "candidates": [
                {"strategy_id": item.strategy_id, "strategy_hash": item.strategy_hash,
                 "condition_count": item.condition_count, "condition": item.condition}
                for item in candidates
            ]}
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    return app
