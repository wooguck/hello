# 확장 코어 — 퀀트 연구 플랫폼 Phase 1

기존 `desktop_app.py` 기반 키움 자동매매 시스템을 한 번에 교체하지 않고, 아래 핵심 모듈을 독립적으로 검증한 뒤 기존 기능과 연결합니다.

- `domain.py`: KST 기준 공통 `Bar`, `Quote`, `Timeframe`
- `data/store.py`: 중복 방지 SQLite canonical bar store, Parquet export hook
- `data/quality.py`: OHLC/중복/시간순서 무결성 보고서
- `broker/base.py`, `broker/kiwoom.py`: 키움 REST adapter 경계. 공식 TR 스키마를 확인하지 않고 endpoint/필드를 추측하지 않음
- `conditions/dsl.py`: JSON/AST 조건식, canonical hash, 안전한 평가기
- `backtest/engine.py`: t 시점 신호 → t+1 시가 체결, 수수료/슬리피지 반영
- `config.py`: 안전한 환경변수 기반 설정과 실전 거래 이중 잠금

## 기존 프로그램과 분리 설치

기존 자동매매 프로그램의 Python 환경을 변경하지 않도록 새 코어는 별도 가상환경에 설치합니다.
새 코어는 현재 실제 주문을 제공하지 않으며, 아래 설치 과정도 기존 `desktop_app.py`의
실행 환경이나 DB를 변경하지 않습니다.

Linux/macOS:

```bash
cd stock-bot
python -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements-platform.txt
```

Windows PowerShell:

```powershell
cd stock-bot
py -m venv .venv
.venv\\Scripts\\python.exe -m pip install --upgrade pip
.venv\\Scripts\\python.exe -m pip install -r requirements-platform.txt
```

## 빠른 확인

```bash
cd stock-bot
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python -m compileall -q quant_platform
.venv/bin/python -m quant_platform.cli demo --output /tmp/quant_platform_demo.json
```

Windows에서는 각 명령의 `.venv/bin/python`을 `.venv\\Scripts\\python.exe`로 바꿉니다.
기존 프로그램은 기존에 사용하던 Python 실행 환경으로 계속 실행합니다.

키움 자격증명은 `.env`나 비밀 저장소에만 두고 GitHub에 커밋하지 않습니다. 실전 주문은 이 코어의 기본값에서 활성화되지 않습니다.

## Phase 2 일부

- `indicators.py`: SMA/EMA/RSI/ATR/Bollinger/MACD와 feature rows
- `conditions/signal.py`: feature rows + DSL을 공통 BUY/SELL 신호로 연결
- `validation/walk_forward.py`: 겹치지 않는 train/test 시간 분할

검증되지 않은 실제 키움 TR 호출은 아직 추가하지 않았습니다. 먼저 공식 문서 기반 응답 fixture를 준비해야 합니다.

## 선택적 API 서버

FastAPI/uvicorn을 설치한 환경에서 백테스트 job과 조건식 검증 API를 실행할 수 있습니다.
실제 주문 endpoint는 의도적으로 제공하지 않습니다.

```bash
pip install -r requirements-platform.txt
python -m quant_platform.cli serve --host 0.0.0.0 --port 8000
```

- `GET /api/system-status`
- `POST /api/backtests` → `job_id`
- `GET /api/backtests/{job_id}`
- `POST /api/conditions/validate`
- `POST /api/strategies/generate`

## 기존 DB 연결

기존 `data/stocks/005930.db`가 있으면 다음 명령으로 새 canonical store와 DSL 백테스트를 함께 확인합니다.

```bash
.venv/bin/python -m quant_platform.cli legacy --symbol 005930
```

Windows에서 실제 canonical DB를 대상으로 백테스트·랜덤 검증·rolling OOS·Monte Carlo·재검증을
한 번에 실행하려면 프로젝트 루트의 `run_quant_research.bat`를 더블클릭합니다.
기본 종목은 `005930`이며 다른 종목은 다음처럼 지정합니다.

```text
run_quant_research.bat 000660
```

이 실행기는 `READ_ONLY_RESEARCH` 모드만 사용하며 주문을 제출하지 않습니다.
결과는 `reports/quant_research_{symbol}.json`에 저장됩니다.

## 전체 오프라인 파이프라인 검증

```bash
python -m quant_platform.cli demo --output data/quant_platform_demo.json
```

이 명령은 실제 키움 키 없이 mock OHLCV를 저장하고, 데이터 품질 검사, 조건식 조합,
백테스트, 랜덤 기간, Walk-forward, Monte Carlo, 생존 gate, Paper ledger를 차례로 실행합니다.
생존 gate를 통과하지 못하면 모의주문을 만들지 않습니다.
