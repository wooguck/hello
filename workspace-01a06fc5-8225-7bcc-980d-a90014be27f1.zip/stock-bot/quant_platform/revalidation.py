"""이전 배포본 호환 shim. 새 구현은 quant_platform.validation.revalidation에 있습니다."""
from .validation.revalidation import RevalidationResult, revalidate_strategy

__all__ = ["RevalidationResult", "revalidate_strategy"]
