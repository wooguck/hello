"""이전 배포본과의 import 호환 shim.

새 코드는 quant_platform.validation.monte_carlo를 사용합니다. 이전 __init__.py가
quant_platform.monte_carlo를 참조해도 패키지 버전 혼합으로 바로 죽지 않도록
동일한 구현을 재수출합니다.
"""
from .validation.monte_carlo import monte_carlo_returns

__all__ = ["monte_carlo_returns"]
