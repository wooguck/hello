"""확장 코어용 안전한 설정 로더.

기존 config.py와 분리해 점진적으로 도입합니다. 비밀키는 repr/log에 포함하지 않고,
실전 주문은 명시적인 이중 확인 플래그 없이는 허용하지 않습니다.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Mapping


TRUE_VALUES = {"1", "true", "yes", "on", "y"}
FALSE_VALUES = {"0", "false", "no", "off", "n"}


def _bool(env: Mapping[str, str], key: str, default: bool) -> bool:
    value = env.get(key)
    if value is None or not value.strip():
        return default
    normalized = value.strip().lower()
    if normalized in TRUE_VALUES:
        return True
    if normalized in FALSE_VALUES:
        return False
    raise ValueError(f"invalid boolean setting {key}={value!r}; use true/false")


def _int(env: Mapping[str, str], key: str, default: int) -> int:
    value = env.get(key)
    if value is None or not value.strip():
        return default
    try:
        return int(value.strip())
    except (TypeError, ValueError) as exc:
        raise ValueError(f"invalid integer setting {key}={value!r}") from exc


def _float(env: Mapping[str, str], key: str, default: float) -> float:
    value = env.get(key)
    if value is None or not value.strip():
        return default
    try:
        return float(value.strip())
    except (TypeError, ValueError) as exc:
        raise ValueError(f"invalid numeric setting {key}={value!r}") from exc


@dataclass(frozen=True)
class Settings:
    data_dir: Path = Path("data")
    database_path: Path = Path("data/quant_platform.sqlite3")
    timezone: str = "Asia/Seoul"
    kiwoom_base_url: str = "https://mockapi.kiwoom.com"
    kiwoom_use_mock: bool = True
    dry_run: bool = True
    allow_live_trading: bool = False
    request_timeout_sec: float = 10.0
    request_retries: int = 3
    commission_pct: float = 0.2
    slippage_pct: float = 0.15
    initial_capital: float = 10_000_000.0
    random_seed: int = 123
    ai_provider: str = "rule"
    ai_timeout_sec: float = 10.0
    # 키 자체는 별도 저장하지만 표시/출력에는 절대 포함하지 않습니다.
    kiwoom_app_key: str = field(default="", repr=False)
    kiwoom_app_secret: str = field(default="", repr=False)
    gemini_api_key: str = field(default="", repr=False)
    openai_api_key: str = field(default="", repr=False)

    @property
    def live_trading_enabled(self) -> bool:
        return self.allow_live_trading and not self.dry_run and not self.kiwoom_use_mock

    def assert_safe(self) -> None:
        if self.live_trading_enabled and not (self.kiwoom_app_key and self.kiwoom_app_secret):
            raise RuntimeError("live trading requires both credentials supplied through the environment")
        if self.commission_pct < 0 or self.slippage_pct < 0:
            raise ValueError("commission/slippage cannot be negative")
        if self.request_timeout_sec <= 0 or self.request_retries < 0:
            raise ValueError("invalid HTTP retry configuration")

    def safe_summary(self) -> dict:
        return {
            "data_dir": str(self.data_dir),
            "database_path": str(self.database_path),
            "timezone": self.timezone,
            "kiwoom_use_mock": self.kiwoom_use_mock,
            "dry_run": self.dry_run,
            "live_trading_enabled": self.live_trading_enabled,
            "request_timeout_sec": self.request_timeout_sec,
            "request_retries": self.request_retries,
            "ai_provider": self.ai_provider,
            "has_kiwoom_credentials": bool(self.kiwoom_app_key and self.kiwoom_app_secret),
            "has_ai_credentials": bool(self.gemini_api_key or self.openai_api_key),
        }


def load_settings(env: Mapping[str, str] | None = None, base_dir: str | Path = ".") -> Settings:
    values = os.environ if env is None else env
    root = Path(base_dir)
    data_dir = Path(values.get("QUANT_DATA_DIR", "data"))
    database = Path(values.get("QUANT_DATABASE_PATH", str(data_dir / "quant_platform.sqlite3")))
    if not data_dir.is_absolute():
        data_dir = root / data_dir
    if not database.is_absolute():
        database = root / database
    settings = Settings(
        data_dir=data_dir,
        database_path=database,
        timezone=values.get("QUANT_TIMEZONE", "Asia/Seoul"),
        kiwoom_base_url=values.get("KIWOOM_BASE_URL", values.get("KIWOOM_BASE_URL_MOCK", "https://mockapi.kiwoom.com")),
        kiwoom_use_mock=_bool(values, "KIWOOM_USE_MOCK", True),
        dry_run=_bool(values, "DRY_RUN", True),
        allow_live_trading=_bool(values, "ALLOW_LIVE_TRADING", False),
        request_timeout_sec=_float(values, "QUANT_REQUEST_TIMEOUT_SEC", 10.0),
        request_retries=_int(values, "QUANT_REQUEST_RETRIES", 3),
        commission_pct=_float(values, "FEE_ROUND_TRIP_PCT", 0.2),
        slippage_pct=_float(values, "SLIPPAGE_PCT", 0.15),
        initial_capital=_float(values, "VALIDATE_CAPITAL", 10_000_000.0),
        random_seed=_int(values, "RANDOM_SEED", 123),
        ai_provider=values.get("AI_PROVIDER", "rule").strip().lower() or "rule",
        ai_timeout_sec=_float(values, "AI_TIMEOUT_SEC", 10.0),
        kiwoom_app_key=values.get("KIWOOM_APP_KEY", ""),
        kiwoom_app_secret=values.get("KIWOOM_APP_SECRET", ""),
        gemini_api_key=values.get("GEMINI_API_KEY", ""),
        openai_api_key=values.get("OPENAI_API_KEY", ""),
    )
    settings.assert_safe()
    return settings
