"""실제 canonical DB를 한 번에 검증하는 읽기 전용 연구 실행기.

기존 data/stocks에서 이미 가져온 canonical DB를 대상으로
backtest + random validation + rolling OOS + Monte Carlo + revalidation을
한 번에 실행합니다. 주문 API는 호출하지 않습니다.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path
from typing import Sequence

from .backtest import BacktestConfig, BacktestEngine
from .conditions import DslSignal
from .data import MarketDataStore
from .deep_learning import run_deep_learning_probe
from .legacy import load_legacy_daily
from .provenance import inspect_provenance
from .validation import monte_carlo_returns, revalidate_strategy, validate_random_periods, walk_forward_splits


DEFAULT_BUY = {
    "indicator": "close",
    "comparison": ">",
    "value": {"indicator": "sma_20"},
}
DEFAULT_SELL = {
    "indicator": "close",
    "comparison": "<",
    "value": {"indicator": "ema_20"},
}


def _config() -> BacktestConfig:
    return BacktestConfig(
        initial_capital=1_000_000,
        commission_pct=0.1,
        slippage_pct=0.05,
    )


def _summary(result) -> dict:
    return {
        "initial_capital": result.initial_capital,
        "final_equity": result.final_equity,
        "total_return_pct": result.total_return_pct,
        "trade_count": result.trade_count,
        "win_rate_pct": result.win_rate_pct,
        "average_trade_return_pct": result.average_trade_return_pct,
        "profit_factor": result.profit_factor if result.profit_factor != float("inf") else None,
        "max_drawdown_pct": result.max_drawdown_pct,
    }


def _signal_factory():
    return lambda: DslSignal(buy=DEFAULT_BUY, sell=DEFAULT_SELL)


def _rolling_oos(rows: Sequence, config: BacktestConfig) -> dict:
    if len(rows) < 160:
        return {"split_count": 0, "positive_rate_pct": 0.0, "results": []}
    test_size = min(100, max(30, len(rows) // 6))
    train_size = min(700, max(90, len(rows) - test_size * 3))
    splits = walk_forward_splits(rows, train_size=train_size, test_size=test_size, step=test_size)
    results = [BacktestEngine(config).run(split.test, DslSignal(buy=DEFAULT_BUY, sell=DEFAULT_SELL))
               for split in splits]
    values = [_summary(result) for result in results]
    return {
        "method": "non_overlapping_rolling_oos",
        "train_size": train_size,
        "test_size": test_size,
        "split_count": len(values),
        "positive_rate_pct": (sum(item["total_return_pct"] > 0 for item in values) / len(values) * 100)
        if values else 0.0,
        "results": values,
    }


def run_research(symbol: str, *, database_path: str | Path = "data/quant_platform.sqlite3",
                 stock_dir: str | Path = "data/stocks", baseline_bars: int = 700,
                 recent_bars: int = 300, deep_learning: bool = False) -> dict:
    database_path = Path(database_path)
    with MarketDataStore(database_path) as store:
        rows = store.get_bars(symbol, "1d")
        imported = 0
        required_bars = baseline_bars + recent_bars
        # canonical DB가 비어 있을 때뿐 아니라, 검증에 필요한 길이보다 짧을 때도
        # 기존 원천 DB를 읽어 canonical DB를 보충합니다. 원천 DB는 읽기 전용입니다.
        if len(rows) < required_bars:
            try:
                legacy_rows = load_legacy_daily(symbol, stock_dir=stock_dir)
            except FileNotFoundError:
                legacy_rows = []
            if len(legacy_rows) > len(rows):
                imported = store.upsert_bars(legacy_rows)
                rows = store.get_bars(symbol, "1d")
        quality = store.integrity_report(symbol)
        coverage = next((item for item in store.coverage(symbol) if item["timeframe"] == "1d"), None)
    provenance = inspect_provenance(rows)
    if provenance["status"] == "FAIL":
        raise ValueError(f"data provenance gate failed: {provenance['findings'][:3]}")

    if len(rows) < 2:
        raise ValueError(f"not enough daily bars for {symbol}: {len(rows)}")

    config = _config()
    backtest = BacktestEngine(config).run(rows, DslSignal(buy=DEFAULT_BUY, sell=DEFAULT_SELL))
    random_result = validate_random_periods(
        rows,
        _signal_factory(),
        runs=min(20, max(5, len(rows) // 100)),
        min_bars=min(90, len(rows)),
        max_bars=min(300, len(rows)),
        seed=123,
        config=config,
    )
    rolling_oos = _rolling_oos(rows, config)
    sell_returns = [trade.return_pct or 0.0 for trade in backtest.trades if trade.side == "SELL"]
    monte_carlo = monte_carlo_returns(sell_returns, runs=200, seed=123)

    if len(rows) >= baseline_bars + recent_bars:
        revalidation = asdict(revalidate_strategy(
            f"S-{symbol}-close-sma20",
            DEFAULT_BUY,
            rows,
            baseline_bars=baseline_bars,
            recent_bars=recent_bars,
        ))
    else:
        revalidation = {
            "status": "INSUFFICIENT_DATA",
            "required_bars": baseline_bars + recent_bars,
            "actual_bars": len(rows),
        }
    deep_learning_result = run_deep_learning_probe(rows) if deep_learning else {
        "status": "NOT_REQUESTED", "eligible": False, "rows": len(rows),
        "detail": "--deep-learning을 명시하기 전에는 모델을 학습하지 않습니다.",
    }

    report = {
        "mode": "READ_ONLY_RESEARCH",
        "symbol": symbol,
        "database_path": str(database_path.resolve()),
        "imported_from_legacy": imported,
        "bars": len(rows),
        "coverage": coverage,
        "quality": {
            "checked": quality.checked,
            "ok": quality.ok,
            "issues": [asdict(issue) for issue in quality.issues],
        },
        "provenance": provenance,
        "deep_learning": deep_learning_result,
        "condition": {"buy": DEFAULT_BUY, "sell": DEFAULT_SELL},
        "backtest": _summary(backtest),
        "random_validation": {
            "runs": random_result.runs,
            "positive_rate_pct": random_result.positive_rate_pct,
            "median_return_pct": random_result.median_return_pct,
            "worst_return_pct": random_result.worst_return_pct,
            "best_return_pct": random_result.best_return_pct,
            "max_drawdown_pct": random_result.max_drawdown_pct,
        },
        "rolling_oos": rolling_oos,
        "monte_carlo": monte_carlo,
        "revalidation": revalidation,
        "orders_submitted": 0,
    }
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="실제 canonical DB 읽기 전용 연구 검증")
    parser.add_argument("--symbol", default="005930")
    parser.add_argument("--db", type=Path, default=Path("data/quant_platform.sqlite3"))
    parser.add_argument("--stock-dir", type=Path, default=Path("data/stocks"))
    parser.add_argument("--baseline", type=int, default=700)
    parser.add_argument("--recent", type=int, default=300)
    parser.add_argument("--deep-learning", action="store_true", help="시간순 holdout 딥러닝 probe 실행; 전략 자동 편입은 하지 않음")
    parser.add_argument("--output", type=Path, default=None)
    args = parser.parse_args()

    report = run_research(
        args.symbol,
        database_path=args.db,
        stock_dir=args.stock_dir,
        baseline_bars=args.baseline,
        recent_bars=args.recent,
        deep_learning=args.deep_learning,
    )
    output = args.output or Path("reports") / f"quant_research_{args.symbol}.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    print("mode =", report["mode"])
    print("symbol =", report["symbol"])
    print("bars =", report["bars"])
    print("quality_ok =", report["quality"]["ok"])
    print("trade_count =", report["backtest"]["trade_count"])
    print("total_return_pct =", report["backtest"]["total_return_pct"])
    print("max_drawdown_pct =", report["backtest"]["max_drawdown_pct"])
    print("random_positive_rate_pct =", report["random_validation"]["positive_rate_pct"])
    print("rolling_oos_positive_rate_pct =", report["rolling_oos"]["positive_rate_pct"])
    print("revalidation_status =", report["revalidation"]["status"])
    print("deep_learning_status =", report["deep_learning"]["status"])
    print("orders_submitted =", report["orders_submitted"])
    print("report =", output.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
