# StockBot Quant 최종 시작 안내

작성일: 2026-09-05 (KST)

## 먼저 읽을 결론

이 배포본은 **연구·검증·로컬 PAPER 전용**입니다.

- 실제 주문: 금지
- 브로커 주문: 0건
- 외부 키움 주문 API: 자동 연결하지 않음
- 기본 연구 모드: `READ_ONLY_RESEARCH`
- PAPER 모드: 로컬 SQLite 원장에만 기록
- 검증되지 않은 아이디어: 자동 사용하지 않음
- 외부 AI를 호출하지 못한 결과: PASS로 표시하지 않음

GitHub의 `hello-merged.zip`을 이 폴더에 덮어쓰지 마세요. 그것은 현재 코드보다 이전 병합본입니다.

## 설치 위치

기존 32비트 OpenAPI/legacy 프로그램 폴더 위에 덮어쓰지 말고, 새 폴더에 압축을 풉니다.

```text
StockBotQuantFinal/
```

기존 `trading.db`, `data/stocks`, `.env`, legacy 자동매매 프로그램은 별도로 보존합니다.

## Windows 최초 실행

64비트 Python 환경을 별도로 만듭니다. 기존 32비트 OpenAPI 환경과 한 프로세스에 섞지 않습니다.

```bat
py -3.11 -m venv .venv
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -r requirements-platform.txt
```

Tkinter가 포함된 Python이면 GUI 실행에 별도 GUI 패키지가 필요하지 않습니다.

## 실행 순서

### 1. GUI 시작

```bat
run_stockbot_gui.bat
```

화면에서 다음 순서로 실행합니다.

1. **전체 오류·안전 점검**
2. 종목코드 입력 후 **선택 종목 실행** 또는 **전체 종목 실행**
3. **결과 검수·요약**
4. 필요할 때 **최근 리포트 열기**와 **오류센터 열기**

화면에 다음 항목이 보이면 정상입니다.

```text
READ_ONLY_RESEARCH
LIVE_ORDERS=false
orders_submitted=0
```

### 2. 하루 로컬 PAPER 감독자

검증용으로 한 cycle만 실행:

```bat
.venv\Scripts\python.exe -m quant_platform.overnight --once
```

하루 동안 실행:

```bat
run_overnight_paper.bat
```

이 모드는 PAPER 주문을 로컬 원장에만 기록합니다. `orders_submitted_to_broker`는 항상 0이어야 합니다.

### 3. CLI 연구 실행

GUI와 동일한 핵심 연구를 확인할 때만 사용합니다.

```bat
run_stockbot_pipeline.bat
```

## 생성되는 주요 파일

```text
reports/integration_audit.json       전체 안전·통합 감사
reports/final_integration_audit.json 최종 검수 시점의 감사
reports/idea_coverage.json           기존 아이디어 연결 증거
reports/RUN-*.json                   종목별 연구 결과
reports/RUN-*_review.json            결과 검수·요약
reports/ALL-*.json                   전체 종목 실행 결과
reports/overnight_status.json        PAPER 감독자 상태
reports/overnight_state.json         재시작용 상태
errors/E-*.json                      구조화된 오류 상세
errors/latest.json                   최근 오류
data/quant_orders.sqlite3             주문 의도 로컬 원장
data/paper_overnight.sqlite3          PAPER cycle 로컬 원장
```

경고(WARN)는 자동으로 PASS로 바꾸지 않습니다. 특히 다음은 연구 승인 전 해결하거나 검토해야 합니다.

- current universe가 공식 현재 목록으로 확인되지 않음
- legacy 주문 경로가 존재함
- 연결 증거가 없는 기존 아이디어
- 데이터 출처가 불명확하거나 표본이 부족함

## 검증·승급 순서

```text
OFF
→ DRY_RUN
→ PAPER
→ Shadow
→ (별도 승인 전까지 중단)
```

현재 배포본은 Shadow 다음의 실제 주문 단계로 진행하지 않습니다. 일봉은 관심종목과 방향을 정하고, 분봉은 확정된 다음 봉 기준으로 진입·청산을 검증합니다. 분봉 매도 신호가 있어도 일봉 추세와 위험 상태를 함께 확인하여 일부 익절·보유 여부를 별도 판단합니다.

## 주의

- 이 배포본에는 비밀키, `.env`, 원본 DB, 실행 중 리포트 묶음을 넣지 않습니다.
- 기존 `.env`의 `DRY_RUN=false`를 자동으로 수정하지 않습니다.
- 기존 legacy GUI/주문 루프를 이 64비트 연구 코어에 import하지 않습니다.
- 딱 저점 매수·딱 고점 매도는 실시간 확정값이 아니라 사후 평가 지표로만 기록합니다.
- `HANDOVER.md`, `USER_GUIDE_SUMMARY.md` 등 오래된 legacy 운영 문서의 실거래 안내와 이 최종 연구본을 혼용하지 마세요.
