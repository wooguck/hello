@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] New quant environment was not found:
    echo %CD%\.venv\Scripts\python.exe
    pause
    exit /b 1
)

set "SYMBOL=%~1"
if "%SYMBOL%"=="" set "SYMBOL=005930"
set "IMPORT_REPORT=%TEMP%\quant_legacy_%SYMBOL%.json"

echo [IMPORT] Existing legacy data to canonical DB: %SYMBOL%
".venv\Scripts\python.exe" -m quant_platform.cli legacy --symbol "%SYMBOL%" --db ".\data\quant_platform.sqlite3" > "%IMPORT_REPORT%"
if errorlevel 1 (
    echo [ERROR] Legacy data import failed. The existing trading app was not started.
    if exist "%IMPORT_REPORT%" type "%IMPORT_REPORT%"
    del /q "%IMPORT_REPORT%" >nul 2>nul
    pause
    exit /b 1
)
if exist "%IMPORT_REPORT%" del /q "%IMPORT_REPORT%" >nul 2>nul

echo [READ_ONLY] Quant research started: %SYMBOL%
".venv\Scripts\python.exe" -m quant_platform.research --symbol "%SYMBOL%" --db ".\data\quant_platform.sqlite3"
if errorlevel 1 (
    echo.
    echo [ERROR] Research failed. The existing trading app was not started.
    pause
    exit /b 1
)

echo.
echo [DONE] Report was saved under reports\quant_research_%SYMBOL%.json
pause
