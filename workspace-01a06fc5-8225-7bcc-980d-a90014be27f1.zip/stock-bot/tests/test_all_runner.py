from __future__ import annotations

import sqlite3
from pathlib import Path

from quant_platform import all_runner


def test_run_all_builds_union_of_source_and_canonical_symbols(tmp_path: Path, monkeypatch):
    source = tmp_path / "stocks"
    source.mkdir()
    (source / "005930.db").write_bytes(b"source")
    database = tmp_path / "quant.sqlite3"
    with sqlite3.connect(database) as db:
        db.execute("CREATE TABLE bars (symbol TEXT, timeframe TEXT, bar_time TEXT)")
        db.execute("INSERT INTO bars VALUES ('000660', '1d', '2026-01-01')")
        db.commit()

    def fake_pipeline(**kwargs):
        return {
            "report_path": str(tmp_path / f"{kwargs['symbol']}.json"),
            "source": {"rows": 2},
            "canonical": {"after_rows": 2},
            "analysis": {"rows": 2},
            "survivors": [],
        }

    monkeypatch.setattr(all_runner, "run_pipeline", fake_pipeline)
    result = all_runner.run_all(
        source_dir=source,
        database_path=database,
        trading_db=tmp_path / "missing-trading.db",
        reports_dir=tmp_path / "reports",
        errors_dir=tmp_path / "errors",
    )

    assert result["total_symbol_count"] == 2
    assert result["completed_count"] == 2
    assert {item["symbol"] for item in result["completed"]} == {"000660", "005930"}
