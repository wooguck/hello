from datetime import datetime, timedelta
import sqlite3

from quant_platform.orchestrator import run_pipeline


def _make_legacy_db(path, count=45):
    with sqlite3.connect(path) as db:
        db.execute(
            """CREATE TABLE daily_bars(
                bar_date TEXT, open_price REAL, high_price REAL, low_price REAL,
                close_price REAL, volume REAL, amount REAL, source TEXT
            )"""
        )
        start = datetime(2024, 1, 2)
        rows = []
        price = 100.0
        for index in range(count):
            current = price + (index % 5) * 0.2
            rows.append(((start + timedelta(days=index)).date().isoformat(), current, current + 1,
                         current - 1, current, 1000 + index, current * (1000 + index), "imported"))
            price = current
        db.executemany("INSERT INTO daily_bars VALUES (?, ?, ?, ?, ?, ?, ?, ?)", rows)


def test_integrated_pipeline_keeps_canonical_extras_out_of_analysis(tmp_path):
    source_dir = tmp_path / "stocks"
    source_dir.mkdir()
    _make_legacy_db(source_dir / "005930.db")

    report = run_pipeline(
        symbol="005930",
        source_dir=source_dir,
        database_path=tmp_path / "quant_platform.sqlite3",
        trading_db=tmp_path / "trading.db",
        reports_dir=tmp_path / "reports",
        errors_dir=tmp_path / "errors",
    )

    assert report["source"]["rows"] == 45
    assert report["canonical"]["after_rows"] == 45
    assert report["analysis"]["rows"] == 45
    assert report["candidates"]["count"] == 14
    assert report["orders_submitted"] == 0
