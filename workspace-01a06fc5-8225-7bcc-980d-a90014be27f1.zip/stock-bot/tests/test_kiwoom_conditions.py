from __future__ import annotations

import pytest

from quant_platform.kiwoom_conditions import ConditionSnapshot, compare_condition_snapshots


def test_kiwoom_and_local_condition_snapshots_compare_explicitly():
    kiwoom = ConditionSnapshot("kiwoom", "breakout", "v3", "2026-09-04T09:05:00+09:00", ("005930", "000660"))
    local = ConditionSnapshot("local", "breakout", "v3", "2026-09-04T09:05:00+09:00", ("000660", "005930"))
    result = compare_condition_snapshots(kiwoom, local)
    assert result.status == "KIWOOM_MATCH"
    assert result.precision_pct == 100
    assert result.recall_pct == 100


def test_condition_version_mismatch_is_not_called_a_match():
    kiwoom = ConditionSnapshot("kiwoom", "breakout", "v3", "t", ("005930",))
    local = ConditionSnapshot("local", "breakout", "v2", "t", ("005930",))
    assert compare_condition_snapshots(kiwoom, local).status == "CONDITION_VERSION_MISMATCH"


def test_condition_snapshot_rejects_invalid_symbols():
    with pytest.raises(ValueError):
        ConditionSnapshot("kiwoom", "breakout", "v3", "t", ("BAD",))
