from __future__ import annotations

import json
from pathlib import Path

from quant_platform.audit import write_audit
from quant_platform.idea_coverage import build_idea_coverage


def test_idea_coverage_does_not_mark_legacy_material_as_used(tmp_path: Path):
    (tmp_path / "prompts").mkdir()
    (tmp_path / "prompts" / "new_idea.txt").write_text("매수 아이디어", encoding="utf-8")
    coverage = build_idea_coverage(tmp_path)
    assert coverage["counts"]["unwired_unverified"] == 1
    assert coverage["legacy_sources"][0]["status"] == "UNWIRED_UNVERIFIED"
    assert coverage["safe_to_use_unverified_ideas"] is False


def test_audit_writes_separate_idea_coverage_report(tmp_path: Path):
    (tmp_path / "prompts").mkdir()
    (tmp_path / "prompts" / "idea.txt").write_text("아이디어", encoding="utf-8")
    output = write_audit(tmp_path)
    assert output.exists()
    coverage = json.loads((tmp_path / "reports" / "idea_coverage.json").read_text(encoding="utf-8"))
    assert coverage["counts"]["unwired_unverified"] == 1
