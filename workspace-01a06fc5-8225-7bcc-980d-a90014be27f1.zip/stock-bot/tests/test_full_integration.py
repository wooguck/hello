from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

from quant_platform.backtest import BacktestConfig
from quant_platform.conditions import DslSignal
from quant_platform.domain import Bar, DataSource
from quant_platform.live_paper import LivePaperSession
from quant_platform.order_gateway import OrderGateway, OrderIntent, OrderMode
from quant_platform.paper import PaperTradingEngine
from quant_platform.pipeline import PipelineConfig, run_demo
from quant_platform.review import review_file


def _bars(symbol: str = "005930", count: int = 80) -> list[Bar]:
    start = datetime(2024, 1, 2)
    output = []
    price = 100.0
    for index in range(count):
        close = price + (1.0 if index % 7 < 4 else -0.4)
        output.append(Bar(symbol, "1d", start + timedelta(days=index), price, close + 1, price - 1, close,
                          1000 + index, close * (1000 + index), DataSource.MOCK))
        price = close
    return output


def test_demo_pipeline_links_ingest_validation_backtest_and_paper(tmp_path: Path):
    report = run_demo(PipelineConfig(
        symbols=("005930", "000660"),
        bars_per_symbol=80,
        candidate_limit=6,
        random_runs=3,
        monte_carlo_runs=10,
        database_path=tmp_path / "demo.sqlite3",
        output_path=tmp_path / "demo.json",
    ))
    assert report["stages"][-1] == "paper_trading"
    assert report["ingested_bars"] == 160
    assert report["quality"]["ok"] is True
    assert len(report["evaluations"]) == 6
    assert (tmp_path / "demo.json").exists()


def test_paper_session_live_session_and_order_gateway_link(tmp_path: Path):
    bars = _bars()
    buy = {"indicator": "close", "comparison": ">", "value": {"indicator": "sma_20"}}
    sell = {"indicator": "close", "comparison": "<", "value": {"indicator": "ema_20"}}
    signal = DslSignal(buy=buy, sell=sell)
    paper_result = PaperTradingEngine(BacktestConfig(initial_capital=100_000)).run(bars, signal)
    assert paper_result.final_equity > 0

    live = LivePaperSession(signal, BacktestConfig(initial_capital=100_000))
    for bar in bars:
        live.on_bar(bar)
    snapshot = live.snapshot()
    assert snapshot.symbol == "005930"
    assert snapshot.timestamp == bars[-1].timestamp.isoformat()

    with OrderGateway(tmp_path / "orders.sqlite3", mode=OrderMode.PAPER) as gateway:
        result = gateway.submit(OrderIntent("005930", "BUY", 1, 100, client_order_id="integration-1"))
        same = gateway.submit(OrderIntent("005930", "BUY", 1, 100, client_order_id="integration-1"))
    assert result.status == "PAPER_PENDING"
    assert same == result


def test_review_file_emits_summary_and_socratic_questions(tmp_path: Path):
    report_path = tmp_path / "RUN-test.json"
    report_path.write_text(
        '{"mode":"READ_ONLY_RESEARCH","orders_submitted":0,'
        '"source":{"rows":80},"analysis":{"rows":80,"quality_ok":true},'
        '"canonical":{"preserved_extra_rows":0},"universe":{},'
        '"evaluations":[{"backtest":{"max_drawdown_pct":1}}]}',
        encoding="utf-8",
    )
    output = review_file(report_path)
    assert output.exists()
    import json
    review = json.loads(output.read_text(encoding="utf-8"))
    assert review["status"] in {"HOLD_FOR_REVIEW", "APPROVE_FOR_SHADOW"}
    assert review["summary"]
    assert review["socratic_questions"]


def test_old_top_level_validation_imports_remain_compatible():
    from quant_platform.monte_carlo import monte_carlo_returns
    from quant_platform.random_period import validate_random_periods
    from quant_platform.revalidation import revalidate_strategy
    from quant_platform.walk_forward import walk_forward_splits

    assert callable(monte_carlo_returns)
    assert callable(validate_random_periods)
    assert callable(revalidate_strategy)
    assert callable(walk_forward_splits)


def test_canonical_schema_is_not_destroyed_by_reopen(tmp_path: Path):
    from quant_platform.data import MarketDataStore

    with MarketDataStore(tmp_path / "market.sqlite3") as store:
        rows = _bars(count=3)
        assert store.upsert_bars(rows) == 3
        assert len(store.get_bars("005930", "1d")) == 3
    with sqlite3.connect(tmp_path / "market.sqlite3") as db:
        assert db.execute("select count(*) from bars").fetchone()[0] == 3
