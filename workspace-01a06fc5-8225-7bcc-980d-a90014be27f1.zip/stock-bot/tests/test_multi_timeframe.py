from __future__ import annotations

from datetime import datetime, timedelta

import pytest

from quant_platform.multi_timeframe import (
    DailyContext,
    DecisionAction,
    IntradayObservation,
    MultiTimeframePolicy,
    PositionState,
    WatchState,
)


def _daily(day=1, trend="NORMAL"):
    return DailyContext("005930", datetime(2026, 1, day), 110, 100, 60, 105, trend, True)


def test_daily_qualifies_then_intraday_buy_and_hold_or_partial_exit():
    policy = MultiTimeframePolicy(partial_exit_pct=50)
    daily = _daily()
    watch = policy.decide(daily, IntradayObservation("005930", datetime(2026, 1, 2), data_ok=True))
    assert watch.action == DecisionAction.WATCH
    assert watch.state == WatchState.ARMED
    buy = policy.decide(daily, IntradayObservation("005930", datetime(2026, 1, 2, 10), buy_signal=True))
    assert buy.action == DecisionAction.BUY
    position = PositionState("005930", 10, 100, 95, 108)
    hold = policy.decide(daily, IntradayObservation("005930", datetime(2026, 1, 2, 11), trend_strength="STRONG"), position)
    assert hold.action == DecisionAction.HOLD
    partial = policy.decide(daily, IntradayObservation("005930", datetime(2026, 1, 2, 12), target_reached=True, trend_strength="STRONG"), position)
    assert partial.action == DecisionAction.PARTIAL_SELL
    assert partial.partial_quantity == 5


def test_stop_or_daily_context_break_exits_position():
    policy = MultiTimeframePolicy()
    position = PositionState("005930", 10, 100, 95, 108)
    stopped = policy.decide(_daily(), IntradayObservation("005930", datetime(2026, 1, 2), stop_broken=True), position)
    assert stopped.action == DecisionAction.SELL
    broken_daily = DailyContext("005930", datetime(2026, 1, 2), 90, 100, 40, 105, "WEAK", True)
    exited = policy.decide(broken_daily, IntradayObservation("005930", datetime(2026, 1, 3)), position)
    assert exited.action == DecisionAction.SELL


def test_lookahead_and_data_quality_are_blocked():
    policy = MultiTimeframePolicy()
    with pytest.raises(ValueError, match="newer"):
        policy.decide(_daily(day=3), IntradayObservation("005930", datetime(2026, 1, 2)))
    blocked = policy.decide(_daily(), IntradayObservation("005930", datetime(2026, 1, 2), data_ok=False))
    assert blocked.action == DecisionAction.BLOCK
    assert blocked.lookahead_check == "PASS"
