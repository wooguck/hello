from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timedelta, timezone
from math import nan
from pathlib import Path

import pytest

from quant_platform.config import load_settings
from quant_platform.deep_learning import run_deep_learning_probe
from quant_platform.domain import Bar, DataSource
from quant_platform.legacy import LegacyDataError, load_legacy_daily, load_legacy_daily_with_report
from quant_platform.orchestrator import run_pipeline
from quant_platform.provenance import inspect_provenance


def _legacy_db(path: Path, rows):
    with sqlite3.connect(path) as db:
        db.execute("CREATE TABLE daily_bars(bar_date TEXT, open_price REAL, high_price REAL, low_price REAL, close_price REAL, volume REAL, amount REAL, source TEXT)")
        db.executemany("INSERT INTO daily_bars VALUES (?, ?, ?, ?, ?, ?, ?, ?)", rows)


def test_invalid_legacy_rows_are_reported_not_silently_ignored(tmp_path: Path):
    _legacy_db(tmp_path / "005930.db", [
        ("2024-01-01", 100, 101, 99, 100, 1000, 100000, "imported"),
        ("not-a-date", 100, 101, 99, 100, 1000, 100000, "imported"),
    ])
    report = load_legacy_daily_with_report("005930", tmp_path)
    assert report.raw_rows == 2
    assert report.accepted_rows == 1
    assert report.rejected_rows == 1
    assert report.issues[0].code == "SOURCE_ROW_REJECTED"
    with pytest.raises(LegacyDataError):
        load_legacy_daily("005930", tmp_path)


def test_pipeline_blocks_rejected_source_rows_and_writes_error(tmp_path: Path):
    source = tmp_path / "stocks"
    source.mkdir()
    _legacy_db(source / "005930.db", [
        ("2024-01-01", 100, 101, 99, 100, 1000, 100000, "imported"),
        ("bad-date", 100, 101, 99, 100, 1000, 100000, "imported"),
        ("2024-01-03", 100, 101, 99, 100, 1000, 100000, "imported"),
    ])
    with pytest.raises(RuntimeError, match="E-"):
        run_pipeline(symbol="005930", source_dir=source, database_path=tmp_path / "market.sqlite3",
                     trading_db=tmp_path / "trading.db", reports_dir=tmp_path / "reports", errors_dir=tmp_path / "errors")
    error = json.loads((tmp_path / "errors" / "latest.json").read_text(encoding="utf-8"))
    assert "rejected" in error["message"]


def test_invalid_settings_are_not_silently_replaced_with_defaults():
    with pytest.raises(ValueError, match="invalid boolean"):
        load_settings({"DRY_RUN": "maybe"})
    with pytest.raises(ValueError, match="invalid numeric"):
        load_settings({"QUANT_REQUEST_TIMEOUT_SEC": "not-a-number"})


def test_non_finite_bar_values_are_rejected():
    with pytest.raises(ValueError, match="finite"):
        Bar("005930", "1d", datetime(2024, 1, 1), nan, 101, 99, 100, 1000)


def test_provenance_flags_synthetic_future_and_flat_data():
    start = datetime.now(timezone.utc) + timedelta(days=3)
    rows = [Bar("005930", "1d", start + timedelta(days=i), 100, 100, 100, 100, 0, source=DataSource.MOCK) for i in range(20)]
    report = inspect_provenance(rows)
    codes = {item["code"] for item in report["findings"]}
    assert report["status"] == "FAIL"
    assert {"SYNTHETIC_SOURCE", "FUTURE_DATA", "MISSING_VOLUME", "FLAT_SERIES"} <= codes
    assert report["analysis_eligible"] is False


def test_deep_learning_probe_never_fakes_success_without_library():
    rows = [Bar("005930", "1d", datetime(2024, 1, 1) + timedelta(days=i), 100 + i, 101 + i, 99 + i, 100 + i, 1000, source="imported") for i in range(120)]
    result = run_deep_learning_probe(rows)
    assert result["status"] in {"NOT_INSTALLED", "PROBED"}
    if result["status"] == "NOT_INSTALLED":
        assert result["eligible"] is False
