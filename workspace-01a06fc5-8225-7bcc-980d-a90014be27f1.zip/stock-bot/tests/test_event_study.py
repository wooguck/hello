from __future__ import annotations

from datetime import datetime, timedelta

from quant_platform.domain import Bar
from quant_platform.event_study import BreakoutRule, run_breakout_event_study


def test_breakout_event_study_returns_visible_rule_and_forward_metrics():
    rows = []
    for index in range(90):
        price = 100 + index * 1.5
        rows.append(Bar("005930", "1d", datetime(2024, 1, 1) + timedelta(days=index), price, price + 2, price - 1, price + 1, 10_000))
    result = run_breakout_event_study(rows, BreakoutRule(
        breakout_lookback=5,
        rsi_low=0,
        rsi_high=100,
        volume_multiplier=0.5,
        horizons=(1, 3, 5),
    ), min_signals=1)
    assert result["rule_text"]
    assert result["signal_count"] > 0
    assert result["all_periods"][0]["horizon_days"] == 1
    assert "average_return_pct" in result["oos_periods"][0]
    assert "next bar open" in result["lookahead_policy"]
