from quant_platform.order_gateway import OrderGateway, OrderIntent, OrderMode


def test_off_mode_never_submits_and_is_idempotent(tmp_path):
    with OrderGateway(tmp_path / "orders.sqlite3", mode=OrderMode.OFF) as gateway:
        intent = OrderIntent("005930", "BUY", 1, 70_000, client_order_id="same")
        first = gateway.submit(intent)
        second = gateway.submit(intent)

    assert first.status == "REJECTED"
    assert first.mode == "OFF"
    assert second == first


def test_dry_run_does_not_call_broker(tmp_path):
    with OrderGateway(tmp_path / "orders.sqlite3", mode="DRY_RUN") as gateway:
        result = gateway.submit(OrderIntent("005930", "SELL", 2, 70_000, client_order_id="dry"))

    assert result.status == "SIMULATED"
    assert result.mode == "DRY_RUN"
    assert "no broker API" in result.message
