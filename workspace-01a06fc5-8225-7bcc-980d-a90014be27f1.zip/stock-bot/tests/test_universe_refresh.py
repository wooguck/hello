from __future__ import annotations

import unittest
from unittest.mock import MagicMock, patch

import universe


class UniverseRefreshTests(unittest.TestCase):
    def _conn(self, market_count=3450):
        conn = MagicMock()
        conn.execute.return_value.fetchone.return_value = {"c": market_count}
        context = MagicMock()
        context.__enter__.return_value = conn
        context.__exit__.return_value = False
        return context

    @patch("universe.db.count_universe", return_value=3450)
    @patch("universe.db.get_conn")
    @patch("universe.universe_freshness", return_value={"updated_at": "2026-09-03T08:00:00+09:00", "age_hours": 2.0})
    def test_recent_large_universe_does_not_refresh(self, _freshness, get_conn, _count):
        get_conn.return_value = self._conn()
        self.assertFalse(universe.needs_refresh())

    @patch("universe.db.count_universe", return_value=3450)
    @patch("universe.db.get_conn")
    @patch("universe.universe_freshness", return_value={"updated_at": "2026-08-27T08:00:00+09:00", "age_hours": 168.0})
    def test_stale_universe_refreshes_even_when_count_is_large(self, _freshness, get_conn, _count):
        get_conn.return_value = self._conn()
        self.assertTrue(universe.needs_refresh())


if __name__ == "__main__":
    unittest.main()
