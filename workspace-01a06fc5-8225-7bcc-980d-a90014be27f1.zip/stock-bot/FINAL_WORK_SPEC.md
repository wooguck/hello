# StockBot Quant 최종 완성 작업명세서

작성 목적: 여러 버전의 파일이 섞이지 않도록 최종 작업 범위·테스트·완료조건을 먼저 고정한다.

## 0. 최종 범위

이 프로젝트의 최종 목표는 다음 하나의 안전한 운영 프로그램이다.

```text
기존 자료 보존
→ 모든 종목 자동 통합
→ 데이터 진위·품질 검사
→ 아이디어 연결 추적
→ 전략 연구
→ 통계·시간순·Monte Carlo 검증
→ 선택적 딥러닝 검증
→ PAPER 모의운용
→ 자동 오류 진단·복구
→ 결과 요약·질문·검수
→ 주문 게이트웨이 대기
```

실거래 자동 연결은 최종 범위에서 제외한다. 최종 주문 게이트웨이도 기본 OFF로 둔다.

---

## 1. 작업 시작 시 workspace 정리

### 처리할 것

- 이전 최종 ZIP과 중간 ZIP은 최종 배포 폴더에서 제외한다.
- 기존 소스·DB·원본 데이터·`.env`는 삭제하지 않는다.
- 기존 legacy 파일은 `legacy` 또는 `archive` 영역으로 구분한다.
- 새 코어는 하나의 `quant_platform`만 사용한다.
- `quant_platform.__init__`와 하위 모듈의 import 경로를 하나로 통일한다.
- 오래된 `__pycache__`, 테스트용 임시파일, 중첩 review 파일을 최종 배포물에서 제외한다.
- 최종 ZIP은 마지막에 단 하나만 만든다.

### 보존 대상

```text
trading.db
data/stocks/*.db
data/quant_platform.sqlite3
.env
.venv
기존 주문 관련 legacy 파일
```

### 최종 배포물에 넣지 않을 것

```text
기존 중간 ZIP
실행 중 생성된 reports 원본 묶음
__pycache__
.pytest_cache
legacy 자동주문 실행 배치
실제 API 비밀키
```

---

## 2. 패키지·실행 오류 제거

### 목표

다음 오류가 다시 발생하지 않게 한다.

```text
ModuleNotFoundError: No module named 'quant_platform.monte_carlo'
```

### 조치

- `quant_platform/__init__.py`는 실제 존재하는 모듈만 import한다.
- `validation/monte_carlo.py`를 정식 구현 위치로 사용한다.
- 이전 배포본이 참조하는 top-level import에는 호환 shim을 둔다.
- GUI 실행 전 패키지 경로 preflight를 수행한다.
- 잘못된 중첩 압축 해제 경로를 실행 전에 검출한다.
- GUI 진입점·CLI·overnight 실행기를 각각 import 테스트한다.

---

## 3. 기존 데이터 전체 목록화

### 입력

```text
data/stocks/*.db
canonical DB
trading.db universe
prompts/
strategy/
기존 전략·주문 파일
```

### 자동 산출

```text
원본 종목 수
canonical 종목 수
canonical-only 종목 수
종목별 파일 크기·수정시각
종목별 행 수
최초일·최종일
DB schema
읽기 실패 파일
```

### 완료조건

- 파일이 없거나 읽히지 않는 경우 누락으로 기록한다.
- 종목을 조용히 건너뛰지 않는다.
- 실패 종목·원인·재시도 상태가 모두 보고서에 남는다.

---

## 4. 데이터 진위·품질 gate

### 하드 오류로 차단할 것

```text
날짜 파싱 실패
필수 컬럼 누락
NaN
Infinity
0 이하 가격
high가 open/close보다 낮음
low가 open/close보다 높음
음수 거래량
음수 거래대금
중복 symbol/timeframe/timestamp
시간 역행
미래 봉
source DB 행 파싱 실패
```

### 의심 데이터로 표시할 것

```text
mock
synthetic
test
demo
generated
unknown source
거래량 0이 과도하게 많음
종가가 지나치게 반복됨
완전히 평평한 시계열
원본과 canonical 가격 불일치
```

### 원칙

- 잘못된 데이터를 자동으로 정상 데이터처럼 보정하지 않는다.
- 문제가 있는 원본 행은 삭제하지 않고 행번호·원문·오류를 기록한다.
- 하드 오류 데이터는 분석에서 차단한다.
- 의심 데이터는 `WARN` 또는 `FAIL`로 표시한다.
- 데모 데이터는 실제 연구 데이터와 분리한다.

### 결과물

```text
reports/data_truth_report.json
reports/data_quality_summary.json
errors/E-*.json
```

---

## 5. current universe와 historical universe 분리

### historical universe

- 과거 상장 종목·상장폐지 종목·과거 데이터 분석용
- 백테스트에 사용할 수 있음
- 현재 주문 대상에는 사용할 수 없음

### current universe

- 공식 현재 종목 목록만 사용
- 공식 키움 응답 또는 검증된 현재 원천이 확인되기 전까지 `UNVERIFIED`
- historical GitHub fallback을 current로 승격하지 않음

### 완료조건

```text
current_universe_source
historical_universe_source
last_updated_at
age_hours
verification_status
```

가 모두 보고서에 있어야 한다.

---

## 6. canonical 통합·증분 실행

### 동작

```text
원본 DB 읽기 전용
→ canonical upsert
→ primary key 중복 방지
→ 원본/canonical 비교
→ 추가 canonical 행 보존
→ 분석 대상 행 분리
```

### 전체 종목 실행

- `data/stocks` 전체 종목을 자동 검색한다.
- canonical-only 종목도 처리한다.
- 종목별 실패가 전체 실행을 중단시키지 않는다.
- 전체 실행 상태를 저장한다.
- 중지 후 재실행하면 완료 종목은 건너뛰고 이어간다.

### 완료조건

```text
source_symbol_count
canonical_only_symbol_count
total_symbol_count
completed_count
failed_count
skipped_count
```

이 반드시 저장되어야 한다.

---

## 7. 기존 아이디어 연결 검수

### 검사 대상

```text
prompts/*.txt
prompts/*.md
strategy/*.json
strategy/**/*.json
기존 조건식·전략 문서
```

### 상태

```text
IMPLEMENTED_TESTED
REGISTERED_NOT_TESTED
UNWIRED_UNVERIFIED
BLOCKED
RETIRED
```

### 원칙

- 기존 아이디어를 자동으로 전략에 넣지 않는다.
- 아이디어별 source hash를 기록한다.
- 새 DSL 전략 ID가 있어야 사용된 것으로 인정한다.
- 백테스트·OOS·Shadow 증거가 없으면 사용되지 않은 것으로 표시한다.
- “파일이 존재한다”는 “사용 중이다”와 같지 않다.

### 결과물

```text
reports/idea_coverage.json
```

---

## 8. 전략 연구·검증

각 후보 전략은 다음을 모두 거친다.

사람이 읽는 조건 검색 카드도 함께 생성한다. 예를 들어 `종가>SMA20`, `RSI 50~70`, `직전 20일 고가 돌파`, `거래량 SMA20×1.5` 조건으로 다음 봉 시가에 진입했을 때 1·3·5·10일 후 평균/중간값/수익확률/목표도달확률/손절도달확률을 학습 구간과 OOS 구간으로 분리해 표시한다. 표본이 부족하면 수익률을 주장하지 않고 `INSUFFICIENT_SAMPLE`로 보류한다.

```text
DSL validation
strategy hash
feature generation
backtest
random period validation
walk-forward OOS
Monte Carlo trade-order test
revalidation
risk gate
survivor gate
```

### 전략 채택 조건

```text
최소 거래 수
최대 MDD
random positive rate
walk-forward positive rate
Monte Carlo loss probability
최소 score
```

중 하나라도 실패하면 `SURVIVOR`로 올리지 않는다.

수익률 하나만으로 전략을 채택하지 않는다.

---

## 9. 모델 교차검증

### 기본 검증 모델

```text
규칙/DSL 모델
통계 검증 모델
walk-forward 모델
Monte Carlo 안정성 모델
paper replay 모델
```

### 외부 AI 모델

- API 키가 없으면 외부 모델 검증을 한 것으로 표시하지 않는다.
- 외부 모델이 연결되면 규칙 결과와 독립적으로 비교한다.
- 의견이 일치하지 않으면 자동 채택하지 않고 `DISAGREEMENT`로 보류한다.
- AI가 내린 결론보다 데이터·위험 gate가 우선한다.

### 최종 표시

```text
RULE_ONLY
MODEL_AGREEMENT
MODEL_DISAGREEMENT
NOT_INSTALLED
NOT_REQUESTED
```

---

## 10. 딥러닝 검증

### 기본 원칙

딥러닝 모델은 데이터가 충분하고 시간순 검증을 통과하기 전까지 전략에 편입하지 않는다.

### 검사

```text
최소 표본 수
시간순 train/test 분리
train/test overlap = 0
미래정보 누수 = 0
기준모델 정확도
딥러닝 정확도
과적합 여부
seed 재현성
```

### 실행 상태

```text
NOT_REQUESTED
NOT_INSTALLED
INSUFFICIENT_DATA
PROBED
BLOCKED
```

`NOT_INSTALLED`와 `INSUFFICIENT_DATA`는 실패를 숨긴 것이 아니라 검증 불충분 상태다.

### 자동 사용 금지

딥러닝 probe가 끝나도 자동으로 주문 전략에 편입하지 않는다.

---

## 11. PAPER 모의운용

### 모드

```text
PAPER_LOCAL_ONLY
```

### 금지

```text
키움 API 호출 금지
실계좌 호출 금지
모의계좌 API 호출 금지
기존 legacy 주문 루프 실행 금지
```

### 처리

```text
paper signal
next-open 체결
수수료
슬리피지
포지션
현금
실현손익
평가손익
모의 주문 원장
```

### 원장

```text
data/paper_overnight.sqlite3
 data/quant_orders.sqlite3
```

### idempotency

동일한 cycle·종목·신호의 중복 주문은 한 번만 기록한다.

### 하루 감독자

- 기본 24시간
- 기본 15분 cycle
- 새 봉이 없으면 중복 replay 금지
- 종목별 오류는 격리
- 다음 cycle에서 재시도
- heartbeat 저장
- 중단 후 상태 복구

---

## 12. 자동 오류 진단·복구

### 자동 복구 허용

```text
필요 폴더 생성
stale temporary 파일 제거
손상된 상태 JSON 백업
DB 연결 재시도
종목 단위 retry
cycle 재시작
```

### 자동 복구 금지

```text
전략 코드 임의 수정
주문 코드 임의 수정
가격 임의 보정
잘못된 행 삭제
실패를 성공으로 변경
경고를 PASS로 변경
```

### 오류 처리

모든 오류는 다음을 가진다.

```text
error_id
run_id
stage
error_type
message
traceback
context
recoverable
recommended_action
impact
```

---

## 13. GUI 최종 기능

```text
선택 종목 실행
전체 종목 실행
중지
재개
전체 오류·안전 점검
결과 검수·요약
아이디어 연결 검수
딥러닝 probe 상태
최근 리포트 열기
오류센터 열기
현재 진행률
완료/실패/건너뜀
제출 주문 수
```

GUI에서 검은 콘솔을 기본으로 사용하지 않는다.

---

## 14. 테스트 매트릭스

### 단위 테스트

```text
domain
indicators
DSL
backtest
paper account
live paper session
order gateway
idempotency
settings
quality
provenance
idea coverage
deep learning status
```

### 통합 테스트

```text
legacy DB
→ canonical DB
→ quality
→ strategy
→ validation
→ paper
→ ledger
→ review
```

### 실패 주입 테스트

```text
잘못된 날짜
NaN
비정상 OHLC
중복 행
미래 봉
가짜 source
손상된 state JSON
누락된 폴더
DB 잠금
잘못된 env
잘못된 DSL
```

### 안전 테스트

```text
OFF 주문 차단
DRY_RUN 외부 API 미호출
PAPER 외부 API 미호출
LIVE adapter 미설정 거부
중복 주문 idempotency
broker_orders = 0
```

### 패키지 테스트

```text
전체 모듈 import
GUI entry import
CLI 실행
overnight --once
압축파일 내부 경로
중첩 quant_platform 검출
Windows batch preflight
```

---

## 15. 최종 검수 기준

### 연구 최종완료

```text
FULL_RUN_STATUS = COMPLETED
실패 종목 전부 기록
SILENTLY_IGNORED_ERRORS = 0
데이터 진위 상태 모두 표시
아이디어 상태 모두 표시
전략 검증 결과 모두 저장
```

### PAPER 최종완료

```text
PAPER_DURATION >= 24h
paper ledger 정상
reconciliation 정상
중복 주문 0
BROKER_ORDERS = 0
```

### 주문 게이트 최종상태

```text
ORDER_MODE = OFF
safe_to_order = false
LIVE = disabled
```

연구·PAPER·Shadow 검증이 끝나도 실거래는 자동 활성화하지 않는다.

---

## 16. 최종 산출물

```text
STOCKBOT_QUANT_FINAL.zip
FINAL_WORK_SPEC.md
FINAL_TEST_REPORT.json
FINAL_AUDIT.md
reports/data_truth_report.json
reports/idea_coverage.json
reports/integration_audit.json
reports/overnight_status.json
reports/PAPER-*.json
reports/RUN-*_review.json
errors/latest.json
```

배포 ZIP에는 다음을 넣는다.

```text
단일 quant_platform
GUI entry
CLI
전체 실행기
overnight 감독자
review 모듈
provenance 모듈
idea coverage 모듈
deep learning probe
테스트 파일
START_HERE.txt
```

---

## 17. 자동매매 연계·최종 운영 목표

자동매매 연계와 실제 운영 방법은 별도 최종 모델 문서에 고정한다.

```text
AUTO_TRADING_OPERATING_MODEL.md
```

핵심 구조는 다음과 같다.

```text
64비트 연구 코어
→ SignalDecision
→ Risk Gate
→ OrderIntent
→ OrderGateway
→ 별도 32비트 Kiwoom Worker
→ 체결 응답
→ reconciliation
```

기존 `desktop_app.py`, `auto_pilot.py`, `paper_test.py` 등의 직접 주문 호출은 새 프로세스에 import하지 않는다. 기존 `trading.db`는 보존하고, 주문 원장은 `quant_orders.sqlite3`로 분리한다.

운영 모드는 다음 순서로만 올린다.

```text
OFF → DRY_RUN → PAPER → SHADOW → 수동 승인
```

`LIVE`는 현재 최종본에서 비활성이다.

최종 연구 결과는 무조건 매수 종목이 아니라 다음 중 하나다.

```text
BUY_CANDIDATE
SELL_CANDIDATE
HOLD
NO_TRADE
BLOCKED_DATA
REJECTED_STRATEGY
SHADOW_ONLY
```

수익은 목표이지 보장이 아니다. 비용 차감 후 양의 기대값, 반복되는 OOS 성과, 관리 가능한 MDD, PAPER/SHADOW 재현성, 주문·잔고 원장 일치를 모두 확인해야 한다.

## 18. 완료 선언 방식

최종 결과는 다음처럼 선언한다.

```text
KNOWN_CODE_ERRORS = 0
SILENT_DATA_DROPS = 0
SILENT_ERROR_IGNORES = 0
UNIT_TESTS = PASS
INTEGRATION_TESTS = PASS
PACKAGE_IMPORT = PASS
PAPER_GATE = PASS 또는 HOLD
DEEP_LEARNING = PROBED 또는 명확한 BLOCKED 사유
MODEL_CROSSCHECK = 완료 또는 미설치 명시
LIVE_ORDER = DISABLED
```

사용자 PC의 실제 3450개 파일·Windows EXE·키움 공식 응답은 해당 PC에서 최종 실행한 뒤에만 최종 판정한다. 이 환경에서 접근할 수 없는 결과를 성공으로 꾸미지 않는다.
