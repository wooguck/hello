# -*- coding: utf-8 -*-
"""
🇺🇸 미국 섹터 → 한국 후보 연동 (us_sector.py) - 2026-08-27 추가
================================================================
사용자: "미국주식 쪽에 오른 종목들로 선별 가능한지? 매일 업데이트"

원리 (실증된 상관): 미국 밤장에서 섹터가 크게 오르면 다음날 한국의
같은 업종이 갭업하는 경향 (반도체가 대표적 - SMH↑ → 삼성전자/하이닉스↑).

동작 (매일 밤 라운드에서 자동):
  [1] 미국 섹터 ETF 15종 등락률 수집 (Yahoo - 키 불필요, 기존 폴백과 같은 소스)
      SMH반도체 SOXX반도체 XLK기술 XBI바이오 XLE에너지 XLF금융 ITA방산
      TAN태양광 LIT2차전지 URA원자력 XLI산업재 XLV헬스케어 JETS항공 KRE은행 XRT소비
  [2] +1.5% 이상 오른 섹터 → 한국 관련 종목 키워드 매핑으로 후보 추출
  [3] 후보 중 '어제까지 과열 아닌 것'만 (전일 +5% 이상 이미 오른 건 제외 - 늦음)
  [4] preopen_radar 후보에 '미국섹터' 가점 +25 병합 → 아침 레이더 랭킹에 반영

주의(정직): 이건 '확률을 약간 올리는 참고 신호'지 보장이 아님.
  섹터 상관은 날마다 다르고, 이미 시초 갭에 반영돼 늦을 때도 많음.
  → 그래서 매수 근거가 아니라 레이더 '가점'으로만 씀.

실행: python us_sector.py           # 지금 미국 섹터 → 한국 후보
      python us_sector.py --forward # 전방검증 (신호 저장 이후 실제 성적)
"""
import argparse
import json
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import sys
import time

try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import db

OUT = os.path.join("strategy", "us_sector.json")
HIST_DIR = os.path.join("strategy", "us_signals")   # 전방검증용 일별 저장
MIN_SECTOR_CHG = _cfg_env_float("US_MIN_SECTOR_CHG", 1.5)   # 섹터 발동 기준 %

# 미국 섹터 ETF → (한글명, 한국 종목명 키워드)
SECTORS = {
    "SMH":  ("반도체", ["반도체", "하이닉스", "삼성전자", "한미반도체", "DB하이텍", "리노공업",
                     "이오테크닉스", "주성엔지", "원익IPS", "테스", "유진테크", "HPSP", "ISC"]),
    "SOXX": ("반도체장비", ["반도체", "케이엔제이", "티씨케이", "하나마이크론", "네패스", "SFA반도체"]),
    "XLK":  ("기술/IT", ["소프트", "IT", "네이버", "NAVER", "카카오", "더존", "안랩"]),
    "XBI":  ("바이오", ["바이오", "제약", "셀트리온", "삼성바이오", "한미약품", "유한양행", "녹십자",
                     "대웅제약", "HLB", "알테오젠", "레고켐", "에이비엘"]),
    "XLE":  ("에너지/정유", ["에너지", "정유", "S-Oil", "SK이노", "GS", "한국석유"]),
    "XLF":  ("금융", ["금융", "은행", "증권", "보험", "KB", "신한", "하나금융", "우리금융"]),
    "ITA":  ("방산", ["방산", "한화에어로", "LIG넥스원", "현대로템", "한국항공", "풍산", "휴니드"]),
    "TAN":  ("태양광", ["태양", "한화솔루션", "HD현대에너지", "OCI", "신성이엔지"]),
    "LIT":  ("2차전지", ["2차전지", "배터리", "LG에너지", "삼성SDI", "SK온", "에코프로", "엘앤에프",
                      "포스코퓨처엠", "코스모신소재", "천보"]),
    "URA":  ("원자력", ["원자력", "두산에너빌", "한전기술", "한전KPS", "우진", "보성파워텍"]),
    "XLI":  ("산업재/기계", ["기계", "중공업", "두산", "현대건설기계", "HD현대인프라"]),
    "XLV":  ("헬스케어", ["헬스", "의료", "메디", "덴탈", "임플란트", "오스템", "덴티움"]),
    "JETS": ("항공/여행", ["항공", "대한항공", "아시아나", "제주항공", "티웨이", "하나투어", "모두투어"]),
    "KRE":  ("지방은행", ["은행", "저축", "캐피탈"]),
    "XRT":  ("소비/유통", ["유통", "백화점", "이마트", "롯데쇼핑", "신세계", "GS리테일", "BGF"]),
}


def _log(m=""):
    print(m, flush=True)


def fetch_us_sectors():
    """Yahoo에서 섹터 ETF 등락률 (마지막 거래일 기준). 반환 [{etf, name, chg}] 내림차순"""
    import requests
    out = []
    for etf, (kname, _kw) in SECTORS.items():
        try:
            r = requests.get(
                f"https://query1.finance.yahoo.com/v8/finance/chart/{etf}?range=5d&interval=1d",
                headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
            res = r.json().get("chart", {}).get("result")
            if not res:
                continue
            closes = [x for x in res[0]["indicators"]["quote"][0]["close"] if x]
            if len(closes) < 2:
                continue
            chg = (closes[-1] / closes[-2] - 1) * 100
            out.append({"etf": etf, "name": kname, "chg": round(chg, 2)})
            time.sleep(0.15)
        except Exception:
            continue
    out.sort(key=lambda x: -x["chg"])
    return out


def kr_candidates(hot_sectors, max_per_sector=8):
    """오른 미국 섹터 → 한국 관련 종목 (과열 제외 + 유동성 확인)"""
    from validation import _load_bars
    univ = db.get_universe()
    out = []
    seen = set()
    for sec in hot_sectors:
        kws = SECTORS.get(sec["etf"], ("", []))[1]
        matches = []
        for u in univ:
            nm = u.get("name") or ""
            if any(k.lower() in nm.lower() or k.lower() in nm.replace(" ", "").lower()
                   for k in kws):
                matches.append(u)
        got = 0
        for u in matches:
            sym = u["symbol"]
            if sym in seen or got >= max_per_sector:
                continue
            bars = _load_bars(sym, max_days=25)
            if len(bars) < 6:
                continue
            c = [b["close"] for b in bars]
            v = [b["volume"] or 0 for b in bars]
            px = c[-1]
            if px < 800 or px > 100000:
                continue                       # 실전 가격필터와 동일
            amt5 = sum(c[k] * v[k] for k in range(-5, 0)) / 5
            if amt5 < 300_000_000:
                continue                       # 유동성
            chg1 = (c[-1] / c[-2] - 1) * 100 if c[-2] else 0
            if chg1 > 5:
                continue                       # ★ 이미 오른 건 제외 (추격 늦음)
            out.append({"symbol": sym, "name": u.get("name", "")[:10],
                        "sector": sec["name"], "etf": sec["etf"],
                        "us_chg": sec["chg"], "kr_chg1": round(chg1, 2), "price": px})
            seen.add(sym)
            got += 1
    return out


def run_daily(log_fn=None):
    """매일 밤 실행: 미국 섹터 → 한국 후보 저장 + 레이더 가점용 심볼 목록"""
    def L(m):
        _log(m)
        if log_fn:
            try:
                log_fn(m)
            except Exception:
                pass

    secs = fetch_us_sectors()
    if not secs:
        L("🇺🇸 미국 섹터 수집 실패 (네트워크) - 오늘은 가점 없음")
        return {"sectors": [], "candidates": []}
    hot = [s for s in secs if s["chg"] >= MIN_SECTOR_CHG]
    cands = kr_candidates(hot) if hot else []
    today = db.now_kst().strftime("%Y-%m-%d")
    data = {"date": today, "updated_at": db.now_kst_iso(),
            "sectors": secs, "hot": hot, "candidates": cands}
    os.makedirs("strategy", exist_ok=True)
    json.dump(data, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    # ★ 전방검증용 일별 스냅샷 (uprank_watch와 같은 원리 - 날짜 도장)
    os.makedirs(HIST_DIR, exist_ok=True)
    json.dump(data, open(os.path.join(HIST_DIR, f"{today}.json"), "w",
                         encoding="utf-8"), ensure_ascii=False)
    if hot:
        hot_text = " · ".join(f"{s['name']}{s['chg']:+.1f}%" for s in hot[:4])
        L(f"🇺🇸 미국 섹터: {hot_text} "
          f"→ 한국 후보 {len(cands)}종목 (아침 레이더 가점 +25)")
    else:
        L(f"🇺🇸 미국 섹터: {MIN_SECTOR_CHG}%+ 오른 섹터 없음 (1위 "
          f"{secs[0]['name']} {secs[0]['chg']:+.1f}%) - 오늘 가점 없음")
    return data


def boost_symbols():
    """오늘 날짜의 미국섹터 후보 심볼 세트 (preopen_radar 가점용)"""
    try:
        d = json.load(open(OUT, encoding="utf-8"))
        if d.get("date") != db.now_kst().strftime("%Y-%m-%d"):
            # 어제 밤 저장분도 유효 (미국장은 한국 새벽 마감 - 당일 아침에 쓰는 게 정상)
            from datetime import timedelta
            yday = (db.now_kst() - timedelta(days=1)).strftime("%Y-%m-%d")
            if d.get("date") not in (yday,):
                return {}
        return {c["symbol"]: c for c in d.get("candidates", [])}
    except Exception:
        return {}


def forward_report(days=1, log_fn=None):
    """전방검증: 저장된 신호의 '다음날' 성적 vs 무작위 (생존편향 없음)"""
    from validation import _load_bars
    import random
    snaps = sorted(f[:-5] for f in os.listdir(HIST_DIR) if f.endswith(".json")) \
        if os.path.isdir(HIST_DIR) else []
    pool, ctrl = [], []
    try:
        cov = db.backfill_coverage(min_days=days + 5)
        all_syms = list(cov["symbols"].keys())
    except Exception:
        all_syms = []
    rng = random.Random(20260827)

    from uprank_watch import _forward_ret as _fwd_base   # ★ 중복 제거: uprank과 동일 로직 재사용
    def _fwd(sym, from_date):
        return _fwd_base(sym, from_date, days)

    used = 0
    for d in snaps:
        try:
            s = json.load(open(os.path.join(HIST_DIR, f"{d}.json"), encoding="utf-8"))
        except Exception:
            continue
        got = 0
        for c in s.get("candidates", []):
            fr = _fwd(c["symbol"], d)
            if fr is not None:
                pool.append(fr)
                got += 1
        if got:
            used += 1
            for sym in rng.sample(all_syms, min(got * 3, len(all_syms))):
                fr = _fwd(sym, d)
                if fr is not None:
                    ctrl.append(fr)
    if not pool:
        r = {"days": used, "note": "표본 없음 - 신호가 며칠 쌓인 뒤 확인"}
    else:
        pa = sum(pool) / len(pool)
        ca = sum(ctrl) / len(ctrl) if ctrl else None
        r = {"days": used, "pool_avg": round(pa, 2), "n": len(pool),
             "win": round(len([x for x in pool if x > 0]) / len(pool) * 100, 1),
             "control_avg": round(ca, 2) if ca is not None else None,
             "edge": round(pa - ca, 2) if ca is not None else None}
    if log_fn:
        try:
            log_fn(f"🇺🇸 [전방검증] {r}")
        except Exception:
            pass
    return r


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--forward", action="store_true", help="전방검증 성적")
    args = ap.parse_args()
    db.init_db()
    if args.forward:
        r = forward_report(log_fn=None)
        print("=" * 60)
        print("🇺🇸 미국섹터 신호 전방검증 (신호 저장 이후 다음날 성적)")
        print("=" * 60)
        print(json.dumps(r, ensure_ascii=False, indent=1))
        if r.get("edge") is not None:
            print("→ edge +0.3%p 이상이면 가점 유지/강화, 마이너스면 가점 제거 판단")
    else:
        d = run_daily(log_fn=None)
        print()
        for s in d.get("sectors", [])[:8]:
            print(f"  {s['name']:8s} ({s['etf']:5s}) {s['chg']:+.2f}%")
        print()
        for c in d.get("candidates", [])[:15]:
            print(f"  {c['symbol']} {c['name']:12s} ← {c['sector']} {c['us_chg']:+.1f}% "
                  f"(어제 {c['kr_chg1']:+.1f}%)")
