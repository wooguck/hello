@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] New quant environment not found:
    echo %CD%\.venv\Scripts\python.exe
    pause
    exit /b 1
)
if not exist ".\quant_platform\overnight.py" (
    echo [ERROR] overnight supervisor is missing.
    echo Extract STOCKBOT_QUANT_FINAL_CLEAN.zip at the project root.
    pause
    exit /b 1
)

if "%~1"=="" (
    echo [OVERNIGHT] 24-hour local PAPER research started.
    echo [OVERNIGHT] No broker API is called. Close this window only to stop it.
    ".venv\Scripts\python.exe" -m quant_platform.overnight --hours 24 --interval 900
) else (
    ".venv\Scripts\python.exe" -m quant_platform.overnight %*
)
set "RC=%ERRORLEVEL%"
echo.
echo [DONE] Check reports\overnight_status.json and data\paper_overnight.sqlite3
if not "%RC%"=="0" pause
exit /b %RC%
