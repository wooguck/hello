@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] New 64-bit Python environment not found:
    echo %CD%\.venv\Scripts\python.exe
    pause
    exit /b 1
)

if not exist ".\quant_platform\__init__.py" (
    echo [ERROR] quant_platform package is missing from the project root.
    echo Expected: %CD%\quant_platform\__init__.py
    pause
    exit /b 1
)
if not exist ".\quant_platform\gui.py" (
    echo [ERROR] quant_platform\gui.py is missing from the project root.
    echo Do not extract the ZIP inside the quant_platform folder.
    pause
    exit /b 1
)

".venv\Scripts\python.exe" -c "from quant_platform.gui import main; print('[OK] GUI package loaded')"
if errorlevel 1 (
    echo [ERROR] quant_platform package import failed. Check the clean package layout.
    pause
    exit /b 1
)

".venv\Scripts\python.exe" -m quant_platform.gui
if errorlevel 1 (
    echo [ERROR] GUI failed to start. Check errors\latest.json if present.
    pause
)
