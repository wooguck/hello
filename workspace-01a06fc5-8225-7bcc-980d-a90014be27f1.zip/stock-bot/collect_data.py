# -*- coding: utf-8 -*-
"""
📥 데이터 수집 전용 프로그램 (collect_data.py)
==============================================
자동매매/모의매매 없이 **데이터만** 받아서 쌓아두는 독립 실행기.

하는 일 (전부 네이버 공개 API - 키 불필요):
  1) 전 종목(약 3,300개) 일봉 최대 1000봉(약 4년) — 미수신/갭만 자동 보충
  2) 분봉(최근 1주일) — 관심/보유 종목 위주
  3) 코스피/코스닥 지수 일봉
  4) 상태 파일(strategy/backfill_state.json)에 마지막 수집 시각 기록

저장 위치:
  - data/stocks/{종목코드}.db  ← 일봉+분봉 통합 (종목별 파일)
  - data/kospi_daily.json      ← 코스피 일봉 캐시
  - trading.db                 ← 종목명/유니버스 등 메타

실행:
  python collect_data.py --once     # 전 종목 1회 수집 (미수신/갭만, 약 1~1.5시간)
  python collect_data.py --watch    # 켜두면 매일 장마감 후 자동 수집 (24시간 데몬)
  python collect_data.py --status   # 수집 현황/마지막 시각 확인
"""
import argparse
import logging
import os
import sys
import time
from datetime import datetime

import db
from config import CFG

# Windows 콘솔 한글 출력
try:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

logging.basicConfig(level=logging.WARNING)
log = logging.getLogger("collect")


def _log(msg):
    ts = datetime.now().strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    # 로그 파일에도 남기기
    try:
        os.makedirs("logs", exist_ok=True)
        with open("logs/collect_data.log", "a", encoding="utf-8") as f:
            f.write(f"{datetime.now().isoformat()} {msg}\n")
    except Exception:
        pass


def _universe_counts():
    """유니버스 개수: (전체, 코스피+코스닥 라벨 개수, KONEX 제외 대상 개수)
    - 전체: count_universe()
    - krx_kospi_kosdaq: market IN (KOSPI, KOSDAQ, KRX) - 일봉 수집 대상 라벨
    - target: KONEX 제외 전 종목 (수집 대상)
    """
    n = db.count_universe()
    kk = kr = 0
    try:
        with db.get_conn() as conn:
            kk = conn.execute(
                "SELECT COUNT(*) c FROM universe WHERE market IN ('KOSPI','KOSDAQ')"
            ).fetchone()["c"]
            kr = conn.execute(
                "SELECT COUNT(*) c FROM universe WHERE market != 'KONEX'"
            ).fetchone()["c"]
    except Exception:
        kk = n
    return n, kk, kr


def ensure_universe():
    """전 종목 목록 확인 (없거나 일부만 있으면 GitHub CSV 재로드 - 키움 무관)
    ★ 원본 3,516개 기준 - 3,000개 미만이면 부분 저장으로 보고 재로드 (네트워크/잠금 복구)
    ★ market 라벨이 KRX 등으로 덮인 경우도 (KOSPI/KOSDAQ 라벨 < 3000) 재로드
    ⛔ 재로드 후에도 3,000개 미만이면 수집을 진행하지 않고 멈춤 (조용히 1291개로 진행하던 버그 방지)
    """
    n, kk, _ = _universe_counts()
    import universe
    stale = universe.needs_refresh()
    if n < 3000 or kk < 3000 or stale:
        freshness = universe.universe_freshness()
        age_text = (f"마지막 갱신 {freshness.get('updated_at')} / "
                    f"{freshness.get('age_hours'):.1f}시간 경과"
                    if freshness.get("age_hours") is not None else "마지막 갱신 시각 없음")
        _log(f"전 종목 목록 {n}개 / 시장 라벨(KOSPI·KOSDAQ) {kk}개 / {age_text} - 재로드 중...")
        try:
            res = universe.refresh_universe()
            _log(f"유니버스 소스: {res.get('method')} ({res.get('count')}개)")
        except Exception as e:
            _log(f"⚠️ 유니버스 로드 실패: {e}")
    n, kk, target = _universe_counts()
    _log(f"전 종목 목록: {n}개 (시장 라벨 {kk}개 · 일봉 수집 대상 {target}개)")
    if n < 3000 or target < 3000:
        _log("⛔ 전 종목 목록이 3,000개 미만입니다 (GitHub CSV 접속 불가/부분 저장 의심).")
        _log("   네트워크 확인 후 다시 실행해주세요. 데이터는 받은 만큼 유지됩니다.")
        raise SystemExit(1)
    if universe.needs_refresh():
        freshness = universe.universe_freshness()
        _log(f"⛔ 유니버스 갱신 실패 또는 갱신 시각 확인 불가: {freshness.get('updated_at')}")
        _log("   최신 종목 목록을 확인할 수 없어 수집을 시작하지 않습니다.")
        raise SystemExit(1)
    return n


def run_full_collection(per_run=None):
    """★ 단계형 수집 (사용자: '일봉부터 다 받아지고, 그 이후에 진행')
    [1/3] 일봉 전체 수집 → 전 종목 30봉+ 완료까지 (분봉은 잠시 미룸)
    [2/3] 분봉 수집 (관심/보유 위주 1배치 - 전 종목은 watch 데몬이 매일 이어서)
    [3/3] 코스피 지수 + 요약 + 다음 단계(자동 전략/검증) 안내
    """
    import backfill_history as bf
    if per_run is None:
        per_run = max(500, int(getattr(CFG, "BACKFILL_PER_RUN", 500)))
    t0 = time.time()
    total_ok = total_bars = 0

    # ── [1/3] 일봉 전체 (분봉을 일봉 완료 후로 미룸) ──
    _log("📥 [1/3] 일봉 전체 수집 시작 (미수신/갭만, 배치 반복 - 분봉은 일봉 완료 후)")
    orig_min = getattr(CFG, "AUTO_BACKFILL_MINUTES", True)
    CFG.AUTO_BACKFILL_MINUTES = False   # 일봉 완료까지 분봉 안 받음
    # ★ 일봉 완료 목표: KONEX 제외 전 종목 (market 라벨과 무관하게 실제 대상 수)
    target = _universe_counts()[2]
    if target < 3000:
        _log(f"⛔ 일봉 수집 대상이 {target}개뿐입니다 - 전 종목 목록 이상. 유니버스 재로드 후 다시 실행해주세요.")
        raise SystemExit(1)
    stall = 0   # "받을 종목 0개인데 진행률 미달" 오판 감지 (연속 3회 → 중단)
    fail_streak = 0   # ★ 연속 실패 횟수 (네이버 차단 시 대기 시간 지수 증가 + 배치 축소)
    while True:
        cov = db.backfill_coverage(min_days=30)
        ready, total = cov.get("ready", 0), cov.get("total", 0)
        # ★ 죽은 종목(폐지/합병 - 어느 소스에도 없음)은 목표에서 제외
        #   (이게 없으면 폐지 종목 때문에 영원히 '완료'가 안 됨)
        try:
            dead_n = len(bf._load_dead())
        except Exception:
            dead_n = 0
        eff_target = max(1, target - dead_n)
        if total:
            extra = f" · 폐지 제외 {dead_n}" if dead_n else ""
            _log(f"진행: 일봉 30봉+ {ready}/{eff_target} 종목 ({min(100.0, ready / eff_target * 100):.0f}%){extra}")
        # ★ 연속 실패가 쌓이면 배치를 줄여 차단 회피 (500 → 250 → 125 → 60)
        cur_per_run = max(60, per_run // (2 ** min(fail_streak, 3)))
        r = bf.auto_backfill(per_run=cur_per_run)
        ok = r.get("symbols_ok", 0)
        fail = r.get("fail", 0)
        total_ok += ok
        total_bars += r.get("bars", 0)
        if ok == 0 and fail > 0:
            fail_streak += 1
            # ★ 실패 원인 집계 (HTTP 4xx=차단 / HTTP 200 빈응답=차단 / DNS=네트워크)
            _log(f"⚠️ 이번 배치 전부 실패({fail}개) - 위 원인 로그 참고 (연속 실패 {fail_streak}회)")
            # ★ 남은 종목 + 폴백 상태 명확히 (사용자: '받아지는지 안 보인다')
            left = max(0, eff_target - ready)
            if getattr(CFG, "BACKFILL_FALLBACK_KIWOOM", True):
                _log(f"   남은 종목 {left}개 · 키움 일봉 폴백으로 수집 중 "
                     f"(키움 1종목/초 제한 - {left}개면 약 {left // 60}분)")
            else:
                _log(f"   남은 종목 {left}개 · 네이버 차단이 풀릴 때까지 대기")
            # ★ 연속 실패 임계 초과 → 자동 중단 (네이버 무한 재시도 방지 - 78회 같은 사태 방지)
            max_streak = int(getattr(CFG, "BACKFILL_MAX_FAIL_STREAK", 5))
            if max_streak > 0 and fail_streak >= max_streak:
                _log(f"⛔ 연속 실패 {fail_streak}회 (최대 {max_streak}회) - 수집을 중단합니다.")
                _log(f"   받은 {ready}개는 안전하게 저장됨 · 네이버 차단이 풀리거나(공유기 재부팅) "
                     f"키움 폴백 설정(BACKFILL_FALLBACK_KIWOOM) 확인 후 다시 실행하세요")
                raise SystemExit(1)
            # ★ 키움 폴백 활성 안내 (네이버 실패 시 자동으로 ka10081 사용)
            if getattr(CFG, "BACKFILL_FALLBACK_KIWOOM", True):
                _log("   → 일봉 폴백 활성: 네이버 실패 종목은 Yahoo→키움(ka10081)으로 대체 수집 중 "
                     "(키 없어도 Yahoo로 수신 가능)")
            # ★ 차단 대기: 연속 실패가 쌓일수록 길게 (30초 → 1분 → 2분 → 4분)
            wait = min(30 * (2 ** min(fail_streak - 1, 4)), 300)
            nxt = max(60, per_run // (2 ** min(fail_streak, 3)))   # 다음 배치 크기 (축소)
            if fail_streak >= 2:
                _log(f"🕐 네이버 차단으로 보임 - {wait // 60}분 후 재시도 "
                     f"(다음 배치 {nxt}개로 축소) · 받은 {ready}개는 안전하게 저장됨")
            else:
                _log(f"🕐 {wait}초 후 재시도 (다음 배치 {nxt}개로 축소)")
            time.sleep(wait)
            continue
        # 성공했으면 연속 실패 초기화 + 배치 복구
        if fail_streak and ok > 0:
            _log(f"✅ 연속 실패 {fail_streak}회에서 회복 - 배치 {per_run}개로 복구")
        fail_streak = 0
        note = r.get("note", "")
        _log(f"일봉 배치: +{ok}종목 {r.get('bars', 0)}봉 ({note})")
        if r.get("strategy"):
            _log(r["strategy"])
        # ★ 완료 판정 (오판 방지): '대상 전 종목 30봉+ 도달'일 때만 진짜 완료
        #   (eff_target = 폐지/합병 종목 제외한 실제 달성 가능 목표)
        if ok == 0:
            if ready >= eff_target:
                _log(f"✅ 일봉 전 종목 완료 (폐지 {dead_n}종목 제외)")
                break
            # 받을 종목이 0개인데 진행률은 미달 → 전 종목 목록 이상 (라벨 오류/부분 저장)
            stall += 1
            _log(f"⚠️ 받을 종목 0개인데 진행률 {ready}/{eff_target} - 전 종목 목록 오류로 판단 (재로드 {stall}회)")
            import universe
            try:
                res = universe.refresh_universe()
                _log(f"   유니버스 재로드: {res.get('method')} ({res.get('count')}개)")
            except Exception as e:
                _log(f"   유니버스 재로드 실패: {e}")
            if stall >= 3:
                _log("⛔ 3회 재로드에도 진행률이 차지 않습니다 - 네트워크/DB 점검이 필요합니다. 수집을 중단합니다.")
                raise SystemExit(1)
            time.sleep(10)
            continue
        if target and ready >= eff_target:
            _log(f"✅ 일봉 전 종목 완료 (폐지 {dead_n}종목 제외)")
            break
    CFG.AUTO_BACKFILL_MINUTES = orig_min
    _log(f"📥 [1/3] 일봉 수집 완료: +{total_ok}종목 {total_bars}봉 ({time.time() - t0:.0f}초)")

    # ── [2/3] 분봉 (일봉 완료 후) - AUTO_BACKFILL_MINUTES=false면 분봉 수집 건너뜀 ──
    if not orig_min:
        _log("📈 [2/3] 분봉 수집 건너뜀 (AUTO_BACKFILL_MINUTES=false) - .env에서 true로 바꾸면 수집")
        _log(f"   대상: 설정(MINUTE_SYMBOLS) + 유니버스 + 계좌 보유 + 감시 풀 (최대 {getattr(CFG, 'MINUTE_MAX_SYMBOLS', 30)}종목)")
    else:
        _log("📈 [2/3] 분봉 수집 시작 (관심/보유 위주 1배치 - 전 종목은 watch 데몬이 매일 이어서)")
        try:
            mres = bf.backfill_minutes()
            _log(f"📈 [2/3] 분봉: {mres.get('symbols_ok', 0)}종목 {mres.get('bars', 0)}봉")
        except Exception as e:
            _log(f"⚠️ 분봉 수집 오류: {e}")

    # ── [3/3] 코스피 지수 + 요약 + 다음 단계 ──
    _log("📊 [3/3] 코스피 지수 캐시 + 다음 단계 확인")
    try:
        from validation import fetch_kospi_daily
        k = fetch_kospi_daily(force=True)
        _log(f"📊 코스피 일봉 캐시: {len(k)}봉 ({k[0]['date']} ~ {k[-1]['date']})")
    except Exception as e:
        _log(f"코스피 수집 오류: {e}")
    st = db.data_collection_stats()
    pct = round(st["stock_files"] / st["universe"] * 100, 1) if st["universe"] else 0
    _log(f"📦 현재 데이터: 종목 {st['stock_files']}/{st['universe']}개 ({pct}%) · "
         f"일봉 {st['daily_bars']:,}봉 · 분봉 {st['minute_bars']:,}봉 · {st['total_mb']}MB")
    # ── ★ 다음 단계 자동 진행: 일봉 완료 + 조건식 있으면 엄밀 검증 자동 1회 ──
    #   (사용자: '일봉 다 받아지고, 그 이후에 뭔가 진행되면 좋겠다')
    auto_val = os.getenv("COLLECT_AUTO_VALIDATE", "true").lower() == "true"
    conds_n = 0
    try:
        conds_n = len(db.get_conditions(status="active"))
    except Exception:
        pass
    if auto_val and total and ready >= total and conds_n > 0:
        _log("🎯 일봉 완료 → 자동 엄밀 검증 시작 (조건식 등급 갱신 - 가볍게 100종목)")
        try:
            import validation
            res = validation.validate_active_conditions(max_symbols=100)
            summary = " · ".join(f"{g} {n}" for g, n in res.get("summary", {}).items())
            _log(f"🎯 엄밀 검증 완료: {res.get('total', 0)}개 조건식 | {summary}")
            _log("   → '채택 후보/조건부' 조건식은 모의매매 최우선으로 자동 등록됩니다")
        except Exception as e:
            _log(f"⚠️ 엄밀 검증 오류: {str(e)[:50]}")
    else:
        _log("🎯 다음 단계: 데이터/조건식이 더 필요하면 → ① 자동 전략 생성(자동) "
             "② 🎯 엄밀 검증(앱 테스트 탭) ③ 앱 켜면 장중 모의매매 자동")
    return {"ok": total_ok, "bars": total_bars, "stats": st}

def watch_forever(per_run=None):
    """24시간 데몬: 장마감(15:30+) 후 자동으로 그날치 수집, 다음 거래일 반복
    - 장중에는 대기 (시세 변동 중 수집은 의미 없음 - 저녁에 일괄)
    - 주말/공휴일에도 다음 거래일 장마감을 기다림
    """
    import teams
    _log("🚀 데이터 수집 데몬 시작 (장마감 후 자동 수집). 종료: Ctrl+C")
    last_run_date = None
    while True:
        try:
            sess = teams.market_session()
            today = db.now_kst().strftime("%Y-%m-%d")
            if sess["mode"] in ("after_hours", "holiday") and last_run_date != today:
                _log(f"🕐 세션: {sess['mode']} - 오늘치 수집 시작")
                run_full_collection(per_run=per_run)
                last_run_date = today
                _log("✅ 오늘 수집 완료. 다음 거래일 장마감까지 대기.")
            else:
                nxt = sess["next_open"]
                if nxt:
                    _log(f"⏳ 다음 수집: {nxt:%Y-%m-%d %H:%M} 장마감 이후 (현재 세션: {sess['mode']})")
                else:
                    _log("⏳ 장중 대기 중...")
        except Exception as e:
            _log(f"⚠️ 데몬 오류: {e} (60초 후 재시도)")
        # 15분 간격으로 세션 확인 (가볍게)
        for _ in range(15):
            time.sleep(60)


def show_status():
    """수집 현황 출력"""
    st = db.data_collection_stats()
    pct = st["stock_files"] / st["universe"] * 100 if st["universe"] else 0
    print("=" * 56)
    print("📥 데이터 수집 현황")
    print("=" * 56)
    print(f"  종목: {st['stock_files']} / {st['universe']}개 ({pct:.1f}%)")
    print(f"  일봉: {st['daily_bars']:,}봉 · 분봉: {st['minute_bars']:,}봉")
    print(f"  용량: {st['total_mb']}MB · 마지막 백필: {st.get('last_backfill') or '없음'}")
    try:
        from validation import fetch_kospi_daily
        k = fetch_kospi_daily()
        if k:
            print(f"  코스피 일봉: {len(k)}봉 ({k[0]['date']} ~ {k[-1]['date']})")
    except Exception:
        pass
    print("=" * 56)
    print("💡 실행 방법:")
    print("  python collect_data.py --once    # 지금 1회 수집")
    print("  python collect_data.py --watch   # 켜두면 매일 장마감 후 자동 수집")
    print("=" * 56)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="데이터 수집 전용 프로그램")
    parser.add_argument("--once", action="store_true", help="전 종목 1회 수집")
    parser.add_argument("--watch", action="store_true", help="장마감 후 자동 수집 데몬 (켜두기)")
    parser.add_argument("--status", action="store_true", help="수집 현황")
    parser.add_argument("--per-run", type=int, default=None, help="배치당 종목 수")
    args = parser.parse_args()

    db.init_db()
    print("─" * 56)
    print(f"📥 데이터 수집기 시작 ({db.now_kst():%Y-%m-%d %H:%M:%S})")
    print("─" * 56)

    if args.status or not (args.once or args.watch):
        show_status()
    else:
        ensure_universe()
        if args.once:
            run_full_collection(per_run=args.per_run)
        elif args.watch:
            watch_forever(per_run=args.per_run)
