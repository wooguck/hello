@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] New quant environment not found.
    pause
    exit /b 1
)
set "SYMBOL=%~1"
if "%SYMBOL%"=="" set "SYMBOL=005930"
echo [DEEP-LEARNING] chronological holdout probe only: %SYMBOL%
".venv\Scripts\python.exe" -m quant_platform.research --symbol "%SYMBOL%" --deep-learning
if errorlevel 1 (
    echo [BLOCKED] See errors or the output above. No strategy was enabled.
    pause
    exit /b 1
)
echo [DONE] Deep learning probe report is under reports\quant_research_%SYMBOL%.json
pause
