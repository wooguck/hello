# StockBot Quant 최종 검증 보고서

검증일: 2026-09-05 (KST)
기준 폴더: `/home/user/stock-bot`

## 최종 판정

```text
배포 가능: 연구·검증·로컬 PAPER 한정
실거래: 차단
hello-merged.zip 덮어쓰기: 하지 않음
```

현재 최신 작업본을 기준으로 진행했으며, GitHub의 이전 `hello-merged.zip`은 코드 병합에 사용하지 않았습니다.

## 자동 검증 결과

### 전체 테스트

```text
40 passed, 1 skipped
```

skip 사유:

```text
tests/test_api.py:17
optional FastAPI dependencies are not installed
```

API 자체가 실패한 것이 아니라 선택 의존성이 없는 환경에서만 skip됩니다. GUI·연구 코어·데이터 검증·오케스트레이터·다중 시간프레임·주문 게이트웨이 테스트는 통과했습니다.

### Python 컴파일

```text
python -m compileall -q quant_platform *.py
COMPILEALL_OK
```

### 단일 종목 통합 실행

입력: `data/stocks/005930.db`

```text
status = COMPLETED
mode = READ_ONLY_RESEARCH
source_rows = 70
canonical_rows = 70
analysis_rows = 70
candidate_count = 14
survivor_count = 0
orders_submitted = 0
```

해석:

- 원천 70봉이 canonical에 보존·정렬됨
- 14개 전략 후보를 평가함
- 생존 전략이 없으므로 자동 사용하지 않음
- 주문은 0건
- 결과는 별도 임시 검증 리포트로 생성됨

### 하루 PAPER 감독자 1 cycle

격리된 임시 프로젝트에서 실행했습니다.

```text
research = COMPLETED
new_bars = 8
paper_orders = 42
broker_orders = 0
```

PAPER 원장 확인:

```text
ledger_rows = 42
PAPER_PENDING = 42
broker order = 0
```

이는 로컬 SQLite 기록만 의미하며 키움·브로커 주문 제출이 아닙니다.

### 주문 안전성 매트릭스

```text
OFF                 -> REJECTED
DRY_RUN             -> SIMULATED, no broker API was called
PAPER               -> PAPER_PENDING, no broker API was called
LIVE allow=false    -> REJECTED
LIVE allow=true     -> REJECTED, live broker adapter is not configured
```

`DRY_RUN=false`처럼 보이는 환경에서도 `KIWOOM_USE_MOCK=true`이면 live trading이 활성화되지 않는 것을 확인했습니다.

## 최종 통합 감사

파일: `reports/final_integration_audit.json`

```text
PASS: 4
WARN: 11
FAIL: 0
safe_to_order: false
```

현재 WARN은 다음 범주입니다.

- 개발 실행 Python이 `.venv`가 아닌 환경임
- 프로젝트에 `.env`가 없음
- historical universe와 current universe를 아직 공식 현재 원천으로 확정하지 않음
- legacy 주문 관련 파일이 존재함
- 공식 원격 데이터 연결 전까지 자동 원격 다운로드를 비활성화함
- 연결 증거가 없는 legacy 아이디어 23개

WARN을 임의로 PASS로 승격하지 않았습니다. 특히 `safe_to_order`는 명시적으로 `false`입니다.

## 이번 최종 단계에서 적용한 수정

### 1. 배포 안내 추가

```text
FINAL_START_HERE.md
```

GUI 시작 순서, PAPER 감독자, 리포트 위치, 안전 승급 순서를 하나로 정리했습니다.

### 2. 의존성 오타 수정

`requirements-platform.txt`의 잘못된 선택 패키지명을 수정했습니다.

```text
httpx2 -> httpx
```

### 3. SQLite sidecar 무시 규칙 추가

```text
*.db-*
```

실행 중 생성되는 `-wal`, `-shm` 파일이 최종 소스 목록에 섞이지 않도록 했습니다. 기존 원본 DB와 `.env`는 수정하지 않았습니다.

## 배포 ZIP 자체 검증

새로 만든 `STOCKBOT_QUANT_FINAL_20260905.zip`을 별도 임시 폴더에 풀어 다시 검증했습니다.

```text
35 passed, 1 skipped
compileall 성공
```

이 ZIP의 skip도 FastAPI 선택 의존성이 없는 환경에서 발생한 `test_api.py` skip입니다.

## 사용자 운영 순서

```text
새 폴더에 최종 ZIP 압축 해제
→ 64비트 .venv 준비
→ requirements-platform.txt 설치
→ run_stockbot_gui.bat
→ GUI의 전체 오류·안전 점검
→ 선택 종목 또는 전체 종목 실행
→ 결과 검수·요약
→ 하루 PAPER 감독자
→ Shadow 검토
```

현재는 여기서 멈춥니다.

```text
실거래 연결 및 실제 주문: 진행하지 않음
```

## 보존한 기존 기능

- 기존 `trading.db`, `data/stocks`, legacy 파일 보존
- 32비트 OpenAPI와 64비트 연구 코어 분리
- 일봉 관심종목 → 분봉 확정 신호 상태머신
- 미래 봉 참조 없는 다음 봉 체결 검증
- 부분 익절·trailing 보유 판단 구조
- provenance·data quality gate
- event study
- Kiwoom 조건식 snapshot 비교 계약
- review·idea coverage
- overnight local PAPER
- 오류센터와 resumable batch

## 배포 파일

최종 배포 ZIP은 다음 파일입니다.

```text
STOCKBOT_QUANT_FINAL_20260905.zip
```

배포 ZIP에는 비밀키, `.env`, 원본 DB, 실행 중 생성된 reports/errors 전체 묶음을 넣지 않습니다.
