"""
4팀 운영 시스템 (teams.py) — 간결한 자동 운영
================================================
사용자 요청: "가상 매매 다 때려치고, 모의로 실제 확인 1팀 / 자료 수집 1팀 / 수집 자료로 검증 1팀 /
총괄 1팀(AI 포함). 필요없는 거 싹 빼고 간결하게."

팀 구성:
  📥 DataTeam        : 자료 수집 (일봉 1000봉 + 분봉 한 달치, 미수신/갭만)
  🔍 ValidateTeam    : 수집된 자료로 조건식 검증 (신호 잡는지/성적)
  🖥 PaperTeam       : 조건식으로 실제 모의 매매 (가상 아님 - 모의 주문 확인)
  🧠 ControlTeam     : 총괄 + AI 지시 (각 팀 실행/순서/변형 지시)

총괄(ControlTeam)이 팀들을 차례로 실행:
  라운드 = [자료수집] → [검증] → [모의매매] → [AI 지시·변형] → 명예의 전당 갱신
"""
import json
import logging
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import time

import db
from config import CFG

log = logging.getLogger("teams")


class Team:
    """팀 공통: 실행 + 로그"""
    name = "팀"

    def __init__(self):
        self.last_log = []

    def log_line(self, msg):
        self.last_log.append(f"[{self.name}] {msg}")
        log.info(f"[{self.name}] {msg}")

    def run(self, **kw):
        raise NotImplementedError


class DataTeam(Team):
    """📥 자료 수집 팀: 일봉(최대 1000봉) + 분봉(한 달치) - 미수신/갭만"""
    name = "자료수집"

    def run(self, per_run=None, **kw):
        import backfill_history as bf
        per_run = per_run or CFG.BACKFILL_PER_RUN
        self.log_line("📥 자료 수집 시작 (미수신/갭 종목만)")
        # ★ 유니버스 보정: 개수뿐 아니라 마지막 갱신 시각도 확인합니다.
        #    오래된 목록으로 검증/모의매매를 진행하지 않고, 갱신 실패 시 라운드를 중단합니다.
        try:
            import universe
            if universe.needs_refresh():
                res = universe.refresh_universe()
                freshness = universe.universe_freshness()
                self.log_line(f"전 종목 목록 보정: {res.get('count', 0)}개 ({res.get('method', '')})")
                if universe.needs_refresh():
                    raise RuntimeError(f"유니버스 갱신 확인 실패: {freshness.get('updated_at')}")
            else:
                freshness = universe.universe_freshness()
                age = freshness.get("age_hours")
                age_text = f"{age:.1f}시간 전" if age is not None else "갱신 시각 없음"
                self.log_line(f"전 종목 목록 최신: {freshness.get('updated_at')} ({age_text})")
        except Exception as e:
            self.log_line(f"⚠️ 유니버스 보정 실패 - 이번 라운드 중단: {str(e)[:80]}")
            raise
        br = bf.auto_backfill(per_run=per_run)
        self.log_line(f"일봉 {br.get('symbols_ok', 0)}종목 {br.get('bars', 0)}봉 {br.get('note', '')}")
        if br.get("minutes"):
            self.log_line(br["minutes"])
        return br

    def status(self):
        st = db.data_collection_stats()
        pct = round(st["stock_files"] / st["universe"] * 100, 1) if st["universe"] else 0
        return (f"종목 {st['stock_files']}/{st['universe']}개 ({pct}%) · "
                f"일봉 {st['daily_bars']:,}봉 · 분봉 {st['minute_bars']:,}봉 · {st['total_mb']}MB")


class ValidateTeam(Team):
    """🔍 검증 팀: 수집된 자료로 조건식이 신호를 잘 잡는지/성적 확인"""
    name = "검증"

    def run(self, max_conds=None, **kw):
        import condition_manager as cm
        self.log_line("🔍 조건식 검증 (수집된 자료 기준)")
        conds = cm.list_conditions_with_stats()
        active = [c for c in conds if c["status"] == "active"]
        self.log_line(f"조건식 {len(active)}개 검증 (운영 중)")
        # 조건식별 신호/성적 집계 (검증 결과)
        rows = []
        for c in active[: (max_conds or 30)]:
            st = c["stats"]
            rows.append({"no": c["cond_no"], "txt": c["cond_txt"][:40],
                         "buys": st.get("buys", 0), "sells": st.get("sells", 0),
                         "win": st.get("win_rate", 0), "net": st.get("net", 0),
                         "status": c["status"]})
        self.last_validation = rows
        # 싹수없는 것 뒤로 (관리)
        mg = cm.manage(max_variations=2)
        for l in mg["log"]:
            self.log_line("→ " + l)
        return {"rows": rows, "backlogged": mg.get("backlogged", []),
                "variations": mg.get("variations", [])}


class PaperTeam(Team):
    """🖥 모의 매매 팀: 조건식으로 실제 모의 매매 (가상 아님 - 실제 모의 주문 확인)"""
    name = "모의매매"

    def run(self, n=10, **kw):
        import condition_manager as cm
        self.log_line(f"🖥 모의 매매 실행 ({n}개 조건식 · 전 종목 스캔)")
        r = cm.run_batch(n=n)
        risk = (r.get("risk") or {}).get("level", "")
        risk_txt = {"danger": "🚨 지수 위험(전량 매도/진입 중단)",
                    "warning": "⚠️ 지수 주의(진입 중단)"}.get(risk, "")
        self.log_line(f"진입 {len(r.get('entered', []))}건 · 청산 {len(r.get('exited', []))}건 · "
                      f"보유 {r.get('held', 0)}건{(' · ' + risk_txt) if risk_txt else ''}")
        return r

    def summary(self):
        import paper_test
        return paper_test.paper_summary()


class ControlTeam(Team):
    """🧠 총괄 팀 (AI 포함): 각 팀 순서대로 실행 + AI 지시·변형 + 명예의 전당"""
    name = "총괄"

    def __init__(self):
        super().__init__()
        self.teams = {"data": DataTeam(), "validate": ValidateTeam(), "paper": PaperTeam()}
        self._round_count = 0   # ★ 주기적 엄밀 검증용 라운드 카운터

    def round(self, per_run=None, paper_n=10, use_ai=True):
        """1라운드: 자료수집 → 검증 → 모의매매 → 명예의 전당 → (AI 지시는 검증 단계에서 변형)"""
        t0 = time.time()
        self.log_line("🧠 총괄 시작: 라운드 운영")
        out = {}

        # ★ 라운드 진행률 파일 (현황판이 읽음 - 몇 % 진행/예상시간 표시)
        #   단계: 0수집 → 1검증 → 2모의매매 → 3리포트/명예의전당 → 4완료
        def _progress(step, name):
            try:
                os.makedirs("strategy", exist_ok=True)
                prev_elapsed = 0
                try:
                    _st = json.load(open(os.path.join("strategy", "control_state.json"),
                                         encoding="utf-8"))
                    prev_elapsed = float((_st.get("last_round") or {}).get("elapsed") or 0)
                except Exception:
                    pass
                json.dump({"round": getattr(self, "_round_count", 0) + 1,
                           "step": step, "steps_total": 4, "step_name": name,
                           "started_at": t0, "now": time.time(),
                           "prev_elapsed": prev_elapsed},
                          open(os.path.join("strategy", "round_progress.json"), "w",
                               encoding="utf-8"))
            except Exception:
                pass

        _progress(0, "📥 자료수집")

        # 0) ★ 사진 원형 조건식 자동 등록 (조건식이 하나도 없을 때만 - 첫 실행 대비)
        try:
            if not db.get_conditions(status="active"):
                import condition_manager as _cm
                n = _cm.init_conditions()
                if n:
                    self.log_line(f"📷 사진 검색식 원형 {n}개 등록 (최초 실행)")
        except Exception as e:
            self.log_line(f"⚠️ 원형 등록 실패: {str(e)[:50]}")

        # 0.1) ★ 이름 없는 조건식 자동 작명 (AI/규칙 - [별명] 형태로 어디서나 표시)
        #   변형/급등유전자로 새 조건식이 생겨도 라운드마다 자동으로 이름이 붙음
        try:
            import name_conditions as _nc
            unnamed = [c for c in (db.get_conditions(status="active")
                                   + db.get_conditions(status="backlog"))
                       if not str(c.get("cond_txt", "")).startswith("[")]
            if unnamed:
                ai = _nc.ai_names(unnamed)
                import json as _json
                used = set()
                with db.get_conn() as conn:
                    for c in unnamed:
                        name = ai.get(str(c["id"]))
                        if not name:
                            try:
                                slots = _json.loads(c.get("slots_json") or "[]")
                            except Exception:
                                slots = []
                            name = _nc.rule_name(slots)
                        base, k = name, 2
                        while name in used:
                            name = f"{base}{k}"
                            k += 1
                        used.add(name)
                        conn.execute("UPDATE conditions SET cond_txt=? WHERE id=?",
                                     (f"[{name}] {c['cond_txt']}", c["id"]))
                self.log_line(f"🏷 조건식 자동 작명: {len(unnamed)}개 "
                              f"({'AI' if ai else '규칙'} 작명)")
        except Exception as e:
            self.log_line(f"⚠️ 자동 작명 스킵: {str(e)[:40]}")

        # 1) 자료 수집 팀
        out["data"] = self.teams["data"].run(per_run=per_run)
        for l in self.teams["data"].last_log[-2:]:
            self.log_line("  " + l.replace("[자료수집] ", ""))

        # 1.5) ★ 데이터 품질 자동 게이트 (2026-08-27): 썩은 데이터로 검증하지 않기
        #   bad면 이번 라운드 검증을 건너뜀 (등급 오염 방지). 매도/가드는 무관하게 계속.
        _q = {"level": "ok"}
        try:
            import quality_gate as _qg
            _q = _qg.run(log_fn=self.log_line)
            out["quality"] = _q
        except Exception as e:
            self.log_line(f"⚠️ 품질게이트 스킵: {str(e)[:40]}")

        # 2) 검증 팀 (수집된 자료로 조건식 검증 + 싹수없는 것 관리)
        _progress(1, "🔍 검증")
        if _q.get("level") == "bad":
            self.log_line("🚦 데이터 품질 🔴 - 이번 라운드 검증 생략 (썩은 자료로 등급 안 매김. "
                          "수집 복구 후 자동 재개)")
            v = {"rows": [], "skipped": "quality_bad"}
        else:
            v = self.teams["validate"].run()
        out["validate"] = v
        for l in self.teams["validate"].last_log[-3:]:
            self.log_line("  " + l.replace("[검증] ", ""))

        # 3) 모의 매매 팀 (실제 모의 확인)
        _progress(2, "🖥 모의매매")
        p = self.teams["paper"].run(n=paper_n)
        out["paper"] = {"entered": len(p.get("entered", [])), "exited": len(p.get("exited", []))}
        for l in self.teams["paper"].last_log[-2:]:
            self.log_line("  " + l.replace("[모의매매] ", ""))

        # 3.4) ★ 주간 리포트 (매주 토요일 장마감 후 1회 - AI 넣은 vs 안 넣은 비교)
        try:
            if getattr(CFG, "WEEKLY_REPORT_ENABLED", True):
                from weekly_report import generate_weekly_report, get_latest, week_start
                latest = get_latest()
                this_ws = str(week_start())
                if latest is None or str(latest.get("week", "")) != this_ws:
                    # 토요일(5) 또는 일요일(6)에만 생성 (주중 라운드에서도 마지막 생성 보장)
                    if db.now_kst().weekday() >= 5:
                        w = generate_weekly_report()
                        self.log_line(f"📅 주간 리포트 생성 ({w['week']}) - "
                                      f"AIvs규칙 비교 + 권장 {len(w['summary'].get('recommendations', []))}건")
                        out["weekly"] = {"week": w["week"]}
        except Exception as e:
            self.log_line(f"⚠️ 주간 리포트 스킵: {str(e)[:60]}")

        # 3.45) ★⚖️ 그림자 3종 리포트 (매 20라운드 - 매수게이트/매도/손실교훈, 2026-08-28)
        #   숫자만 로그로 - 판단 재료 축적 (조정은 사용자 승인제)
        try:
            if self._round_count % 20 == 5:
                import gate_report as _gr
                _g = _gr.report(days=14, log_fn=None)
                if _g.get("a_n") or _g.get("b_n"):
                    self.log_line(f"⚖️ 매수게이트: 통과 {_g.get('a_n',0)}건 vs 거부(샀다면) {_g.get('b_n',0)}건 - gate_report.py 참고")
                import sell_shadow as _ss
                _v = _ss.report(days_window=14, log_fn=None)
                if _v:
                    _worst = max(_v.items(), key=lambda x: x[1])
                    if _worst[1] > 1.5:
                        self.log_line(f"🌒 매도그림자: '{_worst[0]}' 청산 후 평균 +{_worst[1]}% 더 감 (조기매도 신호)")
        except Exception:
            pass

        # 3.5) ★ 주기적 엄밀 검증 (매 5라운드마다 - 조건식 등급 갱신, 100종목 가볍게)
        #   🌱 충원모드(운영 조건식 부족)면 2라운드마다 (승격 파이프라인 가속)
        self._round_count += 1
        _lc_every = 5
        try:
            _rf0 = json.load(open(os.path.join("strategy", "refill_mode.json"),
                                  encoding="utf-8"))
            if _rf0.get("on"):
                _lc_every = 2
        except Exception:
            pass
        if self._round_count % _lc_every == 0:
            try:
                import validation
                res = validation.validate_active_conditions(max_symbols=100)
                summary = " · ".join(f"{g} {n}" for g, n in res.get("summary", {}).items())
                self.log_line(f"🎯 엄밀 검증({self._round_count}라운드): {summary}")
                out["validation"] = res.get("summary", {})
            except Exception as e:
                self.log_line(f"⚠️ 엄밀 검증 스킵: {str(e)[:50]}")
            # ★ 검증 통과 조건식 → 다음날 실제 모의투자 예약 (원본 유지)
            try:
                sched = db.schedule_validation_to_paper()
                if sched.get("scheduled", 0) > 0:
                    self.log_line(f"📅 다음날 모의투자 예약: {sched['scheduled']}개 "
                                  f"({sched.get('date')}) - 원본 조건식은 그대로 유지")
            except Exception:
                pass
            # ★♻️ 자동 승격/강등 (사용자: '대기도 검증해서 싹수 있으면 운영으로,
            #   명전 상위 5개는 운영 보장 - 전부 자동으로')
            #   대기 검증(순환) → 통과 등급 승격 → 기각+실전부진 강등 → 명전 상위 운영 유지
            try:
                import lifecycle
                lc = lifecycle.auto_lifecycle(log_fn=self.log_line)
                out["lifecycle"] = {k: v for k, v in lc.items() if v}
            except Exception as e:
                self.log_line(f"⚠️ 승격/강등 스킵: {str(e)[:50]}")
            # ★🧑‍🏫 AI 코치 진단 (조건식 문제점·개선 제안 기록 - 적용은 사용자 승인제)
            #   제안은 strategy/coach_log.json 누적 → python ai_coach.py --list / --apply
            try:
                import ai_coach
                nc = ai_coach.run_coach(log_fn=self.log_line)
                if nc:
                    self.log_line(f"🧑‍🏫 코치 새 제안 {nc}건 → 'python ai_coach.py --list'로 확인")
                    out["coach"] = nc
            except Exception as e:
                self.log_line(f"⚠️ 코치 진단 스킵: {str(e)[:40]}")

        # ★🌱 충원모드 확인 (lifecycle이 기록 - 운영 조건식 부족하면 탐색 가속)
        #   2026-09-01 사용자: "대량 퇴출했으면 그만큼 찾아서 편입해야 하는데 부족"
        _refill = False
        try:
            _rf = json.load(open(os.path.join("strategy", "refill_mode.json"),
                                 encoding="utf-8"))
            _refill = bool(_rf.get("on"))
        except Exception:
            pass
        if _refill:
            self.log_line("🌱 충원모드: 운영 조건식 부족 - 팜/빌더/유전자 주기 단축 실행")

        # 3.6) ★ 급등 유전자 자동 발굴 → 검색식 등록 (매 10라운드 · 충원모드 땐 3라운드)
        try:
            if getattr(self, "_round_count", 0) % (3 if _refill else 10) == 0:
                import surge_mining as _sm
                _g = _sm.auto_promote_candidates(max_symbols=150, min_success=60.0, max_add=2)
                if _g.get("added", 0) > 0:
                    for a in _g["list"]:
                        self.log_line(f"🧬 급등유전자 검색식 등록: {a['cond_no']} (성공확률 {a['success_pct']}%)")
                elif _g.get("note"):
                    self.log_line(f"🧬 급등유전자: {_g['note'][:50]}")
        except Exception:
            pass

        # 3.615) ★⚾ 팜 리그 (매 10라운드 - 사용자: '유소년→중등→고등→프로 리그처럼')
        #   공격적 생성 500개/시즌 → 리그 오를수록 엄격 시험 → 프로 데뷔는 backlog 등록만
        #   (하루 약 13~20시즌 = 신인 6,500~10,000명 시험 - 데뷔는 시즌당 최대 2명)
        try:
            _farm_every = max(2, _cfg_env_int("FARM_EVERY_ROUNDS", 3))
            if _refill:
                _farm_every = 2   # 🌱 충원모드: 팜 시즌 더 자주 (3라운드→2라운드)
            if (getattr(self, "_round_count", 0) % _farm_every == 3 % _farm_every
                    and os.getenv("FARM_AUTO", "true").lower() == "true"):
                import farm_league as _fl
                _fr = _fl.run_season(log_fn=self.log_line)
                if _fr.get("debut"):
                    out["farm_debut"] = _fr["debut"]
        except Exception as e:
            self.log_line(f"⚾ 팜리그 스킵: {str(e)[:40]}")

        # 3.617) ★🎛 매도 파라미터 자동 최적화 (매 15라운드 - 2026-08-28 사용자: "자동 아니야?")
        #   조건식 1개씩 순환 (1280조합+OOS+고원). 적용은 5개+ 조건식 '중앙값 합의'로만
        #   (한 조건식 결과가 전역 설정을 흔들지 않게 - 사용자가 겪은 --apply 부작용 방지)
        try:
            if (getattr(self, "_round_count", 0) % 15 == 7
                    and os.getenv("AUTO_OPT", "true").lower() == "true"):
                import param_optimizer as _po
                _po.auto_optimize(max_per_call=1, max_symbols=300, log_fn=self.log_line)
        except Exception as e:
            self.log_line(f"🎛 자동최적화 스킵: {str(e)[:40]}")

        # 3.62) ★🧱 단순→복잡 빌더 (매 20라운드마다 - 사용자: '단순함에서 키우는 방식도 한번씩')
        #   1슬롯 전수 → 생존끼리 2~3슬롯 성장 (OOS+간결성 보너스 통과만) → backlog 등록
        #   급등유전자(하향식: 급등에서 역추적)와 반대 방향의 탐색 - 둘이 상호보완
        try:
            if (getattr(self, "_round_count", 0) % (5 if _refill else 20) == 0
                    and os.getenv("SLOT_BUILDER_AUTO", "true").lower() == "true"):
                import slot_builder as _sb
                _b = _sb.build(register=True, log_fn=self.log_line)
                if _b.get("registered"):
                    out["builder"] = _b["registered"]
        except Exception as e:
            self.log_line(f"🧱 빌더 스킵: {str(e)[:40]}")

        # 3.65) ★🏛 거버너 (매 10라운드마다) - 종합판정 자동 반영 + AI 조정
        #   WF 시기의존/파산확률 5%+ → 자동 강등 (스냅샷 후 - 언제든 롤백 가능)
        #   AI(Gemini)는 화이트리스트 행동만 (강등/트레일링 1~3% - 하드손절 등은 불가침)
        try:
            if (getattr(self, "_round_count", 0) % 10 == 0
                    and os.getenv("AUTO_GOVERN", "true").lower() == "true"):
                import governor
                gv = governor.run_governor(log_fn=self.log_line)
                out["governor"] = gv
        except Exception as e:
            self.log_line(f"⚠️ 거버너 스킵: {str(e)[:40]}")

        # 3.675) ★🇺🇸 미국 섹터 → 한국 후보 (밤 라운드 - 하루 1회, 2026-08-27)
        #   미국장 마감 후(한국 새벽) 데이터가 정확하지만, 저녁 라운드 것도 참고 가치 있음
        try:
            import us_sector as _us
            _usf = os.path.join("strategy", "us_sector.json")
            _need = True
            try:
                _u = json.load(open(_usf, encoding="utf-8"))
                # 3시간 내 갱신본 있으면 스킵 (라운드마다 API 두드리지 않게)
                from datetime import datetime as _dtt
                _need = (db.now_kst() - _dtt.fromisoformat(_u["updated_at"])).total_seconds() > 10800
            except Exception:
                pass
            if _need:
                _us.run_daily(log_fn=self.log_line)
        except Exception as e:
            self.log_line(f"🇺🇸 미국섹터 스킵: {str(e)[:40]}")

        # 3.68) ★📡 개장 전 급등 레이더 (밤 라운드에서 다음날 후보 미리 랭킹)
        try:
            import preopen_radar as _pr
            _cands = _pr.preopen_rank(top=15, max_scan=200)
            _pr.save("preopen", _cands)
            if _cands:
                self.log_line(f"📡 내일 급등 후보 {len(_cands)}개 랭킹 "
                              f"(1위 {_cands[0]['symbol']} {_cands[0]['score']:.0f}점)")
        except Exception as e:
            self.log_line(f"📡 레이더 스킵: {str(e)[:40]}")

        # 3.685) ★🗼 다중 시간축 정렬 스캔 (참고용 - 기본 OFF)
        #   2026-08-27 전 종목 3,442개 실측 판정: 기각 (모든 단계 중앙값 마이너스,
        #   3단계도 기준선 대비 평균 -0.53%p - 400종목 때 +2%p는 표본 우연이었음)
        #   → 매수 채널 승격 안 함. 보고 싶으면 MTF_SCAN_AUTO=true
        try:
            if os.getenv("MTF_SCAN_AUTO", "false").lower() == "true":
                import multi_tf as _mtf
                _rows = _mtf.scan_today(top=15)
                if _rows:
                    _t3 = [r for r in _rows if r["tier"] >= 3]
                    if _t3:
                        self.log_line(f"🗼 다중정렬(월주일↑) 후보 {len(_t3)}개 "
                                      f"(1위 {_t3[0]['symbol']} - multi_tf_today.json)")
        except Exception as e:
            self.log_line(f"🗼 다중정렬 스킵: {str(e)[:40]}")

        # 3.69) ★📈 상승률 상위 명단 스냅샷 (하루 1회 - 전방검증용, 2026-08-27)
        #   '오늘 오른 200개'를 날짜 도장 찍어 저장만 함 (매수 아님·백테스트 아님)
        #   → 며칠 쌓이면 uprank_watch --report 로 "급등 다음날 사면 실제로 어땠나" 확인
        #   → 생존편향 없는 전방검증 (저장 시점 이후 성적만 봄)
        try:
            import uprank_watch as _uw
            _us = _uw.snapshot(log_fn=self.log_line)
            if _us.get("saved"):
                out["uprank"] = {"n": _us["n"]}
            # 스냅샷 7일치 이상이면 전방 리포트도 라운드 로그에 요약
            if len(_uw.list_snapshots()) >= 7 and self._round_count % 5 == 0:
                _fr = _uw.forward_report(days=5, log_fn=self.log_line)
                if _fr.get("edge") is not None:
                    out["uprank_edge"] = _fr["edge"]
        except Exception as e:
            self.log_line(f"📈 상승풀 스킵: {str(e)[:40]}")


        # 3.695) ★🩺 자가진단 하루 1회 자동 (2026-09-01 사용자: "확인도구 없이 안 되는지")
        #   결과는 strategy/doctor_report.json → 현황판 시스템 탭에 자동 표시
        #   사용자는 아무 명령도 안 침 - 현황판 열어서 보기만 하면 됨
        try:
            import system_doctor as _sd
            _dr = _sd.auto_run_daily(log_fn=self.log_line)
            if _dr:
                out["doctor"] = _dr
        except Exception as e:
            self.log_line(f"🩺 자가진단 스킵: {str(e)[:40]}")

        # 3.7) ★ 저평가 주식 추적 갱신 (관찰 종목 현재가 - '저평가가 올랐나')
        try:
            import value_watch as _vw
            _res = _vw.update_all()
            if _res.get("updated", 0) > 0:
                _st = db.value_watch_stats()
                self.log_line(f"💎 저평가 추적: 갱신 {_res['updated']}개 · 관찰 {_st['watching']} · "
                              f"회복 {_st['up']} (평균 최고 {_st['avg_peak_return']}%)")
        except Exception:
            pass

        _progress(3, "🧠 리포트·명예의전당")
        # 4) 일일 복기 리포트 자동 생성 (하루 매매를 돌아보는 리포트 - 뷰어/AI 토의용)
        try:
            import daily_report
            dr = daily_report.generate_daily_report()
            if dr:
                s = dr["summary"]
                self.log_line(f"📋 오늘 리포트 생성: 매수 {s['buys']} · 매도 {s['sells']} · "
                              f"승률 {s['win_rate']}% · 손익 {s['total_pnl']:+,}원")
        except Exception as e:
            self.log_line(f"📋 리포트 생성 오류: {e}")

        # 5) 명예의 전당 갱신 (승률 좋은 조건식 → 상위 50개 순위 + 중복 제외)
        new_hof = 0
        try:
            stats = db.paper_stats_per_condition()
            for c in db.get_conditions(status="active"):
                st = stats.get(str(c["id"]), {})
                if st.get("sells", 0) >= 3 and st.get("win_rate", 0) >= 50:
                    try:
                        import json as _json
                        slots = _json.loads(c.get("slots_json") or "[]")
                        db.hof_upsert(str(c["id"]), f"{c['cond_no']}번 {c['cond_txt']}", slots,
                                      st["win_rate"], st.get("profit", 0) / max(1, st.get("loss", 0) or 1),
                                      st["win_rate"], st.get("net", 0) / 10000.0, passed=True)
                        new_hof += 1
                    except Exception:
                        pass
            # ★ 순위 관리: 상위 50개만 ranked=1, 나머지는 이력 보존 (삭제 없음)
            rk = db.hof_rank(limit=50)
        except Exception:
            rk = {"ranked": 0, "total": 0, "deduped": 0}
        self.log_line(f"🏆 명예의 전당: +{new_hof}건 (상위 {rk['ranked']}건 · "
                      f"이력 {rk['total']}건 · 중복 {rk['deduped']}건 제외)")
        out["hof"] = {"new": new_hof, "ranked": rk.get("ranked", 0),
                      "total": rk.get("total", 0), "deduped": rk.get("deduped", 0)}

        out["elapsed"] = round(time.time() - t0, 1)
        _progress(4, "✅ 완료")
        # 상태 저장
        try:
            os.makedirs("strategy", exist_ok=True)
            st = {}
            try:
                st = json.load(open(os.path.join("strategy", "control_state.json"), encoding="utf-8"))
            except Exception:
                pass
            st["last_round"] = out
            st["last_run_at"] = db.now_kst_iso()
            with open(os.path.join("strategy", "control_state.json"), "w", encoding="utf-8") as f:
                json.dump(st, f, ensure_ascii=False, indent=2)
        except Exception:
            pass
        return out

    def status(self):
        """총괄 상태 (UI)"""
        st = {}
        try:
            st = json.load(open(os.path.join("strategy", "control_state.json"), encoding="utf-8"))
        except Exception:
            pass
        return {
            "data": self.teams["data"].status(),
            "paper": self.teams["paper"].summary(),
            "hof_count": len(db.hof_list()),
            "last_run_at": st.get("last_run_at"),
            "last_round": st.get("last_round"),
        }


# 전역 총괄 (앱/자동 파일럿에서 사용)
CONTROL = ControlTeam()


def market_session(now=None):
    """세션 판별: intraday(장중) / after_hours(장마감) / holiday(휴장)"""
    from datetime import datetime
    from db import is_trading_day, next_trading_day
    if now is None:
        now = db.now_kst()
    if not is_trading_day(now.date()):
        nxt = next_trading_day(now.date())
        nxt_open = datetime(nxt.year, nxt.month, nxt.day, 9, 0, tzinfo=now.tzinfo)
        return {"mode": "holiday", "next_open": nxt_open}
    if 9 <= now.hour < 15 or (now.hour == 15 and now.minute <= 30):
        return {"mode": "intraday", "next_open": None}
    nxt = next_trading_day(now.date())
    nxt_open = datetime(nxt.year, nxt.month, nxt.day, 9, 0, tzinfo=now.tzinfo)
    return {"mode": "after_hours", "next_open": nxt_open}


def run_round(round_no=1, per_run=None, paper_n=10):
    """총괄 1라운드 (auto_pilot 호환)"""
    return CONTROL.round(per_run=per_run, paper_n=paper_n)


if __name__ == "__main__":
    db.init_db()
    logging.basicConfig(level=logging.INFO)
    res = CONTROL.round()
    print(json.dumps({k: v for k, v in res.items() if k != "log"}, ensure_ascii=False, indent=1, default=str))
