# StockBot Quant 자동매매 연계·운영 최종 모델

## 1. 최종 목표

최종 목표는 단순히 백테스트 수익률이 높은 전략을 찾는 것이 아니다.

```text
검증된 데이터
→ 비용 반영 전략
→ OOS/Monte Carlo/재검증
→ PAPER
→ Shadow
→ 위험관리
→ 주문
→ 체결·잔고 reconciliation
→ 다음 연구 피드백
```

이 과정을 반복하여 장기적으로 양의 기대값을 갖는 전략과 포트폴리오를 찾는 것이 목표다.

수익은 목표이지 보장된 결과가 아니다. 어떤 전략도 손실 가능성이 있으므로 수익보다 먼저 데이터 진위·위험·중복주문·kill switch를 검증한다.

---

## 2. 전체 프로세스

```text
[기존 원본 데이터 / 공식 현재 데이터]
                 |
                 v
[Data Truth + Quality Gate]
                 |
                 v
[Canonical Market DB]
                 |
                 v
[Research Engine]
  - 조건식/DSL
  - 후보 생성
  - 백테스트
  - random validation
  - walk-forward OOS
  - Monte Carlo
  - revalidation
  - 비용/슬리피지 민감도
                 |
                 v
[Strategy Registry]
  - CANDIDATE
  - REJECTED
  - SURVIVOR
  - SHADOW
  - RETIRED
                 |
                 v
[Signal Engine]
                 |
                 v
[Risk Gate]
  - universe
  - 포지션 한도
  - 종목별 한도
  - 일손실 한도
  - MDD gate
  - 중복 신호
  - stale data
  - kill switch
                 |
                 v
[OrderGateway]
  - OFF
  - DRY_RUN
  - PAPER
  - SHADOW
  - LIVE adapter 미설정
                 |
                 v
[Local Order Ledger / Reconciliation]
                 |
                 v
[보고서 + 다음 연구 피드백]
```

---

## 3. 일봉 관심종목 + 분봉 진입·보유·청산

운영의 중심은 다중 시간프레임 상태머신이다.

```text
일봉 filter 통과
→ WATCHLIST
→ 분봉 trigger 대기
→ ARMED
→ 분봉 매수 확정
→ ENTERED
→ 추세가 살아 있으면 HOLD_TRAILING
→ 목표 도달 시 일부 매도 + trailing
→ 손절/추세 붕괴/매도 확정 시 EXITED
```

일봉이 좋다는 이유만으로 즉시 매수하지 않는다. 일봉은 관심종목과 방향을 정하고, 실제 진입은 분봉의 확정된 신호가 담당한다.

```text
DailyContext
- 전일 종가 > SMA20
- 전일 RSI14 구간
- 전일 돌파 여부
- 데이터 진위 PASS

IntradayObservation
- 분봉 매수 신호
- 분봉 매도 신호
- 목표 도달
- 손절 이탈
- 분봉 추세 강도
```

분봉 매수 신호가 없으면 `WATCH/ARMED`로 기다린다. 매도 신호가 발생해도 일봉·분봉 추세가 강하면 전량 매도 대신 일부 매도 후 trailing을 적용할 수 있다. 손절·데이터 오류·일봉 조건 붕괴는 보유보다 청산을 우선한다.

정확한 저점과 고점은 실시간으로 알 수 없다. 실시간에서는 확정 신호 다음 체결만 사용하고, 저점 매수 근접도·고점 매도 근접도는 사후 성과지표로만 계산한다.

## 4. 이전 프로그램과의 연계

### 직접 import하지 않는 것

새 64비트 연구 코어가 기존 자동매매 파일을 직접 import하지 않는다.

```text
desktop_app.py
auto_pilot.py
paper_test.py
channels_auto.py
baseline_channel.py
ai_picks.py
live_trader.py
```

기존 파일을 한 프로세스에 섞으면 64비트 연구 코어와 기존 32비트 OpenAPI의 런타임 충돌, 숨은 주문 호출, 설정 혼합이 발생할 수 있다.

### 분리 프로세스 구조

```text
프로세스 A: StockBot Quant 연구 코어, 64비트
프로세스 B: Kiwoom Worker, 기존 32비트 OpenAPI 환경
프로세스 C: GUI/운영 화면
```

GUI는 하나지만 연구와 브로커 worker는 분리한다.

### 연계 방식

새 코어는 브로커 메서드를 직접 호출하지 않고 검증된 `OrderIntent`만 생성한다.

```text
SignalDecision
→ OrderIntent
→ OrderGateway
→ local order_intents ledger
→ Kiwoom Worker inbox
→ 기존 OpenAPI 실제 메서드
→ broker response
→ worker outbox
→ reconciliation
```

worker와 코어 사이에는 로컬 SQLite inbox/outbox 또는 명시적으로 검증된 IPC를 사용한다.

필수 필드:

```text
client_order_id
idempotency_key
symbol
side
quantity
limit_price
strategy_id
signal_time
data_timestamp
risk_snapshot
reason
```

기존 `trading.db`는 보존하며, 새 주문 원장은 별도 DB로 분리한다.

```text
trading.db                 기존 프로그램 보존
quant_platform.sqlite3     시장 데이터 canonical DB
quant_orders.sqlite3       OrderGateway 원장
paper_overnight.sqlite3    PAPER cycle/체결 원장
```

---

## 4. 이전 주문 코드 처리

기존 직접 주문 호출은 즉시 삭제하지 않는다. 먼저 감사하고 차단한다.

```text
place_order
_place_real_order
REAL_PAPER_ORDER
submit_order
send_order
```

처리 순서:

1. 호출 위치와 호출 그래프 기록
2. 기존 자동 루프 기본 비활성
3. 직접 broker 호출 차단
4. `OrderIntent` adapter 작성
5. OrderGateway로 통합
6. OFF에서 기능 테스트
7. DRY_RUN에서 외부 API 미호출 확인
8. PAPER에서 로컬 체결 확인
9. Shadow에서 실시간 비교
10. reconciliation 검증

실거래 adapter가 준비되지 않은 상태에서 LIVE를 선택하면 반드시 거부한다.

---

## 5. 운영 모드

### OFF

```text
신호 계산 가능
주문 의도 기록 가능
외부 주문 0
paper 체결 0
```

초기 기본값이다.

### DRY_RUN

```text
주문 의도 생성
위험 gate 실행
외부 주문 0
ledger에 simulated 기록
```

### PAPER

```text
실시간 또는 과거 봉 입력
next-open 또는 명시된 체결 규칙
수수료·슬리피지 반영
로컬 현금·포지션·손익
외부 주문 0
```

### SHADOW

```text
실제 시장 데이터 감시
실제 전략 신호 생성
가상 주문·가상 체결
실제 호가·가상 체결 차이 기록
외부 주문 0
```

### LIVE

현재 최종본에서는 비활성이다.

```text
공식 Kiwoom API 메서드 확인
실제 응답 schema 확인
worker 분리
계정·잔고 확인
reconciliation
kill switch
수동 승인
```

이 모든 조건을 별도 통과하기 전에는 연결하지 않는다.

---

## 6. 하루 운영 방식

### 장 시작 전

```text
1. 데이터 source freshness 확인
2. current universe 확인
3. stale/미래/가짜 데이터 차단
4. 전일 잔고·포지션 reconciliation
5. 전략 status 확인
6. MDD/일손실/종목 한도 확인
7. kill switch 상태 확인
```

### 장중

```text
1. 새 봉 또는 공식 quote 수신
2. 중복 timestamp 검사
3. signal 계산
4. risk gate
5. OFF/DRY_RUN/PAPER/SHADOW 처리
6. order ledger 기록
7. 체결과 잔고 비교
8. 오류 시 종목 격리·재시도
```

### 장 마감 후

```text
1. 미체결·체결·잔고 reconciliation
2. paper/shadow 결과 저장
3. 전략별 손익 계산
4. 슬리피지·수수료 차이 계산
5. 데이터 누락·오류 요약
6. 전략 유지/보류/폐기 판정
7. 다음 연구 후보 생성
```

### 반복 주기

```text
15분: 상태·신규 데이터·오류 heartbeat
장중: quote/bar 도착 시
장 마감: 전체 reconciliation 및 결과 리뷰
매일: 전략 재검증
매주: 아이디어·전략·모델 교차검수
```

---

## 7. 연구 결과가 최종적으로 만드는 것

현재 연구의 결과는 “무조건 매수할 종목”이 아니다.

종목별로 다음 판단을 만든다.

```text
BUY_CANDIDATE
SELL_CANDIDATE
HOLD
NO_TRADE
BLOCKED_DATA
REJECTED_STRATEGY
SHADOW_ONLY
```

각 판단에는 다음 증거가 따라간다.

조건 검색은 별도의 사람이 읽는 rule card로 함께 만든다.

```text
종가 > SMA20
RSI(14) 50~70
종가 > 직전 20일 고가
거래량 > 거래량 SMA20 × 1.5
다음 봉 시가 진입
```

그리고 다음 기간별 결과를 표시한다.

```text
1일·3일·5일·10일 후 평균 수익률
중간값·하위 25%·상위 25%
수익 발생 확률
목표 도달 확률
손절 도달 확률
목표 도달 중간 일수
학습 구간 표본
OOS 구간 표본
```

표본이 적으면 `INSUFFICIENT_SAMPLE`로 표시하며 몇 퍼센트 수익 모델이라고 선언하지 않는다.

```text
symbol
strategy_id
strategy_hash
signal_time
data_timestamp
entry/exit condition
backtest result
random validation
walk-forward OOS
Monte Carlo
revalidation
MDD
trade count
cost sensitivity
provenance status
review status
```

최종 포트폴리오 결과는 다음을 보여준다.

```text
총자산
현금
보유 종목
종목별 비중
누적 수익률
일간 수익률
실현손익
평가손익
최대낙폭
승률
profit factor
거래 횟수
수수료
슬리피지
거래 거부 수
데이터 오류 수
```

---

## 8. 수익 목표와 성과 판정

수익률만으로 전략을 통과시키지 않는다.

최소 확인 항목:

```text
net return after fees
max drawdown
profit factor
trade count
walk-forward positive rate
random positive rate
Monte Carlo loss probability
최근 구간 성과
슬리피지 민감도
수수료 민감도
종목·시장별 편중
```

전략은 다음 조건을 만족해야 다음 단계로 간다.

```text
CANDIDATE
→ 모든 데이터 gate 통과
→ OOS 통과
→ 비용 반영 후 양수 기대값
→ 충분한 거래 표본
→ PAPER 통과
→ SHADOW 통과
→ 수동 승인
```

현재 70봉 정도의 단일 종목 결과처럼 거래 수가 적거나 revalidation이 `INSUFFICIENT_DATA`이면 수익률이 높아도 채택하지 않는다.

---

## 9. 피드백 구조

매일 다음 결과를 다음 연구 입력으로 보낸다.

```text
예상 체결가 vs 실제 paper 체결가
신호 발생 시점
신호 지연
거부된 주문
손실 원인
MDD 변화
데이터 오류
전략별 성과 저하
아이디어별 미사용 상태
```

피드백은 다음 상태로 분류한다.

```text
DATA_PROBLEM
SIGNAL_PROBLEM
EXECUTION_PROBLEM
RISK_PROBLEM
MODEL_OVERFIT
INSUFFICIENT_SAMPLE
NO_ACTION
```

소크라테스식 질문은 자동 결론 대신 다음 결정을 유도한다.

```text
이 성과는 비용을 빼도 남는가?
최근 구간에도 유지되는가?
이 데이터는 실제 원천인가?
상장폐지 편향이 있는가?
이 아이디어는 실제 코드에 연결됐는가?
딥러닝이 기준모델보다 개선됐는가?
손실 한도를 초과하면 중단할 것인가?
```

---

## 10. 최종 안전 판정

```text
RESEARCH_READY
```

데이터·전략 연구 결과를 만들 수 있는 상태.

```text
PAPER_READY
```

외부 주문 없이 모의운용과 원장·reconciliation을 통과한 상태.

```text
SHADOW_READY
```

실시간 신호와 가상체결을 일정 기간 검증한 상태.

```text
ORDER_GATE_READY
```

기술적으로 worker·gateway·kill switch·reconciliation이 연결됐지만 LIVE는 별도 승인 상태.

```text
LIVE_ENABLED
```

현재 최종 목표에서 자동으로 도달하지 않는다. 공식 API와 사용자 승인 없이는 만들지 않는다.

---

## 11. 최종 결과 해석

이 시스템이 내는 가장 중요한 결과는 매일 다음 세 가지다.

```text
1. 오늘 실제로 검증된 전략과 종목
2. 데이터 또는 모델 때문에 거래하지 않은 종목
3. 수익성과 위험이 어제보다 좋아졌는지 나빠졌는지
```

수익이 나지 않는 날에도 `NO_TRADE`가 올바른 결과일 수 있다.

검증되지 않은 전략을 억지로 거래하는 것보다 거래하지 않는 것이 안전한 판단이다.

최종 성공 조건은 단일 백테스트 수익률이 아니라:

```text
비용 차감 후 양의 기대값
반복되는 OOS 성과
관리 가능한 MDD
PAPER/SHADOW 재현성
주문·잔고 원장 일치
오류를 숨기지 않는 운영
```

이다.
