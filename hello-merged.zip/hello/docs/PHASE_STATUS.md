# 개발 진행 상태

기준일: 2026-09-04 (KST)

## 2026-09-04 — quant_platform 오케스트레이터/GUI 통합

GitHub `hello` 저장소에 별도로 올라와 있던 quant_platform 배포판(오케스트레이터/GUI 중심 구성)을 이 워크스페이스에 흡수했습니다.

- `quant_platform/orchestrator.py`, `gui.py`, `order_gateway.py`, `audit.py`, `all_runner.py`, `research.py`, `error_center.py` 7개 파일 추가. 이미 두 배포판이 공유하던 핵심 모듈(`backtest`, `broker`, `conditions`, `data`, `domain.py`, `indicators.py`, `jobs.py`, `legacy.py`, `live_paper.py`, `paper.py`, `pipeline.py`, `strategies`, `survivors.py`, `validation`)은 바이트 단위로 동일해 충돌 없이 추가됨을 확인했습니다.
- `stock-bot/quant_platform_entry.py`, `stockbot_quant_gui_entry.py`, `run_stockbot_gui.bat`, `run_stockbot_pipeline.bat`, `build_stockbot_quant.bat` 진입점과 `quant_platform/GUI_GUIDE.md` 사용 안내를 추가했습니다.
- `quant_platform/api.py`는 기존 테스트가 통과하는 단순화된 버전을 그대로 유지했습니다(오류센터 REST 엔드포인트는 복원하지 않음). `error_center.py`는 `orchestrator`/`all_runner`/`gui`에서 직접 사용됩니다.
- `.gitignore`에 `**/errors/`를 추가해 오류센터가 만드는 런타임 오류 리포트가 커밋되지 않도록 했습니다.
- 검증: `python -m compileall -q stock-bot` 통과, 신규 7개 모듈 import 확인(GUI는 tkinter 필요 — 표준 배포 Python에는 포함), 기존 `python -m unittest discover -s tests -v` **15개 테스트 그대로 통과** (회귀 없음).
- 주문 관련 파일(`order_gateway.py`)은 기본 `OFF`이며 LIVE 브로커 어댑터 없이는 거부되는 안전장치를 그대로 유지했습니다.

## 이전 기록 (기준일: 2026-09-03)

### 이번 작업에서 완료한 항목

### 가져오기 및 범위 정리

- `hello` GitHub 저장소를 워크스페이스로 clone했습니다.
- 업로드된 ZIP을 `stock-bot/`으로 복원했습니다.
- 프로젝트 범위를 주식/퀀트 연구와 모의투자로 한정했습니다. 숏폼·영상 생성 기능은 제외했습니다.
- GitHub 공개 저장소에 올라가면 안 되는 `.env`, 계좌정보, SQLite DB, 수집 데이터, 생성 리포트를 ignore 처리했습니다. 개인 경로/실계좌 수치는 공개 문서에서 제거했습니다.

### 신규 코어 설치 Phase — 기존 환경과 분리

- 기존 자동매매 환경을 변경하지 않도록 `stock-bot/.venv`에 `requirements-platform.txt`를 설치했습니다.
- 설치된 신규 코어 의존성: FastAPI, Uvicorn, DuckDB, PyArrow, Polars, NumPy, Pandas, Requests, httpx2, pytest
- 가상환경에서 테스트 15개, 오프라인 demo, FastAPI TestClient 상태조회까지 확인했습니다.
- 기존 `data/stocks`의 8개 종목·총 560봉을 임시 canonical store로 읽기 전용 import했고 품질 이슈가 없음을 확인했습니다. 원본 DB는 변경하지 않았습니다.
- 새 코어의 기본 동작은 `DRY_RUN`/Paper이며, 키움 자격증명 없이 실행됩니다.

### Phase 1 — 실행 가능한 코어 기반

- 공통 KST 도메인 모델: `Bar`, `Quote`, `Timeframe`, `DataSource`
- 원천 봉 데이터 canonical SQLite 저장소: 중복 키 `symbol + timeframe + bar_time`
- Parquet export hook: `pyarrow`가 설치된 환경에서 사용
- 데이터 품질 보고서: 중복/시간순서/타임프레임 이슈 보고
- 키움 REST adapter 경계: 공식 TR 문서를 확인하지 않고 URL/필드를 추측하지 않도록 parser/transport 주입 방식으로 분리
- JSON/AST 조건식 DSL: AND/OR/NOT, 비교, BETWEEN, CROSS_ABOVE/CROSS_BELOW, canonical hash
- 백테스트 코어: 신호는 현재까지의 history만 받고 다음 봉 시가에서 체결
- 수수료/슬리피지/포지션 크기/거래별 손익/승률/PF/MDD 계산
- 설정 기본값은 `DRY_RUN=true`, 모의투자이며 비밀키는 repr에 노출되지 않음
- GitHub Actions CI 추가

### 현재 장애에 대한 수정

초기 화면의 `Gemini 호출 실패 ... read timeout` 문제를 다음처럼 보완했습니다.

- 연결/읽기 timeout 분리
- timeout/네트워크 오류 시 모델을 여러 개 연속 호출하지 않음
- 404일 때만 다음 모델 후보로 이동
- 429/5xx 쿨다운 적용
- AI 실패 시 빈 화면 대신 즉시 규칙 기반 폴백 표시
- `.env`와 `settings.env` 로딩 순서 수정
- AI 컨설턴트의 `short` 인자를 `brief`로 정리했습니다. 영상/숏폼 기능과는 관계없는 응답 길이 옵션입니다.

## 검증 결과

- `python -m unittest discover -s tests -v`: **15개 통과**
- `python -m compileall -q stock-bot`: **통과**
- 기존 `python backtest.py`: 실행은 되지만 샘플 DB에 전략이 없어 `전략이 없습니다 - bootstrap 필요`를 보고함
- 기존 `python system_doctor.py`: 실행 완료, 데이터 신선도/손절/미래누출 방지 등은 정상으로 보고했으나 검증 기록 부족과 미검증 조건식 매수 경고가 남음

## 운영 전 남은 필수 검증/보강

- 키움 공식 REST 문서에 맞춘 TR별 parser와 실제 응답 fixture 검증
- 실제 모의계좌 주문의 접수→부분체결→완전체결→거부/취소 상태를 ledger와 동기화
- 초단기 전략의 intrabar TP/SL, 호가 잔량, 거래량·가격 단위, 세금·시장별 비용 fixture 검증
- 기존 `engine.py`/`paper_test.py` 경로와 `quant_platform` 경로를 단일 실행 경로로 통합
- DuckDB/Parquet 대용량 query 최적화 및 장기 수집 성능 측정
- Supabase/S3/R2 상용화 계층

현재 새 코어의 오프라인 next-open Paper ledger와 기존 앱의 실시간/조건식 매매는
서로 다른 저장 스키마와 실행 경로를 사용합니다. legacy bridge는 기존 일봉을 새 코어로
읽어오는 연결이지 기존 주문 엔진을 완전히 교체한 것은 아닙니다.

## 다음 단계

1. 키움 API의 실제 응답을 비밀값을 제거한 fixture로 저장하고 adapter parser를 검증합니다.
2. 모의계좌 체결 통보를 받아 내부 장부를 확정하는 pending-order/chejan 동기화를 추가합니다.
3. 기존 앱의 조건식 신호·매도 가드와 새 DSL의 의미를 fixture로 대조합니다.
4. intrabar 체결·시장별 거래비용·유동성 제한을 추가한 뒤 OOS/WF gate를 재검증합니다.
5. 충분한 모의검증 후에만 실계좌 또는 외부 상용 API를 활성화합니다.

### Phase 2 일부 — 같은 지표/조건식 신호 기반

- 표준 라이브러리 기반 SMA/EMA/RSI/ATR/Bollinger/MACD 계산기를 추가했습니다.
- `DslSignal`이 현재 봉까지의 feature와 직전 feature만 사용해 BUY/SELL을 생성합니다.
- Walk-forward 분할기를 추가해 train/test 구간이 겹치지 않도록 했습니다.
- 새 기능은 15개 테스트와 전체 컴파일을 통과했습니다.

### Phase 11~13 오프라인/API 통합

- 기존 `data/stocks/{symbol}.db`를 새 canonical store로 옮기는 legacy bridge 추가
- 기존 데이터 기반 DSL 백테스트 CLI 추가
- 신규 데이터 재검증 결과(`KEEP/WARN/RETIRED`) 추가
- 동일 신호 계약을 사용하는 실시간 봉 단위 Paper session 추가
- 로컬 job queue와 선택적 FastAPI API 추가
- 실제 주문 endpoint는 안전을 위해 API에서 제외했습니다.
- FastAPI 설치 환경에서 상태조회, 조건식 검증, 전략 후보 생성, 백테스트 job 조회를 TestClient로 검증했습니다.

### Phase 3~10 오프라인 연결 검증

- 제한된 조합 폭발 방지 전략 생성기와 canonical hash를 연결했습니다.
- 랜덤 기간 검증, 거래 순서를 섞는 Monte Carlo, 보수적인 생존 전략 gate를 추가했습니다.
- 생존 전략만 PaperTrading ledger로 전달되도록 했습니다.
- `python -m quant_platform.cli demo --output data/quant_platform_demo.json`으로
  키움 자격증명 없이 수집→품질→지표/DSL→백테스트→랜덤 검증→WF→Monte Carlo→생존선별→모의투자 전체 흐름을 실행할 수 있습니다.
- 데모에서 Walk-forward가 약하면 생존 전략을 0개로 차단합니다. 수익률만 높은 합성 전략을 자동으로 모의투자에 보내지 않는 것이 의도된 동작입니다.
