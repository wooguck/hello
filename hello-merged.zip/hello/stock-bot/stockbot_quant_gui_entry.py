"""PyInstaller entry point for the visible StockBot Quant GUI."""
from quant_platform.gui import main

if __name__ == "__main__":
    raise SystemExit(main())
