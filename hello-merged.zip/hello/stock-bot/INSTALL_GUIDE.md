# 📦 설치 안내 (cmd 명령어 복사-붙여넣기용)

> 사용자 PC: Windows / Python 3.10.11 **32bit** / 프로젝트 폴더는 설치한 위치를 사용합니다.

---

## 0) cmd(명령 프롬프트) 열기

1. 키보드 **`Win` + `R`** 누르기
2. `cmd` 입력 후 **Enter**
3. 아래 명령 실행 (복사 → 우클릭 → 붙여넣기):

```
cd /d "프로젝트를_설치한_폴더"
```

> 매번 cmd를 새로 열면 **이 cd 명령부터 다시** 실행하세요.

---

## 1) Python이 32bit인지 확인 (실시간 모드에 필수)

```
python -c "import struct; print(struct.calcsize('P')*8)"
```

- **`32`** 출력 → ✅ 계속 진행
- **`64`** 출력 → ⚠️ 64bit입니다. **실시간(OpenAPI+) 모드는 32bit Python만** 되므로,
  python.org 에서 **Python 3.10 32bit** 설치 후 이 폴더에서 `py -3.10-32` 로 진행하거나
  지금은 **REST 모드만** 쓰세요. (REST 모드는 64bit에서도 정상 동작)

---

## 2) 기본 패키지 설치 (필수 - REST 모드)

```
pip install requests pillow matplotlib python-dotenv
```

성공 메시지: `Successfully installed ...` 확인

---

## 3) 실시간(OpenAPI+) 모드용 패키지 (선택 - 나중에 해도 됨)

```
pip install pykiwoom PyQt5
```

> - **32bit Python에서만** 설치/동작합니다.
> - 영웅문 프로그램도 설치 + 로그인돼 있어야 합니다 (키움증권 사이트에서 다운로드).
> - 설치 중 빌드 에러가 나면: `pip install pykiwoom --no-cache-dir` 재시도, 그래도 안 되면
>   **anaconda(32bit)** 환경 권장.

---

## 4) 설정 파일 만들기 (.env + settings.env 두 개)

> 설정이 두 파일로 분리되어 있습니다:
> - **`.env`** = 연결/인증만 (키움 키·계좌·실행모드·AI 키) — **시스템이 절대 안 건드림, 사람 손만**
> - **`settings.env`** = 일반 설정 전부 — 앱 ⚙️설정 탭에서 저장하면 여기로 자동 기록

1. **`env.example`** 파일을 **복사** → 이름을 **`.env`** 로 변경
   (탐색기: 파일 선택 → F2 → `.env` 입력. 안 보이면 보기→파일 확장명 체크)
2. **`settings.env.example`** 파일을 **복사** → 이름을 **`settings.env`** 로 변경
   (값은 그대로 시작해도 됩니다 - 나중에 앱 설정 탭에서 바꾸면 됨)
3. 메모장으로 `.env` 열어서 **아래 3~4줄만 수정**:

```
KIWOOM_APP_KEY=발급받은_앱키
KIWOOM_APP_SECRET=발급받은_시크릿키
KIWOOM_ACCOUNT_NO=모의계좌번호_숫자만
GEMINI_API_KEY=발급받은_제미나이_키
```

> - 키움 앱키: 키움증권 OpenAPI 사이트 → 모의투자 → App Key 발급
> - **DRY_RUN=true 유지** (기본) = 주문 안 나가고 안전. 실제 모의주문 원할 때만 false로.

---

## 5) 파일/설치 확인 (30초)

```
python verify_final.py
```

- **`🎉 최종 자체 검증 통과 - 26개 항목 전부 정상`** → ✅ 준비 완료

---

## 6) 실행

### A. 데이터 먼저 쌓기 (첫날 1~3시간, 그다음부터 매일 몇 분)

```
python collect_data.py --once
```

### B. 자동매매 앱 실행

```
python desktop_app.py
```

- 앱 켜지면 자동 파일럿 자동 시작 (장중 3분 주기 모의매매 + 장초반 1분 스캘핑)
- 장마감 후엔 데이터 수집 + 조건식 진화 + 일일 리포트 자동

### C. 실시간 모드 (OpenAPI+) — 3번까지 설치했을 때만

1. **영웅문 실행 + 로그인** (켜둔 채로)
2. 확인:

```
python live_trader.py --selftest
```

3. `⚡ 실시간(OpenAPI+) 구독` 출력되면:
   - 앱에서 **⚡ 실시간 모드** 버튼 클릭
   - 또는 단독 실행: `python live_trader.py --console`

---

## 7) 매일 사용 (데이터만 쌓고 싶을 때)

```
python collect_data.py --once    # 매일 1번 (장마감 후가 좋음)
```

또는 `데이터수집_켜두기.bat` 더블클릭 → 매일 장마감 후 자동 수집 (창 켜둠).

---

## ⚠️ 자주 나는 오류와 해결

| 오류 | 해결 |
|---|---|
| `pip is not recognized` | Python이 PATH에 없음 → Python 설치 시 "Add to PATH" 체크하고 재설치, cmd 닫고 다시 열기 |
| `ModuleNotFoundError: requests` | 2번 pip install 다시 실행 |
| `KIWOOM_APP_KEY 이 설정되지 않았습니다` | 4번 .env 만들기 확인 |
| `실시간 불가 (Windows+pykiwoom 필요)` | 3번 설치 + 32bit Python 확인 + 영웅문 로그인 |
| `Could not install packages ... pykiwoom` | `pip install pykiwoom --no-cache-dir` 또는 anaconda 32bit 사용 |

---

*궁금한 건 언제든 물어보세요. 에러 메시지 복사해서 주시면 바로 알려드릴게요.*
