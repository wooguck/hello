# StockBot 통합 실행기

## 목적

기존 StockBot을 삭제하거나 주문 루프와 새 Python 환경을 섞지 않고, 기존 자료와 새 quant_platform을 하나의 안전한 연구 파이프라인으로 연결합니다.

기본 모드는 `READ_ONLY_RESEARCH`이며 주문을 제출하지 않습니다.

## 기존 파일 보존

다음은 그대로 둡니다.

- `trading.db`
- `data/stocks/`
- `.env`
- `.venv/`
- `teams.py`, `auto_pilot.py`, `collect_data.py`, `desktop_app.py`

새 코어는 `data/quant_platform.sqlite3`에 canonical 데이터를 upsert합니다. 기존 canonical 행을 삭제하지 않으며, 원본과 일치하는 행만 해당 실행의 분석 대상에 사용합니다.

## 화면으로 한 번 실행

Windows PowerShell에서 프로젝트 루트에서 실행합니다.

```powershell
.\run_stockbot_gui.bat
```

GUI에서 종목코드, 현재 단계, 원본/canonical/분석 봉 수, 전략 후보·통과 수, 실행 로그와 오류 버튼을 확인할 수 있습니다.

- `선택 종목 실행`: 입력한 한 종목의 전체 연구
- `전체 종목 실행`: `data/stocks/*.db`와 canonical-only 종목 전체를 resumable batch로 처리
- 전체 실행은 `reports/all_run_state.json`을 저장해 중단 후 다음 실행에서 완료 종목을 건너뜁니다.
- `중지`: 현재 종목 처리가 끝난 뒤 안전하게 중지합니다.
- `전체 오류·안전 점검`: 기존 DB·자료·주문 코드 패턴·환경 안전장치를 감사하고 `reports/integration_audit.json`을 만듭니다. 기존 주문 호출부가 누락되지 않도록 `_place_real_order`, `place_order`, `submit_order`도 탐지합니다.
- 주문은 `quant_platform/order_gateway.py` 한 곳으로 모으는 구조입니다. 기본 `OFF`이며 DRY_RUN/PAPER도 외부 주문 API를 호출하지 않습니다. LIVE 브로커 어댑터는 미설정 상태에서 거부됩니다.

검은 콘솔 대신 창에서 진행상황을 표시합니다. EXE를 만든 뒤에는 `StockBotQuant.exe`를 더블클릭합니다.

개발용 콘솔 리포트가 필요할 때만 다음을 사용합니다.

```powershell
.\run_stockbot_pipeline.bat
```

다른 종목은 GUI의 종목코드 칸에 입력합니다.

실행 단계:

1. 환경과 경로 점검
2. `data/stocks/{symbol}.db` 원본 읽기
3. canonical DB에 idempotent upsert
4. source-aligned 분석 데이터 생성
5. canonical에 남아 있는 추가 행은 보존하고 별도 보고
6. 데이터 품질 검사
7. legacy `trading.db` universe의 수량과 갱신 시각 읽기
8. 전략 후보 생성
9. 백테스트·랜덤·Walk-forward·Monte Carlo·재검증
10. 생존 전략 여부 보고

리포트는 `reports/RUN-*.json`에 저장됩니다.

## 오류센터

실패하면 실행은 중단되며 주문은 제출되지 않습니다.

- `errors/E-*.json`: 오류 상세
- `errors/latest.json`: 가장 최근 오류
- `reports/RUN-*.json`: 마지막 성공 단계와 실행 정보

사용자가 전달할 값은 오류번호입니다.

```text
E-20260903-XXXXXXXX
```

오류 보고서에는 단계, 종목, 경로, 입력/출력 수, 예외 종류, traceback, 영향 범위가 들어가며 키·시크릿·계좌번호는 기록하지 않습니다.

## EXE 빌드

Windows에서 새 64비트 `.venv`가 준비된 뒤 다음을 실행합니다.

```powershell
.\build_stockbot_quant.bat
```

`StockBotQuant.exe`가 프로젝트 루트에 만들어집니다. 데이터·리포트·오류 폴더는 EXE 외부에 두어 기존 자료를 보존합니다.

## 안전 범위

현재 통합 실행기는 연구·검증 전용입니다.

```text
DRY_RUN=true
LIVE_TRADING_ENABLED=false
LIVE_ORDERS=false
orders_submitted=0
```

기존 주문 루프, 모의계좌 주문, 실계좌 주문은 이 실행기가 시작하지 않습니다. Shadow 비교와 모의투자는 연구 결과와 기존 전략 연결을 별도 검증한 뒤 다음 단계에서 추가합니다.

## 현재 지원 범위와 미지원 범위

지원:

- 기존 local `data/stocks` 자동 연결
- canonical DB 통합 및 source/canonical 대조
- 기존 `trading.db` universe 감사
- 새 DSL 후보·백테스트·검증
- JSON 리포트와 구조화된 오류센터

다음 단계에서 추가할 항목:

- 키움 공식 API 기반 current universe 자동 갱신
- 누락 데이터 재개형 다운로드
- 기존 전략과 새 전략 Shadow 비교
- 안전한 PAPER 연결

실거래는 검증 후에도 기본 비활성입니다.
