"""자격증명 없이 전체 연구 흐름을 실행하는 결정론적 데모 파이프라인.

실제 키움 호출 없이도 수집→품질→지표/DSL→백테스트→랜덤 검증→WF→Monte Carlo
→생존선별→모의투자까지 연결을 검증할 수 있습니다.
"""
from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Sequence

from .backtest import BacktestConfig, BacktestEngine
from .conditions import DslSignal
from .data import MarketDataStore
from .domain import Bar, DataSource
from .paper import PaperTradingEngine
from .strategies import CandidateStrategy, generate_candidates
from .survivors import StrategyEvaluation, score_evaluation, select_survivors
from .validation import monte_carlo_returns, validate_random_periods, walk_forward_splits


@dataclass(frozen=True)
class PipelineConfig:
    symbols: tuple[str, ...] = ("005930", "000660", "035420")
    bars_per_symbol: int = 180
    seed: int = 123
    candidate_limit: int = 24
    random_runs: int = 8
    monte_carlo_runs: int = 100
    output_path: Path | None = None
    database_path: Path = Path("data/quant_platform_demo.sqlite3")


def generate_demo_bars(symbol: str, count: int, *, seed: int = 123) -> list[Bar]:
    if count < 40:
        raise ValueError("demo dataset needs at least 40 bars")
    base = 50_000 + (sum(ord(c) for c in symbol) % 20_000)
    rows: list[Bar] = []
    previous = float(base)
    start = datetime(2020, 1, 2, 9)
    for index in range(count):
        wave = math.sin((index + seed) / 8) * 0.012
        drift = 0.0008 if (index // 30) % 2 == 0 else -0.0002
        open_price = max(1000.0, previous * (1 + wave * 0.25))
        close = max(1000.0, open_price * (1 + drift + wave))
        high = max(open_price, close) * 1.006
        low = min(open_price, close) * 0.994
        volume = 100_000 * (1 + (index % 7) * 0.15 + max(wave, 0) * 10)
        rows.append(Bar(symbol, "1d", start + timedelta(days=index), open_price, high, low, close, volume,
                        close * volume, DataSource.MOCK))
        previous = close
    return rows


def _sell_condition() -> dict:
    return {"indicator": "close", "comparison": "<", "value": {"indicator": "ema_20"}}


def _atoms() -> list[dict]:
    return [
        {"indicator": "close", "comparison": ">", "value": {"indicator": "sma_20"}},
        {"indicator": "rsi_14", "comparison": "BETWEEN", "value": [45, 75]},
        {"indicator": "volume", "comparison": ">", "value": {"indicator": "volume_sma_20", "multiplier": 1.1}},
        {"operator": "CROSS_ABOVE", "left": {"indicator": "close"}, "right": {"indicator": "ema_20"}},
    ]


def _factory(condition: dict):
    return lambda: DslSignal(buy=condition, sell=_sell_condition())


def _evaluate_candidate(candidate: CandidateStrategy, datasets: dict[str, Sequence[Bar]], config: PipelineConfig) -> StrategyEvaluation:
    results = []
    for rows in datasets.values():
        results.append(BacktestEngine(BacktestConfig(initial_capital=1_000_000, commission_pct=0.1, slippage_pct=0.05)).run(rows, _factory(candidate.condition)()))
    total_return = sum(result.total_return_pct for result in results) / len(results)
    trade_count = sum(result.trade_count for result in results)
    win_rate = sum(result.win_rate_pct * result.trade_count for result in results) / trade_count if trade_count else 0.0
    gains = sum(trade.pnl or 0 for result in results for trade in result.trades if trade.side == "SELL" and (trade.pnl or 0) > 0)
    losses = abs(sum(trade.pnl or 0 for result in results for trade in result.trades if trade.side == "SELL" and (trade.pnl or 0) < 0))
    pf = gains / losses if losses else (float("inf") if gains else 0.0)
    mdd = max((result.max_drawdown_pct for result in results), default=0.0)
    first = list(datasets.values())[0]
    random_result = validate_random_periods(first, _factory(candidate.condition), runs=config.random_runs,
                                            min_bars=40, max_bars=min(100, len(first)), seed=config.seed)
    splits = walk_forward_splits(first, train_size=90, test_size=30, step=30)
    wf_results = tuple(BacktestEngine(BacktestConfig(initial_capital=1_000_000, commission_pct=0.1, slippage_pct=0.05)).run(split.test, _factory(candidate.condition)()) for split in splits)
    wf_positive = sum(result.total_return_pct > 0 for result in wf_results) / len(wf_results) * 100 if wf_results else 0.0
    trade_returns = [trade.return_pct or 0 for result in results for trade in result.trades if trade.side == "SELL"]
    mc = monte_carlo_returns(trade_returns, runs=config.monte_carlo_runs, seed=config.seed)
    score = score_evaluation(total_return_pct=total_return, win_rate_pct=win_rate, profit_factor=pf,
                             max_drawdown_pct=mdd, trade_count=trade_count,
                             random_positive_rate_pct=random_result.positive_rate_pct,
                             walk_forward_positive_rate_pct=wf_positive,
                             monte_carlo_loss_probability_pct=mc["loss_probability_pct"])
    return StrategyEvaluation(candidate.strategy_id, candidate.strategy_hash, round(total_return, 4), round(win_rate, 4),
                              round(pf, 4) if math.isfinite(pf) else 999.0, round(mdd, 4), trade_count,
                              round(random_result.positive_rate_pct, 4), round(wf_positive, 4),
                              round(mc["loss_probability_pct"], 4), round(score, 4))


def run_demo(config: PipelineConfig | None = None) -> dict:
    config = config or PipelineConfig()
    datasets = {symbol: generate_demo_bars(symbol, config.bars_per_symbol, seed=config.seed) for symbol in config.symbols}
    config.database_path.parent.mkdir(parents=True, exist_ok=True)
    with MarketDataStore(config.database_path) as store:
        ingested = sum(store.upsert_bars(rows) for rows in datasets.values())
        quality = store.integrity_report()
        candidates = generate_candidates(_atoms(), max_conditions=3, max_combinations=config.candidate_limit, seed=config.seed)
        evaluations = tuple(_evaluate_candidate(candidate, datasets, config) for candidate in candidates)
        survivors = select_survivors(evaluations, min_score=45.0, max_drawdown_pct=35.0, limit=5)
        paper = None
        if survivors:
            chosen = survivors[0]
            condition = next(candidate.condition for candidate in candidates if candidate.strategy_id == chosen.strategy_id)
            paper_result = PaperTradingEngine(BacktestConfig(initial_capital=1_000_000, commission_pct=0.1, slippage_pct=0.05)).run(
                list(datasets[config.symbols[0]][-60:]), _factory(condition)())
            paper = {"final_equity": paper_result.final_equity, "realized_pnl": paper_result.realized_pnl,
                     "orders": [asdict(order) for order in paper_result.orders], "strategy_id": chosen.strategy_id}
        report = {
            "stages": ["ingest", "quality", "indicators_dsl", "backtest", "random_validation", "walk_forward", "monte_carlo", "survivor_selection", "paper_trading"],
            "ingested_bars": ingested,
            "quality": {"checked": quality.checked, "ok": quality.ok, "issues": [asdict(issue) for issue in quality.issues]},
            "coverage": store.coverage(),
            "candidate_count": len(candidates),
            "evaluations": [asdict(item) for item in evaluations],
            "survivors": [asdict(item) for item in survivors],
            "paper": paper,
        }
    if config.output_path:
        config.output_path.parent.mkdir(parents=True, exist_ok=True)
        config.output_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report
