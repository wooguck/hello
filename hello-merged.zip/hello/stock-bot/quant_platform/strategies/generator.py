"""조건식 조합을 제한적으로 생성하는 전략 후보 엔진."""
from __future__ import annotations

import itertools
import random
from dataclasses import dataclass
from typing import Mapping, Sequence

from ..conditions.dsl import canonicalize, strategy_hash


@dataclass(frozen=True)
class CandidateStrategy:
    strategy_id: str
    condition: dict
    strategy_hash: str
    condition_count: int


def generate_candidates(atoms: Sequence[Mapping], *, max_conditions: int = 3,
                         max_combinations: int = 100, seed: int = 123) -> tuple[CandidateStrategy, ...]:
    if max_conditions <= 0 or max_combinations <= 0:
        raise ValueError("max_conditions and max_combinations must be positive")
    unique_atoms: dict[str, dict] = {}
    for atom in atoms:
        normalized = canonicalize(atom)
        unique_atoms[strategy_hash(normalized)] = normalized
    pool = list(unique_atoms.values())
    all_conditions: list[dict] = []
    for size in range(1, min(max_conditions, len(pool)) + 1):
        for group in itertools.combinations(pool, size):
            all_conditions.append(group[0] if size == 1 else {"operator": "AND", "conditions": list(group)})
    rng = random.Random(seed)
    if len(all_conditions) > max_combinations:
        all_conditions = rng.sample(all_conditions, max_combinations)
    result: list[CandidateStrategy] = []
    seen: set[str] = set()
    for condition in all_conditions:
        digest = strategy_hash(condition)
        if digest in seen:
            continue
        seen.add(digest)
        count = len(condition.get("conditions", [condition])) if condition.get("operator") == "AND" else 1
        result.append(CandidateStrategy(f"S-{digest[:12]}", canonicalize(condition), digest, count))
    return tuple(result)
