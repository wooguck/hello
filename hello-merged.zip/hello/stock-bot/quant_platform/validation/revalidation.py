"""신규 데이터 유입 시 생존 전략을 재검증하는 gate."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence

from ..backtest import BacktestConfig, BacktestEngine
from ..conditions import DslSignal
from ..domain import Bar


@dataclass(frozen=True)
class RevalidationResult:
    strategy_id: str
    baseline_return_pct: float
    recent_return_pct: float
    degradation_pct: float
    status: str


def revalidate_strategy(strategy_id: str, condition: Mapping, bars: Sequence[Bar], *, baseline_bars: int = 90,
                        recent_bars: int = 30, warn_degradation_pct: float = 10.0,
                        retire_degradation_pct: float = 25.0) -> RevalidationResult:
    rows = tuple(bars)
    if len(rows) < baseline_bars + recent_bars:
        raise ValueError("not enough bars for baseline and recent revalidation")
    config = BacktestConfig(initial_capital=1_000_000, commission_pct=0.1, slippage_pct=0.05)
    engine = BacktestEngine(config)
    sell = {"indicator": "close", "comparison": "<", "value": {"indicator": "ema_20"}}
    baseline = engine.run(rows[-(baseline_bars + recent_bars):-recent_bars], DslSignal(buy=condition, sell=sell))
    recent = engine.run(rows[-recent_bars:], DslSignal(buy=condition, sell=sell))
    degradation = baseline.total_return_pct - recent.total_return_pct
    if degradation >= retire_degradation_pct:
        status = "RETIRED"
    elif degradation >= warn_degradation_pct:
        status = "WARN"
    else:
        status = "KEEP"
    return RevalidationResult(strategy_id, baseline.total_return_pct, recent.total_return_pct, degradation, status)
