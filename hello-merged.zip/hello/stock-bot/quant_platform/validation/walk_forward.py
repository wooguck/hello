"""시간 순서를 보존하는 Walk-forward 분할."""
from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass

from ..domain import Bar


@dataclass(frozen=True)
class WalkForwardSplit:
    number: int
    train: tuple[Bar, ...]
    test: tuple[Bar, ...]


def walk_forward_splits(bars: Sequence[Bar], *, train_size: int, test_size: int, step: int | None = None) -> tuple[WalkForwardSplit, ...]:
    if train_size <= 0 or test_size <= 0:
        raise ValueError("train_size and test_size must be positive")
    step = test_size if step is None else step
    if step <= 0:
        raise ValueError("step must be positive")
    rows = tuple(bars)
    splits: list[WalkForwardSplit] = []
    start = 0
    number = 1
    while start + train_size + test_size <= len(rows):
        train_end = start + train_size
        test_end = train_end + test_size
        splits.append(WalkForwardSplit(number, rows[start:train_end], rows[train_end:test_end]))
        start += step
        number += 1
    return tuple(splits)


def run_walk_forward(bars: Sequence[Bar], evaluator: Callable[[Sequence[Bar], Sequence[Bar], int], object], *, train_size: int, test_size: int, step: int | None = None) -> tuple[object, ...]:
    """evaluator(train, test, split_number)를 호출합니다.

    evaluator 내부에서 train으로 전략/파라미터를 결정하고 test를 단 한 번 평가해야
    하며, 이 함수는 train/test 경계가 겹치지 않는 것만 보장합니다.
    """
    return tuple(evaluator(split.train, split.test, split.number)
                 for split in walk_forward_splits(bars, train_size=train_size, test_size=test_size, step=step))
