"""랜덤 기간 검증. 난수는 seed를 받아 재현 가능해야 합니다."""
from __future__ import annotations

import random
from dataclasses import dataclass
from statistics import median
from typing import Callable, Sequence

from ..backtest import BacktestConfig, BacktestEngine, BacktestResult
from ..domain import Bar


@dataclass(frozen=True)
class RandomValidationResult:
    runs: int
    positive_rate_pct: float
    median_return_pct: float
    worst_return_pct: float
    best_return_pct: float
    max_drawdown_pct: float
    results: tuple[BacktestResult, ...]


def random_windows(bars: Sequence[Bar], *, runs: int, min_bars: int, max_bars: int, seed: int = 123) -> tuple[tuple[Bar, ...], ...]:
    rows = tuple(bars)
    if runs <= 0 or min_bars < 2 or max_bars < min_bars:
        raise ValueError("invalid random window configuration")
    if len(rows) < min_bars:
        return tuple()
    max_bars = min(max_bars, len(rows))
    rng = random.Random(seed)
    output = []
    for _ in range(runs):
        size = rng.randint(min_bars, max_bars)
        start = rng.randint(0, len(rows) - size)
        output.append(rows[start:start + size])
    return tuple(output)


def validate_random_periods(bars: Sequence[Bar], signal_factory: Callable[[], Callable], *, runs: int = 30,
                            min_bars: int = 40, max_bars: int = 120, seed: int = 123,
                            config: BacktestConfig | None = None) -> RandomValidationResult:
    windows = random_windows(bars, runs=runs, min_bars=min_bars, max_bars=max_bars, seed=seed)
    engine = BacktestEngine(config)
    results = tuple(engine.run(window, signal_factory()) for window in windows)
    returns = [result.total_return_pct for result in results]
    return RandomValidationResult(
        runs=len(results),
        positive_rate_pct=(sum(value > 0 for value in returns) / len(returns) * 100) if returns else 0.0,
        median_return_pct=median(returns) if returns else 0.0,
        worst_return_pct=min(returns) if returns else 0.0,
        best_return_pct=max(returns) if returns else 0.0,
        max_drawdown_pct=max((result.max_drawdown_pct for result in results), default=0.0),
        results=results,
    )
