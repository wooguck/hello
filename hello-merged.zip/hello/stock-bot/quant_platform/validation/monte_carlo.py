"""거래 순서를 섞는 간단한 Monte Carlo 안정성 검사."""
from __future__ import annotations

import random
from statistics import median
from typing import Sequence


def monte_carlo_returns(returns: Sequence[float], *, runs: int = 200, seed: int = 123) -> dict:
    if runs <= 0:
        raise ValueError("runs must be positive")
    values = [float(value) for value in returns]
    if not values:
        return {"runs": 0, "median_final_pct": 0.0, "p05_final_pct": 0.0,
                "loss_probability_pct": 0.0, "median_mdd_pct": 0.0}
    rng = random.Random(seed)
    finals: list[float] = []
    mdds: list[float] = []
    for _ in range(runs):
        shuffled = list(values)
        rng.shuffle(shuffled)
        equity = 100.0
        peak = equity
        mdd = 0.0
        for ret in shuffled:
            equity *= 1 + ret / 100
            peak = max(peak, equity)
            mdd = max(mdd, (peak - equity) / peak * 100 if peak else 0.0)
        finals.append((equity - 100) if equity else -100.0)
        mdds.append(mdd)
    ordered = sorted(finals)
    p05 = ordered[max(0, int(len(ordered) * 0.05) - 1)]
    return {
        "runs": runs,
        "median_final_pct": median(finals),
        "p05_final_pct": p05,
        "loss_probability_pct": sum(value < 0 for value in finals) / len(finals) * 100,
        "median_mdd_pct": median(mdds),
    }
