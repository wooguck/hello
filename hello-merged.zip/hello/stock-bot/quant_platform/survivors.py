"""수익률 하나가 아닌 안정성 지표를 함께 보는 생존 전략 gate."""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Mapping, Sequence


@dataclass(frozen=True)
class StrategyEvaluation:
    strategy_id: str
    strategy_hash: str
    total_return_pct: float
    win_rate_pct: float
    profit_factor: float
    max_drawdown_pct: float
    trade_count: int
    random_positive_rate_pct: float
    walk_forward_positive_rate_pct: float
    monte_carlo_loss_probability_pct: float
    score: float
    status: str = "CANDIDATE"


def score_evaluation(*, total_return_pct: float, win_rate_pct: float, profit_factor: float,
                     max_drawdown_pct: float, trade_count: int, random_positive_rate_pct: float,
                     walk_forward_positive_rate_pct: float, monte_carlo_loss_probability_pct: float) -> float:
    """설명 가능한 보수적 점수(0~100). 자동 매매를 승인하는 수익 보장식이 아닙니다."""
    pf_component = min(max(profit_factor, 0.0), 3.0) / 3.0 * 20
    return_component = max(min(total_return_pct, 20.0), -20.0) / 20.0 * 20 + 20
    stability = random_positive_rate_pct * 0.15 + walk_forward_positive_rate_pct * 0.15
    risk_penalty = min(max(max_drawdown_pct, 0.0), 30.0) * 0.45
    mc_penalty = min(max(monte_carlo_loss_probability_pct, 0.0), 100.0) * 0.08
    sample_bonus = min(trade_count, 30) / 30 * 5
    return max(0.0, min(100.0, return_component + win_rate_pct * 0.10 + pf_component + stability + sample_bonus - risk_penalty - mc_penalty))


def select_survivors(evaluations: Sequence[StrategyEvaluation], *, min_score: float = 55.0,
                     max_drawdown_pct: float = 25.0, min_trades: int = 5,
                     min_random_positive_rate_pct: float = 60.0,
                     min_walk_forward_positive_rate_pct: float = 50.0,
                     max_monte_carlo_loss_probability_pct: float = 50.0,
                     limit: int = 10) -> tuple[StrategyEvaluation, ...]:
    """검증을 모두 통과한 전략만 SURVIVOR로 승격합니다.

    점수 상위라는 이유만으로 생존시키지 않습니다. 특히 OOS/WF가 약한 합성
    전략이 모의투자로 넘어가지 않도록 기본 gate를 보수적으로 둡니다.
    """
    ranked = sorted(evaluations, key=lambda item: (-item.score, item.strategy_id))
    output = []
    for item in ranked:
        passed = (
            item.score >= min_score
            and item.max_drawdown_pct <= max_drawdown_pct
            and item.trade_count >= min_trades
            and item.random_positive_rate_pct >= min_random_positive_rate_pct
            and item.walk_forward_positive_rate_pct >= min_walk_forward_positive_rate_pct
            and item.monte_carlo_loss_probability_pct <= max_monte_carlo_loss_probability_pct
        )
        output.append(replace(item, status="SURVIVOR" if passed else "REJECTED"))
    return tuple(item for item in output if item.status == "SURVIVOR")[:limit]
