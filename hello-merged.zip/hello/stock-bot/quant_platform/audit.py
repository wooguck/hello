"""기존 StockBot과 새 코어의 통합 전 자동 감사."""
from __future__ import annotations

import json
import os
import re
import sqlite3
import sys
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class AuditItem:
    code: str
    severity: str  # PASS | WARN | FAIL
    title: str
    detail: str
    path: str | None = None
    action: str = ""

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _check_db(path: Path, table: str) -> tuple[bool, str]:
    if not path.exists():
        return False, "파일이 없습니다"
    try:
        with sqlite3.connect(path) as db:
            exists = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
        return bool(exists), "정상" if exists else f"{table} 테이블이 없습니다"
    except sqlite3.Error as exc:
        return False, str(exc)


def run_audit(root: str | Path = ".") -> dict[str, Any]:
    root = Path(root).resolve()
    items: list[AuditItem] = []

    def add(code: str, severity: str, title: str, detail: str, path: Path | None = None, action: str = "") -> None:
        items.append(AuditItem(code, severity, title, detail, str(path.resolve()) if path else None, action))

    python_path = Path(sys.executable).resolve()
    bundled = bool(getattr(sys, "frozen", False)) or python_path.name.lower().endswith("stockbotquant.exe")
    python_ok = bundled or ".venv" in str(python_path)
    python_detail = "StockBotQuant.exe bundled runtime" if bundled else str(python_path)
    add("ENV_PYTHON", "PASS" if python_ok else "WARN", "Python 환경", python_detail,
        action="개발 실행은 프로젝트의 .venv\\Scripts\\python.exe, 배포 실행은 StockBotQuant.exe를 사용하세요.")

    old_db = root / "trading.db"
    ok, detail = _check_db(old_db, "universe")
    add("LEGACY_DB", "PASS" if ok else "WARN", "기존 trading.db", detail, old_db,
        "기존 프로그램을 먼저 실행하지 말고 DB 백업 후 확인하세요.")

    source_dir = root / "data" / "stocks"
    files = sorted(path for path in source_dir.glob("*.db") if path.stem.isdigit() and len(path.stem) == 6) if source_dir.exists() else []
    if files:
        add("LEGACY_STOCK_FILES", "PASS", "기존 종목 데이터", f"{len(files)}개 파일 확인", source_dir)
    else:
        add("LEGACY_STOCK_FILES", "FAIL", "기존 종목 데이터", "data\\stocks\\*.db가 없습니다", source_dir,
            "원본 데이터 경로를 확인하세요.")

    canonical = root / "data" / "quant_platform.sqlite3"
    if canonical.exists():
        try:
            with sqlite3.connect(canonical) as db:
                count = db.execute("SELECT COUNT(*) FROM bars").fetchone()[0]
                symbols = db.execute("SELECT COUNT(DISTINCT symbol) FROM bars").fetchone()[0]
                daily = db.execute("SELECT COUNT(*) FROM bars WHERE timeframe='1d'").fetchone()[0]
            add("CANONICAL_DB", "PASS", "새 canonical DB",
                f"symbols {symbols:,}개 · bars {count:,}개 · daily {daily:,}개", canonical)
        except sqlite3.Error as exc:
            add("CANONICAL_DB", "FAIL", "새 canonical DB", str(exc), canonical,
                "canonical DB를 다른 프로세스가 잠그고 있는지 확인하세요.")
    else:
        add("CANONICAL_DB", "WARN", "새 canonical DB", "아직 생성되지 않았습니다", canonical,
            "통합 실행 시 자동 생성됩니다.")

    env_path = root / ".env"
    if not env_path.exists():
        add("ENV_FILE", "WARN", ".env 파일", "없음 - 키움/AI 원격 기능은 비활성 상태로만 실행됩니다", env_path)
    else:
        try:
            text = env_path.read_text(encoding="utf-8", errors="replace")
            dry = re.search(r"^DRY_RUN\s*=\s*(.*)$", text, re.MULTILINE | re.IGNORECASE)
            live = re.search(r"^(?:LIVE_ORDERS|ALLOW_LIVE_TRADING)\s*=\s*(.*)$", text, re.MULTILINE | re.IGNORECASE)
            dry_value = dry.group(1).strip().lower() if dry else "missing"
            live_value = live.group(1).strip().lower() if live else "missing"
            safe = dry_value in {"true", "1", "yes", "on"} and live_value not in {"true", "1", "yes", "on"}
            add("ENV_SAFETY", "PASS" if safe else "FAIL", ".env 주문 안전장치",
                f"DRY_RUN={dry_value}, LIVE/ALLOW={live_value}", env_path,
                "검증 전 DRY_RUN=true와 LIVE_ORDERS=false를 유지하세요.")
        except OSError as exc:
            add("ENV_FILE", "FAIL", ".env 파일", str(exc), env_path)

    old_universe = root / "universe.py"
    if old_universe.exists():
        text = old_universe.read_text(encoding="utf-8", errors="replace")
        unsafe_fallback = "GITHUB_URL" in text and "refresh_universe_from_github" in text
        add("UNIVERSE_FALLBACK", "WARN" if unsafe_fallback else "PASS", "current/historical universe 분리",
            "기존 universe.py에 historical GitHub fallback이 존재합니다" if unsafe_fallback else "위험한 fallback 패턴 없음",
            old_universe, "GitHub historical 목록을 current 실시간 목록으로 사용하지 마세요.")

    order_files = ("paper_test.py", "channels_auto.py", "baseline_channel.py", "ai_picks.py", "engine.py", "live_trader.py")
    order_patterns = ("place_order", "_place_real_order", "REAL_PAPER_ORDER", "submit_order", "send_order")
    for filename in order_files:
        path = root / filename
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        matched = [pattern for pattern in order_patterns if pattern in text]
        direct_order = bool(matched)
        add("LEGACY_ORDER_PATH", "WARN" if direct_order else "PASS", f"기존 주문 경로: {filename}",
            f"주문 관련 패턴 발견: {', '.join(matched)}" if direct_order else "직접 주문 패턴 없음",
            path, "주문 게이트웨이 연결 전 기존 자동 라운드를 실행하지 마세요.")

    add("NEW_ORDER_GATE", "PASS", "새 주문 게이트웨이", "기본 OFF·DRY_RUN/PAPER 외부주문 차단",
        root / "quant_platform" / "order_gateway.py")
    add("REMOTE_DOWNLOAD", "WARN", "원격 데이터 다운로드", "공식 현재 universe/API 연결 전까지 자동 원격 다운로드는 비활성",
        action="기존 로컬 data\\stocks를 사용하고, 키움 API는 문서·실응답 확인 후 연결하세요.")

    counts = {severity: sum(item.severity == severity for item in items) for severity in ("PASS", "WARN", "FAIL")}
    return {
        "audit_at": datetime.now(timezone.utc).astimezone().isoformat(),
        "root": str(root),
        "counts": counts,
        "safe_to_order": False,
        "items": [item.as_dict() for item in items],
    }


def write_audit(root: str | Path = ".", output: str | Path = "reports/integration_audit.json") -> Path:
    report = run_audit(root)
    destination = Path(root) / output
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return destination
