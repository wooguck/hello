"""확장형 퀀트 연구 플랫폼의 공통 도메인/저장/조건식 모듈.

기존 데스크톱 앱을 한 번에 교체하지 않고, 검증 가능한 코어를 먼저 추가해
백테스트와 모의투자에서 같은 데이터 모델과 조건식을 재사용하기 위한 패키지입니다.
"""

from .domain import Bar, DataSource, Timeframe
from .indicators import feature_rows

__all__ = ["Bar", "DataSource", "Timeframe", "feature_rows"]
