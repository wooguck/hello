"""새 통합 실행기의 구조화된 오류 센터.

오류를 숨기지 않고 실행번호·단계·입력 경로·영향 범위와 함께 JSON으로 남깁니다.
민감한 환경변수 값은 기록하지 않습니다.
"""
from __future__ import annotations

import json
import re
import traceback
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


_SECRET_KEY = re.compile(r"(key|secret|token|password|account|authorization)", re.IGNORECASE)


def _safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): "[REDACTED]" if _SECRET_KEY.search(str(k)) else _safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_safe(item) for item in value]
    if isinstance(value, Path):
        return str(value)
    return value


def _now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat()


@dataclass(frozen=True)
class ErrorRecord:
    error_id: str
    run_id: str
    occurred_at: str
    stage: str
    error_type: str
    message: str
    traceback: str
    context: dict[str, Any]
    recoverable: bool
    recommended_action: str
    impact: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class ErrorCenter:
    def __init__(self, root: str | Path = "errors"):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def record(self, run_id: str, stage: str, exc: BaseException, *, context: dict[str, Any] | None = None,
               recoverable: bool = False, recommended_action: str = "오류 보고서와 traceback을 확인하세요.",
               impact: str = "현재 실행을 중단했습니다.") -> ErrorRecord:
        record = ErrorRecord(
            error_id=f"E-{datetime.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:8].upper()}",
            run_id=run_id,
            occurred_at=_now(),
            stage=stage,
            error_type=type(exc).__name__,
            message=str(exc),
            traceback="".join(traceback.format_exception(type(exc), exc, exc.__traceback__)),
            context=_safe(context or {}),
            recoverable=recoverable,
            recommended_action=recommended_action,
            impact=impact,
        )
        destination = self.root / f"{record.error_id}.json"
        destination.write_text(json.dumps(record.as_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
        (self.root / "latest.json").write_text(json.dumps(record.as_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
        return record

    def list_recent(self, limit: int = 20) -> list[dict[str, Any]]:
        files = sorted((p for p in self.root.glob("E-*.json") if p.name != "latest.json"), reverse=True)[:limit]
        output = []
        for path in files:
            try:
                output.append(json.loads(path.read_text(encoding="utf-8")))
            except (OSError, json.JSONDecodeError):
                continue
        return output
