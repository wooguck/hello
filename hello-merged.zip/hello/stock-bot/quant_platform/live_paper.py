"""봉 단위 입력으로 동작하는 실시간 모의투자 세션.

백테스트와 같은 DslSignal, next-open 체결, 수수료/슬리피지를 사용합니다.
실제 키움 주문 API를 호출하지 않으므로 안전한 통합 테스트용입니다.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from .backtest import BacktestConfig
from .domain import Bar
from .paper import PaperAccount, PaperOrder


@dataclass(frozen=True)
class SessionSnapshot:
    symbol: str | None
    timestamp: str | None
    cash: float
    quantity: int
    average_price: float
    realized_pnl: float
    pending_action: str | None


class LivePaperSession:
    def __init__(self, signal, config: BacktestConfig | None = None):
        self.signal = signal
        self.config = config or BacktestConfig()
        self.account = PaperAccount(self.config.initial_capital)
        self.bars: list[Bar] = []
        self.orders: list[PaperOrder] = []
        self.pending: tuple[str, int] | None = None

    def on_bar(self, bar: Bar) -> tuple[PaperOrder, ...]:
        # 실시간 입력은 단일 종목·단일 주기·엄격한 시간순이어야
        # next-open 체결과 지표 warm-up의 의미가 깨지지 않습니다.
        if self.bars:
            previous = self.bars[-1]
            if bar.symbol != previous.symbol:
                raise ValueError("live paper session accepts one symbol at a time")
            if bar.timeframe != previous.timeframe:
                raise ValueError("live paper session timeframe cannot change")
            if bar.timestamp <= previous.timestamp:
                raise ValueError("live bars must arrive in strictly increasing order")
        self.bars.append(bar)
        new_orders: list[PaperOrder] = []
        index = len(self.bars) - 1
        if self.pending and self.pending[1] < index:
            action, _signal_index = self.pending
            self.pending = None
            if action == "BUY" and self.account.quantity == 0:
                price = bar.open * (1 + self.config.slippage_pct / 100)
                quantity = int((self.account.cash * self.config.position_size_pct / 100) /
                               (price * (1 + self.config.commission_pct / 100)))
                if quantity > 0:
                    self.account.buy(price, quantity, self.config.commission_pct)
                    new_orders.append(PaperOrder("BUY", bar.symbol, quantity, price, bar.timestamp.isoformat()))
            elif action == "SELL" and self.account.quantity > 0:
                price = bar.open * (1 - self.config.slippage_pct / 100)
                quantity = self.account.quantity
                self.account.sell(price, quantity, self.config.commission_pct)
                new_orders.append(PaperOrder("SELL", bar.symbol, quantity, price, bar.timestamp.isoformat()))
        action = self.signal(index, tuple(self.bars))
        if self.pending is None:
            normalized = action.upper() if isinstance(action, str) else None
            if normalized == "BUY" and self.account.quantity == 0 and index + 1 >= 1:
                self.pending = ("BUY", index)
            elif normalized == "SELL" and self.account.quantity > 0:
                self.pending = ("SELL", index)
        self.orders.extend(new_orders)
        return tuple(new_orders)

    def snapshot(self) -> SessionSnapshot:
        last = self.bars[-1] if self.bars else None
        return SessionSnapshot(last.symbol if last else None, last.timestamp.isoformat() if last else None,
                               self.account.cash, self.account.quantity, self.account.average_price,
                               self.account.realized_pnl, self.pending[0] if self.pending else None)
