"""거래소/브로커 인터페이스.

전략 엔진은 키움 SDK의 세부 필드나 HTTP 구현을 직접 알지 않습니다.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Protocol, Sequence

from ..domain import Bar, Quote


class BrokerError(RuntimeError):
    """브로커 공통 오류."""


class OrderSide(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class OrderStatus(str, Enum):
    QUEUED = "QUEUED"
    FILLED = "FILLED"
    PARTIAL_FILLED = "PARTIAL_FILLED"
    REJECTED = "REJECTED"
    CANCELLED = "CANCELLED"


@dataclass(frozen=True)
class OrderRequest:
    symbol: str
    side: OrderSide
    quantity: int
    limit_price: float | None = None
    client_order_id: str | None = None

    def __post_init__(self) -> None:
        if not str(self.symbol).strip():
            raise ValueError("symbol is required")
        if self.quantity <= 0:
            raise ValueError("quantity must be positive")
        if self.limit_price is not None and self.limit_price <= 0:
            raise ValueError("limit_price must be positive")


class MarketDataBroker(Protocol):
    def get_bars(self, symbol: str, timeframe: str, *, start: datetime | None = None, end: datetime | None = None) -> Sequence[Bar]: ...
    def get_quote(self, symbol: str) -> Quote: ...
    def submit_order(self, order: OrderRequest) -> str: ...
    def cancel_order(self, order_id: str) -> bool: ...
