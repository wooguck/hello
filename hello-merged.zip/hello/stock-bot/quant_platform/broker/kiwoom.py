"""키움 REST adapter 경계.

키움 TR별 URL/필드명은 공식 문서 버전에 따라 달라질 수 있으므로 이 모듈은
임의의 endpoint나 응답 필드를 추측하지 않습니다. 기존 kiwoom_client.py 또는
공식 SDK를 KiwoomTransport로 주입해 사용합니다.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Mapping, Protocol, Sequence

from ..domain import Bar, Quote
from .base import BrokerError, MarketDataBroker, OrderRequest


class KiwoomTransport(Protocol):
    def request(self, *, api_id: str, endpoint: str, payload: Mapping[str, Any]) -> Mapping[str, Any]: ...


class KiwoomRestAdapter(MarketDataBroker):
    """TR parser를 외부에서 주입하는 안전한 adapter."""

    def __init__(self, transport: KiwoomTransport):
        self.transport = transport
        self._bar_parser = None
        self._quote_parser = None
        self._order_parser = None

    def register_bar_parser(self, parser) -> None:
        self._bar_parser = parser

    def register_quote_parser(self, parser) -> None:
        self._quote_parser = parser

    def register_order_parser(self, parser) -> None:
        self._order_parser = parser

    def get_bars(self, symbol: str, timeframe: str, *, start: datetime | None = None, end: datetime | None = None) -> Sequence[Bar]:
        if self._bar_parser is None:
            raise BrokerError("Kiwoom bar parser is not configured; consult the current official TR schema first")
        raw = self.transport.request(api_id="MARKET_DATA", endpoint="", payload={
            "symbol": symbol, "timeframe": timeframe,
            "start": start.isoformat() if start else None,
            "end": end.isoformat() if end else None,
        })
        return self._bar_parser(raw)

    def get_quote(self, symbol: str) -> Quote:
        if self._quote_parser is None:
            raise BrokerError("Kiwoom quote parser is not configured; consult the current official TR schema first")
        raw = self.transport.request(api_id="QUOTE", endpoint="", payload={"symbol": symbol})
        return self._quote_parser(raw)

    def submit_order(self, order: OrderRequest) -> str:
        if self._order_parser is None:
            raise BrokerError("live order parser is not configured; paper trading must be used first")
        raw = self.transport.request(api_id="ORDER", endpoint="", payload={
            "symbol": order.symbol, "side": order.side.value,
            "quantity": order.quantity, "limit_price": order.limit_price,
            "client_order_id": order.client_order_id,
        })
        order_id = self._order_parser(raw)
        if not order_id:
            raise BrokerError("Kiwoom order response did not contain an order id")
        return str(order_id)

    def cancel_order(self, order_id: str) -> bool:
        raise BrokerError("cancel endpoint must be explicitly configured from the official Kiwoom schema")
