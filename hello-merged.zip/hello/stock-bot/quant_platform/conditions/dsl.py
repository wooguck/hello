"""안전한 조건식 DSL.

Python eval을 사용하지 않으며, 동일한 조건 순서만 다른 전략은 같은 hash를
갖도록 canonicalize합니다. 실시간과 백테스트가 같은 AST를 사용할 수 있습니다.
"""
from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from typing import Any


class DslError(ValueError):
    pass


LOGICAL = {"AND", "OR", "NOT", "GROUP"}
COMPARISONS = {"GREATER_THAN", "LESS_THAN", "GREATER_EQUAL", "LESS_EQUAL", "EQUAL", "NOT_EQUAL", "BETWEEN", ">", "<", ">=", "<=", "==", "!="}
CROSSINGS = {"CROSS_ABOVE", "CROSS_BELOW"}


def parse(text: str) -> dict:
    try:
        node = json.loads(text)
    except json.JSONDecodeError as exc:
        raise DslError(f"invalid JSON DSL: {exc.msg}") from exc
    validate(node)
    return node


def _children(node: Mapping[str, Any]) -> list[Any]:
    if "conditions" in node:
        value = node["conditions"]
    elif "condition" in node:
        value = [node["condition"]]
    else:
        value = []
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise DslError("conditions must be an array")
    return list(value)


def validate(node: Any) -> None:
    if not isinstance(node, Mapping):
        raise DslError("each DSL node must be an object")
    op = str(node.get("operator", node.get("comparison", ""))).upper()
    if op in LOGICAL:
        children = _children(node)
        minimum = 1 if op != "NOT" else 1
        if len(children) < minimum:
            raise DslError(f"{op} requires at least one child")
        if op == "NOT" and len(children) != 1:
            raise DslError("NOT requires exactly one child")
        for child in children:
            validate(child)
        return
    if op in CROSSINGS:
        if "left" not in node or "right" not in node:
            raise DslError(f"{op} requires left and right operands")
        _validate_operand(node["left"])
        _validate_operand(node["right"])
        return
    comparison = op
    if comparison not in COMPARISONS:
        raise DslError(f"unsupported operator/comparison: {comparison or '<missing>'}")
    if "indicator" not in node:
        raise DslError("comparison requires an indicator")
    _validate_operand(node["indicator"])
    if "value" not in node:
        raise DslError("comparison requires a value")
    _validate_operand(node["value"])
    if comparison == "BETWEEN":
        value = node["value"]
        if not isinstance(value, Sequence) or isinstance(value, (str, bytes)) or len(value) != 2:
            raise DslError("BETWEEN value must contain [lower, upper]")


def _validate_operand(value: Any) -> None:
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if not math.isfinite(float(value)):
            raise DslError("numeric operand must be finite")
        return
    if isinstance(value, str):
        if not value.strip():
            raise DslError("operand cannot be empty")
        return
    if isinstance(value, Mapping):
        if "indicator" not in value:
            raise DslError("reference operand requires indicator")
        if not isinstance(value["indicator"], str) or not value["indicator"].strip():
            raise DslError("reference indicator must be a non-empty string")
        if "multiplier" in value and not isinstance(value["multiplier"], (int, float)):
            raise DslError("multiplier must be numeric")
        return
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        for item in value:
            _validate_operand(item)
        return
    raise DslError(f"unsupported operand type: {type(value).__name__}")


def canonicalize(node: Mapping[str, Any]) -> dict:
    validate(node)

    def normalize(value: Any) -> Any:
        if isinstance(value, Mapping):
            result = {str(k): normalize(v) for k, v in value.items()}
            op = str(result.get("operator", result.get("comparison", ""))).upper()
            if op in {"AND", "OR"} and "conditions" in result:
                result["conditions"] = sorted(result["conditions"], key=lambda item: json.dumps(item, sort_keys=True, separators=(",", ":")))
            return dict(sorted(result.items(), key=lambda item: item[0]))
        if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
            return [normalize(v) for v in value]
        if isinstance(value, float) and value.is_integer():
            return int(value)
        return value

    return normalize(node)


def strategy_hash(node: Mapping[str, Any]) -> str:
    payload = json.dumps(canonicalize(node), ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _operand(value: Any, values: Mapping[str, Any]) -> float:
    if isinstance(value, Mapping):
        key = str(value["indicator"])
        if key not in values or values[key] is None:
            raise DslError(f"missing indicator value: {key}")
        result = float(values[key])
        if "multiplier" in value:
            result *= float(value["multiplier"])
        if "offset" in value:
            result += float(value["offset"])
        return result
    if isinstance(value, str):
        if value not in values or values[value] is None:
            raise DslError(f"missing indicator value: {value}")
        return float(values[value])
    return float(value)


def evaluate(node: Mapping[str, Any], values: Mapping[str, Any], previous: Mapping[str, Any] | None = None) -> bool:
    validate(node)
    try:
        op = str(node.get("operator", node.get("comparison", ""))).upper()
        if op == "AND":
            return all(evaluate(child, values, previous) for child in _children(node))
        if op == "OR":
            return any(evaluate(child, values, previous) for child in _children(node))
        if op in {"NOT", "GROUP"}:
            result = evaluate(_children(node)[0], values, previous)
            return not result if op == "NOT" else result
        if op in CROSSINGS:
            if previous is None:
                return False
            left_now, right_now = _operand(node["left"], values), _operand(node["right"], values)
            left_prev, right_prev = _operand(node["left"], previous), _operand(node["right"], previous)
            if op == "CROSS_ABOVE":
                return left_now > right_now and left_prev <= right_prev
            return left_now < right_now and left_prev >= right_prev
        left = _operand(node["indicator"], values)
        right = node["value"]
        if op == "BETWEEN":
            low, high = (_operand(item, values) for item in right)
            return low <= left <= high
        right_value = _operand(right, values)
        return {
            "GREATER_THAN": left > right_value, ">": left > right_value,
            "LESS_THAN": left < right_value, "<": left < right_value,
            "GREATER_EQUAL": left >= right_value, ">=": left >= right_value,
            "LESS_EQUAL": left <= right_value, "<=": left <= right_value,
            "EQUAL": left == right_value, "==": left == right_value,
            "NOT_EQUAL": left != right_value, "!=": left != right_value,
        }[op]
    except DslError as exc:
        # Indicator warm-up periods legitimately produce None. They are not signals;
        # malformed DSL remains an exception from validate().
        if str(exc).startswith("missing indicator value:"):
            return False
        raise
