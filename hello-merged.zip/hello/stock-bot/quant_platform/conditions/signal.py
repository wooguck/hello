"""DSL 조건식을 백테스트/모의투자 공통 signal callable로 연결합니다."""
from __future__ import annotations

from collections.abc import Mapping, Sequence

from ..domain import Bar
from ..indicators import feature_rows
from .dsl import evaluate


class DslSignal:
    def __init__(self, *, buy: Mapping, sell: Mapping | None = None):
        self.buy = buy
        self.sell = sell

    def __call__(self, index: int, history: Sequence[Bar]) -> str | None:
        if not history:
            return None
        rows = feature_rows(history)
        current = rows[-1]
        previous = rows[-2] if len(rows) > 1 else None
        if self.sell is not None and evaluate(self.sell, current, previous):
            return "SELL"
        if evaluate(self.buy, current, previous):
            return "BUY"
        return None
