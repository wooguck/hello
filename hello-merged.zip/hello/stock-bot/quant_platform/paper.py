"""실제 주문 없이 동일한 next-open 규칙으로 동작하는 모의투자 ledger."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from .backtest import BacktestConfig
from .domain import Bar


@dataclass(frozen=True)
class PaperOrder:
    side: str
    symbol: str
    quantity: int
    price: float
    timestamp: str
    status: str = "FILLED"


@dataclass(frozen=True)
class PaperResult:
    initial_capital: float
    final_equity: float
    realized_pnl: float
    orders: tuple[PaperOrder, ...]


class PaperAccount:
    def __init__(self, initial_capital: float):
        if initial_capital <= 0:
            raise ValueError("initial_capital must be positive")
        self.initial_capital = float(initial_capital)
        self.cash = float(initial_capital)
        self.quantity = 0
        self.average_price = 0.0
        self.realized_pnl = 0.0

    def buy(self, price: float, quantity: int, fee_pct: float) -> None:
        cost = price * quantity * (1 + fee_pct / 100)
        if quantity <= 0 or cost > self.cash:
            raise ValueError("paper buy rejected: insufficient cash or invalid quantity")
        # 평균단가는 매수 수수료까지 포함한 비용 기준으로 관리합니다.
        # 그래야 realized_pnl이 진입 수수료를 누락하지 않고 백테스트와 일치합니다.
        total_cost = self.average_price * self.quantity + cost
        self.cash -= cost
        self.quantity += quantity
        self.average_price = total_cost / self.quantity

    def sell(self, price: float, quantity: int, fee_pct: float) -> float:
        if quantity <= 0 or quantity > self.quantity:
            raise ValueError("paper sell rejected: insufficient position")
        proceeds = price * quantity * (1 - fee_pct / 100)
        pnl = (price - self.average_price) * quantity - price * quantity * fee_pct / 100
        self.cash += proceeds
        self.quantity -= quantity
        self.realized_pnl += pnl
        if self.quantity == 0:
            self.average_price = 0.0
        return pnl

    def equity(self, price: float) -> float:
        return self.cash + self.quantity * price


class PaperTradingEngine:
    def __init__(self, config: BacktestConfig | None = None):
        self.config = config or BacktestConfig()

    def run(self, bars: Sequence[Bar], signal) -> PaperResult:
        rows = list(bars)
        if len(rows) < 2:
            raise ValueError("at least two bars are required")
        account = PaperAccount(self.config.initial_capital)
        orders: list[PaperOrder] = []
        pending = None
        for index, bar in enumerate(rows):
            if pending and pending[1] < index:
                action, signal_index = pending
                pending = None
                if action == "BUY" and account.quantity == 0:
                    price = bar.open * (1 + self.config.slippage_pct / 100)
                    max_cash = account.cash * self.config.position_size_pct / 100
                    quantity = int(max_cash / (price * (1 + self.config.commission_pct / 100)))
                    if quantity > 0:
                        account.buy(price, quantity, self.config.commission_pct)
                        orders.append(PaperOrder("BUY", bar.symbol, quantity, price, bar.timestamp.isoformat()))
                elif action == "SELL" and account.quantity > 0:
                    price = bar.open * (1 - self.config.slippage_pct / 100)
                    quantity = account.quantity
                    account.sell(price, quantity, self.config.commission_pct)
                    orders.append(PaperOrder("SELL", bar.symbol, quantity, price, bar.timestamp.isoformat()))
            action = signal(index, tuple(rows[:index + 1]))
            if index + 1 < len(rows) and pending is None:
                normalized = action.upper() if isinstance(action, str) else None
                if normalized == "BUY" and account.quantity == 0:
                    pending = ("BUY", index)
                elif normalized == "SELL" and account.quantity > 0:
                    pending = ("SELL", index)
        if account.quantity > 0:
            last = rows[-1]
            price = last.close * (1 - self.config.slippage_pct / 100)
            quantity = account.quantity
            account.sell(price, quantity, self.config.commission_pct)
            orders.append(PaperOrder("SELL", last.symbol, quantity, price, last.timestamp.isoformat(), "FILLED_END_OF_DATA"))
        return PaperResult(self.config.initial_capital, account.cash, account.realized_pnl, tuple(orders))
