"""look-ahead bias를 막는 최소 백테스트 엔진.

신호는 t 시점까지의 history로만 계산하고, 체결은 다음 봉 시가에서 처리합니다.
실시간 모의투자 엔진도 이 체결 규칙을 공유해야 합니다.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import isfinite
from typing import Callable, Sequence

from ..domain import Bar
from ..data.quality import validate_bars

SignalFunction = Callable[[int, Sequence[Bar]], str | None]


@dataclass(frozen=True)
class BacktestConfig:
    initial_capital: float = 10_000_000.0
    position_size_pct: float = 100.0
    commission_pct: float = 0.1
    slippage_pct: float = 0.05

    def __post_init__(self) -> None:
        if self.initial_capital <= 0:
            raise ValueError("initial_capital must be positive")
        if not 0 < self.position_size_pct <= 100:
            raise ValueError("position_size_pct must be in (0, 100]")
        if self.commission_pct < 0 or self.slippage_pct < 0:
            raise ValueError("commission/slippage cannot be negative")


@dataclass(frozen=True)
class Trade:
    side: str
    symbol: str
    signal_time: str
    execution_time: str
    execution_price: float
    quantity: int
    pnl: float | None = None
    return_pct: float | None = None
    reason: str = "signal"


@dataclass(frozen=True)
class BacktestResult:
    initial_capital: float
    final_equity: float
    total_return_pct: float
    trade_count: int
    win_rate_pct: float
    average_trade_return_pct: float
    profit_factor: float
    max_drawdown_pct: float
    trades: tuple[Trade, ...]
    equity_curve: tuple[tuple[str, float], ...]

    def as_dict(self) -> dict:
        return {
            "initial_capital": self.initial_capital,
            "final_equity": self.final_equity,
            "total_return_pct": self.total_return_pct,
            "trade_count": self.trade_count,
            "win_rate_pct": self.win_rate_pct,
            "average_trade_return_pct": self.average_trade_return_pct,
            "profit_factor": self.profit_factor if isfinite(self.profit_factor) else None,
            "profit_factor_unbounded": not isfinite(self.profit_factor),
            "max_drawdown_pct": self.max_drawdown_pct,
            "trades": [trade.__dict__ for trade in self.trades],
            "equity_curve": list(self.equity_curve),
        }


class BacktestEngine:
    def __init__(self, config: BacktestConfig | None = None):
        self.config = config or BacktestConfig()

    def run(self, bars: Sequence[Bar], signal: SignalFunction) -> BacktestResult:
        rows = list(bars)
        if len(rows) < 2:
            raise ValueError("at least two bars are required")
        report = validate_bars(rows)
        if not report.ok:
            raise ValueError(f"invalid bars: {report.by_code()}")
        for left, right in zip(rows, rows[1:]):
            if left.timestamp >= right.timestamp:
                raise ValueError("bars must be sorted in strictly increasing order")

        cash = self.config.initial_capital
        quantity = 0
        entry_price = 0.0
        entry_cost = 0.0
        entry_signal_time = ""
        entry_execution_time = ""
        trades: list[Trade] = []
        equity_curve: list[tuple[str, float]] = []
        pending: tuple[str, int] | None = None

        for index, bar in enumerate(rows):
            # 예약된 신호는 반드시 다음 봉에서만 체결됩니다.
            if pending is not None and pending[1] < index:
                action, signal_index = pending
                pending = None
                if action == "BUY" and quantity == 0:
                    execution_price = bar.open * (1 + self.config.slippage_pct / 100)
                    max_cash = cash * self.config.position_size_pct / 100
                    quantity = int(max_cash / (execution_price * (1 + self.config.commission_pct / 100)))
                    if quantity > 0:
                        entry_cost = execution_price * quantity * (1 + self.config.commission_pct / 100)
                        cash -= entry_cost
                        entry_price = execution_price
                        entry_signal_time = rows[signal_index].timestamp.isoformat()
                        entry_execution_time = bar.timestamp.isoformat()
                        trades.append(Trade("BUY", bar.symbol, entry_signal_time, entry_execution_time, execution_price, quantity))
                elif action == "SELL" and quantity > 0:
                    execution_price = bar.open * (1 - self.config.slippage_pct / 100)
                    proceeds = execution_price * quantity * (1 - self.config.commission_pct / 100)
                    cash += proceeds
                    pnl = proceeds - entry_cost
                    ret = pnl / entry_cost * 100 if entry_cost else 0.0
                    trades.append(Trade("SELL", bar.symbol, entry_signal_time, bar.timestamp.isoformat(), execution_price, quantity, pnl, ret))
                    quantity = 0
                    entry_cost = 0.0

            # 현재 봉 종가까지 알려진 자료만 signal 함수에 제공합니다.
            history = tuple(rows[: index + 1])
            action = signal(index, history)
            normalized = action.upper() if isinstance(action, str) else None
            if index + 1 < len(rows) and pending is None:
                if normalized == "BUY" and quantity == 0:
                    pending = ("BUY", index)
                elif normalized == "SELL" and quantity > 0:
                    pending = ("SELL", index)

            equity_curve.append((bar.timestamp.isoformat(), cash + quantity * bar.close))

        # 데이터 끝에 포지션이 남으면 마지막 종가에서 보수적으로 정산합니다.
        if quantity > 0:
            last = rows[-1]
            execution_price = last.close * (1 - self.config.slippage_pct / 100)
            proceeds = execution_price * quantity * (1 - self.config.commission_pct / 100)
            cash += proceeds
            pnl = proceeds - entry_cost
            ret = pnl / entry_cost * 100 if entry_cost else 0.0
            trades.append(Trade("SELL", last.symbol, entry_signal_time, last.timestamp.isoformat(), execution_price, quantity, pnl, ret, "end_of_data"))
            quantity = 0
            if equity_curve:
                equity_curve[-1] = (equity_curve[-1][0], cash)

        sell_trades = [trade for trade in trades if trade.side == "SELL" and trade.return_pct is not None]
        wins = [trade for trade in sell_trades if (trade.return_pct or 0) > 0]
        gains = sum(trade.pnl for trade in sell_trades if (trade.pnl or 0) > 0)
        losses = abs(sum(trade.pnl for trade in sell_trades if (trade.pnl or 0) < 0))
        peak = self.config.initial_capital
        max_drawdown = 0.0
        for _, equity in equity_curve:
            peak = max(peak, equity)
            if peak:
                max_drawdown = max(max_drawdown, (peak - equity) / peak * 100)
        final_equity = equity_curve[-1][1]
        return BacktestResult(
            initial_capital=self.config.initial_capital,
            final_equity=final_equity,
            total_return_pct=(final_equity / self.config.initial_capital - 1) * 100,
            trade_count=len(sell_trades),
            win_rate_pct=(len(wins) / len(sell_trades) * 100) if sell_trades else 0.0,
            average_trade_return_pct=(sum(trade.return_pct or 0 for trade in sell_trades) / len(sell_trades)) if sell_trades else 0.0,
            profit_factor=(gains / losses) if losses else (float("inf") if gains else 0.0),
            max_drawdown_pct=max_drawdown,
            trades=tuple(trades),
            equity_curve=tuple(equity_curve),
        )
