"""주문 게이트웨이.

전략 코드가 브로커 API를 직접 호출하지 못하도록 주문 요청을 한 곳에서 받습니다.
현재 기본 모드는 OFF이며, DRY_RUN/PAPER에서도 외부 주문 API를 호출하지 않습니다.
LIVE는 명시적인 설정과 별도 브로커 어댑터가 모두 준비되기 전에는 거부합니다.
"""
from __future__ import annotations

import json
import sqlite3
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path


class OrderMode(str, Enum):
    OFF = "OFF"
    DRY_RUN = "DRY_RUN"
    PAPER = "PAPER"
    LIVE = "LIVE"


class OrderStatus(str, Enum):
    REJECTED = "REJECTED"
    SIMULATED = "SIMULATED"
    PAPER_PENDING = "PAPER_PENDING"
    SUBMITTED = "SUBMITTED"


@dataclass(frozen=True)
class OrderIntent:
    symbol: str
    side: str
    quantity: int
    price: float | None = None
    strategy_id: str = ""
    signal_time: str = ""
    client_order_id: str | None = None
    reason: str = ""

    def normalized(self) -> "OrderIntent":
        symbol = str(self.symbol).strip()
        side = str(self.side).strip().upper()
        if len(symbol) != 6 or not symbol.isdigit():
            raise ValueError("symbol must be a six-digit code")
        if side not in {"BUY", "SELL"}:
            raise ValueError("side must be BUY or SELL")
        if int(self.quantity) <= 0:
            raise ValueError("quantity must be positive")
        if self.price is not None and float(self.price) <= 0:
            raise ValueError("price must be positive")
        return OrderIntent(
            symbol=symbol,
            side=side,
            quantity=int(self.quantity),
            price=float(self.price) if self.price is not None else None,
            strategy_id=str(self.strategy_id),
            signal_time=str(self.signal_time),
            client_order_id=self.client_order_id,
            reason=str(self.reason),
        )


@dataclass(frozen=True)
class OrderResult:
    client_order_id: str
    status: str
    mode: str
    message: str
    broker_order_id: str | None = None


SCHEMA = """
CREATE TABLE IF NOT EXISTS order_intents (
    client_order_id TEXT PRIMARY KEY,
    created_at TEXT NOT NULL,
    mode TEXT NOT NULL,
    status TEXT NOT NULL,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    price REAL,
    strategy_id TEXT,
    signal_time TEXT,
    reason TEXT,
    broker_order_id TEXT,
    message TEXT NOT NULL,
    raw_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_order_intents_created ON order_intents(created_at);
"""


def _now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat()


class OrderGateway:
    def __init__(self, database_path: str | Path = "data/quant_orders.sqlite3", *, mode: OrderMode | str = OrderMode.OFF,
                 allow_live: bool = False, max_quantity: int = 100_000, max_price: float = 1_000_000_000):
        self.database_path = Path(database_path)
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.mode = mode if isinstance(mode, OrderMode) else OrderMode(str(mode).upper())
        self.allow_live = bool(allow_live)
        self.max_quantity = int(max_quantity)
        self.max_price = float(max_price)
        self._conn = sqlite3.connect(self.database_path, timeout=30)
        self._conn.executescript(SCHEMA)
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()

    def __enter__(self) -> "OrderGateway":
        return self

    def __exit__(self, *_exc) -> None:
        self.close()

    def _record(self, intent: OrderIntent, result: OrderResult) -> None:
        self._conn.execute(
            """INSERT OR IGNORE INTO order_intents(
               client_order_id, created_at, mode, status, symbol, side, quantity, price,
               strategy_id, signal_time, reason, broker_order_id, message, raw_json)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (result.client_order_id, _now(), result.mode, result.status, intent.symbol, intent.side,
             intent.quantity, intent.price, intent.strategy_id, intent.signal_time, intent.reason,
             result.broker_order_id, result.message, json.dumps(asdict(intent), ensure_ascii=False)),
        )
        self._conn.commit()

    def _existing(self, client_order_id: str) -> OrderResult | None:
        row = self._conn.execute(
            "SELECT client_order_id, status, mode, message, broker_order_id FROM order_intents WHERE client_order_id=?",
            (client_order_id,),
        ).fetchone()
        return OrderResult(*row) if row else None

    def submit(self, intent: OrderIntent) -> OrderResult:
        normalized = intent.normalized()
        client_order_id = normalized.client_order_id or f"Q-{uuid.uuid4().hex.upper()}"
        normalized = OrderIntent(**{**asdict(normalized), "client_order_id": client_order_id})
        existing = self._existing(client_order_id)
        if existing is not None:
            return existing

        if normalized.quantity > self.max_quantity:
            result = OrderResult(client_order_id, OrderStatus.REJECTED.value, self.mode.value,
                                 f"quantity exceeds limit {self.max_quantity}")
        elif normalized.price is not None and normalized.price > self.max_price:
            result = OrderResult(client_order_id, OrderStatus.REJECTED.value, self.mode.value,
                                 f"price exceeds limit {self.max_price}")
        elif self.mode == OrderMode.OFF:
            result = OrderResult(client_order_id, OrderStatus.REJECTED.value, self.mode.value, "order mode is OFF")
        elif self.mode == OrderMode.DRY_RUN:
            result = OrderResult(client_order_id, OrderStatus.SIMULATED.value, self.mode.value,
                                 "DRY_RUN: no broker API was called")
        elif self.mode == OrderMode.PAPER:
            result = OrderResult(client_order_id, OrderStatus.PAPER_PENDING.value, self.mode.value,
                                 "PAPER: recorded locally; no broker API was called")
        elif self.mode == OrderMode.LIVE and not self.allow_live:
            result = OrderResult(client_order_id, OrderStatus.REJECTED.value, self.mode.value,
                                 "LIVE is blocked until explicit gateway approval")
        else:
            # 브로커 어댑터를 실제 연결하기 전까지 LIVE도 안전하게 차단합니다.
            result = OrderResult(client_order_id, OrderStatus.REJECTED.value, self.mode.value,
                                 "live broker adapter is not configured")
        self._record(normalized, result)
        return result

    def recent(self, limit: int = 50) -> list[dict]:
        rows = self._conn.execute(
            "SELECT client_order_id, created_at, mode, status, symbol, side, quantity, price, strategy_id, message "
            "FROM order_intents ORDER BY created_at DESC LIMIT ?", (max(1, min(int(limit), 500)),)
        ).fetchall()
        columns = ["client_order_id", "created_at", "mode", "status", "symbol", "side", "quantity", "price", "strategy_id", "message"]
        return [dict(zip(columns, row)) for row in rows]
