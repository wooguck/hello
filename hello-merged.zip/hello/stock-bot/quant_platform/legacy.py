"""기존 stock-bot SQLite 일봉을 새 canonical 코어로 연결하는 bridge."""
from __future__ import annotations

import sqlite3
from datetime import datetime, time
from pathlib import Path
from typing import Sequence

from .backtest import BacktestConfig, BacktestEngine, BacktestResult
from .conditions import DslSignal
from .data import MarketDataStore
from .domain import Bar, DataSource, KST


def load_legacy_daily(symbol: str, stock_dir: str | Path = "data/stocks") -> list[Bar]:
    path = Path(stock_dir) / f"{symbol}.db"
    if not path.exists():
        raise FileNotFoundError(f"legacy stock database not found: {path}")
    connection = sqlite3.connect(path)
    try:
        rows = connection.execute(
            "SELECT bar_date, open_price, high_price, low_price, close_price, volume, amount, source "
            "FROM daily_bars ORDER BY bar_date"
        ).fetchall()
    finally:
        connection.close()
    result: list[Bar] = []
    for bar_date, open_price, high_price, low_price, close_price, volume, amount, source in rows:
        try:
            text = str(bar_date).strip()
            if len(text) == 8 and text.isdigit():
                text = f"{text[:4]}-{text[4:6]}-{text[6:]}"
            timestamp = datetime.fromisoformat(text).replace(tzinfo=KST) if "T" not in text else datetime.fromisoformat(text)
            result.append(Bar(symbol, "1d", timestamp, float(open_price), float(high_price), float(low_price),
                              float(close_price), float(volume or 0), float(amount) if amount is not None else None,
                              source or DataSource.IMPORTED))
        except (TypeError, ValueError):
            # 잘못된 원천행은 자동 수정하지 않고 건너뜁니다. 별도 품질 리포트에서 확인해야 합니다.
            continue
    return result


def import_legacy_daily(symbols: Sequence[str], *, stock_dir: str | Path = "data/stocks",
                        database_path: str | Path = "data/quant_platform.sqlite3") -> dict:
    imported = 0
    skipped = []
    with MarketDataStore(database_path) as store:
        for symbol in symbols:
            try:
                imported += store.upsert_bars(load_legacy_daily(symbol, stock_dir))
            except (FileNotFoundError, ValueError) as exc:
                skipped.append({"symbol": symbol, "reason": str(exc)})
        report = store.integrity_report()
        return {"imported": imported, "skipped": skipped, "quality_ok": report.ok,
                "quality_issues": [issue.message for issue in report.issues], "coverage": store.coverage()}


def run_legacy_dsl_backtest(symbol: str, *, stock_dir: str | Path = "data/stocks",
                            database_path: str | Path = "data/quant_platform.sqlite3") -> BacktestResult:
    rows = load_legacy_daily(symbol, stock_dir)
    with MarketDataStore(database_path) as store:
        store.upsert_bars(rows)
    buy = {"indicator": "close", "comparison": ">", "value": {"indicator": "sma_20"}}
    sell = {"indicator": "close", "comparison": "<", "value": {"indicator": "ema_20"}}
    return BacktestEngine(BacktestConfig(initial_capital=1_000_000, commission_pct=0.1, slippage_pct=0.05)).run(
        rows, DslSignal(buy=buy, sell=sell))
