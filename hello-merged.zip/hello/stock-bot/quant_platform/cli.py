"""확장 코어 CLI."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from .pipeline import PipelineConfig, run_demo


def main() -> int:
    parser = argparse.ArgumentParser(description="키움 퀀트 연구 코어")
    sub = parser.add_subparsers(dest="command", required=True)
    demo = sub.add_parser("demo", help="자격증명 없이 전체 파이프라인 실행")
    demo.add_argument("--output", type=Path, default=Path("data/quant_platform_demo.json"))
    demo.add_argument("--bars", type=int, default=180)
    demo.add_argument("--candidates", type=int, default=24)
    legacy = sub.add_parser("legacy", help="기존 stock-bot 일봉 DB를 새 코어로 연결")
    legacy.add_argument("--symbol", required=True)
    legacy.add_argument("--stock-dir", type=Path, default=Path("data/stocks"))
    legacy.add_argument("--db", type=Path, default=Path("data/quant_platform.sqlite3"))
    serve = sub.add_parser("serve", help="선택적 FastAPI API 서버 실행")
    serve.add_argument("--host", default="0.0.0.0")
    serve.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    if args.command == "demo":
        report = run_demo(PipelineConfig(bars_per_symbol=args.bars, candidate_limit=args.candidates, output_path=args.output))
        print(json.dumps({"ingested_bars": report["ingested_bars"], "candidate_count": report["candidate_count"],
                          "survivors": report["survivors"], "paper": report["paper"]}, ensure_ascii=False, indent=2))
        return 0
    if args.command == "legacy":
        from .legacy import import_legacy_daily, run_legacy_dsl_backtest
        report = import_legacy_daily([args.symbol], stock_dir=args.stock_dir, database_path=args.db)
        if not report["quality_ok"]:
            print(json.dumps(report, ensure_ascii=False, indent=2))
            return 1
        result = run_legacy_dsl_backtest(args.symbol, stock_dir=args.stock_dir, database_path=args.db)
        print(json.dumps({"import": report, "backtest": result.as_dict()}, ensure_ascii=False, indent=2))
        return 0
    if args.command == "serve":
        try:
            import uvicorn
            from .api import create_app
        except ImportError:
            parser.error("serve requires: pip install -r requirements-platform.txt")
        uvicorn.run(create_app(), host=args.host, port=args.port)
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
