"""원천 시장 데이터 무결성 검사.

오류를 조용히 보정하지 않습니다. 백테스트 전에 보고서를 확인하고, 문제가 있으면
실행을 중단할 수 있도록 구조화된 이슈를 반환합니다.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta
from typing import Iterable

from ..domain import Bar, Timeframe


@dataclass(frozen=True)
class QualityIssue:
    code: str
    message: str
    symbol: str | None = None
    timestamp: str | None = None


@dataclass(frozen=True)
class QualityReport:
    checked: int
    issues: tuple[QualityIssue, ...]

    @property
    def ok(self) -> bool:
        return not self.issues

    def by_code(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for issue in self.issues:
            counts[issue.code] = counts.get(issue.code, 0) + 1
        return counts


def validate_bars(bars: Iterable[Bar], *, expected_timeframe: str | None = None) -> QualityReport:
    rows = list(bars)
    issues: list[QualityIssue] = []
    seen: set[tuple[str, str, str]] = set()
    previous: dict[tuple[str, str], Bar] = {}
    for bar in rows:
        key = bar.key
        if key in seen:
            issues.append(QualityIssue("duplicate_timestamp", "duplicate symbol/timeframe/timestamp", bar.symbol, bar.timestamp.isoformat()))
        seen.add(key)
        if expected_timeframe and str(bar.timeframe) != expected_timeframe:
            issues.append(QualityIssue("timeframe_mismatch", f"expected {expected_timeframe}, got {bar.timeframe}", bar.symbol, bar.timestamp.isoformat()))
        group = (bar.symbol, str(bar.timeframe))
        prev = previous.get(group)
        if prev and bar.timestamp <= prev.timestamp:
            issues.append(QualityIssue("out_of_order", "timestamps must be strictly increasing", bar.symbol, bar.timestamp.isoformat()))
        if prev and str(bar.timeframe) != Timeframe.DAILY.value:
            # 1m/5m/15m 데이터는 고정 간격이 아니더라도 큰 역행만 차단합니다.
            if bar.timestamp < prev.timestamp:
                issues.append(QualityIssue("timestamp_regression", "timestamp moved backwards", bar.symbol, bar.timestamp.isoformat()))
        previous[group] = bar
    return QualityReport(len(rows), tuple(issues))
