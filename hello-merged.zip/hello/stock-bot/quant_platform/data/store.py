"""SQLite 원천 데이터 저장소.

현재는 의존성이 적은 SQLite를 기본으로 사용하고, 동일한 canonical 스키마를
Parquet으로 내보낼 수 있게 해 DuckDB/오브젝트 스토리지로 확장할 수 있습니다.
"""
from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Iterable

from ..domain import Bar
from .quality import QualityReport, validate_bars


SCHEMA = """
CREATE TABLE IF NOT EXISTS bars (
    symbol TEXT NOT NULL,
    timeframe TEXT NOT NULL,
    bar_time TEXT NOT NULL,
    open REAL NOT NULL,
    high REAL NOT NULL,
    low REAL NOT NULL,
    close REAL NOT NULL,
    volume REAL NOT NULL DEFAULT 0,
    trading_value REAL,
    source TEXT NOT NULL DEFAULT 'unknown',
    adjusted INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (symbol, timeframe, bar_time)
);
CREATE INDEX IF NOT EXISTS idx_bars_lookup ON bars(symbol, timeframe, bar_time);
"""


class MarketDataStore:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self.path, timeout=30)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.executescript(SCHEMA)
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()

    def __enter__(self) -> "MarketDataStore":
        return self

    def __exit__(self, *_exc) -> None:
        self.close()

    def upsert_bars(self, bars: Iterable[Bar], *, reject_invalid: bool = True) -> int:
        rows = list(bars)
        report = validate_bars(rows)
        if reject_invalid and not report.ok:
            raise ValueError(f"market data quality check failed: {report.by_code()}")
        payload = [
            (bar.symbol, str(bar.timeframe), bar.timestamp.isoformat(), bar.open, bar.high, bar.low, bar.close,
             bar.volume, bar.trading_value, bar.source, int(bar.adjusted))
            for bar in rows
        ]
        self._conn.executemany(
            """INSERT INTO bars(symbol,timeframe,bar_time,open,high,low,close,volume,trading_value,source,adjusted)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(symbol,timeframe,bar_time) DO UPDATE SET
                 open=excluded.open, high=excluded.high, low=excluded.low, close=excluded.close,
                 volume=excluded.volume, trading_value=excluded.trading_value, source=excluded.source,
                 adjusted=excluded.adjusted""",
            payload,
        )
        self._conn.commit()
        return len(payload)

    def get_bars(self, symbol: str, timeframe: str, *, start: str | None = None, end: str | None = None) -> list[Bar]:
        sql = "SELECT * FROM bars WHERE symbol=? AND timeframe=?"
        params: list[str] = [symbol, timeframe]
        if start:
            sql += " AND bar_time >= ?"
            params.append(start)
        if end:
            sql += " AND bar_time <= ?"
            params.append(end)
        sql += " ORDER BY bar_time"
        rows = self._conn.execute(sql, params).fetchall()
        return [
            Bar(symbol=row["symbol"], timeframe=row["timeframe"], timestamp=row["bar_time"], open=row["open"], high=row["high"],
                low=row["low"], close=row["close"], volume=row["volume"], trading_value=row["trading_value"],
                source=row["source"], adjusted=bool(row["adjusted"]))
            for row in rows
        ]

    def coverage(self, symbol: str | None = None) -> list[dict]:
        sql = """SELECT symbol, timeframe, COUNT(*) AS bars, MIN(bar_time) AS first_bar,
                         MAX(bar_time) AS last_bar FROM bars"""
        params: list[str] = []
        if symbol:
            sql += " WHERE symbol=?"
            params.append(symbol)
        sql += " GROUP BY symbol, timeframe ORDER BY symbol, timeframe"
        return [dict(row) for row in self._conn.execute(sql, params).fetchall()]

    def integrity_report(self, symbol: str | None = None) -> QualityReport:
        all_rows: list[Bar] = []
        for item in self.coverage(symbol):
            all_rows.extend(self.get_bars(item["symbol"], item["timeframe"]))
        return validate_bars(all_rows)

    def export_parquet(self, output_path: str | Path, *, symbol: str | None = None) -> Path:
        """canonical 데이터를 Parquet으로 내보냅니다(pyarrow 선택 의존성)."""
        try:
            import pyarrow as pa
            import pyarrow.parquet as pq
        except ImportError as exc:
            raise RuntimeError("Parquet export requires optional dependency: pyarrow") from exc
        rows = [bar.as_dict() for item in self.coverage(symbol) for bar in self.get_bars(item["symbol"], item["timeframe"])]
        destination = Path(output_path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        table = pa.Table.from_pylist(rows)
        pq.write_table(table, destination)
        return destination
