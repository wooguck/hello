"""향후 Redis/Celery로 교체 가능한 로컬 job queue."""
from __future__ import annotations

import threading
import uuid
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Callable, Any


class JobStatus(str, Enum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


@dataclass
class Job:
    job_id: str
    status: JobStatus
    created_at: str
    result: Any = None
    error: str | None = None


class LocalJobQueue:
    def __init__(self, max_workers: int = 2):
        if max_workers <= 0:
            raise ValueError("max_workers must be positive")
        self._executor = ThreadPoolExecutor(max_workers=max_workers)
        self._jobs: dict[str, Job] = {}
        self._lock = threading.Lock()

    def submit(self, function: Callable, *args, **kwargs) -> str:
        job_id = uuid.uuid4().hex
        job = Job(job_id, JobStatus.QUEUED, datetime.now(timezone.utc).isoformat())
        with self._lock:
            self._jobs[job_id] = job
        self._executor.submit(self._run, job_id, function, args, kwargs)
        return job_id

    def _run(self, job_id: str, function: Callable, args: tuple, kwargs: dict) -> None:
        with self._lock:
            self._jobs[job_id].status = JobStatus.RUNNING
        try:
            result = function(*args, **kwargs)
            with self._lock:
                self._jobs[job_id].status = JobStatus.COMPLETED
                self._jobs[job_id].result = result
        except Exception as exc:
            with self._lock:
                self._jobs[job_id].status = JobStatus.FAILED
                self._jobs[job_id].error = f"{type(exc).__name__}: {exc}"

    def get(self, job_id: str) -> Job | None:
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None:
                return None
            return Job(job.job_id, job.status, job.created_at, job.result, job.error)

    def shutdown(self) -> None:
        self._executor.shutdown(wait=True)
