"""의존성 없는 기본 기술적 지표 엔진.

초기 코어는 Python 표준 자료구조로 동작해 Windows/CI에서 쉽게 검증합니다.
대용량 데이터가 확인되면 같은 계약을 Polars/NumPy 구현으로 교체할 수 있습니다.
"""
from __future__ import annotations

from collections.abc import Iterable, Sequence
from math import sqrt

from .domain import Bar

Number = float | None


def _values(values: Iterable[float]) -> list[float]:
    return [float(value) for value in values]


def sma(values: Iterable[float], period: int) -> list[Number]:
    rows = _values(values)
    if period <= 0:
        raise ValueError("period must be positive")
    result: list[Number] = [None] * len(rows)
    total = 0.0
    for index, value in enumerate(rows):
        total += value
        if index >= period:
            total -= rows[index - period]
        if index + 1 >= period:
            result[index] = total / period
    return result


def ema(values: Iterable[float], period: int) -> list[Number]:
    rows = _values(values)
    if period <= 0:
        raise ValueError("period must be positive")
    result: list[Number] = [None] * len(rows)
    if len(rows) < period:
        return result
    seed = sum(rows[:period]) / period
    result[period - 1] = seed
    multiplier = 2 / (period + 1)
    previous = seed
    for index in range(period, len(rows)):
        previous = (rows[index] - previous) * multiplier + previous
        result[index] = previous
    return result


def rsi(values: Iterable[float], period: int = 14) -> list[Number]:
    rows = _values(values)
    if period <= 0:
        raise ValueError("period must be positive")
    result: list[Number] = [None] * len(rows)
    if len(rows) <= period:
        return result
    gains = [max(rows[i] - rows[i - 1], 0.0) for i in range(1, len(rows))]
    losses = [max(rows[i - 1] - rows[i], 0.0) for i in range(1, len(rows))]
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period

    def value() -> float:
        if avg_loss == 0:
            return 100.0 if avg_gain > 0 else 50.0
        relative = avg_gain / avg_loss
        return 100 - (100 / (1 + relative))

    result[period] = value()
    for index in range(period + 1, len(rows)):
        avg_gain = (avg_gain * (period - 1) + gains[index - 1]) / period
        avg_loss = (avg_loss * (period - 1) + losses[index - 1]) / period
        result[index] = value()
    return result


def true_range(bars: Sequence[Bar]) -> list[float]:
    result: list[float] = []
    previous_close: float | None = None
    for bar in bars:
        if previous_close is None:
            current = bar.high - bar.low
        else:
            current = max(bar.high - bar.low, abs(bar.high - previous_close), abs(bar.low - previous_close))
        result.append(current)
        previous_close = bar.close
    return result


def atr(bars: Sequence[Bar], period: int = 14) -> list[Number]:
    return sma(true_range(bars), period)


def bollinger(values: Iterable[float], period: int = 20, deviations: float = 2.0) -> list[dict[str, Number]]:
    rows = _values(values)
    if period <= 0 or deviations < 0:
        raise ValueError("invalid Bollinger configuration")
    output: list[dict[str, Number]] = []
    for index in range(len(rows)):
        if index + 1 < period:
            output.append({"middle": None, "upper": None, "lower": None})
            continue
        window = rows[index - period + 1:index + 1]
        middle = sum(window) / period
        variance = sum((item - middle) ** 2 for item in window) / period
        width = sqrt(variance) * deviations
        output.append({"middle": middle, "upper": middle + width, "lower": middle - width})
    return output


def macd(values: Iterable[float], fast: int = 12, slow: int = 26, signal_period: int = 9) -> list[dict[str, Number]]:
    rows = _values(values)
    fast_line = ema(rows, fast)
    slow_line = ema(rows, slow)
    line: list[Number] = [None if f is None or s is None else f - s for f, s in zip(fast_line, slow_line)]
    known = [item for item in line if item is not None]
    signal_known = ema(known, signal_period)
    signal_line: list[Number] = [None] * len(line)
    cursor = 0
    for index, item in enumerate(line):
        if item is not None:
            if signal_known[cursor] is not None:
                signal_line[index] = signal_known[cursor]
            cursor += 1
    return [{"macd": line[index], "signal": signal_line[index],
             "histogram": (line[index] - signal_line[index]) if line[index] is not None and signal_line[index] is not None else None}
            for index in range(len(rows))]


def feature_rows(bars: Sequence[Bar], *, ma_period: int = 20, ema_period: int = 20,
                 rsi_period: int = 14, volume_period: int = 20, atr_period: int = 14) -> list[dict[str, float | None]]:
    """봉 배열을 DSL이 읽는 현재 시점 feature row 배열로 변환합니다."""
    closes = [bar.close for bar in bars]
    volumes = [bar.volume for bar in bars]
    ma = sma(closes, ma_period)
    ema_values = ema(closes, ema_period)
    rsi_values = rsi(closes, rsi_period)
    volume_ma = sma(volumes, volume_period)
    atr_values = atr(bars, atr_period)
    bands = bollinger(closes, ma_period)
    macd_values = macd(closes)
    output: list[dict[str, float | None]] = []
    for index, bar in enumerate(bars):
        previous_close = closes[index - 1] if index else None
        output.append({
            "open": bar.open, "high": bar.high, "low": bar.low, "close": bar.close,
            "volume": bar.volume, "trading_value": bar.trading_value,
            "sma_20": ma[index], "ema_20": ema_values[index], "rsi_14": rsi_values[index],
            "volume_sma_20": volume_ma[index], "atr_14": atr_values[index],
            "bollinger_middle": bands[index]["middle"], "bollinger_upper": bands[index]["upper"],
            "bollinger_lower": bands[index]["lower"], "macd": macd_values[index]["macd"],
            "macd_signal": macd_values[index]["signal"], "macd_histogram": macd_values[index]["histogram"],
            "change_pct": ((bar.close / previous_close) - 1) * 100 if previous_close else None,
        })
    return output
