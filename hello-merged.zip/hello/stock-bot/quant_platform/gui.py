"""화면으로 진행상황을 보여주는 StockBot 통합 GUI.

기본 기능은 기존 data/stocks와 새 canonical DB를 연결하는 읽기 전용 연구입니다.
Tkinter 표준 라이브러리만 사용해 Windows EXE로 묶을 수 있습니다.
"""
from __future__ import annotations

import json
import os
import queue
import threading
import webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, ttk

from .all_runner import run_all
from .audit import run_audit, write_audit
from .orchestrator import run_pipeline


class QuantGui:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("StockBot Quant 통합센터")
        self.root.geometry("1050x720")
        self.root.minsize(900, 620)
        self.events: queue.Queue[tuple[str, object]] = queue.Queue()
        self.running = False
        self.stop_event = threading.Event()
        self.last_report: dict | None = None
        self._build()
        self._refresh_files()
        self._poll()

    def _build(self) -> None:
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"))
        style.configure("Section.TLabel", font=("Segoe UI", 11, "bold"))
        style.configure("Safe.TLabel", foreground="#087f5b", font=("Segoe UI", 10, "bold"))
        style.configure("Danger.TLabel", foreground="#c92a2a", font=("Segoe UI", 10, "bold"))

        header = ttk.Frame(self.root, padding=(18, 15, 18, 8))
        header.pack(fill="x")
        ttk.Label(header, text="StockBot Quant 통합센터", style="Title.TLabel").pack(side="left")
        self.safe_label = ttk.Label(header, text="안전모드 · 주문 차단", style="Safe.TLabel")
        self.safe_label.pack(side="right")

        controls = ttk.LabelFrame(self.root, text="실행", padding=12)
        controls.pack(fill="x", padx=18, pady=(0, 10))
        ttk.Label(controls, text="종목코드").pack(side="left")
        self.symbol_var = tk.StringVar(value="005930")
        symbol = ttk.Entry(controls, width=12, textvariable=self.symbol_var)
        symbol.pack(side="left", padx=(8, 18))
        self.run_button = ttk.Button(controls, text="선택 종목 실행", command=lambda: self.start_run(all_symbols=False))
        self.run_button.pack(side="left")
        self.all_button = ttk.Button(controls, text="전체 종목 실행", command=lambda: self.start_run(all_symbols=True))
        self.all_button.pack(side="left", padx=(8, 0))
        self.stop_button = ttk.Button(controls, text="중지", command=self.stop_run, state="disabled")
        self.stop_button.pack(side="left", padx=(8, 0))
        self.refresh_button = ttk.Button(controls, text="리포트 새로고침", command=self._refresh_files)
        self.refresh_button.pack(side="left", padx=8)
        self.report_button = ttk.Button(controls, text="최근 리포트 열기", command=self.open_report, state="disabled")
        self.report_button.pack(side="right")
        self.error_button = ttk.Button(controls, text="오류센터 열기", command=self.open_error, state="disabled")
        self.error_button.pack(side="right", padx=8)
        self.audit_button = ttk.Button(controls, text="전체 오류·안전 점검", command=self.start_audit)
        self.audit_button.pack(side="right", padx=8)

        self.status_var = tk.StringVar(value="대기 중")
        ttk.Label(self.root, textvariable=self.status_var, padding=(18, 0, 18, 6)).pack(anchor="w")

        body = ttk.PanedWindow(self.root, orient="horizontal")
        body.pack(fill="both", expand=True, padx=18, pady=(0, 12))

        left = ttk.Frame(body, padding=8)
        right = ttk.Frame(body, padding=8)
        body.add(left, weight=1)
        body.add(right, weight=2)

        ttk.Label(left, text="현재 상태", style="Section.TLabel").pack(anchor="w", pady=(0, 8))
        self.cards: dict[str, tk.StringVar] = {}
        for key, label in (
            ("mode", "실행모드"), ("source", "원본 데이터"), ("canonical", "canonical DB"),
            ("analysis", "분석 데이터"), ("candidates", "전략 후보"), ("survivors", "통과 전략"),
            ("orders", "제출 주문"), ("report", "리포트"),
        ):
            frame = ttk.Frame(left, relief="groove", borderwidth=1, padding=8)
            frame.pack(fill="x", pady=3)
            ttk.Label(frame, text=label, width=16).pack(side="left")
            var = tk.StringVar(value="-")
            self.cards[key] = var
            ttk.Label(frame, textvariable=var).pack(side="left", fill="x", expand=True)

        ttk.Label(left, text="안전 규칙", style="Section.TLabel").pack(anchor="w", pady=(18, 8))
        ttk.Label(left, text="• 기존 trading.db 원본 보존\n• 기존 data\\stocks 원본 보존\n• 분석용 행과 추가 canonical 행 분리\n• 현재 주문 제출 0건\n• 오류 발생 시 자동 중지", justify="left").pack(anchor="w")

        ttk.Label(right, text="실행 로그", style="Section.TLabel").pack(anchor="w", pady=(0, 8))
        log_frame = ttk.Frame(right)
        log_frame.pack(fill="both", expand=True)
        self.log_text = tk.Text(log_frame, wrap="word", state="disabled", font=("Consolas", 10), background="#10151c", foreground="#d9e2ec", insertbackground="white")
        scrollbar = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scrollbar.set)
        self.log_text.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        footer = ttk.Frame(self.root, padding=(18, 0, 18, 12))
        footer.pack(fill="x")
        self.footer_var = tk.StringVar(value="오류센터: errors\\latest.json")
        ttk.Label(footer, textvariable=self.footer_var).pack(side="left")
        ttk.Label(footer, text="READ_ONLY_RESEARCH · LIVE_ORDERS=false").pack(side="right")

    def _append(self, text: str) -> None:
        self.log_text.configure(state="normal")
        self.log_text.insert("end", text.rstrip() + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _poll(self) -> None:
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == "progress":
                    event = value
                    stage = event.get("stage", "")
                    status = event.get("status", "")
                    progress_text = ""
                    if "candidate_index" in event:
                        progress_text = f" · 후보 {event['candidate_index']}/{event['candidate_total']} ({event.get('candidate_id', '')})"
                    elif stage == "ALL_RUN" and "index" in event:
                        progress_text = f" · 종목 {event['index']}/{event['total']} ({event.get('symbol', '')})"
                        if "completed" in event:
                            progress_text += f" · 완료 {event['completed']} · 실패 {event['failed']}"
                    self.status_var.set(f"{stage} · {status}{progress_text}")
                    self._append(f"[{stage}] {status}{progress_text}")
                    for key, field in (("source", "source_rows"), ("canonical", "canonical_after"), ("analysis", "analysis_rows"), ("candidates", "candidate_count"), ("survivors", "survivor_count")):
                        if field in event:
                            self.cards[key].set(str(event[field]))
                elif kind == "done":
                    self.running = False
                    self.run_button.configure(state="normal")
                    self.all_button.configure(state="normal")
                    self.stop_button.configure(state="disabled")
                    self.refresh_button.configure(state="normal")
                    report = value
                    self.last_report = report
                    self.status_var.set("완료 · 주문 없음")
                    if "all_run_id" in report:
                        self.cards["mode"].set(report.get("mode", "-"))
                        self.cards["source"].set(f"{report.get('source_symbol_count', 0)}종목")
                        self.cards["canonical"].set(f"canonical 전용 {report.get('canonical_only_symbol_count', 0)}종목")
                        self.cards["analysis"].set(f"완료 {report.get('completed_count', 0)} / 실패 {report.get('failed_count', 0)}")
                        self.cards["candidates"].set("종목별 14개")
                        self.cards["survivors"].set(str(sum(item.get('survivor_count', 0) for item in report.get('completed', []))))
                        self.cards["orders"].set(str(report.get("orders_submitted", 0)))
                    else:
                        self.cards["mode"].set(report.get("mode", "-"))
                        self.cards["source"].set(str(report.get("source", {}).get("rows", "-")))
                        self.cards["canonical"].set(str(report.get("canonical", {}).get("after_rows", "-")))
                        self.cards["analysis"].set(str(report.get("analysis", {}).get("rows", "-")))
                        self.cards["candidates"].set(str(report.get("candidates", {}).get("count", "-")))
                        self.cards["survivors"].set(str(len(report.get("survivors", []))))
                        self.cards["orders"].set(str(report.get("orders_submitted", 0)))
                    self.cards["report"].set(str(report.get("report_path", "-")))
                    self.report_button.configure(state="normal")
                    self.error_button.configure(state="normal" if Path("errors/latest.json").exists() else "disabled")
                    self._append("[DONE] 통합 연구 완료")
                elif kind == "audit":
                    self.running = False
                    self.run_button.configure(state="normal")
                    self.all_button.configure(state="normal")
                    self.stop_button.configure(state="disabled")
                    audit = value
                    counts = audit.get("counts", {})
                    self._append(f"[AUDIT] PASS={counts.get('PASS', 0)} WARN={counts.get('WARN', 0)} FAIL={counts.get('FAIL', 0)}")
                    self.status_var.set(f"감사 완료 · FAIL {counts.get('FAIL', 0)} · WARN {counts.get('WARN', 0)}")
                    self.safe_label.configure(text="안전 점검 완료", style="Safe.TLabel" if counts.get("FAIL", 0) == 0 else "Danger.TLabel")
                    write_audit(".", "reports/integration_audit.json")
                    if counts.get("FAIL", 0):
                        messagebox.showwarning("오류·안전 점검", f"FAIL {counts.get('FAIL', 0)}건, WARN {counts.get('WARN', 0)}건이 발견되었습니다. reports\\integration_audit.json을 확인하세요.")
                    else:
                        messagebox.showinfo("오류·안전 점검", f"FAIL 0건, WARN {counts.get('WARN', 0)}건입니다. reports\\integration_audit.json에 저장했습니다.")
                elif kind == "audit_button":
                    self.audit_button.configure(state="normal")
                elif kind == "error":
                    self.running = False
                    self.run_button.configure(state="normal")
                    self.all_button.configure(state="normal")
                    self.stop_button.configure(state="disabled")
                    self.refresh_button.configure(state="normal")
                    error = value
                    self.status_var.set("실패 · 주문 없음 · 오류센터 확인")
                    self._append(f"[ERROR] {error}")
                    self.error_button.configure(state="normal" if Path("errors/latest.json").exists() else "disabled")
                    messagebox.showerror("통합 실행 오류", str(error))
        except queue.Empty:
            pass
        self.root.after(200, self._poll)

    def start_audit(self) -> None:
        if self.running:
            return
        self.running = True
        self.audit_button.configure(state="disabled")
        self.run_button.configure(state="disabled")
        self.all_button.configure(state="disabled")
        self.status_var.set("전체 오류·안전 점검 중")
        self._append("[AUDIT] 기존 자료·DB·주문 경로·환경을 점검합니다.")

        def worker() -> None:
            try:
                self.events.put(("audit", run_audit(".")))
            except Exception as exc:
                self.events.put(("error", exc))
            finally:
                self.events.put(("audit_button", None))

        threading.Thread(target=worker, name="quant-audit", daemon=True).start()

    def start_run(self, all_symbols: bool = False) -> None:
        if self.running:
            return
        symbol = self.symbol_var.get().strip()
        if not all_symbols and not (len(symbol) == 6 and symbol.isdigit()):
            messagebox.showwarning("종목코드 확인", "6자리 숫자 종목코드를 입력하세요.")
            return
        self.running = True
        self.stop_event.clear()
        self.run_button.configure(state="disabled")
        self.all_button.configure(state="disabled")
        self.stop_button.configure(state="normal")
        self.refresh_button.configure(state="disabled")
        self.report_button.configure(state="disabled")
        title = "전체 종목" if all_symbols else symbol
        self._append(f"[START] {title} 통합 실행")
        self.status_var.set("전체 실행 준비 중" if all_symbols else "실행 준비 중")

        def worker() -> None:
            try:
                if all_symbols:
                    report = run_all(progress=lambda event: self.events.put(("progress", event)), stop_event=self.stop_event)
                else:
                    report = run_pipeline(symbol=symbol, progress=lambda event: self.events.put(("progress", event)))
                self.events.put(("done", report))
            except Exception as exc:
                self.events.put(("error", exc))

        threading.Thread(target=worker, name="quant-pipeline", daemon=True).start()

    def stop_run(self) -> None:
        if self.running:
            self.stop_event.set()
            self.status_var.set("중지 요청됨 · 현재 종목 완료 후 안전하게 중지")
            self._append("[STOP] 중지 요청됨")

    def _refresh_files(self) -> None:
        reports = sorted(Path("reports").glob("RUN-*.json"), reverse=True) if Path("reports").exists() else []
        errors = Path("errors/latest.json")
        if reports:
            self.report_button.configure(state="normal")
            self.cards["report"].set(str(reports[0]))
        self.error_button.configure(state="normal" if errors.exists() else "disabled")
        self._append(f"[INFO] 프로젝트: {Path.cwd().resolve()}")
        self._append(f"[INFO] 원본: {Path('data/stocks').resolve()}")
        self._append(f"[INFO] canonical: {Path('data/quant_platform.sqlite3').resolve()}")

    def open_report(self) -> None:
        path = self.last_report.get("report_path") if self.last_report else None
        if not path:
            reports = sorted(Path("reports").glob("RUN-*.json"), reverse=True) if Path("reports").exists() else []
            path = str(reports[0]) if reports else None
        if path and Path(path).exists():
            os.startfile(str(Path(path).resolve()))  # type: ignore[attr-defined]

    def open_error(self) -> None:
        path = Path("errors/latest.json")
        if path.exists():
            os.startfile(str(path.resolve()))  # type: ignore[attr-defined]


def main() -> int:
    root = tk.Tk()
    QuantGui(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
