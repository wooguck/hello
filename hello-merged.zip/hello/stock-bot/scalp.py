# -*- coding: utf-8 -*-
"""
⚡ 장초반 스캘핑 엔진 (scalp.py) — 09:00~09:40 빠른 매수/눌림매수/빠른 매도
=============================================================================
사용자 목표: "장 시작 직후 활발한 때(9시~9:30) 빠르게 사서 수익 보고,
눌림 되면 또 사서 매도" — 개장 초반 집중 스캘핑.

데이터 소스 (하이브리드):
  - 분봉: 네이버 실시간 1분봉 (fetch_minutes) — REST 모드에서도 1분 단위 실시간
  - 실시간: realtime_bridge 가 OpenAPI+ 연결되면 즉시 시세/주문
  - 주문: OpenAPI+ (연결 시) → 아니면 키움 REST place_order (DRY_RUN 안전)

전략 (장초반 한정):
  [매수 A - 오전 강세] 등락률 ≥ SCALP_MOMENTUM_CHG + 거래량 급증
  [매수 B - 눌림매수]  최근 고점 대비 SCALP_PULLBACK_PCT 이상 눌림 + 시초가 위 유지
  [매도]  빠른 익절(TP) / 스캘핑 손절(SL) / 최대 보유시간

실행:
  python scalp.py --cycle        # 1사이클 실행 (장중)
  python scalp.py --simulate     # 최근 분봉으로 장초반 전략 시뮬레이션 (테스트)
  python scalp.py --status       # 현황
"""
import json
import logging
import os
from config import _env_int as _cfg_env_int, _env_float as _cfg_env_float
import time
from datetime import datetime, timedelta

import db
from config import CFG

log = logging.getLogger("scalp")

# ── 설정 (.env) ──
SCALP_ENABLED = os.getenv("SCALP_ENABLED", "true").lower() == "true"
WINDOW_START = os.getenv("SCALP_WINDOW_START", "09:00")
WINDOW_END = os.getenv("SCALP_WINDOW_END", "09:40")
TP_PCT = _cfg_env_float("SCALP_TP_PCT", 0.8)          # 빠른 익절 %
SL_PCT = _cfg_env_float("SCALP_SL_PCT", 0.4)          # 스캘핑 손절 %
MAX_HOLD_MIN = _cfg_env_int("SCALP_MAX_HOLD_MIN", 25)  # 최대 보유 분
MOMENTUM_CHG = _cfg_env_float("SCALP_MOMENTUM_CHG", 1.5)  # 오전 강세 등락률 %
PULLBACK_PCT = _cfg_env_float("SCALP_PULLBACK_PCT", 0.5)  # 눌림 기준 (고점 대비 %)
LOOKBACK_MIN = _cfg_env_int("SCALP_LOOKBACK_MIN", 15)  # 눌림 판단 참고 최근 N분
MAX_POS = _cfg_env_int("SCALP_MAX_POS", 5)
MAX_QTY = _cfg_env_int("SCALP_MAX_QTY", 10)
MIN_VOL_RATIO = _cfg_env_float("SCALP_MIN_VOL_RATIO", 1.5)  # 거래량 급증 배수


# ── 오늘 분봉 (네이버 실시간 1분봉) ─────────────────────
def today_minutes(symbol, days=1):
    """오늘(또는 최근) 1분봉: [{t(datetime), price, volume}] 오름차순
    db 분봉 우선, 없으면 네이버 fetch (장중 실시간)
    """
    try:
        bars = db.get_minute_bars(symbol, days=days, limit=500)
        if len(bars) >= 30:
            out = []
            for b in bars:
                try:
                    t = datetime.fromisoformat(b["bar_time"].replace("Z", "+00:00"))
                    out.append({"t": t, "price": float(b["price"] or 0),
                                "volume": float(b.get("volume") or 0)})
                except Exception:
                    continue
            if len(out) >= 30:
                return out
    except Exception:
        pass
    try:
        from backfill_history import fetch_minutes
        bars = fetch_minutes(symbol, max_bars=500)
        out = []
        for b in bars:
            try:
                out.append({"t": b["bar_time"], "price": float(b["price"] or 0),
                            "volume": float(b.get("volume") or 0)})
            except Exception:
                continue
        return out
    except Exception:
        return []


def _in_window(now):
    """장초반 윈도우(09:00~09:40) 여부"""
    hm = f"{now.hour:02d}:{now.minute:02d}"
    return WINDOW_START <= hm <= WINDOW_END


# ── ★ 핵심 판단 로직 (순수 함수 - 테스트 가능) ──────────
def find_live_entries(price, open_price=None, high=None, low=None, prev_close=None,
                       volume=None, avg_vol=None, now=None):
    """★ 실시간 틱 스냅샷 기반 즉시 판단 (OpenAPI+ 실시간 모드용 - 밀리초 반응)
    - 분봉 대기 없이 현재 시세 1틱으로 즉시 매수 신호 판단
    - price: 현재가, open_price: 당일 시가, high/low: 당일 고/저가
    - prev_close: 전일 종가, volume: 누적 거래량, avg_vol: 평균 거래량
    반환: [{"type": "momentum"|"pullback", "price", "reason"}]
    """
    if not price or price <= 0:
        return []
    sigs = []
    prev_close = prev_close or open_price or price
    day_open = open_price or price
    chg = (price / prev_close - 1) * 100 if prev_close else 0       # 전일 대비 등락률
    chg_open = (price / day_open - 1) * 100 if day_open else 0      # 시초가 대비

    # ── 오전 강세: 전일 대비 상승 + 시초가 위 + (거래량 급증 있으면) ──
    if chg >= MOMENTUM_CHG and chg_open >= 0:
        vtxt = ""
        if avg_vol and volume and avg_vol > 0:
            vratio = volume / avg_vol
            if vratio < MIN_VOL_RATIO:
                pass  # 거래량 미달이어도 일단 강세 후보 (하드 필터 아님)
            else:
                vtxt = f" 거래량{vratio:.1f}배"
        sigs.append({"type": "momentum", "price": price,
                     "reason": f"실시간 강세 {chg:+.2f}%{vtxt}"})

    # ── 눌림매수: 당일 고가 대비 하락 + 시초가 위 (실시간 즉시) ──
    if high and high > 0 and price < high:
        dip = (high - price) / high * 100
        if dip >= PULLBACK_PCT and chg_open >= 0:
            sigs.append({"type": "pullback", "price": price,
                         "reason": f"실시간 눌림 {dip:.2f}% (고가{high:,.0f}) 시초가위 {chg_open:+.2f}%"})
    return sigs


def find_scalp_entries(minutes, now=None, day_open=None):
    """1분봉 리스트에서 장초반 매수 신호 감지 (순수 함수)
    minutes: [{t, price, volume}] 오름차순
    반환: [{"type": "momentum"|"pullback", "price", "reason", "idx"}]
    """
    if len(minutes) < 5:
        return []
    now = now or datetime.now()
    sigs = []
    prices = [m["price"] for m in minutes if m["price"] > 0]
    vols = [m.get("volume") or 0 for m in minutes]
    if not prices:
        return []
    day_open = day_open or minutes[0]["price"] or prices[0]
    last_price = prices[-1]
    last_vol = vols[-1] if vols else 0
    avg_vol = (sum(vols[-10:]) / max(1, len(vols[-10:]))) if len(vols) >= 3 else 0
    chg_vs_open = (last_price / day_open - 1) * 100 if day_open else 0

    # ── 매수 A: 오전 강세 (등락률 상승 + 거래량 급증) ──
    if chg_vs_open >= MOMENTUM_CHG and last_vol >= avg_vol * MIN_VOL_RATIO:
        sigs.append({"type": "momentum", "price": last_price, "idx": len(minutes) - 1,
                     "reason": f"오전강세 {chg_vs_open:+.1f}% 거래량 {last_vol/avg_vol:.1f}배"})

    # ── 매수 B: 눌림매수 (최근 고점 대비 눌림 + 시초가 위) ──
    if len(prices) >= 3:
        recent = prices[-LOOKBACK_MIN:]
        high = max(recent)
        dip = (high - last_price) / high * 100 if high else 0
        # 눌림: 고점에서 PULLBACK_PCT 이상 하락했지만 시초가 위 (상승 추세 유지)
        if dip >= PULLBACK_PCT and chg_vs_open >= 0:
            sigs.append({"type": "pullback", "price": last_price, "idx": len(minutes) - 1,
                         "reason": f"눌림 {dip:.1f}% (고점{high:,.0f}) 시초가위 {chg_vs_open:+.1f}%"})
    return sigs


def check_scalp_exit(entry_price, highest, price, hold_min):
    """빠른 매도 판단 (순수 함수)
    반환: (exit, reason) — exit True면 매도
    """
    if not entry_price or entry_price <= 0 or not price:
        return False, ""
    ret = (price - entry_price) / entry_price * 100
    if ret >= TP_PCT:
        return True, f"익절 {ret:+.2f}% (≥+{TP_PCT}%)"
    if ret <= -SL_PCT:
        return True, f"손절 {ret:.2f}% (≤-{SL_PCT}%)"
    if hold_min >= MAX_HOLD_MIN:
        return True, f"보유 {hold_min}분 경과 ({ret:+.2f}%)"
    return False, ""


# ── 주문 (하이브리드: OpenAPI+ → REST) ──────────────────
def _place(symbol, side, qty, price):
    """주문: 실시간 브리지(OpenAPI+) 우선, 아니면 키움 REST (DRY_RUN 안전)"""
    try:
        import realtime_bridge as rb
        if rb.is_realtime():
            r = rb.order(symbol, side, qty, price)
            if r:
                return r
    except Exception:
        pass
    from kiwoom_client import client
    return client.place_order(symbol, side, qty, price, order_type="00")


def _order_accepted(result) -> bool:
    """주문 요청 실패 시 내부 paper 포지션을 만들지 않습니다."""
    if not isinstance(result, dict):
        return False
    status = str(result.get("status", "")).lower()
    if status in {"error", "rejected", "cancelled", "dry_run_skipped", "failed"}:
        return False
    code = result.get("return_code")
    if code is not None and str(code).strip() not in {"0", "200", "ok", "success"}:
        return False
    return status in {"ok", "success", "sent", "queued", "filled", "accepted"} or code in (0, "0", 200, "200") or bool(
        result.get("order_no") or result.get("ord_no") or result.get("odno")
    )


# ── 실시간 캔들 폴링 (REST 모드에서 1분 단위 실시간 근사) ─
def live_candle(symbol):
    """장중 현재 1분봉 (네이버 실시간) - {t, price, volume} or None"""
    try:
        from leader import fetch_live_quote
        q = fetch_live_quote(symbol)
        if q:
            return {"t": datetime.now(), "price": q["price"], "volume": q["volume"]}
    except Exception:
        pass
    return None


# ── 후보 종목 (장초반 스캘핑 대상) ──────────────────────
def scalp_candidates(max_n=20):
    """오늘 강한 종목 후보: 조건식 신호 + 거래대금 상위 (네이버 실시간)"""
    cands = []
    try:
        # 1) 조건식 신호
        from paper_test import top_conditions, _signals_all_conditions
        conds = top_conditions(n=3)
        sig = _signals_all_conditions(conds)
        for v in sig.values():
            cands += v
    except Exception:
        pass
    # 2) 거래대금 상위 (KOSPI/KOSDAQ)
    try:
        import requests
        for market in ("KOSPI", "KOSDAQ"):
            r = requests.get(f"https://m.stock.naver.com/api/stocks/marketValue/{market}"
                             f"?page=1&pageSize=20",
                             headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
            if r.status_code == 200:
                for s in r.json().get("stocks", []):
                    try:
                        v = float(str(s.get("accumulatedTradingValue", "0")).replace(",", ""))
                        if v >= 30_000_000:  # 3억 이상
                            cands.append(s.get("itemCode"))
                    except Exception:
                        continue
    except Exception:
        pass
    out = []
    for c in cands:
        if c and c not in out:
            out.append(c)
    return out[:max_n]


# ── 1사이클 실행 (장중 호출) ────────────────────────────
def run_scalp_cycle(log_out=None, max_new=3):
    """스캘핑 1사이클: 후보 → 분봉 분석 → 진입/청산
    반환: {"entered": [...], "exited": [...], "held": n, "note": str, "window": bool}
    """
    def _log(m):
        if log_out:
            log_out(m)
        log.info(m)

    now = db.now_kst()
    if not _in_window(now):
        return {"entered": [], "exited": [], "held": db.count_paper_open(),
                "note": f"장초반 윈도우({WINDOW_START}~{WINDOW_END}) 아님 - 현재 {now:%H:%M}",
                "window": False}
    if not SCALP_ENABLED:
        return {"entered": [], "exited": [], "held": 0, "note": "SCALP_ENABLED=false", "window": True}

    # ★ 일일 손실 서킷브레이커: 한도 초과 시 스캘핑 신규 진입도 정지 (청산은 아래 계속)
    _cb_block = False
    try:
        import paper_test as _pt
        ok_cb, pnl_cb, lim_cb = _pt.daily_circuit_ok()
        if not ok_cb:
            _cb_block = True
            _log(f"🚫 [서킷브레이커] 오늘 손실 {pnl_cb:+,.0f}원 > 한도 - 스캘핑 신규 진입 정지 (청산은 계속)")
    except Exception:
        pass

    entered, exited = [], []
    # ── 1) 진입: 후보 종목 분봉 분석 ──
    cands = [] if _cb_block else scalp_candidates(max_n=20)
    if not _cb_block:
        _log(f"⚡ 스캘핑 후보 {len(cands)}개")
    for sym in cands[:max_new * 4]:
        if len(entered) >= max_new:
            break
        if db.paper_has_open(sym):
            continue
        price = None
        try:
            from engine import get_quote_cached
            q = get_quote_cached(sym, max_age_sec=120)
            price = q.get("price") if q else None
        except Exception:
            pass
        if not price or price <= 0:
            continue
        minutes = today_minutes(sym, days=1)
        if len(minutes) < 3:
            continue
        sigs = find_scalp_entries(minutes, now=now)
        if not sigs:
            continue
        # 신호 중 첫 번째 (모멘텀 우선)
        s = sigs[0]
        qty = min(MAX_QTY, max(1, int(10_000_000 / s["price"] / MAX_POS)))
        r = _place(sym, "buy", qty, s["price"])
        if not CFG.DRY_RUN and not _order_accepted(r):
            _log(f"⚠️ [스캘핑] 매수 주문 미접수 {sym}: {(r or {}).get('message', '응답 없음')[:50]}")
            continue
        db.open_paper_position(f"SCALP-{s['type']}", f"[스캘핑] {s['reason']}", sym,
                               s["price"], qty,
                               order_kind=("real" if (r or {}).get("status") == "ok" else "virtual"))
        entered.append({"symbol": sym, "type": s["type"], "price": s["price"],
                        "qty": qty, "reason": s["reason"], "order": r.get("status", "ok")})
        _log(f"⚡ [스캘핑 진입] {sym} {qty}주 @{s['price']:,.0f} | {s['reason']}")

    # ── 2) 청산: 보유 스캘핑 포지션 빠른 익절/손절 ──
    for pos in db.get_paper_open():
        if not (pos.get("cond_txt") or "").startswith("[스캘핑]"):
            continue
        price = None
        try:
            from engine import get_quote_cached
            q = get_quote_cached(pos["symbol"], max_age_sec=120)
            price = q.get("price") if q else None
        except Exception:
            pass
        if not price or price <= 0:
            continue
        try:
            hold_min = int((now - datetime.fromisoformat(pos["entry_time"])).total_seconds() / 60)
        except Exception:
            hold_min = 0
        exit_now, reason = check_scalp_exit(pos["entry_price"],
                                            (pos.get("highest_return") or 0) * pos["entry_price"] / 100 + pos["entry_price"],
                                            price, hold_min)
        if exit_now:
            slip = float(getattr(CFG, "SLIPPAGE_PCT", 0.15)) / 100.0
            exit_p = price * (1 - slip) if CFG.DRY_RUN else price
            ret = (exit_p - pos["entry_price"]) / pos["entry_price"] * 100
            r = _place(pos["symbol"], "sell", pos["qty"], price)
            if not CFG.DRY_RUN and not _order_accepted(r):
                _log(f"⚠️ [스캘핑] 매도 주문 미접수 {pos['symbol']}: {(r or {}).get('message', '응답 없음')[:50]}")
                continue
            db.close_paper_position(pos["id"], exit_p, ret)
            exited.append({"symbol": pos["symbol"], "ret": round(ret, 2), "reason": reason})
            _log(f"⚡ [스캘핑 청산] {pos['symbol']} {ret:+.2f}% | {reason}")
    return {"entered": entered, "exited": exited, "held": db.count_paper_open(),
            "note": f"진입 {len(entered)} · 청산 {len(exited)}", "window": True}


# ── 장초반 시뮬레이션 (백테스트 - 테스트/검증용) ─────────
def simulate_scalp(symbols=None, days=5):
    """최근 N일 1분봉으로 장초반(9:00~9:40) 스캘핑 시뮬레이션
    반환: {"trades": [...], "summary": {trades, win_rate, avg_ret, total, pf}}
    """
    if symbols is None:
        symbols = ["005930", "000660", "035420", "042700", "086520"]
    trades = []
    for sym in symbols:
        bars = today_minutes(sym, days=days)
        # 날짜별 분리
        by_day = {}
        for b in bars:
            k = b["t"].date().isoformat()
            by_day.setdefault(k, []).append(b)
        for day, mints in sorted(by_day.items()):
            # 장초반 구간만
            win = [b for b in mints if WINDOW_START <= b["t"].strftime("%H:%M") <= WINDOW_END]
            if len(win) < 5:
                continue
            day_open = win[0]["price"]
            entry = None
            entry_t = None
            highest = 0
            for i in range(len(win)):
                b = win[i]
                if entry is None:
                    sigs = find_scalp_entries(win[:i + 1], now=b["t"], day_open=day_open)
                    if sigs:
                        entry = sigs[0]["price"]
                        entry_t = b["t"]
                        highest = entry
                else:
                    highest = max(highest, b["price"])
                    hold_min = int((b["t"] - entry_t).total_seconds() / 60)
                    ex, _r = check_scalp_exit(entry, highest, b["price"], hold_min)
                    if ex:
                        ret = (b["price"] / entry - 1) * 100 - float(CFG.FEE_ROUND_TRIP_PCT)
                        trades.append({"symbol": sym, "date": day, "entry": entry,
                                       "exit": b["price"], "ret": round(ret, 2),
                                       "hold_min": hold_min})
                        entry = None
            if entry is not None:
                last = win[-1]["price"]
                ret = (last / entry - 1) * 100 - float(CFG.FEE_ROUND_TRIP_PCT)
                trades.append({"symbol": sym, "date": day, "entry": entry,
                               "exit": last, "ret": round(ret, 2),
                               "hold_min": int((win[-1]["t"] - entry_t).total_seconds() / 60)})
    n = len(trades)
    wins = [t for t in trades if t["ret"] > 0]
    losses = [t for t in trades if t["ret"] <= 0]
    gp = sum(t["ret"] for t in wins)
    gl = abs(sum(t["ret"] for t in losses))
    return {"trades": trades,
            "summary": {"trades": n,
                        "win_rate": round(len(wins) / n * 100, 1) if n else 0,
                        "avg_ret": round(sum(t["ret"] for t in trades) / n, 2) if n else 0,
                        "total": round(sum(t["ret"] for t in trades), 2),
                        "pf": round(gp / gl, 2) if gl else (999.0 if gp else 0)},
            "days": days}


def scalp_status():
    """현재 스캘핑 상태 (UI)"""
    try:
        import realtime_bridge as rb
        rb.connect()
        bridge = rb.status_text()
    except Exception:
        bridge = "REST 폴링"
    now = db.now_kst()
    return {"enabled": SCALP_ENABLED, "window": _in_window(now),
            "window_txt": f"{WINDOW_START}~{WINDOW_END}", "now": f"{now:%H:%M}",
            "bridge": bridge, "held": db.count_paper_open()}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="장초반 스캘핑")
    parser.add_argument("--cycle", action="store_true", help="1사이클 실행")
    parser.add_argument("--simulate", action="store_true", help="분봉 시뮬레이션")
    parser.add_argument("--status", action="store_true", help="상태")
    args = parser.parse_args()
    db.init_db()
    logging.basicConfig(level=logging.INFO)
    if args.status:
        print(scalp_status())
    elif args.simulate:
        res = simulate_scalp()
        print("=" * 56)
        print(f"⚡ 장초반 스캘핑 시뮬레이션 ({res['days']}일 · {res['summary']['trades']}건)")
        print(f"  승률 {res['summary']['win_rate']}% · 평균 {res['summary']['avg_ret']}% · "
              f"총 {res['summary']['total']}% · 손익비 {res['summary']['pf']}")
        print("=" * 56)
        for t in res["trades"][:15]:
            print(f"  {t['date']} {t['symbol']} {t['ret']:+.2f}% ({t['hold_min']}분)")
    elif args.cycle:
        r = run_scalp_cycle()
        print(r)
    else:
        parser.print_help()
