"""
환경설정 파일
- 실제 앱키/시크릿은 절대 이 파일에 직접 쓰지 말고 .env 파일에 넣으세요.
- .env 파일은 .gitignore에 반드시 등록하세요 (깃허브에 올리면 계좌가 털립니다).
"""
import os
from dataclasses import dataclass

try:
    from dotenv import load_dotenv
    # 일반 설정을 먼저 읽고, 인증 전용 .env를 마지막에 읽어 .env가 우선하도록 합니다.
    # 기존 순서에서는 python-dotenv의 override=False 때문에 settings.env 값이
    # 이미 로드된 .env에 가려지는 문제가 있었습니다.
    load_dotenv("settings.env", override=False)
    load_dotenv(".env", override=True)
except ImportError:
    pass




def _env_int(key, default):
    """★ 2026-09-02 빈 값 안전 (사용자 사고: 설정 탭에서 빈 칸 저장 →
    settings.env에 'KEY=' → int('') → 앱이 시작조차 못 함). 빈/불량 값이면 기본값."""
    v = os.getenv(key)
    try:
        return int(str(v).strip()) if v is not None and str(v).strip() != "" else default
    except Exception:
        return default


def _env_float(key, default):
    v = os.getenv(key)
    try:
        return float(str(v).strip()) if v is not None and str(v).strip() != "" else default
    except Exception:
        return default


@dataclass
class Config:
    # ── 키움 REST API 인증 ──────────────────────────────
    APP_KEY: str = os.getenv("KIWOOM_APP_KEY", "")
    APP_SECRET: str = os.getenv("KIWOOM_APP_SECRET", "")
    ACCOUNT_NO: str = os.getenv("KIWOOM_ACCOUNT_NO", "")
    # 모의투자 계좌는 8자리 + 구분코드 '11' = 10자리 (8자리 입력 시 자동 변환)
    ACCOUNT_SUFFIX: str = os.getenv("KIWOOM_ACCOUNT_SUFFIX", "11")

    BASE_URL_MOCK: str = os.getenv("KIWOOM_BASE_URL_MOCK", "https://mockapi.kiwoom.com")
    BASE_URL_REAL: str = os.getenv("KIWOOM_BASE_URL_REAL", "https://api.kiwoom.com")

    # ── 실행 모드 (핵심 안전장치) ────────────────────────
    USE_MOCK: bool = os.getenv("KIWOOM_USE_MOCK", "true").lower() == "true"
    DRY_RUN: bool = os.getenv("DRY_RUN", "true").lower() == "true"

    # ── 유전 알고리즘 파라미터 ───────────────────────────
    POPULATION_SIZE: int = 10          # 동시에 굴리는 전략 수
    # 실제 모의투자 주문을 내는 전략 수 (기본 10 = 전체 population이 모의투자 진행)
    SURVIVOR_COUNT: int = _env_int("SURVIVOR_COUNT", 10)
    MIN_TRADES_FOR_EVAL: int = 20
    MUTATION_RATE: float = 0.2
    GENERATION_INTERVAL_DAYS: int = 14
    # 백테스트 스크리닝: 세대교체 시 못난 전략(백테스트 점수 낮은) 과감히 폐기
    SCREENING_ENABLED: bool = os.getenv("SCREENING_ENABLED", "true").lower() == "true"
    SCREENING_RETIRE_RATE: float = _env_float("SCREENING_RETIRE_RATE", 0.4)  # 하위 40% 폐기

    # ── 거래 파라미터 ──────────────────────────────
    CONDITION_SEQ: str = os.getenv("CONDITION_SEQ", "")
    RISK_PER_TRADE_PCT: float = _env_float("RISK_PER_TRADE_PCT", 2.0)
    MAX_POSITIONS_PER_STRATEGY: int = _env_int("MAX_POSITIONS_PER_STRATEGY", 5)
    DEFAULT_ORDER_QTY: int = _env_int("DEFAULT_ORDER_QTY", 1)

    # ── AI 판단 (프롬프트 기반) ─────────────────────────
    AI_JUDGE_ENABLED: bool = os.getenv("AI_JUDGE_ENABLED", "true").lower() == "true"
    # ★ AI(Gemini 등) 실패 쿨다운 (초) - 실패 시 일정 시간 동안 AI 호출 건너뛰고 규칙 폴백
    #   - 429(할당량 초과): 길게 (보통 분~시간 단위로 풀림)
    #   - 503(모델 과부하): 짧게 (일시적)
    #   - 기타 오류: 중간
    AI_COOLDOWN_429_SEC: int = _env_int("AI_COOLDOWN_429_SEC", 600)    # 10분
    AI_COOLDOWN_503_SEC: int = _env_int("AI_COOLDOWN_503_SEC", 120)    # 2분
    AI_COOLDOWN_OTHER_SEC: int = _env_int("AI_COOLDOWN_OTHER_SEC", 60) # 1분
    # ★ 매수/매도 AI 판단 게이트 (앱 설정 탭에서 클릭 토글 - 기본은 지금 방향)
    #   AI_BUY_GATE=true  → 매수 시에도 AI 매수 판단(신뢰도 70%) 통과해야 진입
    #   AI_SELL_GATE=true → 매도 시 AI 매도 프롬프트 판단 (기본 - 지금 방향)
    AI_BUY_GATE: bool = os.getenv("AI_BUY_GATE", "false").lower() == "true"
    AI_SELL_GATE: bool = os.getenv("AI_SELL_GATE", "true").lower() == "true"
    # ★ 주간 리포트 (매주 주말 자동 생성 - AI 넣은 vs 안 넣은 비교 결과 포함)
    WEEKLY_REPORT_ENABLED: bool = os.getenv("WEEKLY_REPORT_ENABLED", "true").lower() == "true"

    # ── 데이터 저장 위치 (★ 원하는 곳으로 고정) ──
    # 기본: 프로그램 폴더 아래 data/ (exe 옆). Windows에서 고정하려면 예) DATA_DIR=C:/stock_data
    #   → 일봉/분봉/거래DB(trading.db) 전부 이 폴더에 생성됨 (한 곳에 모음)
    DATA_DIR: str = os.getenv("DATA_DIR", "data")
    # ★ 종목별 저장 (검증/차트 최적화): true면 data/stocks/005930.db 로 종목별 누적 저장
    #   (조회=파일 1개 열면 끝 → 차트/검증 빠름). false면 날짜별 파일 (백필 쓰기 성능 우선)
    STOCK_DIR_SAVE: bool = os.getenv("STOCK_DIR_SAVE", "true").lower() == "true"

    # ── 과거 데이터 자동 백필 (네이버 공개 API - 키움 무관) ──
    # ★ 수동 수집 모드 (기본): 앱 켜져도 자동으로 받지 않음.
    #   사용자가 대시보드 '📥 데이터 수집' 버튼을 누르면 전 종목 일봉(90일)+분봉을 받습니다.
    #   true로 바꾸면 앱 시작 시 + 장외에 자동으로 받기 시작.
    AUTO_BACKFILL: bool = os.getenv("AUTO_BACKFILL", "false").lower() == "true"
    # ★ 일봉 수신 범위: 1000 = 네이버가 주는 최대(약 4년, 제일 뒷날~오늘)
    #   사용자 요청 "받을 수 있는 모든 데이터를 제일 뒷날부터 오늘까지" 반영
    #   (검증/가상테스트/실제vs가상에 더 많은 과거 데이터 = 더 정확)
    BACKFILL_DAYS: int = _env_int("BACKFILL_DAYS", 1000)       # 일봉 최대 1000봉
    BACKFILL_PER_RUN: int = _env_int("BACKFILL_PER_RUN", 500)   # 1회당 종목 수
    # ★ 네이버 차단 시 키움 일봉(ka10081) 폴백 (키 있는 PC에서 동작 - 기본 ON)
    BACKFILL_FALLBACK_KIWOOM: bool = os.getenv("BACKFILL_FALLBACK_KIWOOM", "true").lower() == "true"
    # ★ Yahoo Finance 일봉 폴백 (키 없음, 전 세계 - 네이버/키움 실패 시. 최대 ~8년치)
    #   ★ 실제 확인: 모의 서버는 일봉 데이터를 안 줌 → Yahoo가 가장 현실적인 대체 소스
    BACKFILL_FALLBACK_YAHOO: bool = os.getenv("BACKFILL_FALLBACK_YAHOO", "true").lower() == "true"
    # ★ 다음(카카오) 금융 일봉 폴백 (키 없음, 500봉/회, 코스피+코스닥) - 네이버 차단 시 1순위
    #   2026-08-23 실측: 0.7초 간격이면 안정 · 버스트(간격 없는 연속 호출)는 403 (20~30초 후 해제)
    BACKFILL_FALLBACK_DAUM: bool = os.getenv("BACKFILL_FALLBACK_DAUM", "true").lower() == "true"
    # ★ 네이버 종목 간 대기(초) - 0.3으로 1300종목쯤에서 IP 차단된 사례 → 기본 0.5로 상향
    #   (차단이 반복되면 0.8~1.0으로 올리세요. 전 종목 3330개 × 0.5초 ≈ 28분)
    BACKFILL_SLEEP_SEC: float = _env_float("BACKFILL_SLEEP_SEC", 0.5)
    # ★ 연속 실패 최대 횟수 (0=무한) - 초과하면 자동 중단 (네이버 무한 재시도 방지)
    BACKFILL_MAX_FAIL_STREAK: int = _env_int("BACKFILL_MAX_FAIL_STREAK", 5)
    BACKFILL_INTERVAL_HOURS: int = _env_int("BACKFILL_INTERVAL_HOURS", 6)  # 몇 시간마다

    # ── ★ 자동 전략 생성 (백필 데이터가 쌓이면 자동으로 전략 갱신) ──
    # 90일치 일봉이 충분한 종목 수가 모이면, 데이터 기반 통계 분석 + 후보 전략
    # 백테스트를 돌려 최고 전략을 매수/매도 프롬프트에 자동 반영합니다.
    # 보수 원칙: 하드 손절/최소 익절/신뢰도 임계값은 절대 자동 변경하지 않습니다.
    AUTO_STRATEGY_GEN: bool = os.getenv("AUTO_STRATEGY_GEN", "true").lower() == "true"
    STRATEGY_MIN_DAYS: int = _env_int("STRATEGY_MIN_DAYS", 30)        # 종목당 최소 일봉 수
    STRATEGY_MIN_SYMBOLS: int = _env_int("STRATEGY_MIN_SYMBOLS", 500) # 이 종목 수 이상 채워지면 분석 시작
    STRATEGY_COOLDOWN_DAYS: int = _env_int("STRATEGY_COOLDOWN_DAYS", 7)  # 재분석 최소 간격(일)
    STRATEGY_MAX_SYMBOLS: int = _env_int("STRATEGY_MAX_SYMBOLS", 1500) # 분석에 쓰는 최대 종목 수
    STRATEGY_MIN_TRADES: int = _env_int("STRATEGY_MIN_TRADES", 500)   # 전략 적용 최소 샘플 수
    STRATEGY_APPLY_MIN_WINRATE: float = _env_float("STRATEGY_APPLY_MIN_WINRATE", 52.0)  # 승률 하한 %
    STRATEGY_APPLY_MIN_PF: float = _env_float("STRATEGY_APPLY_MIN_PF", 1.05)            # 손익비 하한

    # ── 분봉 자동 백필 (네이버 분봉: 최근 약 1주일, 분당 종가+누적거래량) ──
    # ★ 분봉 전 종목 수신 (사용자 요청: "최근 스크랩 가능한 분봉은 다 받는걸로")
    #   - MINUTE_ALL=true: 코스피+코스닥 전 종목(~3,300) 분봉을 장외 하루 1회 수신
    #   - 종목별·날짜별로 누적 저장 (UNIQUE(symbol,bar_time) → 중단 후 재개 시 이어받기, 갭 없음)
    #   - 네이버 무료 분봉은 최근 7거래일(~2,667봉)이 최대 → 매일 백필하면 1개월치 자동 누적
    #   - false: 유니버스+계좌 보유+감시 풀+설정 종목만 (가벼움)
    AUTO_BACKFILL_MINUTES: bool = os.getenv("AUTO_BACKFILL_MINUTES", "true").lower() == "true"
    # ★ 키움 분봉 보충: 네이버(7일) 이전 분봉을 키움 ka10080로 추가
    #   - 목표: 한 달치(약 22거래일) - 이미 받은 날짜는 다시 받지 않음 (중복 방지)
    #   - 키움 키(모의/실전)가 사용자 PC에 있을 때만 동작 (없으면 자동 스킵)
    KIWOOM_MINUTE_SUPPLEMENT: bool = os.getenv("KIWOOM_MINUTE_SUPPLEMENT", "true").lower() == "true"
    # 분봉 목표 거래일 수 (기본 한 달 ≈ 22거래일) - 네이버 7일 + 키움 그 뒤 최신부터 채움
    MINUTE_TARGET_DAYS: int = _env_int("MINUTE_TARGET_DAYS", 22)
    # ★ 분봉 전 종목은 용량/속도 부담(수 GB, 백필 느림) → 기본 false (관심 종목만)
    #   true로 바꾸면 전 종목 분봉 (스캘핑 전 종목 필요 시에만)
    MINUTE_ALL: bool = os.getenv("MINUTE_ALL", "false").lower() == "true"  # false=관심 종목 분봉
    MINUTE_SYMBOLS: str = os.getenv("MINUTE_SYMBOLS", "")        # 콤마 구분 (MINUTE_ALL=false일 때 최우선)
    MINUTE_MAX_SYMBOLS: int = _env_int("MINUTE_MAX_SYMBOLS", 30)  # MINUTE_ALL=false일 때 최대 종목 수
    AI_BUY_CONFIDENCE: bool = os.getenv("AI_BUY_CONFIDENCE", "true").lower() == "true"
    AI_BUY_CONFIDENCE_THRESHOLD: int = _env_int("AI_BUY_CONFIDENCE_THRESHOLD", 70)
    AI_PROVIDER: str = os.getenv("AI_PROVIDER", "rule")  # rule | openai | gemini | ollama
    AI_MODEL: str = os.getenv("AI_MODEL", "gpt-4o-mini")
    # ── ★ OpenAI 호환 API 서버 주소 (DeepSeek 등) ──
    #   AI_PROVIDER=openai + AI_BASE_URL=https://api.deepseek.com + AI_MODEL=deepseek-chat
    #   + OPENAI_API_KEY=딥시크키 → DeepSeek 연결 (OpenAI 클라이언트 호환)
    AI_BASE_URL: str = os.getenv("AI_BASE_URL", "")
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    # ★ 엔진 모드 기본: ai_prompt (프롬프트+AI 중심, 전략 DNA 최소 사용)
    #   - 기존 지표 기반 전략 파라미터(RSI 30 등)는 폐기 수순 - 봉분석 부재로 부적합
    #   - 매수 = 순위(200위) + 프롬프트 충족 + AI 판단
    ENGINE_MODE_DEFAULT: str = os.getenv("ENGINE_MODE_DEFAULT", "ai_prompt")
    # 실제 엔진 모드 (설정 탭 저장 시 갱신): auto | params | ai_prompt
    ENGINE_MODE: str = os.getenv("ENGINE_MODE", "auto")

    # ── 스케줄러 ──────────────────────────────
    TRADING_CYCLE_SECONDS: int = _env_int("TRADING_CYCLE_SECONDS", 120)
    MARKET_START_HOUR: int = 9
    MARKET_END_HOUR: int = 15
    MARKET_END_MINUTE: int = 30

    # ★ 매매 감시 주기 (분) - 순위 조회 + 매수 감시 사이클 간격
    #   09:00 정각을 기준으로 정렬됩니다 (09:00, 09:03, 09:06, ...)
    #   - 프로그램을 언제 켰든 관계없이 매주기 0초에 시작 (켠 시점 기준 아님)
    #   - 1분: 모의서버(1req/초)에선 순위3건+호가50건 ≈ 55초로 빡빡
    #   - 3분(기본): 여유 있고 순위 갱신도 자주 (권장)
    #   - 5분: 가장 넉넉함
    WATCH_PERIOD_MINUTES: int = _env_int("WATCH_PERIOD_MINUTES", 3)

    # ── 테스트 ──────────────────────────────
    TEST_FORCE_MOCK_INDICATORS: bool = os.getenv("TEST_FORCE_MOCK_INDICATORS", "false").lower() == "true"

    # ── 전체 종목 스캔 ───────────────────────
    # true = 전 종목(코스피+코스닥, 약 3500개)을 배치로 순환 스캔 (종목 관리 불필요)
    # false = 아래 UNIVERSE 또는 CONDITION_SEQ 만 스캔
    SCAN_ALL_MODE: bool = os.getenv("SCAN_ALL_MODE", "true").lower() == "true"
    # 한 사이클에 스캔할 종목 수 (전체 커버: 3500 / 배치 20 ≈ 175 사이클)
    SCAN_BATCH_SIZE: int = _env_int("SCAN_BATCH_SIZE", 20)

    # ── 모의 테스트 가격 필터 ────────────────
    # ★ 매수 감시 후보 50개 선정 시 + 매수 시: 이 가격 범위(800원 ~ 100,000원) 안의 종목만
    #   (사용자 요청: "800원~10만원 이하의 종목에서 50종목 채우기")
    # 데이터 수집/스캔은 전 종목 그대로 (필터 없음).
    MOCK_PRICE_MIN: int = _env_int("MOCK_PRICE_MIN", 800)
    MOCK_PRICE_MAX: int = _env_int("MOCK_PRICE_MAX", 100000)

    # ── 데이터 수집 모드 (수집과 매매 분리) ──
    # 장중(09:00~15:30): 당일치만 실시간 수집 (매매 성능 유지)
    # 장외: 과거 데이터 대량 수집 (검증용 - 봉/지수/순위 전 종목)
    COLLECT_INTRADAY: bool = os.getenv("COLLECT_INTRADAY", "true").lower() == "true"
    COLLECT_OFFHOURS: bool = os.getenv("COLLECT_OFFHOURS", "true").lower() == "true"
    # 장외 대량 수집: 과거 N일치 일봉 + 순위 + 지수 (하루 1회 장마감 후)
    OFFHOURS_HISTORY_DAYS: int = _env_int("OFFHOURS_HISTORY_DAYS", 120)
    # 순위 합산: 거래대금(ka10032) + 거래량(ka10030) + 회전율(ka10038)
    RANK_SCORING_ENABLED: bool = os.getenv("RANK_SCORING_ENABLED", "true").lower() == "true"
    RANK_TOP_N: int = _env_int("RANK_TOP_N", 50)        # 각 순위 상위 N개
    # ★ 매수 감시 후보 수는 아래 '감시 카테고리' 섹션에서 최소 50으로 강제됨
    RANK_INCLUDE_TURNOVER: bool = os.getenv("RANK_INCLUDE_TURNOVER", "true").lower() == "true"  # 회전율 포함

    # ── 매수 감시 1차 조건식 (프리필터 - 순위 점수 전에 먼저 걸러냄) ──
    # 순위 50개를 만들기 전에 아래 조건에 하나라도 걸리면 후보에서 제외 (하드 필터)
    #   - 등락률 범위 밖: 급락(-5%↓) / 상한가 추격(+25%↑) 방지
    #   - 당일 거래대금 미만: 저유동성 종목 제외 (체결 안 될 위험)
    #   - 가격 800~100,000원 (기존 MOCK_PRICE_MIN/MAX)
    WATCH_CHG_MIN: float = _env_float("WATCH_CHG_MIN", -5.0)        # 등락률 하한 %
    WATCH_CHG_MAX: float = _env_float("WATCH_CHG_MAX", 25.0)        # 등락률 상한 %
    WATCH_MIN_AMOUNT: int = _env_int("WATCH_MIN_AMOUNT", 300000000)  # 최소 당일 거래대금(원) = 3억

    # ★ 자동 파일럿: 앱 켜지면 자동 시작 (데이터 우선 → AI 지시 → 테스트/최적화/변형 →
    #   명예의 전당 → 모의 실전). 사용자 개입 없음. false면 수동(테스트 탭 버튼).
    AUTO_PILOT: bool = os.getenv("AUTO_PILOT", "true").lower() == "true"
    # ★ 매일 자동 데이터 수집: 자동 파일럿 장마감 세션에서 그날치 1일씩 계속 백필
    #   (미수신+갭 종목만 - 데이터는 절대 안 지워지고 매일 누적, 재시작해도 이어받기)
    #   false면 대시보드 '📥 데이터 수집' 버튼으로만 수동 수집
    DAILY_AUTO_BACKFILL: bool = os.getenv("DAILY_AUTO_BACKFILL", "true").lower() == "true"

    # ★ 매수 감시 카테고리 (감시 대기 풀) - 콤마 구분, 여러 개 동시에
    #   급등  : 당일 등락률·거래대금·거래량·회전율 순위 (실시간 API만으로 판별)
    #   반등  : 최근 5일 하락(-3%↓) 후 오늘 반등 - 백필 일봉 필요 (주봉 그림)
    #   저평가: 60일 고가 대비 -30%↓ 낙폭과대 + 오늘 반등 조짐 - 백필 일봉 필요 (월봉 그림)
    #   각 카테고리마다 CATEGORY_SIZE(50)개씩 → 총 최대 150개 풀, 그 중에서 매수 감시
    #   백필 데이터가 부족한 카테고리는 자동 생략 (나머지로 감시)
    WATCH_CATEGORIES: str = os.getenv("WATCH_CATEGORIES", "급등,반등,저평가")
    CATEGORY_SIZE: int = _env_int("CATEGORY_SIZE", 50)  # 카테고리당 후보 수

    # ── 매수 감시 후보 (하한 강제) ──
    # 사용자 PC .env에 20 등 낮은 값이 남아 있어도 최소 50은 보장 (그 중에서 뽑아쓰기 때문)
    RANK_CANDIDATE_COUNT: int = max(50, _env_int("RANK_CANDIDATE_COUNT", 50))

    # ── 매도 최소 기준 (돈 버는 시스템 핵심) ──
    # 1) 최소 익절: 수익률이 이 % 이상일 때만 '수익청산' 허용 (미만이면 보유 유지)
    #    → AI/프롬프트가 "수익청산" 말해도 최소 익절 못 넘으면 안 팖
    MIN_TAKE_PROFIT_PCT: float = _env_float("MIN_TAKE_PROFIT_PCT", 0.5)
    # 2) 손절: 이 % 이상 손실이면 무조건 손절 (AI가 "보유"라 해도 강제)
    #    HARD_STOP_LOSS_PCT=0 이면 하드손절 비활성 (AI 의견 우선)
    HARD_STOP_LOSS_PCT: float = _env_float("HARD_STOP_LOSS_PCT", 3.0)
    # 3) ★ 거래 비용(왕복 수수료+세금) - 백테스트/전략 생성에 반영 (수익 과대평가 방지)
    #    코스피: 매도세 0.15% + 수수료 ≈ 0.18% / 코스닥: 0.23% + 수수료 ≈ 0.26%
    #    보수적으로 0.2% 사용 (설정으로 조절 가능)
    FEE_ROUND_TRIP_PCT: float = _env_float("FEE_ROUND_TRIP_PCT", 0.2)

    # ── 모의/시뮬레이션 슬리피지 (실제 체결 괴리 보정) ──
    # 실주문이 아닌 경로(DRY_RUN/기록)에서 매수는 +슬리피지, 매도는 -슬리피지 반영 (보수적)
    # 0.15% ≈ 호가 1틱 수준. 실제 모의주문은 키움 체결가 기준이라 미적용
    SLIPPAGE_PCT: float = _env_float("SLIPPAGE_PCT", 0.15)

    # ── ★ 시장(지수) 위험 스위치 - 지수 급락 시 매수 중단/보유 청산 ──
    # 네이버 실시간 코스피 등락률 기준 (키 없이 동작):
    #   정상(≥WARN)  : 진입 정상, 보유는 AI/규칙 판단
    #   주의(≤WARN)  : 신규 진입 중단 (보유는 AI 판단 유지)
    #   위험(≤CRASH) : 신규 진입 중단 + 보유 전부 시장 리스크 청산
    # 0으로 두면 해당 레벨 비활성
    INDEX_ENABLED: bool = os.getenv("INDEX_ENABLED", "true").lower() == "true"
    INDEX_WARN_PCT: float = _env_float("INDEX_WARN_PCT", -1.0)
    INDEX_CRASH_PCT: float = _env_float("INDEX_CRASH_PCT", -2.0)
    # ── ★ 펀더멘털 보충 (영웅문 opt10001 우선 → 네이버 폴백) ──
    #   빠른 데이터는 네이버, PER/PBR/ROE 등 필요한 자료는 영웅문에서 보충
    FUND_ENABLED: bool = os.getenv("FUND_ENABLED", "true").lower() == "true"
    FUND_VALUE_MAX_PER: float = _env_float("FUND_VALUE_MAX_PER", 15.0)  # 버핏 저PER
    FUND_VALUE_MIN_ROE: float = _env_float("FUND_VALUE_MIN_ROE", 8.0)   # 버핏 고ROE

    # ★ 모의 단계: 지수 필터 완전 해제 (하락장에서도 전 조건식 매매 확인)
    #   INDEX_ENABLED=false면 지수 수집만(로그) 하고 진입/청산에 영향 없음
    #   INDEX_EMERGENCY_SELL=true면 danger(-2%)에서 보유 전량 매도 (실전 전환 시 권장)

    # ── ★ 조건식 × 지수 국면 점수제 (나중에 쌓인 데이터로 AI가 판단) ──
    # 진입 시점 지수 등락률을 모든 모의 포지션에 기록 → 표본이 쌓이면
    # 조건식별 "하락장 국면 점수"를 계산(AI 우선, 없으면 규칙) →
    # 점수가 INDEX_COND_MIN_SCORE 미만이면 그 국면(하락)에서 해당 조건식 진입 제한
    # - 표본이 INDEX_COND_MIN_SELLS 미만이면 미평가(제한 없음) - 데이터 쌓일 때까지 허용
    INDEX_COND_ENABLED: bool = os.getenv("INDEX_COND_ENABLED", "true").lower() == "true"
    INDEX_COND_MIN_SCORE: float = _env_float("INDEX_COND_MIN_SCORE", 50)
    # ★ 표본 20건 이상 쌓여야 하락장 점수 평가 (우연한 5건으로 조건식이 잘못 배제되는 것 방지)
    INDEX_COND_MIN_SELLS: int = _env_int("INDEX_COND_MIN_SELLS", 20)

    # ── ★👑 AI 대장주 공략 ──
    # 검색식 신호 종목 중 '오늘 강한 종목(대장주)'만 골라 저점매수 (leader.py)
    #   true: 신호 종목 → 실시간 시세 분석 → 상위 LEADER_MAX개만 진입
    #   false: 기존처럼 신호 종목 전부 진입
    LEADER_ENABLED: bool = os.getenv("LEADER_ENABLED", "true").lower() == "true"
    LEADER_MAX: int = _env_int("LEADER_MAX", 2)           # 선별 종목 수 (한두 종목)
    LEADER_MIN_SCORE: float = _env_float("LEADER_MIN_SCORE", 40)
    LEADER_AI: bool = os.getenv("LEADER_AI", "true").lower() == "true"  # AI 최종 선택
    LEADER_CHG_MAX: float = _env_float("LEADER_CHG_MAX", 15.0)  # 등락률 상한 (과열 제외)
    LEADER_DIP_MIN: float = _env_float("LEADER_DIP_MIN", 1.0)   # 고가 대비 최소 하락폭 %

    # ── ⚡ 장초반 스캘핑 (scalp.py) - 09:00~09:40 빠른 매수/눌림매수/빠른 매도 ──
    # 하이브리드: 분봉은 네이버 실시간, 주문은 OpenAPI+ 있으면 즉시/아니면 키움 REST
    SCALP_ENABLED: bool = os.getenv("SCALP_ENABLED", "true").lower() == "true"
    SCALP_WINDOW_START: str = os.getenv("SCALP_WINDOW_START", "09:00")
    SCALP_WINDOW_END: str = os.getenv("SCALP_WINDOW_END", "09:40")
    SCALP_TP_PCT: float = _env_float("SCALP_TP_PCT", 0.8)          # 빠른 익절 %
    SCALP_SL_PCT: float = _env_float("SCALP_SL_PCT", 0.4)          # 스캘핑 손절 %
    SCALP_MAX_HOLD_MIN: int = _env_int("SCALP_MAX_HOLD_MIN", 25)   # 최대 보유 분
    SCALP_MOMENTUM_CHG: float = _env_float("SCALP_MOMENTUM_CHG", 1.5)  # 오전 강세 %
    SCALP_PULLBACK_PCT: float = _env_float("SCALP_PULLBACK_PCT", 0.5)  # 눌림 기준 %
    SCALP_MAX_POS: int = _env_int("SCALP_MAX_POS", 5)
    SCALP_MAX_QTY: int = _env_int("SCALP_MAX_QTY", 10)

    # ── 같은 종목 추가 매수 ──
    # false(기본): 보유 중인 종목은 재매수 금지 (종목당 1포지션)
    # true: 보유 중이어도 매수 조건 계속 만족하면 추가 매수 (평균단가, 중복 포지션 합산)
    ALLOW_AVERAGING: bool = os.getenv("ALLOW_AVERAGING", "false").lower() == "true"

    # 기본 검사 종목 (CONDITION_SEQ 없을 때)
    # 삼성전자 같은 초대형주는 변동성이 낮아 단타 전략 테스트에 부적합.
    # 변동성 있는 중소형주 + 다양한 섹터로 구성. 커스텀: STOCK_UNIVERSE=종목,종목
    UNIVERSE: list = None

    @property
    def base_url(self) -> str:
        return self.BASE_URL_MOCK if self.USE_MOCK else self.BASE_URL_REAL


CFG = Config()

# ── 기본 검사 종목 세트 (CFG 인스턴스 생성 후 값 채움) ─────────────
_DEFAULT_UNIVERSE = [
    "042700",  # 한미반도체 (반도체 장비)
    "086520",  # 에코프로 (2차전지)
    "247540",  # 에코프로비엠 (2차전지)
    "352820",  # 하이브 (엔터)
    "010130",  # 고려아연 (비철금속)
    "034220",  # LG디스플레이 (디스플레이)
    "011070",  # LG이노텍 (전자부품)
    "028050",  # 삼성엔지니어링 (건설)
]
CFG.UNIVERSE = [s.strip() for s in
                os.getenv("STOCK_UNIVERSE", ",".join(_DEFAULT_UNIVERSE)).split(",") if s.strip()]

if not CFG.APP_KEY or not CFG.APP_SECRET:
    print("[경고] KIWOOM_APP_KEY / KIWOOM_APP_SECRET 이 설정되지 않았습니다. .env 파일을 확인하세요.")
    print("  .env.example 을 참고해서 .env 파일을 생성하세요.")
