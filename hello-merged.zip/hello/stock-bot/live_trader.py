# -*- coding: utf-8 -*-
"""
⚡ 실시간 트레이더 코어 (live_trader.py) — OpenAPI+(영웅문) 기반 실시간 매수/매도
===============================================================================
사용자 목표: "실시간으로 정밀하게 — 장시작 직후 빠르게 사고, 눌림되면 즉시 재매수,
수익/손절 즉시 매도."

이 모듈이 하는 일 (OpenAPI+ 실시간):
  1) 실시간 시세 구독 (SetRealReg) — 현재가/시가/고가/저가/거래량/등락률을 **틱 단위 push**
     → 즉시 스냅샷 저장 + scalp.find_live_entries 로 실시간 판단 → 즉시 주문(SendOrder)
  2) 실시간 체결 통보 (OnReceiveChejan) — 주문 체결 확인 → 포지션 확정
  3) 실시간 조건검색식 (OnReceiveRealCondition) — 키움 검색식 편입 종목 즉시 통보 → 판단
  4) 즉시 주문 (SendOrder) — REST 왕복 없이 영웅문 경유 즉시 체결 시도

운영 모드:
  - OpenAPI+ (Windows + 영웅문 로그인 + pykiwoom) → 실시간
  - 그 외 → REST 폴링 (기존 시스템 그대로 - 자동 폴백, 안전)

실행:
  python live_trader.py --selftest   # 연결/실시간 가능 여부 진단
  python live_trader.py --console    # 실시간 트레이더 콘솔 실행 (전용)
  python live_trader.py --status     # 상태 확인

연동:
  - desktop_app.py: 실시간 모드 버튼 → init_qt() 후 _qt_pump() 로 이벤트 처리
  - scalp.py: 실시간 판단 로직 (find_live_entries) 재사용
"""
import logging
import os
import threading
import time

import db
from config import CFG

log = logging.getLogger("live")

_state = {"connected": False, "mode": "rest", "error": "", "started": False,
          "app": None, "kiwoom": None, "subscribed": set(),
          "callbacks": [], "condition_seqs": [], "account": "",
          "last_price": {}, "last_snapshot": {}}


def is_available():
    """OpenAPI+ 사용 가능 여부: Windows + pykiwoom + PyQt5"""
    if os.name != "nt":
        return False
    try:
        import pykiwoom  # noqa
        import PyQt5  # noqa
        return True
    except Exception:
        return False


def _kiwoom():
    from pykiwoom.kiwoom import Kiwoom
    return Kiwoom()


# ── Qt 이벤트 루프 초기화 (메인 스레드에서 호출 - Tkinter와 공존) ──
def init_qt():
    """QApplication 생성 (없으면). 데스크톱 앱 시작 시 1회 호출.
    이후 process_events() 를 주기적으로 호출해 Qt 이벤트를 펌프.
    """
    if _state["app"] is not None:
        return _state["app"]
    try:
        from PyQt5.QtWidgets import QApplication
        import sys as _s
        app = QApplication.instance() or QApplication(_s.argv or [])
        _state["app"] = app
        return app
    except Exception as e:
        _state["error"] = f"Qt 초기화 실패: {e}"
        return None


def process_events():
    """Qt 이벤트 펌프 (Tkinter after 콜백에서 30~50ms마다 호출)"""
    if _state["app"] is not None:
        try:
            _state["app"].processEvents()
        except Exception:
            pass


# ── OpenAPI+ 연결 + 로그인 ─────────────────────────────
def connect(block=True, timeout=60):
    """영웅문 로그인 (block=True면 로그인 완료까지 대기)
    성공 시 실시간 모드, 실패/불가 시 REST 폴백 (상태만 설정, 예외 없음)
    """
    if _state["connected"]:
        return True
    if not is_available():
        _state["mode"], _state["error"] = "rest", "OpenAPI+ 불가 (Windows+pykiwoom 필요)"
        return False
    try:
        kw = _kiwoom()
        _state["kiwoom"] = kw
        # 실시간 이벤트 시그널 연결
        try:
            kw.OnReceiveRealData.connect(_on_real_data)
            kw.OnReceiveChejan.connect(_on_chejan)
            kw.OnReceiveRealCondition.connect(_on_real_condition)
        except Exception as e:
            log.warning(f"시그널 연결 실패(구버전 pykiwoom일 수 있음): {e}")
        # 로그인 (영웅문 프로그램 필요 - 로그인 창 자동)
        kw.CommConnect(block=True)
        state = kw.GetConnectState()
        if state != 1:
            _state["mode"], _state["error"] = "rest", "영웅문 로그인 안 됨"
            return False
        # 계좌번호
        try:
            accs = kw.GetLoginInfo("ACCNO")
            _state["account"] = (accs or "").split(";")[0].strip()
        except Exception:
            _state["account"] = ""
        _state["connected"] = True
        _state["mode"] = "openapi"
        _state["error"] = ""
        log.info("⚡ OpenAPI+ 실시간 연결 성공")
        return True
    except Exception as e:
        _state["mode"], _state["error"] = "rest", f"OpenAPI+ 연결 실패: {e}"
        log.warning(f"OpenAPI+ 연결 실패 → REST: {e}")
        return False


def disconnect():
    """연결 종료"""
    try:
        if _state["kiwoom"] is not None:
            _state["kiwoom"].DisconnectRealData("1000")
    except Exception:
        pass
    _state["connected"] = False
    _state["mode"] = "rest"
    _state["kiwoom"] = None


# ── 실시간 시세 구독 ───────────────────────────────────
FIDS = "10;11;12;13;15;16;17;18;20;27"  # 현재가/전일/등락률/누적거래량/거래량/시가/고가/저가/체결시간/거래대금


def subscribe(symbols):
    """실시간 시세 구독 (최대 100종목). REST 모드면 False"""
    if not _state["connected"] or _state["kiwoom"] is None:
        return False
    try:
        syms = [s for s in symbols if s not in _state["subscribed"]][:100]
        if syms:
            _state["kiwoom"].SetRealReg("1000", ";".join(syms), FIDS, "0")
            _state["subscribed"].update(syms)
        return True
    except Exception as e:
        log.warning(f"실시간 구독 실패: {e}")
        return False


def _on_real_data(code, real_type, real_data):
    """★ 실시간 시세 수신 (틱 단위 push) → 스냅샷 + 실시간 판단 트리거"""
    kw = _state["kiwoom"]
    if kw is None:
        return
    try:
        price = _fid(kw, code, 10)
        prev_close = _fid(kw, code, 11)
        chg = _fid(kw, code, 12, signed=True)
        cum_vol = _fid(kw, code, 13)
        vol = _fid(kw, code, 15)
        open_p = _fid(kw, code, 16)
        high = _fid(kw, code, 17)
        low = _fid(kw, code, 18)
        amt = _fid(kw, code, 27)
        if not price or price <= 0:
            return
        snap = {"symbol": code, "price": price, "prev_close": prev_close,
                "chg_pct": chg, "volume": cum_vol, "open": open_p,
                "high": high, "low": low, "amount": amt,
                "ts": time.time()}
        _state["last_price"][code] = price
        _state["last_snapshot"][code] = snap
        # DB 스냅샷 저장 (매 틱은 과함 - 5초에 1회만)
        try:
            last_save = getattr(_state, "_last_save", {})
            now = time.time()
            if now - last_save.get(code, 0) >= 5:
                db.record_snapshot(code, price, volume=cum_vol, source="live")
                last_save[code] = now
                _state["_last_save"] = last_save
        except Exception:
            pass
        # 실시간 판단 콜백 호출 (스캘핑/모의매매 전략 연결)
        for cb in list(_state["callbacks"]):
            try:
                cb("quote", snap)
            except Exception:
                pass
    except Exception as e:
        log.warning(f"실시간 시세 처리 실패 {code}: {e}")


def _fid(kw, code, fid, *, signed=False):
    """GetCommRealData 안전 래퍼.

    키움은 일부 FID에 방향 부호를 붙입니다. 현재가/거래량은 절댓값으로
    읽지만 등락률 같은 값은 부호를 보존해야 하락을 상승으로 오인하지 않습니다.
    """
    try:
        v = kw.GetCommRealData(code, fid)
        if v is None or v in ("", "-", "+", "N/A"):
            return 0
        text = str(v).replace(",", "").strip()
        sign = -1 if text.startswith("-") else 1
        text = text.lstrip("+-")
        value = float(text) if text else 0.0
        value = value * sign if signed else abs(value)
        return int(value) if value.is_integer() else value
    except Exception:
        return 0


# ── 실시간 체결 통보 ───────────────────────────────────
def _on_chejan(gubun, item_cnt, fid_list):
    """체결/잔고 통보 → 포지션 확정 + 콜백"""
    kw = _state["kiwoom"]
    if kw is None:
        return
    try:
        code = _chejan_data(kw, "종목코드")
        order_no = _chejan_data(kw, "주문번호")
        qty = _chejan_data(kw, "주문수량")
        price = _chejan_data(kw, "주문가격")
        status = _chejan_data(kw, "주문상태")
        side = _chejan_data(kw, "매도수구분")
        if not code:
            return
        chejan = {"symbol": code, "order_no": order_no, "qty": qty,
                  "price": price, "status": status, "side": side,
                  "gubun": gubun, "ts": time.time()}
        for cb in list(_state["callbacks"]):
            try:
                cb("chejan", chejan)
            except Exception:
                pass
    except Exception as e:
        log.warning(f"체결 통보 처리 실패: {e}")


def _chejan_data(kw, key):
    try:
        v = kw.GetChejanData(kw.GetChejanKey(key))
        if v is None:
            return ""
        s = str(v).strip()
        return s.replace("+", "").replace("-", "")
    except Exception:
        return ""


# ── 실시간 조건검색식 알림 ─────────────────────────────
def register_conditions(condition_seq_list):
    """키움 조건검색식 실시간 등록 (영웅문에서 만든 검색식 인덱스/이름)
    편입 종목 → on_real_condition 콜백 → 전략 판단 트리거
    """
    if not _state["connected"] or _state["kiwoom"] is None:
        return False
    try:
        kw = _state["kiwoom"]
        kw.GetConditionLoad()
        time.sleep(0.3)
        # 조건식 목록에서 이름/인덱스 매칭
        for cond_ref in condition_seq_list:
            try:
                if str(cond_ref).isdigit():
                    idx = int(cond_ref)
                else:
                    idx = _find_cond_index(kw, str(cond_ref))
                if idx is not None:
                    kw.SendCondition("live", idx, 1)  # 1 = 편입통보
                    _state["condition_seqs"].append(idx)
            except Exception as e:
                log.warning(f"조건식 등록 실패 {cond_ref}: {e}")
        return True
    except Exception as e:
        log.warning(f"조건식 실시간 등록 실패: {e}")
        return False


def _find_cond_index(kw, name):
    try:
        lst = kw.GetConditionNameList()
        for item in lst.split(";"):
            if item:
                idx, nm = item.split("*")
                if nm == name:
                    return int(idx)
    except Exception:
        pass
    return None


def _on_real_condition(code, event_type, cond_name, cond_index):
    """조건검색식 실시간 편입/이탈 (code=종목, event=1편입/2이탈)"""
    for cb in list(_state["callbacks"]):
        try:
            cb("condition", {"symbol": code, "event": int(event_type),
                             "cond": cond_name, "ts": time.time()})
        except Exception:
            pass


# ── 즉시 주문 (OpenAPI SendOrder) ──────────────────────
def order(symbol, side, qty, price, order_type="00"):
    """OpenAPI 즉시 주문. REST 모드면 None → 호출측이 REST place_order 사용"""
    if not _state["connected"] or _state["kiwoom"] is None:
        return None
    try:
        if not _state["account"]:
            _state["error"] = "계좌번호 없음 (영웅문 로그인 확인)"
            return None
        kw = _state["kiwoom"]
        order_type_code = "1" if side == "buy" else "2"
        res = kw.SendOrder("live_order", "1000", _state["account"],
                           order_type_code, symbol, int(qty), int(price),
                           order_type, "0")
        if res not in (0, "0"):
            return {"status": "error", "openapi": True, "rq": res, "symbol": symbol,
                    "side": side, "qty": qty, "price": price,
                    "message": f"SendOrder 반환코드 {res}"}
        return {"status": "sent", "openapi": True, "rq": res, "symbol": symbol,
                "side": side, "qty": qty, "price": price}
    except Exception as e:
        log.warning(f"OpenAPI 주문 실패 {symbol}: {e}")
        return None


def get_fundamentals(symbol):
    """★ 영웅문(opt10001) 펀더멘털 보충 - 미연결이면 None → 호출측이 네이버 폴백"""
    if not is_realtime():
        return None
    try:
        import fundamentals as _f
        return _f.openapi_fundamentals(symbol, _state["kiwoom"])
    except Exception:
        return None


def get_investor_flow(symbol):
    """★ 영웅문 투자자 수급 보충 (미연결이면 None)"""
    if not is_realtime():
        return None
    try:
        import fundamentals as _f
        return _f.openapi_investor_flow(symbol, _state["kiwoom"])
    except Exception:
        return None


def _order_accepted(result) -> bool:
    """실시간 주문 응답이 접수된 경우에만 내부 장부를 갱신합니다."""
    if not isinstance(result, dict):
        return False
    status = str(result.get("status", "")).lower()
    if status in {"error", "rejected", "cancelled", "failed", "dry_run_skipped"}:
        return False
    return status in {"ok", "success", "sent", "queued", "filled", "accepted"} or result.get("rq") in (0, "0")


def enable_auto_strategy(max_new=3, max_qty=None, cooldown=10, use_ai=True):
    """실시간 시세 수신 시 자동 판단/주문 활성화
    - 매수: scalp.find_live_entries (강세/눌림) → 즉시 OpenAPI 주문
    - 매도: 실시간 수익률 TP/SL 즉시 판단 (scalp.check_scalp_exit)
    - 중복 방지: paper_positions open 체크 + 쿨다운
    - AI(use_ai): 매수 전 AI 최종 확인 (없으면 규칙)
    반환: 핸들러 등록 여부 (REST 모드면 False)
    """
    if not is_realtime():
        return False
    import scalp
    auto = {"last": {}, "cooldown": cooldown, "max_new": max_new,
            "max_qty": max_qty or int(getattr(CFG, "SCALP_MAX_QTY", 10))}

    def handler(kind, data):
        try:
            if kind == "quote":
                sym = data["symbol"]
                now = time.time()
                if now - auto["last"].get(sym, 0) < auto["cooldown"]:
                    return
                # ── 매수 신호 (강세/눌림 - 틱 즉시) ──
                if db.count_paper_open() < 50:
                    sigs = scalp.find_live_entries(
                        data["price"], open_price=data["open"] or 0,
                        high=data["high"] or 0, low=data["low"] or 0,
                        prev_close=data["prev_close"] or 0,
                        volume=data["volume"] or 0)
                    if sigs and not db.paper_has_open(sym):
                        s = sigs[0]
                        # AI 최종 확인 (선택)
                        if use_ai:
                            try:
                                from ai_judge import evaluate_buy
                                enr = {"price": s["price"], "현재가": s["price"],
                                       "전일고가": (data["prev_close"] or s["price"]) * 1.02,
                                       "전일저가": (data["prev_close"] or s["price"]) * 0.98,
                                       "전일종가": data["prev_close"] or s["price"],
                                       "체결강도": 120, "최근1분거래대금": (data["amount"] or 0) / max(1, data["volume"] or 1),
                                       "최근3분거래대금": (data["amount"] or 0), "저가": data["low"] or s["price"],
                                       "고점갱신": False, "거래대금동시증가": True, "중심선아래약세": False}
                                ok, _r = evaluate_buy(sym, enr)
                                if not ok:
                                    auto["last"][sym] = now
                                    return
                            except Exception:
                                pass
                        qty = min(auto["max_qty"], 10)
                        r = order(sym, "buy", qty, s["price"])
                        if not _order_accepted(r):
                            auto["last"][sym] = now
                            log.warning(f"⚠️ [실시간 매수] {sym} 주문 미접수: {(r or {}).get('message', '응답 없음')}")
                            return
                        db.open_paper_position(f"LIVE-{s['type']}", f"[실시간] {s['reason']}",
                                               sym, s["price"], qty,
                                               order_kind="real")
                        auto["last"][sym] = now
                        log.info(f"⚡ [실시간 매수] {sym} {qty}주 @{s['price']:,.0f} | {s['reason']}")
                # ── 매도 판단 (실시간 보유 종목) ──
                for pos in db.get_paper_open():
                    if pos["symbol"] != sym:
                        continue
                    try:
                        hold_min = int((time.time() -
                                        __import__("datetime").datetime.fromisoformat(
                                            pos["entry_time"]).timestamp()) / 60)
                    except Exception:
                        hold_min = 0
                    ex, reason = scalp.check_scalp_exit(
                        pos["entry_price"], (pos.get("highest_return") or 0),
                        data["price"], hold_min)
                    if ex:
                        r = order(sym, "sell", pos["qty"], data["price"])
                        if not _order_accepted(r):
                            log.warning(f"⚠️ [실시간 매도] {sym} 주문 미접수: {(r or {}).get('message', '응답 없음')}")
                            continue
                        db.close_paper_position(pos["id"], data["price"],
                                                (data["price"] / pos["entry_price"] - 1) * 100,
                                                reason=f"[실시간] {reason}")
                        log.info(f"⚡ [실시간 매도] {sym} | {reason}")
            elif kind == "chejan":
                log.info(f"[체결] {data.get('symbol')} {data.get('side')} {data.get('qty')}주 "
                         f"@{data.get('price')} ({data.get('status')})")
        except Exception as e:
            log.warning(f"실시간 전략 오류: {e}")

    on_event(handler)
    return True


# ── 상태/콜백 ──────────────────────────────────────────
def on_event(cb):
    """실시간 이벤트 콜백 등록: cb(kind, data) kind: quote/chejan/condition"""
    if cb not in _state["callbacks"]:
        _state["callbacks"].append(cb)


def is_realtime():
    return _state["connected"] and _state["mode"] == "openapi"


def mode():
    return _state["mode"] if _state["connected"] else _state["mode"]


def get_error():
    return _state["error"]


def latest_price(symbol):
    """실시간 최근가 (구독 중이면 즉시, 아니면 None)"""
    return _state["last_price"].get(symbol)


def latest_snapshot(symbol):
    return _state["last_snapshot"].get(symbol)


def status_text():
    if is_realtime():
        return f"⚡ 실시간(OpenAPI+) 구독{len(_state['subscribed'])}개"
    return f"📡 REST 폴링 ({_state['error'][:40] if _state['error'] else '실시간 비활성'})"


# ── 콘솔 실행 (전용 실시간 트레이더) ────────────────────
def run_console(symbols=None):
    """단독 실행: 실시간 구독 + 실시간 판단(스캘핑) + 즉시 주문"""
    import scalp
    print("=" * 60)
    print("⚡ 실시간 트레이더 (OpenAPI+)")
    print("=" * 60)
    if not connect():
        print(f"  실시간 불가 → REST 폴백: {get_error()}")
        print("  (기존 REST 시스템으로 계속 운영됩니다)")
        return
    print(f"  계좌: {_state['account'] or '(조회 실패)'}")
    if symbols:
        subscribe(symbols)
        print(f"  실시간 구독: {len(symbols)}개")
    print("  Ctrl+C 종료")
    print("=" * 60)

    def handler(kind, data):
        if kind == "quote":
            sym = data["symbol"]
            # ★ 실시간 판단 → 즉시 주문
            sigs = scalp.find_live_entries(
                data["price"], open_price=data["open"] or 0,
                high=data["high"] or 0, low=data["low"] or 0,
                prev_close=data["prev_close"] or 0,
                volume=data["volume"] or 0)
            if sigs:
                s = sigs[0]
                print(f"[{time.strftime('%H:%M:%S')}] ⚡ {sym} 신호: {s['reason']} "
                      f"→ 주문 시도 @{s['price']:,.0f}")
                r = order(sym, "buy", 1, s["price"])
                print(f"    주문 결과: {r.get('status', '?') if r else '(REST 폴백 필요)'}")
        elif kind == "chejan":
            print(f"[체결] {data['symbol']} {data['side']} {data['qty']}주 @{data['price']} "
                  f"({data['status']})")

    on_event(handler)
    # Qt 이벤트 루프 (콘솔: 메인에서 직접 실행)
    if _state["app"] is None:
        init_qt()
    try:
        _state["app"].exec_()
    except KeyboardInterrupt:
        pass
    finally:
        disconnect()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="실시간 트레이더")
    parser.add_argument("--selftest", action="store_true")
    parser.add_argument("--console", action="store_true")
    parser.add_argument("--status", action="store_true")
    parser.add_argument("--symbols", default="", help="구독 종목 (콤마)")
    args = parser.parse_args()
    db.init_db()
    logging.basicConfig(level=logging.INFO)
    if args.selftest:
        print("=" * 60)
        print("⚡ 실시간 트레이더 자가진단")
        print("=" * 60)
        print(f"  OpenAPI+ 가능(Windows+pykiwoom): {'✅' if is_available() else '❌ (REST 폴백)'}")
        print(f"  연결 시도: {connect()}")
        print(f"  상태: {status_text()}")
        print(f"  상세: {get_error() or '정상'}")
        print()
        print("  [실시간 모드 준비물]")
        print("   1. 영웅문 설치 + 로그인 (프로그램 켜둔 채)")
        print("   2. pip install pykiwoom PyQt5")
        print("   3. python live_trader.py --selftest  → '⚡ 실시간' 확인")
    elif args.console:
        syms = [s for s in args.symbols.split(",") if s] or None
        run_console(syms)
    elif args.status:
        print(status_text())
        print(f"  구독: {len(_state['subscribed'])}개 · 계좌: {_state['account'] or '-'}")
    else:
        parser.print_help()
