@echo off
title SETUP - One Shot Install
cd /d "%~dp0"
echo.
echo ============================================================
echo   [1/5] Python check (MUST be 32bit)
echo ============================================================
python --version
python -c "import struct; print('bit:', struct.calcsize('P')*8)"
echo.
echo ============================================================
echo   [2/5] Upgrade pip
echo ============================================================
python -m pip install --upgrade pip
echo.
echo ============================================================
echo   [3/5] Install base packages
echo ============================================================
pip install requests pillow matplotlib python-dotenv
echo.
echo ============================================================
echo   [4/5] Create .env from .env.example (if missing)
echo ============================================================
if not exist ".env" (
    copy ".env.example" ".env" >nul
    echo   .env created - EDIT IT NOW (keys/account) before running!
) else (
    echo   .env already exists - keep it
)
echo.
echo ============================================================
echo   [5/5] Verify system
echo ============================================================
python verify_final.py
echo.
echo   DONE! Next:
echo     - Edit .env (appkey/secret/account/gemini key)
echo     - python collect_data.py --once
echo     - python desktop_app.py
echo ============================================================
pause
