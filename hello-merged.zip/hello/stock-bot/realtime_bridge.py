# -*- coding: utf-8 -*-
"""
⚡ 실시간 브리지 (realtime_bridge.py) — OpenAPI+(영웅문) ↔ REST 하이브리드
=========================================================================
목표: 장초반(09:00~09:30) 빠른 매수/눌림매수/빠른 매도를 위한 실시간 트리거.

동작:
  - Windows + 영웅문 로그인 + pykiwoom 사용 가능 → OpenAPI+ 실시간 모드
    (실시간 시세 구독, 실시간 체결 통보, 실시간 조건검색식 알림, 즉시 주문)
  - 아니면(리눅스/영웅문 없음/연결 실패) → REST 폴링 모드 (기존 방식 그대로)
  - 두 모드 모두 '두뇌'(scalp.py, paper_test.py)는 동일 - 데이터 소스만 다름

모드 확인:
  python realtime_bridge.py            # 현재 브리지 상태
  python realtime_bridge.py --selftest # 연결/폴백 자가진단

주의: pykiwoom은 Windows + 32bit Python + 영웅문 로그인이 필요합니다.
      이 파일은 실패 시 조용히 REST 모드로 폴백하므로 어느 환경에서도 안전.
"""
import logging
import os
import time

log = logging.getLogger("bridge")

# ── 모드 ──
MODE_REST = "rest"          # 폴링 (기본 - 서버/리눅스/영웅문 없음)
MODE_OPENAPI = "openapi"    # 실시간 (Windows + 영웅문 + pykiwoom)

_state = {"mode": MODE_REST, "connected": False, "error": "", "kiwoom": None, "account": ""}


def _try_import_pykiwoom():
    """pykiwoom 사용 가능 여부 (Windows 전용)"""
    try:
        if os.name != "nt":
            return None, "Windows가 아님 (리눅스/맥) - REST 모드"
        import pykiwoom
        return pykiwoom, ""
    except Exception as e:
        return None, f"pykiwoom 없음: {e}"


def connect(timeout=30):
    """OpenAPI+ 연결 시도. 실패 시 REST 모드로 폴백. (멱등 - 여러 번 호출 안전)"""
    if _state["connected"]:
        return _state["mode"]
    pyk, err = _try_import_pykiwoom()
    if pyk is None:
        _state["mode"], _state["error"] = MODE_REST, err
        return MODE_REST
    try:
        # 영웅문 로그인 대기 (사용자가 영웅문에서 로그인해야 함)
        from pykiwoom.kiwoom import Kiwoom
        kw = Kiwoom()
        kw.CommConnect(block=True)  # 로그인 창 뜸/자동
        state = kw.GetConnectState()
        if state != 1:
            _state["mode"], _state["error"] = MODE_REST, "영웅문 로그인 안 됨"
            return MODE_REST
        accounts = str(kw.GetLoginInfo("ACCNO") or "").split(";")
        account = next((a.strip() for a in accounts if a.strip()), "")
        if not account:
            _state["mode"], _state["error"] = MODE_REST, "로그인 계좌번호 없음"
            return MODE_REST
        _state["kiwoom"], _state["mode"], _state["connected"], _state["account"] = kw, MODE_OPENAPI, True, account
        _state["error"] = ""
        log.info("⚡ OpenAPI+ 연결 성공 (실시간 모드)")
        return MODE_OPENAPI
    except Exception as e:
        _state["mode"], _state["error"] = MODE_REST, f"OpenAPI+ 연결 실패: {e}"
        log.warning(f"OpenAPI+ 연결 실패 → REST 폴백: {e}")
        return MODE_REST


def mode():
    """현재 모드 (connect를 한 번은 부른 뒤 사용)"""
    return _state["mode"]


def is_realtime():
    return _state["mode"] == MODE_OPENAPI and _state["connected"]


def get_error():
    return _state["error"]


# ── 실시간 시세 ─────────────────────────────────────────
def subscribe_quotes(symbols):
    """실시간 시세 구독 (OpenAPI 모드). REST 모드면 no-op.
    이후 current_price(symbol) 로 즉시 조회 가능.
    """
    if not is_realtime():
        return False
    try:
        fids = [10, 11, 12, 13, 14, 15, 20, 27, 28]  # 현재가/전일/시가/고가/저가/거래량 등
        for sym in symbols[:100]:
            _state["kiwoom"].SetRealReg("1000", sym, ";".join(map(str, fids)), "0")
        return True
    except Exception as e:
        log.warning(f"실시간 구독 실패: {e}")
        return False


def current_price(symbol):
    """실시간 현재가 (OpenAPI) - 실패 시 None → 호출측이 REST 폴백"""
    if not is_realtime():
        return None
    try:
        v = _state["kiwoom"].GetMasterCurrentPrice(symbol)
        if v:
            return int(str(v).replace(",", ""))
    except Exception:
        pass
    return None


def realtime_minute_close(symbol):
    """실시간 분봉 종가 (OpenAPI) - 실패 시 None"""
    if not is_realtime():
        return None
    try:
        v = _state["kiwoom"].GetCommData("opt10080", 0, 0, "현재가")
        return int(str(v).replace(",", "")) if v else None
    except Exception:
        return None


# ── 실시간 조건검색식 알림 ──────────────────────────────
def register_condition_alerts(condition_seq_list, on_hit):
    """키움 조건검색식 실시간 알림 등록 (OpenAPI 모드)
    on_hit(cond_seq, symbol_list) 콜백 - 조건에 걸린 종목을 두뇌가 판단/주문
    REST 모드면 False (두뇌가 기존 슬롯 폴링으로 대체)
    """
    if not is_realtime():
        return False
    try:
        kw = _state["kiwoom"]
        # 조건식 목록
        kw.GetConditionLoad()
        for seq in condition_seq_list:
            kw.SendCondition("scalp", str(seq), 1)  # 1=편입통보
        # 체결/조건 이벤트는 pykiwoom의 이벤트 루프에서 처리.
        # 조건검색식 결과는 GetCommData/OnReceiveRealCondition 으로 수신됨.
        log.info(f"실시간 조건식 등록: {condition_seq_list}")
        return True
    except Exception as e:
        log.warning(f"조건식 알림 등록 실패: {e}")
        return False


# ── 주문 (OpenAPI 즉시 주문) ────────────────────────────
def order(symbol, side, qty, price, order_type="00"):
    """OpenAPI 즉시 주문. REST 모드면 None → 호출측이 REST place_order 사용"""
    if not is_realtime():
        return None
    try:
        kw = _state["kiwoom"]
        rq = "buy" if side == "buy" else "sell"
        if not _state.get("account"):
            log.warning("OpenAPI 주문 실패: 계좌번호가 없습니다")
            return None
        res = kw.SendOrder("scalp_order", "1000", _state["account"],
                           "1" if rq == "buy" else "2", symbol, int(qty),
                           int(price), order_type, "0")
        if res not in (0, "0", None):
            log.warning(f"OpenAPI 주문 미접수: 반환코드={res}")
            return None
        if res is None:
            log.warning("OpenAPI 주문 미접수: 반환코드 없음")
            return None
        return {"status": "accepted", "openapi": True, "rq": res, "symbol": symbol,
                "side": side, "qty": qty, "price": price}
    except Exception as e:
        log.warning(f"OpenAPI 주문 실패: {e}")
        return None


def get_chejan():
    """실시간 체결 확인 (OpenAPI) - 최근 체결 1건 or None"""
    if not is_realtime():
        return None
    try:
        kw = _state["kiwoom"]
        # pykiwoom은 이벤트로 받는 게 일반적. 여기서는 스냅샷 조회로 폴백.
        return None
    except Exception:
        return None


def status_text():
    """브리지 상태 요약 (UI/로그용)"""
    if is_realtime():
        return "⚡ 실시간(OpenAPI+)"
    if _state["mode"] == MODE_REST:
        err = _state["error"]
        return f"📡 REST 폴링 (실시간 불가: {err[:40]})"
    return f"📡 {_state['mode']}"


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="실시간 브리지 상태")
    parser.add_argument("--selftest", action="store_true")
    args = parser.parse_args()
    print("=" * 56)
    print("⚡ 실시간 브리지 (OpenAPI+ ↔ REST 하이브리드)")
    print("=" * 56)
    if args.selftest:
        m = connect()
        print(f"  연결 시도 결과: {m}")
        print(f"  상태: {status_text()}")
        print(f"  상세: {get_error() or '정상'}")
        print()
        print("  [참고] OpenAPI+ 모드 조건:")
        print("   - Windows + 32bit Python + pykiwoom 설치")
        print("   - 영웅문 프로그램 실행 + 로그인")
        print("   - 그 외 환경은 자동으로 REST 폴링 모드")
    else:
        print(f"  현재 모드: {mode()}")
        print(f"  상태: {status_text()}")
