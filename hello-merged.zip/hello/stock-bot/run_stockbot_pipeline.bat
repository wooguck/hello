@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] New quant environment not found:
    echo %CD%\.venv\Scripts\python.exe
    pause
    exit /b 1
)

set "SYMBOL=%~1"
if "%SYMBOL%"=="" set "SYMBOL=005930"

echo [INTEGRATED] StockBot pipeline started: %SYMBOL%
".venv\Scripts\python.exe" -m quant_platform.orchestrator --symbol "%SYMBOL%"
set "RC=%ERRORLEVEL%"

if not "%RC%"=="0" (
    echo.
    echo [FAILED] Check errors\latest.json and reports\ for details.
    pause
    exit /b %RC%
)

echo.
echo [DONE] Integrated report is under reports\
pause
