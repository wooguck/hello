"""백테스트 & 자체 테스트 모듈

- run_backtest(params, symbol, days): 키움 차트 데이터로 전략 신호 과거 재현
- self_test(): 시스템 전체 자체 점검
- demo_backtest(): 키 없이도 동작하는 모의 백테스트 (랜덤 캔들)

실행:
    python backtest.py                 # 전체 자체 테스트
    python backtest.py --symbol 005930 # 삼성전자 백테스트 (차트 API 필요)
"""
import json
import logging
import random
import argparse
import os
from datetime import datetime

import db
from config import CFG
from strategy import (random_params, calc_indicators, evaluate_entry, evaluate_exit,
                      compute_fitness, fill_default_params)

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("backtest")


def test_conditions_snapshot():
    """
    ★ 테스트 재현용 조건 스냅샷 - 백테스트 결과(note)에 저장
    나중에 "같은 조건으로 다시 테스트"할 때 그 시점의 조건을 정확히 알 수 있게:
      - 적용된 자동 전략(version:rule_id) / 매수 신뢰도 임계값 / 거래 비용 / 감시 모드
    """
    parts = []
    try:
        import json as _json
        with open(os.path.join("strategy", "auto_strategy.json"), encoding="utf-8") as f:
            st = _json.load(f)
        parts.append(f"자동전략 v{st.get('version', '?')}:{st.get('rule_id', '-')}")
    except Exception:
        parts.append("자동전략:없음")
    parts.append(f"신뢰도{getattr(CFG, 'AI_BUY_CONFIDENCE_THRESHOLD', 70)}%")
    parts.append(f"수수료{getattr(CFG, 'FEE_ROUND_TRIP_PCT', 0.2)}%")
    parts.append(f"감시모드:{getattr(CFG, 'WATCH_MODE', '급등')}")
    return " | ".join(parts)


def _mock_candles(days=60, seed=None):
    """키 없이 테스트용 랜덤 캔들 생성 (오래된순)
    seed를 주면 같은 조건으로 재현 가능 (시드 고정)
    """
    if seed is not None:
        random.seed(seed)
    candles = []
    base = random.randint(30000, 120000)
    for _ in range(days):
        change_pct = random.uniform(-3, 3) / 100
        base = max(1000, base * (1 + change_pct))
        high = base * (1 + random.uniform(0, 0.02))
        low = base * (1 - random.uniform(0, 0.02))
        candles.append({
            "close": round(base), "high": round(high), "low": round(low),
            "volume": random.randint(50000, 800000),
        })
    return candles


def _real_candles(symbol, days=60):
    """키움 차트 API로 실제 캔들 가져오기"""
    from kiwoom_client import client
    chart_raw = client.get_chart_daily(symbol)
    candles = []
    if isinstance(chart_raw, dict):
        for key in ["stk_dt_pole_chart_qry", "chart", "data", "output", "items"]:
            if key in chart_raw and isinstance(chart_raw[key], list):
                candles = chart_raw[key]
                break
    if not candles:
        return []
    out = []
    for c in candles[:days]:
        # ★ ka10081(일봉) 응답: stk_clpr(종가) 등 키움 표준 필드 우선
        close = (c.get("stk_clpr") or c.get("cur_prc") or c.get("close_prc")
                 or c.get("close") or 0)
        high = c.get("stk_hgpr") or c.get("high_pric") or c.get("high") or close
        low = c.get("stk_lwpr") or c.get("low_pric") or c.get("low") or close
        volume = c.get("cntg_vol") or c.get("trde_qty") or c.get("volume") or 0
        try:
            out.append({"close": float(str(close).replace(",", "").replace("+", "")),
                        "high": float(str(high).replace(",", "").replace("+", "")),
                        "low": float(str(low).replace(",", "").replace("+", "")),
                        "volume": float(str(volume).replace(",", ""))})
        except Exception:
            continue
    out.reverse()
    return out


def run_backtest(params=None, symbol="005930", days=60, use_real_data=False, is_out_of_sample=0, seed=None):
    """
    과거 캔들로 전략 신호 재현 백테스트
    - AI_JUDGE_ENABLED면 ai_judge(프롬프트) 판단, 아니면 params 판단
    - seed를 주면 params + 랜덤 캔들 모두 고정 → 같은 조건 재현 가능
    반환: 결과 dict (DB에 자동 저장됨)
    """
    if seed is not None:
        random.seed(seed)
    if params is None:
        params = random_params()
    else:
        params = fill_default_params(params)

    candles = _real_candles(symbol, days) if use_real_data else _mock_candles(days, seed=seed)
    if len(candles) < 30:
        candles = _mock_candles(days, seed=seed)

    # AI 판단 사용 여부 (엔진과 동일 로직)
    use_ai = False
    try:
        from config import CFG as _CFG
        from ai_judge import evaluate_buy_rule_based, evaluate_sell_rule_based, enrich_market_data
        use_ai = _CFG.AI_JUDGE_ENABLED
    except Exception:
        use_ai = False

    trades = []
    entry_price = None
    entry_idx = 0
    for i in range(max(20, days - 20), len(candles)):
        window = candles[:i + 1]
        indicators = calc_indicators(window)
        price = indicators.get("price", candles[i]["close"])
        md = {"price": price, "rsi_14": indicators.get("rsi_14", 50),
              "volume_ratio": 1.5, "체결강도": 120, "chegyul": 120,
              "ema_12": indicators.get("ema_12", price), "ema_26": indicators.get("ema_26", price * 0.99),
              "ema_fast": indicators.get("ema_12", price), "ema_slow": indicators.get("ema_26", price * 0.99),
              "전일고가": price * 1.02, "전일저가": price * 0.98, "전일종가": price * 1.0,
              "저가": price * 0.99, "고점갱신": True, "중심선아래약세": False,
              "거래대금동시증가": True, "최근1분거래대금": 300_000_000, "최근3분거래대금": 600_000_000}

        if entry_price is None:
            try:
                if use_ai:
                    enriched = enrich_market_data(md)
                    is_buy, _r, _s = evaluate_buy_rule_based(enriched)
                else:
                    is_buy = evaluate_entry(params, md)
                if is_buy:
                    entry_price = price
                    entry_idx = i
            except Exception:
                continue
        else:
            holding_days = (i - entry_idx)
            try:
                if use_ai:
                    enriched = enrich_market_data(md)
                    pos = {"entry_price": entry_price, "highest_return": 1.0,
                           "holding_minutes": holding_days * 24 * 60}
                    decision, _r2 = evaluate_sell_rule_based(enriched, pos)
                    should_sell = decision in ("수익청산", "손절")
                else:
                    should_sell = evaluate_exit(params, md, entry_price, int(holding_days))
                if should_sell:
                    ret = (price - entry_price) / entry_price * 100
                    trades.append({"entry": entry_price, "exit": price, "ret": ret})
                    entry_price = None
            except Exception:
                continue

    if entry_price is not None:
        last = candles[-1]["close"]
        ret = (last - entry_price) / entry_price * 100
        trades.append({"entry": entry_price, "exit": last, "ret": ret})

    n = len(trades)
    wins = sum(1 for t in trades if t["ret"] > 0)
    win_rate = wins / n * 100 if n else 0
    total_return = sum(t["ret"] for t in trades) if n else 0
    avg_return = total_return / n if n else 0

    # MDD 계산
    equity, peak, mdd = 0, 0, 0
    for t in trades:
        equity += t["ret"]
        peak = max(peak, equity)
        mdd = max(mdd, peak - equity)

    result = {
        "params": params,
        "symbol": symbol,
        "period_days": days,
        "trade_count": n,
        "win_rate": round(win_rate, 2),
        "total_return": round(total_return, 2),
        "max_drawdown": round(mdd, 2),
        "avg_return": round(avg_return, 2),
        "is_out_of_sample": is_out_of_sample,
        "use_real_data": use_real_data,
    }

    note = "실데이터" if use_real_data else f"모의랜덤 seed={seed}"
    # ★ 테스트 조건 스냅샷 추가 (나중에 같은 조건 재현용)
    note += f" | {test_conditions_snapshot()}"
    db.save_backtest_result(params, symbol, days, n, win_rate, total_return, mdd, avg_return, note)
    return result


def self_test():
    """전체 시스템 자체 테스트"""
    print("=" * 56)
    print("🤖 시스템 자체 테스트 (SELF TEST)")
    print("=" * 56)

    # 1. DB
    print("\n[1/6] DB 점검")
    result = db.self_test()
    for name, ok in result["checks"]:
        print(f"  {'✅' if ok else '❌'} {name}")
    if result["problems"]:
        print("  문제:", result["problems"])
    if not result["ok"]:
        return False

    # 2. 유전알고리즘
    print("\n[2/6] 유전알고리즘 점검")
    from genetic import select_survivors, crossover, mutate, next_generation
    import strategy
    p1, p2 = strategy.random_params(), strategy.random_params()
    child = crossover(p1, p2)
    mutated = mutate(child, 0.5)
    survivors = select_survivors(
        [{"id": 1, "params": p1, "fitness": 1.5}, {"id": 2, "params": p2, "fitness": -999.0}], 1)
    ng = next_generation(survivors, 5, 0.2)
    print(f"  ✅ crossover/mutate/select/next_generation 동작 (다음세대 {len(ng)}개)")

    # 3. 전략 평가
    print("\n[3/6] 전략 평가 점검")
    fitness = compute_fitness(0.6, 1.5, 5.0, 30, 20)
    fitness_low = compute_fitness(0.6, 1.5, 5.0, 5, 20)
    print(f"  ✅ fitness(거래30건)={fitness:.3f} / fitness(거래5건)={fitness_low:.1f} (표본부족=-999 정상)")

    # 4. 백테스트 (모의)
    print("\n[4/6] 백테스트 점검 (모의 랜덤 데이터)")
    bt = run_backtest(days=60)
    print(f"  ✅ 거래 {bt['trade_count']}건 / 승률 {bt['win_rate']}% / 수익 {bt['total_return']}% / MDD {bt['max_drawdown']}%")

    # 5. AI 판단
    print("\n[5/6] AI 매수/매도 판단 점검")
    try:
        from ai_judge import evaluate_buy_rule_based, evaluate_sell_rule_based
        md = {"price": 50000, "전일고가": 49000, "전일저가": 48000, "전일종가": 49500,
              "체결강도": 150, "최근1분거래대금": 1_000_000_000, "최근3분거래대금": 2_000_000_000,
              "저가": 49500, "고점갱신": True, "거래대금동시증가": True, "중심선아래약세": False}
        enriched = __import__("ai_judge").enrich_market_data(md)
        is_buy, reason, score = evaluate_buy_rule_based(enriched)
        decision, reason2 = evaluate_sell_rule_based(enriched, {"entry_price": 49000, "highest_return": 3.0})
        print(f"  ✅ 매수 판단: {is_buy} (score={score}) / 매도 판단: {decision}")
    except Exception as e:
        print(f"  ⚠️ AI 판단 점검 생략: {e}")

    # 6. 스냅샷 저장
    print("\n[6/6] 시세 스냅샷 저장 점검")
    ok = db.record_snapshot("005930", 50000, volume=100000, chegyul=120, rsi=50)
    print(f"  {'✅' if ok else '❌'} 스냅샷 저장 {'성공' if ok else '실패'}")

    print("\n" + "=" * 56)
    print("🎉 자체 테스트 완료 - 시스템 정상")
    print("=" * 56)
    return True


def _simulate_from_minutes(minutes, fee_pct=None):
    """
    ★ 분봉 기반 단타 신호 재현 (감시 후보 50종목 분봉 테스트용)
    - 분봉: [{bar_time, price, volume}, ...] 오래된순 (네이버 분봉 저장 데이터)
    - 진입: 3분 연속 상승 + 거래량 1.5배↑ (장중 모멘텀)
    - 청산: -0.8% 손절 / +1.2% 익절 / 15분 경과 시 청산 (단타 규칙)
    - 거래 비용 반영 (수익 과대평가 방지)
    - 데이터가 매일 누적되면 기간이 늘어나면서 신뢰도 상승 (당장은 7일치 = 샘플 적음)
    """
    if fee_pct is None:
        fee_pct = float(getattr(CFG, "FEE_ROUND_TRIP_PCT", 0.2))
    trades = []
    entry = None
    entry_i = 0
    for i in range(1, len(minutes)):
        p = minutes[i]["price"]
        v = minutes[i].get("volume") or 0
        vprev = minutes[i - 1].get("volume") or 0
        if entry is None:
            if i >= 3:
                up3 = all(minutes[j]["price"] > minutes[j - 1]["price"]
                          for j in range(i - 2, i + 1))
                if up3 and v > vprev * 1.5 and p > 0:
                    entry = p
                    entry_i = i
        else:
            ret = (p - entry) / entry * 100
            if ret <= -0.8 or ret >= 1.2 or (i - entry_i) >= 15:
                trades.append({"entry": entry, "exit": p, "ret": ret})
                entry = None
    if entry is not None:
        last = minutes[-1]["price"]
        trades.append({"entry": entry, "exit": last,
                       "ret": (last - entry) / entry * 100})
    # 거래 비용 차감
    for t in trades:
        t["ret"] -= fee_pct
    n = len(trades)
    wins = sum(1 for t in trades if t["ret"] > 0)
    win_rate = wins / n * 100 if n else 0
    total_return = sum(t["ret"] for t in trades) if n else 0
    avg_return = total_return / n if n else 0
    return {"trade_count": n, "win_rate": round(win_rate, 2),
            "total_return": round(total_return, 2),
            "avg_return": round(avg_return, 2),
            "max_drawdown": 0.0}


def run_backtest_on_minutes(symbols=None, days=30, limit=50):
    """
    ★ 분봉 단타 백테스트: 감시 후보 50종목(또는 지정)의 분봉으로 신호 재현
    - 분봉 데이터가 쌓인 기간(현재 최대 7일, 매일 누적되면 1개월+) 내에서만
    - 반환: {summary, results:[{symbol,name,분봉수,거래,승률,평균%}...], note}
    """
    from db import get_minute_bars, get_symbol_name
    if symbols is None:
        try:
            from engine import get_watch_candidates
            symbols = [c["symbol"] for c in get_watch_candidates(limit=limit)]
        except Exception:
            symbols = []
    if not symbols:
        # 분봉 있는 종목으로 대체
        syms = db.get_minute_symbols(days=8)
        symbols = syms[:limit]
    results = []
    total_trades = total_wins = 0
    for sym in symbols[:limit]:
        bars = get_minute_bars(sym, days=days)
        if len(bars) < 20:
            continue
        sim = _simulate_from_minutes(bars)
        results.append({"symbol": sym, "name": get_symbol_name(sym),
                        "bars": len(bars), **sim})
        total_trades += sim["trade_count"]
        total_wins += round(sim["trade_count"] * sim["win_rate"] / 100)
    n_sym = len(results)
    win_rate = total_wins / total_trades * 100 if total_trades else 0
    return {
        "summary": {"symbols": n_sym, "trades": total_trades,
                    "win_rate": round(win_rate, 2),
                    "avg_return": round(sum(r["avg_return"] for r in results) / n_sym, 2) if n_sym else 0,
                    "days": days},
        "results": sorted(results, key=lambda r: -r["trade_count"]),
        "note": (f"분봉 단타 백테스트: {n_sym}종목 × 분봉 {days}일치 누적분 "
                 f"(수수료 {getattr(CFG, 'FEE_ROUND_TRIP_PCT', 0.2)}% 차감) | "
                 f"{test_conditions_snapshot()}"),
    }


def _simulate_from_snapshots(snaps, params):
    """스냅샷 리스트로 신호 재현 시뮬레이션 (공통 코어 - 빠름, API 불필요)"""
    trades = []
    entry_price = None
    entry_idx = 0
    for i in range(1, len(snaps)):
        s = snaps[i]
        price = s.get("price") or 0
        if price <= 0:
            continue
        md = {
            "price": price,
            "체결강도": s.get("chegyul") or 100,
            "chegyul": s.get("chegyul") or 100,
            "rsi_14": s.get("rsi") or 50,
            "rsi": s.get("rsi") or 50,
            "ema_fast": s.get("ema_fast") or price,
            "ema_slow": s.get("ema_slow") or price * 0.99,
            "volume_ratio": s.get("volume_ratio") or 1.5,
            "최근1분거래대금": price * (s.get("volume") or 100000) / 10,
            "최근3분거래대금": price * (s.get("volume") or 100000) / 3,
            "최근3분평균": price * (s.get("volume") or 100000) / 9,
        }
        try:
            from ai_judge import evaluate_buy_rule_based, evaluate_sell_rule_based, enrich_market_data
            enriched = enrich_market_data(md)
            if entry_price is None:
                is_buy, _r, _sc = evaluate_buy_rule_based(enriched)
                if is_buy:
                    entry_price = price
                    entry_idx = i
            else:
                pos = {"entry_price": entry_price, "highest_return": 1.0,
                       "holding_minutes": (i - entry_idx) * 2}
                decision, _r2 = evaluate_sell_rule_based(enriched, pos)
                if decision in ("수익청산", "손절"):
                    ret = (price - entry_price) / entry_price * 100
                    trades.append({"entry": entry_price, "exit": price, "ret": ret})
                    entry_price = None
        except Exception:
            continue

    if entry_price is not None:
        last = snaps[-1].get("price") or entry_price
        trades.append({"entry": entry_price, "exit": last,
                       "ret": (last - entry_price) / entry_price * 100})

    n = len(trades)
    wins = sum(1 for t in trades if t["ret"] > 0)
    win_rate = wins / n * 100 if n else 0
    total_return = sum(t["ret"] for t in trades) if n else 0
    avg_return = total_return / n if n else 0
    equity, peak, mdd = 0, 0, 0
    for t in trades:
        equity += t["ret"]
        peak = max(peak, equity)
        mdd = max(mdd, peak - equity)
    return {"trade_count": n, "win_rate": round(win_rate, 2),
            "total_return": round(total_return, 2), "max_drawdown": round(mdd, 2),
            "avg_return": round(avg_return, 2)}


def run_backtest_on_snapshots(symbol, params=None):
    """실제 저장된 시세 스냅샷(market_snapshots)으로 신호 재현 백테스트
    - 체결강도/거래대금까지 스냅샷에 저장된 값 사용 (실제 수급 기반)
    """
    if params is None:
        params = random_params()
    else:
        params = fill_default_params(params)
    snaps = db.get_snapshots(symbol=symbol, hours=720*2, limit=50000)  # 최대 60일치
    if len(snaps) < 10:
        return {"symbol": symbol, "trade_count": 0, "note": "스냅샷 부족",
                "win_rate": 0, "total_return": 0, "max_drawdown": 0, "avg_return": 0}
    sim = _simulate_from_snapshots(snaps, params)
    result = {"symbol": symbol, "params": params, "period_days": 14, "note": f"스냅샷 {len(snaps)}개 재현",
              **sim}
    # ★ 재현성: 데이터 수 + 조건 스냅샷 기록
    note_txt = f"스냅샷기반 · {len(snaps)}샘플 | {test_conditions_snapshot()}"
    db.save_backtest_result(params, symbol, 14, sim["trade_count"], sim["win_rate"],
                            sim["total_return"], sim["max_drawdown"], sim["avg_return"],
                            note_txt)
    return result


def run_backtest_on_date(symbols=None, target_date=None, params=None, fast=True):
    """
    ★ 특정 날짜 검산 - 주말/공휴일 자동 제외 (KRX 거래일만)
    - target_date가 비거래일이면 자동으로 이전 거래일로 보정
    - 그날(또는 보정일) 수집된 스냅샷으로 신호 재현
    - fast=True: 종목 3개만, 빠르게 (스냅샷 기반이라 즉시)
    반환: {"date": 보정된 거래일, "requested": 원래 요청일, "is_holiday": bool,
           "symbols": [...], "results": [...], "note": ...}
    """
    from db import is_trading_day, prev_trading_day, now_kst
    import sqlite3
    if target_date is None:
        target_date = now_kst().strftime("%Y-%m-%d")
    if symbols is None:
        # 스냅샷이 있는 종목 우선 (없으면 기본 3종목)
        try:
            conn = sqlite3.connect(db.DB_PATH)
            rows = conn.execute(
                "SELECT DISTINCT symbol FROM market_snapshots WHERE snapshot_time LIKE ? LIMIT 8",
                (target_date + "%",),
            ).fetchall()
            conn.close()
            syms = [r[0] for r in rows]
        except Exception:
            syms = []
        symbols = syms or ["005930", "000660", "035420"]

    requested = target_date
    is_holiday = not is_trading_day(target_date)
    if is_holiday:
        target_date = prev_trading_day(target_date).isoformat()
    note = (f"요청 {requested}(비거래일) → {target_date}(거래일)로 보정"
            if is_holiday else f"{target_date} 거래일")
    if params is None:
        params = random_params()
    else:
        params = fill_default_params(params)

    results = []
    for sym in symbols[:8]:
        try:
            conn = sqlite3.connect(db.DB_PATH)
            rows = conn.execute(
                "SELECT * FROM market_snapshots WHERE symbol=? AND snapshot_time LIKE ? ORDER BY id",
                (sym, target_date + "%"),
            ).fetchall()
            conn.close()
            snaps = [dict(r) for r in rows]
        except Exception:
            snaps = []
        if len(snaps) < 2:
            results.append({"symbol": sym, "trade_count": 0, "note": f"{target_date} 데이터 없음"})
            continue
        sim = _simulate_from_snapshots(snaps, params)
        results.append({"symbol": sym, **sim, "samples": len(snaps)})

    # ★ 재현성: 데이터 커버리지(몇 종목에 데이터 있었는지) + 테스트 조건 스냅샷 기록
    n_with_data = sum(1 for r in results if r.get("samples", 0) >= 2)
    total_samples = sum(r.get("samples", 0) for r in results)
    cov_txt = (f"날짜검산:{target_date} · 데이터 {n_with_data}/{len(results)}종목 "
               f"({total_samples}샘플) | {test_conditions_snapshot()}")
    db.save_backtest_result(params, ",".join(symbols[:3]), 1,
                            sum(r.get("trade_count", 0) for r in results),
                            round(sum(r.get("win_rate", 0) for r in results) / max(1, len(results)), 2),
                            round(sum(r.get("total_return", 0) for r in results), 2),
                            round(max((r.get("max_drawdown", 0) for r in results), default=0), 2),
                            round(sum(r.get("avg_return", 0) for r in results) / max(1, len(results)), 2),
                            cov_txt)
    return {"date": target_date, "requested": requested, "is_holiday": is_holiday,
            "symbols": symbols, "results": results, "note": note,
            "coverage": {"with_data": n_with_data, "total": len(results), "samples": total_samples}}


def validate_prompt_strategy(symbols=None, days=7, min_trades=3):
    """
    ★ 프롬프트 매수 전략 검증 시스템
    - "프롬프트로 실제 매수했던 조건"을 전략으로 삼아
    - 순위 100개 종목의 ★다른 날짜★ 스냅샷에 적용해서 재검증
    - 매수 신호가 나온 종목의 후행 수익률/승률/손익비 집계

    symbols: None이면 (1) 스냅샷 있는 종목 우선 + (2) 순위 100개 (가능 시)
    반환: {summary:{signal_count, win_rate, avg_return, profit_factor, total_pnl},
           results:[{symbol,name,signals,trades,win_rate,avg_return,total_return,pnl}...],
           tested_days:[...], note}
    """
    from db import get_symbol_name, get_snapshots, now_kst

    # 0) 검증 대상 종목 선정: 순위 100개 (실제 키 있으면) + 스냅샷 있는 종목
    if not symbols:
        symbols = []
        # 순위 후보 시도 (거래대금/거래량 상위 합집합)
        try:
            from kiwoom_client import client
            seen = {}
            for rank, sym, name, _v in (client.get_top_trading_value(limit=100) or []):
                seen.setdefault(sym, name)
            for rank, sym, name, _v in (client.get_top_volume(limit=100) or []):
                seen.setdefault(sym, name)
            if seen:
                symbols = list(seen.keys())[:100]
        except Exception:
            pass
        # 순위 실패 시: 스냅샷 존재 종목 (날짜별 파일에서 수집, 코드순 상위 100)
        if not symbols:
            try:
                snaps = get_snapshots(hours=days * 24, limit=100000)
                seen = []
                for s in snaps:
                    if s["symbol"] not in seen:
                        seen.append(s["symbol"])
                    if len(seen) >= 100:
                        break
                symbols = seen
            except Exception:
                symbols = []

    # 1) 각 종목의 최근 days일 스냅샷으로 신호 재현 (프롬프트 rule 판단 = 실제 매수 조건과 동일)
    tested_days = set()
    results = []
    total_signals = 0
    for sym in symbols[:100]:
        snaps = get_snapshots(symbol=sym, hours=days * 24, limit=5000)
        for s in snaps:
            try:
                tested_days.add(s["snapshot_time"][:10])
            except Exception:
                pass
        if len(snaps) < 3:
            continue
        sim = _simulate_from_snapshots(snaps, random_params())  # params는 rule 판단이라 무의미, 내부에서 ai_judge 사용
        results.append({"symbol": sym, "name": get_symbol_name(sym),
                        "signals": sim["trade_count"], **sim})

    # 2) 집계: 매수 신호가 실제로 몇 건 났고, 수익률/승률/손익비
    signal_list = []
    for r in results:
        for _ in range(r["signals"]):
            signal_list.append(r["total_return"] / max(1, r["signals"]))
    n_signal = sum(r["signals"] for r in results)
    n = len(signal_list)
    wins = [x for x in signal_list if x > 0]
    losses = [x for x in signal_list if x <= 0]
    win_rate = len(wins) / n * 100 if n else 0
    avg_return = sum(signal_list) / n if n else 0
    gross_profit = sum(wins)
    gross_loss = abs(sum(losses))
    pf = gross_profit / gross_loss if gross_loss > 0 else (999.0 if gross_profit > 0 else 0)

    results.sort(key=lambda x: -x["total_return"])
    note = (f"전략: 프롬프트 매수 조건 | 검증: 순위 {len(symbols)}개 종목 × 최근 {days}일 "
            f"({len(tested_days)}거래일) 스냅샷 | {test_conditions_snapshot()}" if tested_days else
            f"전략: 프롬프트 매수 조건 | 검증: {len(symbols)}개 종목 (스냅샷 부족) | "
            f"{test_conditions_snapshot()}")
    return {
        "summary": {
            "signal_count": n_signal,
            "win_rate": round(win_rate, 2),
            "avg_return": round(avg_return, 2),
            "profit_factor": round(pf, 2),
            "total_pnl": round(sum(signal_list), 2),
            "symbols_tested": len(results),
            "days_tested": len(tested_days),
        },
        "results": results,
        "tested_days": sorted(tested_days),
        "note": note,
    }
    """여러 전략/종목 모의 백테스트 - 전략 품질 비교"""
    from config import CFG
    symbols = CFG.UNIVERSE[:3]  # 기본 검사 종목 중 3개
    results = []
    for _ in range(5):  # 5개 랜덤 전략
        params = random_params()
        for sym in symbols:
            r = run_backtest(params, symbol=sym, days=60)
            results.append(r)
    results.sort(key=lambda x: -(x["win_rate"] * x["avg_return"]))
    print("=== 모의 백테스트 결과 (상위 5) ===")
    for r in results[:5]:
        print(f"  {r['symbol']} | 거래 {r['trade_count']} | 승률 {r['win_rate']}% | "
              f"수익 {r['total_return']}% | MDD {r['max_drawdown']}%")
    return results


def screening_score(params, symbols=None, days=60, trials=3):
    """
    전략 1개를 여러 종목/시드로 백테스트해서 평균 점수 계산 (스크리닝용).
    점수 = 승률% * 평균수익률% (MDD 페널티 포함) - 못난 전략 걸러내기
    """
    if symbols is None:
        from config import CFG
        symbols = CFG.UNIVERSE
    scores = []
    for sym in symbols:
        for _ in range(trials):
            r = run_backtest(params, symbol=sym, days=days)
            if r["trade_count"] == 0:
                continue
            # 승률이 0이거나 거래 1건이면 낮은 점수
            if r["trade_count"] <= 1:
                continue
            mdd_penalty = 1.0 / (1.0 + r["max_drawdown"] / 10.0)
            s = r["win_rate"] * max(r["avg_return"], -20) * mdd_penalty
            scores.append(s)
    if not scores:
        return 0.0, 0
    return round(sum(scores) / len(scores), 2), len(scores)


def screen_strategies(strategies_with_params, retire_rate=0.4):
    """
    전략 리스트를 백테스트로 스크리닝해 하위 retire_rate%를 폐기 대상으로 표시.
    strategies_with_params: [{"id":.., "params":..}, ...]
    반환: {"keep": [ids], "retire": [ids], "scores": {id: score}}
    """
    scored = []
    for s in strategies_with_params:
        score, n = screening_score(s["params"])
        scored.append({"id": s["id"], "score": score, "trials": n, "params": s["params"]})
    scored.sort(key=lambda x: -x["score"])
    n_retire = max(1, int(len(scored) * retire_rate))
    keep = [s["id"] for s in scored[n_retire:]]
    retire = [s["id"] for s in scored[:n_retire]]
    scores = {s["id"]: s["score"] for s in scored}
    return {"keep": keep, "retire": retire, "scores": scores, "detail": scored}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbol", default=None, help="실데이터 백테스트 종목 (예: 005930)")
    parser.add_argument("--demo", action="store_true", help="모의 백테스트 멀티 실행")
    args = parser.parse_args()

    db.init_db()

    if args.symbol:
        print(f"실데이터 백테스트: {args.symbol}")
        r = run_backtest(symbol=args.symbol, days=60, use_real_data=True)
        print(json.dumps(r, ensure_ascii=False, indent=2))
    elif args.demo:
        demo_backtest_multi()
    else:
        self_test()
