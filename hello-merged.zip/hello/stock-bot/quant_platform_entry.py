"""PyInstaller entry point for StockBotQuant.exe."""
from quant_platform.orchestrator import main

if __name__ == "__main__":
    raise SystemExit(main())
