from __future__ import annotations

import unittest

import realtime_bridge as bridge


class _FakeKiwoom:
    def __init__(self, result):
        self.result = result
        self.calls = []

    def SendOrder(self, *args):
        self.calls.append(args)
        return self.result


class OpenApiSafetyTests(unittest.TestCase):
    def test_order_uses_logged_in_account_and_rejects_error_code(self):
        old_state = dict(bridge._state)
        try:
            fake = _FakeKiwoom(0)
            bridge._state.update({"mode": bridge.MODE_OPENAPI, "connected": True,
                                  "kiwoom": fake, "account": "12345678"})
            result = bridge.order("005930", "buy", 2, 70000)
            self.assertEqual(result["status"], "accepted")
            self.assertEqual(fake.calls[0][2], "12345678")
            self.assertEqual(fake.calls[0][5:7], (2, 70000))

            fake.result = -308
            self.assertIsNone(bridge.order("005930", "sell", 1, 70000))
        finally:
            bridge._state.clear()
            bridge._state.update(old_state)


if __name__ == "__main__":
    unittest.main()
