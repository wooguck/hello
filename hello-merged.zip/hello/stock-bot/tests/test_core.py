from __future__ import annotations

import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path

from quant_platform.backtest import BacktestConfig, BacktestEngine
from quant_platform.conditions import DslError, DslSignal, evaluate, strategy_hash
from quant_platform.data import MarketDataStore
from quant_platform.domain import Bar
from quant_platform.config import load_settings
from quant_platform.validation import revalidate_strategy, walk_forward_splits
from quant_platform.survivors import StrategyEvaluation, select_survivors
from quant_platform.conditions import DslSignal
from quant_platform.live_paper import LivePaperSession
from quant_platform.jobs import JobStatus, LocalJobQueue
from quant_platform.paper import PaperAccount


def bar(day: int, open_price: float, close: float) -> Bar:
    timestamp = datetime(2026, 1, 1, 9) + timedelta(days=day - 1)
    return Bar("005930", "1d", timestamp, open_price, max(open_price, close), min(open_price, close), close, 1000)


class CoreTests(unittest.TestCase):
    def test_dsl_canonical_hash_and_evaluation(self):
        left = {"operator": "AND", "conditions": [
            {"indicator": "close", "comparison": ">", "value": 100},
            {"indicator": "volume", "comparison": ">", "value": {"indicator": "volume_ma", "multiplier": 2}},
        ]}
        right = {"operator": "AND", "conditions": list(reversed(left["conditions"]))}
        self.assertEqual(strategy_hash(left), strategy_hash(right))
        self.assertTrue(evaluate(left, {"close": 105, "volume": 300, "volume_ma": 100}))
        self.assertFalse(evaluate(left, {"close": 99, "volume": 300, "volume_ma": 100}))

        crossing = {"operator": "CROSS_ABOVE", "left": {"indicator": "ma20"}, "right": {"indicator": "ma60"}}
        self.assertTrue(evaluate(crossing, {"ma20": 101, "ma60": 100}, {"ma20": 99, "ma60": 100}))
        self.assertFalse(evaluate(crossing, {"ma20": 99, "ma60": 100}, {"ma20": 98, "ma60": 100}))
        with self.assertRaises(DslError):
            evaluate({"operator": "OR", "conditions": []}, {})

    def test_store_upsert_and_coverage(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "bars.sqlite3"
            with MarketDataStore(path) as store:
                rows = [bar(1, 100, 101), bar(2, 101, 103)]
                self.assertEqual(store.upsert_bars(rows), 2)
                self.assertEqual(store.upsert_bars([bar(1, 100, 102)]), 1)
                fetched = store.get_bars("005930", "1d")
                self.assertEqual(len(fetched), 2)
                self.assertEqual(fetched[0].close, 102)
                self.assertEqual(store.coverage("005930")[0]["bars"], 2)
                self.assertTrue(store.integrity_report("005930").ok)

    def test_indicator_warmup_and_dsl_signal(self):
        rows = [bar(index + 1, 100 + index, 100 + index) for index in range(25)]
        buy = {"indicator": "close", "comparison": ">", "value": {"indicator": "sma_20"}}
        signal = DslSignal(buy=buy)
        self.assertIsNone(signal(0, rows[:1]))
        self.assertEqual(signal(20, rows[:21]), "BUY")

    def test_walk_forward_splits_do_not_overlap(self):
        rows = [bar(index + 1, 100, 100) for index in range(10)]
        splits = walk_forward_splits(rows, train_size=4, test_size=2)
        self.assertEqual(len(splits), 3)
        for split in splits:
            self.assertLess(split.train[-1].timestamp, split.test[0].timestamp)
            self.assertEqual(len(set(split.train) & set(split.test)), 0)

    def test_backtest_uses_next_bar_and_costs(self):
        rows = [bar(1, 100, 100), bar(2, 101, 102), bar(3, 102, 110), bar(4, 115, 115)]
        seen_lengths = []

        def signal(index, history):
            seen_lengths.append((index, len(history)))
            self.assertEqual(index + 1, len(history))
            if index == 0:
                return "BUY"
            if index == 2:
                return "SELL"
            return None

        result = BacktestEngine(BacktestConfig(initial_capital=100_000, commission_pct=0.1, slippage_pct=0)).run(rows, signal)
        self.assertEqual([item[1] for item in seen_lengths], [1, 2, 3, 4])
        self.assertEqual(result.trade_count, 1)
        self.assertGreater(result.total_return_pct, 0)
        buy, sell = result.trades
        self.assertLess(buy.signal_time, buy.execution_time)
        self.assertEqual(sell.execution_time, rows[3].timestamp.isoformat())

    def test_survivor_gate_rejects_weak_walk_forward(self):
        item = StrategyEvaluation("S-test", "hash", 20, 70, 1.5, 5, 10, 90, 0, 0, 80)
        self.assertEqual(select_survivors([item]), tuple())
        passed = StrategyEvaluation("S-pass", "hash2", 10, 60, 1.2, 5, 10, 75, 75, 20, 70)
        self.assertEqual(select_survivors([passed])[0].status, "SURVIVOR")

    def test_revalidation_and_live_paper_use_same_signal_contract(self):
        rows = [bar(index + 1, 100 + index, 100 + index) for index in range(130)]
        condition = {"indicator": "close", "comparison": ">", "value": {"indicator": "sma_20"}}
        result = revalidate_strategy("S-demo", condition, rows, baseline_bars=90, recent_bars=30)
        self.assertIn(result.status, {"KEEP", "WARN", "RETIRED"})
        session = LivePaperSession(DslSignal(buy=condition, sell={"indicator": "close", "comparison": "<", "value": {"indicator": "ema_20"}}))
        for row in rows[-40:]:
            session.on_bar(row)
        self.assertGreaterEqual(session.snapshot().cash, 0)

        with self.assertRaises(ValueError):
            session.on_bar(rows[-1])
        with self.assertRaises(ValueError):
            session.on_bar(Bar("000660", "1d", rows[-1].timestamp + timedelta(days=1),
                               100, 101, 99, 100, 1000))

    def test_local_job_queue_reports_completion(self):
        queue = LocalJobQueue(max_workers=1)
        try:
            job_id = queue.submit(lambda: {"ok": True})
            for _ in range(100):
                job = queue.get(job_id)
                if job and job.status in {JobStatus.COMPLETED, JobStatus.FAILED}:
                    break
                import time
                time.sleep(0.01)
            self.assertIsNotNone(job)
            self.assertEqual(job.status, JobStatus.COMPLETED)
            self.assertEqual(job.result, {"ok": True})
        finally:
            queue.shutdown()

    def test_paper_realized_pnl_includes_entry_and_exit_fees(self):
        account = PaperAccount(1000)
        account.buy(price=100, quantity=5, fee_pct=1)
        pnl = account.sell(price=110, quantity=5, fee_pct=1)
        self.assertAlmostEqual(pnl, 39.5, places=6)
        self.assertAlmostEqual(account.cash, 1039.5, places=6)

    def test_settings_are_safe_by_default_and_hide_secrets(self):
        settings = load_settings({"KIWOOM_APP_SECRET": "do-not-print"})
        self.assertTrue(settings.dry_run)
        self.assertFalse(settings.live_trading_enabled)
        self.assertNotIn("do-not-print", repr(settings))
        with self.assertRaises(RuntimeError):
            load_settings({"ALLOW_LIVE_TRADING": "true", "DRY_RUN": "false",
                           "KIWOOM_USE_MOCK": "false", "KIWOOM_APP_KEY": "only-key"})


if __name__ == "__main__":
    unittest.main()
