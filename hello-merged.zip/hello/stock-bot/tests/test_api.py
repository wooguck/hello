from __future__ import annotations

import unittest

try:
    from fastapi.testclient import TestClient
    _FASTAPI_AVAILABLE = True
except ImportError:
    _FASTAPI_AVAILABLE = False

from quant_platform.api import create_app
from quant_platform.jobs import LocalJobQueue


@unittest.skipUnless(_FASTAPI_AVAILABLE, "optional FastAPI dependencies are not installed")
class ApiTests(unittest.TestCase):
    def test_status_condition_and_job_endpoints(self):
        queue = LocalJobQueue(max_workers=1)
        try:
            client = TestClient(create_app(queue=queue))
            self.assertEqual(client.get("/api/system-status").status_code, 200)
            condition = {"condition": {"indicator": "close", "comparison": ">", "value": 100}}
            response = client.post("/api/conditions/validate", json=condition)
            self.assertEqual(response.status_code, 200)
            self.assertTrue(response.json()["valid"])
            response = client.post("/api/backtests", json={"bars": 40, "candidates": 4})
            self.assertEqual(response.status_code, 200)
            job_id = response.json()["job_id"]
            import time
            for _ in range(200):
                job = client.get(f"/api/backtests/{job_id}").json()
                if job["status"] in {"COMPLETED", "FAILED"}:
                    break
                time.sleep(0.01)
            self.assertEqual(job["status"], "COMPLETED")
        finally:
            queue.shutdown()


if __name__ == "__main__":
    unittest.main()
