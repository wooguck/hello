from __future__ import annotations

import sqlite3
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

from quant_platform.legacy import import_legacy_daily, load_legacy_daily, run_legacy_dsl_backtest


class LegacyBridgeTests(unittest.TestCase):
    def test_imports_existing_stock_db_and_runs_dsl(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            stock_dir = root / "stocks"
            stock_dir.mkdir()
            path = stock_dir / "005930.db"
            conn = sqlite3.connect(path)
            conn.execute("CREATE TABLE daily_bars (bar_date TEXT PRIMARY KEY, open_price REAL, high_price REAL, low_price REAL, close_price REAL, volume REAL, amount REAL, source TEXT)")
            for index in range(45):
                price = 100 + index
                day = date(2026, 1, 1) + timedelta(days=index)
                conn.execute("INSERT INTO daily_bars VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                             (day.isoformat(), price, price + 1, price - 1, price + .5, 1000, 100000, "imported"))
            conn.commit()
            conn.close()
            report = import_legacy_daily(["005930"], stock_dir=stock_dir, database_path=root / "canonical.db")
            self.assertTrue(report["quality_ok"])
            self.assertEqual(report["imported"], 45)
            self.assertEqual(len(load_legacy_daily("005930", stock_dir)), 45)
            result = run_legacy_dsl_backtest("005930", stock_dir=stock_dir, database_path=root / "canonical.db")
            self.assertEqual(result.initial_capital, 1_000_000)
            self.assertGreaterEqual(result.trade_count, 0)


if __name__ == "__main__":
    unittest.main()
