from __future__ import annotations

import unittest
from unittest.mock import patch

import requests

import ai_consult


class AiFallbackTests(unittest.TestCase):
    def test_gemini_timeout_returns_rule_review(self):
        old_provider = ai_consult.CFG.AI_PROVIDER
        old_key = ai_consult.CFG.GEMINI_API_KEY
        ai_consult.CFG.AI_PROVIDER = "gemini"
        ai_consult.CFG.GEMINI_API_KEY = "test-placeholder"
        ai_consult._aj._AI_COOLDOWN.update({"until": 0.0, "last_err": "", "logged": False})
        try:
            with patch.object(ai_consult.requests, "post", side_effect=requests.exceptions.Timeout("simulated")):
                result = ai_consult.review_prompts("매수 기준", "매도 기준")
            self.assertIn("규칙 폴백 검토", result)
            self.assertNotIn("read timeout", result.lower())
        finally:
            ai_consult.CFG.AI_PROVIDER = old_provider
            ai_consult.CFG.GEMINI_API_KEY = old_key
            ai_consult._aj._AI_COOLDOWN.update({"until": 0.0, "last_err": "", "logged": False})

    def test_llm_cannot_bypass_buy_and_sell_safety_gates(self):
        import ai_judge

        old = (ai_judge.AI_ENABLED, ai_judge.PROVIDER, ai_judge.GEMINI_API_KEY)
        ai_judge.AI_ENABLED = True
        ai_judge.PROVIDER = "gemini"
        ai_judge.GEMINI_API_KEY = "test-placeholder"
        try:
            with patch.object(ai_judge, "call_llm", return_value="매수: 지금 진입"):
                ok, reason = ai_judge.evaluate_buy(
                    "005930",
                    {"price": 100, "전일고가": 200, "전일저가": 100,
                     "전일종가": 200, "저가": 100, "중심선아래약세": True},
                    params={"buy_score_threshold": 1, "chegyul_threshold": 999},
                )
            self.assertFalse(ok)
            self.assertIn("매수금지", reason)

            with patch.object(ai_judge, "call_llm", return_value="수익청산: 지금"):
                decision, reason = ai_judge.evaluate_sell(
                    "005930", {"price": 100.1},
                    {"entry_price": 100, "stop_price": 100.5, "highest_return": 0},
                )
            self.assertEqual(decision, "손절")
            self.assertIn("손절가", reason)

            # 일반 규칙이 지지선 이탈로 손절을 결정한 경우에도
            # LLM의 "보유" 응답이 규칙 손절을 무효화하지 않아야 합니다.
            with patch.object(ai_judge, "call_llm", return_value="보유: 아직 관찰"):
                decision, reason = ai_judge.evaluate_sell(
                    "005930", {"price": 99, "전일저가": 100},
                    {"entry_price": 100, "highest_return": 0},
                )
            self.assertEqual(decision, "손절")
        finally:
            ai_judge.AI_ENABLED, ai_judge.PROVIDER, ai_judge.GEMINI_API_KEY = old


if __name__ == "__main__":
    unittest.main()
