@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] New 64-bit Python environment not found:
    echo %CD%\.venv\Scripts\python.exe
    pause
    exit /b 1
)

".venv\Scripts\python.exe" -m quant_platform.gui
if errorlevel 1 (
    echo [ERROR] GUI failed to start. Check errors\latest.json if present.
    pause
)
