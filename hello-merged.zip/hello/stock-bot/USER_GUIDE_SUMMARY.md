# 📘 키움 AI 자동매매 — 설치·사용 요약 (대화 정리본)

> 이 문서는 대화 전체를 정리한 것입니다. 설치 파일 목록 + 사용법 + 핵심 구조만 남겼습니다.

---

## 📦 설치 파일 목록 (Desktop\rest 폴더)

### 실행 파일 (.py)
| 파일 | 역할 |
|---|---|
| **desktop_app.py** | 메인 앱 (Tkinter 대시보드 9탭) — 자동파일럿 자동 시작 |
| **collect_data.py** | 데이터 수집기 (일봉 전 종목 → 분봉 → 지수 → 자동 검증) |
| **web_status.py** | 웹 대시보드 (http://localhost:8000, 13카드) |
| **verify_final.py** | 자가진단 (26항목 E2E) |
| **live_trader.py** | 실시간 트레이더 (OpenAPI+ 영웅문, 실시간 매수/매도) |
| **scalp.py** | 장초반 스캘핑 (09:00~09:40, 1분 주기) |
| **surge_mining.py** | 🧬 급등 유전자 발굴 (급등 직전 공통 조건 → 검색식 자동 등록) |
| **validation.py** | 🎯 엄밀 검증 (지수대비+무작위 대조군+등급) |
| **value_watch.py** | 💎 저평가 주식 추적 (PER/ROE → 관찰 → 회복 판정) |
| **fundamentals.py** | 📊 펀더멘털 (영웅문 opt10001 우선 → 네이버 폴백) |
| **import_parquet.py** | 📦 parquet(2800종목 4~5GB) → 우리 DB 변환 |
| **set_env_keys.py** | 🔑 cmd에서 키 입력 → .env 자동 생성 |
| **cleanup_old.py** | 🧹 구버전 가상 기록 정리 |
| **db.py / config.py / teams.py / engine.py / paper_test.py / ai_judge.py / ai_consult.py / backfill_history.py / screener.py / condition_manager.py / photo_conditions.py / strategy*.py / charting.py / daily_report.py / universe.py / kiwoom_client.py / leader.py / realtime_bridge.py / auto_pilot.py / backtest.py / genetic.py** | 시스템 코어 |

### 배치 파일 (.bat — 전부 영문·한글 깨짐 없음)
| 파일 | 역할 |
|---|---|
| **setup_new_pc.bat** | 새 PC 원클릭 설치 (파이썬 확인→pip→.env 생성→검증) |
| **run_all.bat** | 데이터 수집 + 앱 실행 |
| **install_base.bat** | 기본 패키지 설치 |
| **install_live.bat** | 실시간(OpenAPI+) 패키지 설치 |
| **verify.bat** | 자가진단 |
| **collect_once.bat** | 데이터 수집 1회 |
| **collect_watch.bat** | 매일 장마감 자동 수집 (켜두기) |
| **start_app.bat** | 앱 실행 |
| **status_server.bat** | 웹 대시보드 켜기 |

---

## 🚀 설치 순서 (새 PC)

```
1. 폴더 전체를 원하는 프로젝트 폴더에 복사
2. setup_new_pc.bat  (더블클릭 - 설치+검증)
3. python set_env_keys.py  (키 4개 입력 - .env 자동 생성)
4. run_all.bat  (데이터 수집 + 앱)
```

### 실시간 모드 (선택)
```
pip install pykiwoom PyQt5
→ 영웅문 실행 + 로그인
→ python live_trader.py --selftest  (⚡ 실시간 확인)
→ 앱에서 ⚡ 실시간 모드 버튼
```

### parquet 데이터 활용 (있으면)
```
python import_parquet.py --file C:/data/all.parquet
python import_parquet.py --dir C:/parquet폴더
```
→ 몇 분 안에 전 종목 일봉 로드 (네이버 백필 1~3시간 대체)

---

## ⚙️ 핵심 설정 (.env)

```
KIWOOM_USE_MOCK=true        # 모의투자 서버
DRY_RUN=false               # false=실제 모의주문 / true=주문생략(안전)
KIWOOM_APP_KEY=모의용_앱키   # ★ 실전 키 아님!
KIWOOM_APP_SECRET=모의용_시크릿
KIWOOM_ACCOUNT_NO=모의계좌번호
GEMINI_API_KEY=발급받은_키 # AI 판단용
INDEX_ENABLED=false         # 지수 필터 해제 (모의 단계 - 하락장도 전부 매수)
MINUTE_ALL=false            # 분봉: 관심 종목만 (전 종목은 true - 수 GB)
LEADER_ENABLED=true         # 대장주 공략
```

---

## 🤖 자동화 루프 (앱 켜두면 전부 자동)

```
[장중] 09:00~09:40 스캘핑(1분) → 09:40~15:30 모의매매(3분)
[장마감/휴장] 총괄 라운드:
   ① 자료수집(일봉+분봉+지수) ② 조건식 검증·변형
   ③ 모의매매 ④ 엄밀 검증(5라운드) ⑤ 다음날 모의투자 예약
   ⑥ 🧬 급등 유전자 발굴→검색식 등록(10라운드) ⑦ 💎 저평가 추적
   ⑧ 일일 리포트 ⑨ 명예의 전당
```

---

## 🖥 웹 대시보드 (크롬)

```
python desktop_app.py  (앱 - 서버 자동 시작)
→ 크롬에서 localhost:8000
```
13개 카드: 접속설정·데이터수집·명예의전당·모듈상태·엄밀검증등급·봉기준·
지수×시간대·펀더멘털·저평가·급등유전자·주요설정·자동파일럿·파일

---

## ⚠️ 주의사항

- **키는 모의용!** 실전 키 넣으면 실전 주문 나감 (KIWOOM_USE_MOCK=true 유지)
- **.env는 절대 공유 금지** (계좌/키 정보)
- parquet 사용 시: 컬럼명 다르면 `--map date=일자,symbol=종목코드` 로 지정
- AnySign/공인인증서로 .env가 열리면 → `python set_env_keys.py` 사용 (메모장 안 거침)
