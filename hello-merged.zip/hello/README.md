# 키움 퀀트 연구 플랫폼

키움증권 REST API를 중심으로 시장 데이터 수집, 조건식 연구, 백테스트, 검증,
모의투자를 단계적으로 연결하는 프로젝트입니다. 기존 `stock-bot/` 데스크톱 앱을
보존하면서 검증 가능한 코어를 먼저 추가했습니다.

> **범위:** 주식/퀀트 연구 플랫폼만 포함합니다. 숏폼·영상 생성 기능은 포함하지 않습니다.

## 현재 구조

- `stock-bot/`: ZIP에서 복원한 기존 키움 자동매매 데스크톱 앱
- `stock-bot/quant_platform/`: 새 확장 코어
  - 공통 KST `Bar`/`Quote` 도메인 모델
  - SQLite canonical 시장 데이터 저장소와 Parquet export hook
  - 데이터 품질 보고서
  - 키움 REST adapter 경계(공식 TR 스키마를 확인하지 않고 추측하지 않음)
  - JSON/AST 조건식 DSL 및 전략 hash
  - `t` 신호 → `t+1` 시가 체결 규칙을 지키는 백테스트 코어
  - 랜덤 기간·Monte Carlo·Walk-forward·신규 데이터 재검증
  - Paper ledger·실시간 봉 단위 Paper session
  - 선택적 FastAPI job API(실제 주문 endpoint 없음)
- `stock-bot/tests/`: 코어 회귀 테스트
- `.github/workflows/ci.yml`: GitHub에서 비밀키 없이 실행하는 CI
- `docs/PHASE_STATUS.md`: 단계별 완료/남은 작업 기록

## 실행

### 기존 데스크톱 앱

Windows에서 다음 순서로 실행합니다.

```bat
cd stock-bot
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy env.example .env
python desktop_app.py
```

처음에는 반드시 `.env`에서 `DRY_RUN=true`, `KIWOOM_USE_MOCK=true`로 시작하세요.
`.env`, 계좌번호, API 키, DB/시세 데이터는 GitHub에 올리지 않습니다.

### 새 코어 테스트

```bash
cd stock-bot
python -m unittest discover -s tests -v
python -m compileall -q quant_platform
```

## 개발 원칙

1. 실제 API 문서와 응답을 확인한 뒤 adapter를 구현합니다. 존재하지 않는 TR/필드를 추측하지 않습니다.
2. 원천 데이터와 계산 데이터를 분리합니다.
3. 백테스트/모의투자에서 동일한 조건식 AST와 체결 규칙을 사용합니다.
4. 미래 데이터 누출, 수수료, 슬리피지, 데이터 품질 오류를 테스트로 차단합니다.
5. 수익률만으로 전략을 선별하지 않고 표본 수, MDD, Profit Factor, OOS,
   Walk-forward, 랜덤 기간 검증을 함께 적용합니다.
6. 실전 주문은 기본적으로 차단하며, 모의투자와 충분한 검증 전에는 활성화하지 않습니다.

## 참고자료 반영

MoneyPrinterTurbo의 영상 생성 기능은 제외하고, 단계별 구현·테스트·작업 상태 기록이라는
개발 방식만 참고합니다. 이 저장소의 제품 기능은 키움 기반 주식 퀀트 연구와 모의투자입니다.
