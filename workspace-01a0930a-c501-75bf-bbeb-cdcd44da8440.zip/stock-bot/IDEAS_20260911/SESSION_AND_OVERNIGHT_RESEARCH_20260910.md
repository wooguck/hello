# Session and overnight research — 2026-09-10

## Questions answered by the event study

The full run now separately measures:

```text
시초 0~5분
시초 5~15분
오전 15~60분
오전 이후/점심
오후
종가 전 30분
```

For each time bucket and horizon, it records:

```text
5/15/30/60 one-minute bars forward
net return after commission/slippage
win rate
expectancy
payoff ratio
profit factor
p05/CVaR-like tail loss
best/worst event
sample count
```

## Overnight / 종배

The scanner separately measures:

```text
previous close -> next open
after next open -> next 5/15/30/60 bars
previous close -> next close
```

This separates three different effects:

```text
overnight gap
morning continuation/reversal
full next-day carry
```

They must not be merged into one “overnight success rate.”

## Interpretation rules

A high opening win rate is not enough. The final comparison must include:

```text
expectancy
payoff ratio
profit factor
tail loss
sample size
slippage sensitivity
symbol concentration
year/regime stability
```

The event study does not modify the sealed OOS candidate selection. It is diagnostic until a time-window rule is pre-registered and independently validated.

## Current limitations

- scanner uses imported 1-minute bars; actual 5m/15m resampling needs its own quality gate
- event study is not a portfolio simulation
- index regime and sector context are not yet included
- time bucket discovery cannot be selected after looking at OOS
