# StockBot 연구·AI 분석 발전 순서와 기준

작성일: 2026-09-10
목적: 현재 가능한 기능은 즉시 적용하고, 데이터 연동이 필요한 기능은 순서와 승인 기준을 정해 단계적으로 추가한다.

## 0. 전체 원칙

```text
관찰 가능성
→ 데이터 품질
→ 후보 발견
→ validation
→ 비용·체결 stress
→ sealed OOS
→ paper/shadow
→ 수동 승인
```

AI 분석 결과나 validation 1위 결과를 바로 live 주문으로 편입하지 않는다.

현재 안전 상태:

```text
orders_submitted=0
source CSV read-only
canonical DB read-only during research
automatic live promotion=false
```

## 1. 지금 즉시 적용하는 핵심 기능

### 1.1 한 번 실행·진행 관찰

사용자는 다음 하나만 실행한다.

```text
RUN_ONE_CLICK_FULL_AUTO_20260910.bat
```

동시에 다음을 제공한다.

- desktop UI
- 브라우저 상태판 `http://127.0.0.1:8010`
- 단계별 상태
- 603개 종목 진행률
- 10개 종목 단위 checkpoint
- 후보 중간 상위 5개
- 최종 validation 상위 5개
- 중복 실행 lock

### 1.2 현재 Full Auto 순서

```text
Data Gate
→ Session/O​​vernight diagnostic
→ Candidate Evolution
→ 상위 후보·checkpoint
→ Exit Policy
→ Entry Timing
→ sealed OOS
→ Final Summary
```

### 1.3 현재 후보·policy 기준

- 최대 candidate 400개
- validation top-k 20
- 화면 표시 상위 5개
- exit policy 37개
- entry timing 5개
- worker 4개 bounded parallelism
- 수수료·슬리피지 포함
- MFE/MAE·capture 진단
- 거래 수·기대값·PF·payoff·MDD·tail loss 확인

## 2. 현재 연구가 끝난 뒤 바로 추가할 우선 기능

### P0. Opening Edge 별도 트랙

시초 상승 종목을 무조건 매수하지 않고, 기존 Session/O​​vernight 결과에서 다음을 별도로 검증한다.

```text
전일 종가·추세·거래대금
overnight gap/뉴스가 확인된 경우
시초 1·5·15·30분 수익률
opening range 돌파
초기 급등 후 pullback
```

비교할 진입 방식:

```text
시초 즉시 진입
5분 opening range 확인 후 진입
15분 opening range 확인 후 진입
초기 급등 후 pullback limit
```

기준:

- 시초 전 정보만 사용한 신호와 시초 이후 확정된 신호를 분리
- 시초 1분봉의 종가를 시초 체결 가격에 사용하지 않음
- 수수료·슬리피지·spread·급등 추격 비용 포함
- 1·5·15·30분 수익률과 MFE/MAE 비교
- 최소 표본 30개 이상
- 상승장·하락장·횡보장 분리
- 단순 시초 매수보다 기대값·MDD·거래 수가 개선되는지 확인

시초 트랙이 validation에서 양수여도 전체 전략에 자동 승격하지 않고, 기존 baseline과 별도 비교한다.

### P1. 상위 후보 5개에 대한 policy screening

현재는 Evolution 상위 후보를 표시하고, 기본 policy 단계는 우선순위가 가장 높은 후보를 중심으로 실행한다.

개선 순서:

```text
상위 5개 후보
→ 대표 exit policy 빠른 screening
→ 안정적인 상위 1~2개 선별
→ 1~2개에 37개 exit policy와 5개 timing 상세 비교
→ 최종 1개만 OOS
```

기준:

- 표본 수 최소 30 거래
- 비용 후 기대값 양수
- Profit Factor 기준 통과
- positive symbol rate 50% 이상
- MDD 허용 범위 이내
- 기간·종목별 순위 안정성

### P2. local fine tuning

coarse search의 1위 숫자 하나를 바로 채택하지 않고, 상위 policy 주변만 validation에서 추가 탐색한다.

예:

```text
SL 2.0% 주변: 1.5%, 1.75%, 2.0%, 2.25%, 2.5%
TP 5.0% 주변: 4%, 4.5%, 5%, 5.5%, 6%
pullback 0.7% 주변: 0.3%, 0.5%, 0.7%, 1.0%, 1.2%
wait: 3, 5, 10, 15 bars
```

기준:

- 상위 후보 3~5개에만 적용
- 전체 candidate×전체 조합으로 확장하지 않음
- 주변 조합도 성능이 좋은 plateau인지 확인
- OOS를 본 뒤 수치를 변경하지 않음

### P3. standalone strategy backtest

사용자가 특정 종목·ETF·지수와 전략을 직접 지정하는 기능을 추가한다.

출력:

- 거래 횟수
- 승률
- 평균 수익·손실
- payoff ratio
- profit factor
- 누적수익률
- CAGR
- MDD
- 단순 보유 benchmark
- 시장 국면별 성능
- 약점과 개선 3가지

필수 조건:

- 조정주가·배당·분할 처리 여부 기록
- 수수료·슬리피지 포함
- 신호 시점과 체결 시점 분리
- 단순 보유와 같은 기간 비교
- 최소 표본과 신뢰구간 표시

## 3. 데이터가 추가로 필요한 AI 모듈

### P4. AI 기술적 분석가

현재 일봉·분봉 데이터로 일부 가능하다.

```text
일봉·주봉
지지·저항
20·60·120·200일선
거래량
RSI
MACD
고점·저점
분할매수·보유·비중축소·관망
```

단, 주봉 이력과 MACD·조정 데이터가 확인된 경우에만 사용한다.

### P5. 뉴스·공시 영향 분석기

최신 뉴스·공시 원문과 날짜별 출처가 필요하다.

```text
사실
→ 매출 영향
→ 영업이익 영향
→ 성장성 영향
→ 단기·장기 주가 영향
→ 강한 호재~강한 악재
```

루머·출처 없는 내용은 제외한다.

### P6. 돈 몰리는 종목 스크리너

전체 KOSPI·KOSDAQ universe에 대해 다음 데이터가 필요하다.

- 거래대금 증가
- 외국인·기관 수급
- 실적
- 공시·뉴스
- 모멘텀
- 유동성
- 급등 추격 위험

### P7. 오늘의 투자 계획

금리·환율·경제 일정·실적·뉴스·수급을 장 시작 전·장중·장 마감으로 나누어 표시한다.

현재 시스템의 분봉 분석과 연결하되, 데이터 timestamp가 늦으면 `STALE_DATA`로 표시한다.

### P8. 포트폴리오 리스크 매니저

사용자 입력이 필요하다.

```text
종목
평균단가
비중
현금
통화
```

출력:

- 집중도
- 섹터·종목 상관관계
- 성장주 편중
- 환율 위험
- -10%·-20%·-30% stress
- 리밸런싱 제안

### P9. 매매일지 AI 코치

최근 20건의 거래 기록이 필요하다.

```text
종목
진입가
청산가
수익률
매수 이유
```

출력:

- 추격매수
- 물타기
- 늦은 손절
- 빠른 익절
- FOMO
- 확증편향
- 수익·손실 거래 차이
- 개인 원칙 5개

## 4. 최종 판정 기준

### Keep 후보

```text
validation·OOS 모두 비용 후 기대값 양수
거래 수 충분
PF·payoff 기준 통과
MDD 허용 범위
여러 종목·기간에서 재현
주변 policy도 유사한 성능
체결 stress 후에도 붕괴하지 않음
```

### Warn

```text
평균 수익은 양수지만 표본 부족
특정 종목 또는 기간에 집중
pullback 체결률 stress에서 약함
OOS가 validation보다 크게 악화
```

### Blocked

```text
데이터 gate 실패
OOS trade count 부족
비용 후 기대값 음수
MDD 초과
positive symbol rate 기준 미달
체결 현실성 부족
```

## 5. 사용자에게 보여줄 순서

기본 화면:

```text
1. 현재 단계
2. 전체 진행률
3. 후보 상위 5개
4. policy 상위 결과
5. OOS 결과
6. 최종 결론
```

세부 화면:

```text
후보 전체
policy 전체
TP 3%·TP 5% 필터
entry timing
MFE/MAE
session diagnostic
```

## 6. 개발 원칙

현재 Full Auto를 한 번에 모든 AI 모듈로 무겁게 만들지 않는다.

```text
현재 가능한 연구·관찰성 먼저 안정화
→ 상위 후보 policy screening
→ local fine tuning
→ standalone backtest
→ 뉴스·수급·포트폴리오·일지 모듈
→ paper/shadow
```

각 모듈은 독립적으로 실패할 수 있어야 하며, 뉴스·수급 데이터가 없다고 기술적 연구 전체가 임의의 값으로 진행되면 안 된다.
