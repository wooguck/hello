# StockBot 아이디어·연구 기준

운영 package와 분리한 아이디어/연구 기준 문서입니다.

- `TRADING_IDEA_GENERATOR_STANDARD_20260910.md`
- `RESEARCH_ROADMAP_AND_CRITERIA_20260910.md`
- `SESSION_AND_OVERNIGHT_RESEARCH_20260910.md`

이 문서들은 연구 아이디어와 검증 기준을 정의하지만 live 주문이나 자동 전략 승격을 수행하지 않습니다.
