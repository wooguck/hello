# Deep Validation Report

검증일: 2026-09-05 (KST)

## 판정

```text
연구·검증 코어: PASS
실거래 승인: 불가
외부 영웅문 재무·수급·실시간 snapshot: PENDING_EXTERNAL_SNAPSHOT
```

## 반복 테스트

```text
pytest run 1: 56 passed, 1 skipped
pytest run 2: 56 passed, 1 skipped
pytest run 3: 56 passed, 1 skipped
```

skip:

```text
tests/test_api.py:17
optional FastAPI dependencies are not installed
```

## 정적·실행 검증

```text
compileall: PASS
OPENAPI_BACKFILL_COLLECTOR.py syntax: PASS
demo pipeline: PASS
hero-coverage command: PASS
Shadow 005930: PENDING_DATA (daily 70, intraday 0, broker orders 0)
safety audit: PASS 4 / WARN 11 / FAIL 0
safe_to_order: false
```

## 기술지표 불변성 검사

합성 OHLCV 테스트 봉 240개로 다음을 확인했습니다.

- RSI는 0~100 범위
- Stochastic은 0~100 범위
- Williams %R은 -100~0 범위
- MFI는 0~100 범위
- ADX는 0~100 범위
- Bollinger/Envelope/Keltner 상·중·하단 순서
- NaN/무한대 미발생
- 미래 봉을 뒤에 추가해도 과거 feature가 변하지 않음(prefix invariance)

```text
INDICATOR_INVARIANT_CHECK_OK
```

## 영웅문 조건검색 커버리지

```text
OHLCV 기술 조건 구현: 24개
외부 snapshot 필요: 5개
기술 조건 미구현: 0개
```

외부 snapshot이 필요한 범위는 재무, 외국인·기관, 공매도·신용, 뉴스·테마, 영웅문 실시간 조건 편입입니다. 이 범위는 로컬 데이터만으로 PASS 처리하지 않습니다.

## 안전 판정

- 실제 주문 endpoint 호출 없음
- Shadow broker 주문 0건
- 실제 API 키 없이 REST 수집 성공으로 표시하지 않음
- 원본 CSV를 수정하지 않음
- exact duplicate만 명시적 옵션에서 dedupe
- OHLCV 충돌은 conflict log에 보존
- 미래 label은 실시간 feature에서 제외해야 함
